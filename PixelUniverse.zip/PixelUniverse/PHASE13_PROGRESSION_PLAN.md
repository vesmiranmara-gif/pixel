# 🚀 PHASE 13: Progression Systems - Implementation Plan

## 📋 Overview

**Goal**: Implement comprehensive player progression with leveling, skills, ship upgrades, and reputation systems

**Estimated**: ~1,500-2,000 lines of code
**Time**: 4-6 hours
**Priority**: HIGH

---

## 🎯 Core Systems

### **1. Player Leveling System** ⭐
- Experience points (XP) from combat, exploration, trading, missions
- Level progression (1-50)
- XP requirements scale exponentially
- Level-up rewards (credits, skill points, unlocks)
- Visual level-up notification

### **2. Skill Tree System** 🌳
- Multiple skill categories:
  - **Combat**: Weapon damage, fire rate, accuracy
  - **Defense**: Shield capacity, armor, regeneration
  - **Engineering**: Engine power, energy efficiency, repair speed
  - **Piloting**: Maneuverability, speed, evasion
  - **Trading**: Better prices, cargo capacity, market intel
  - **Exploration**: Sensor range, fuel efficiency, discovery bonuses
- Skill points earned per level
- Prerequisites for advanced skills
- Respec option (with cost)

### **3. Ship Upgrade System** 🔧
- Upgradeable components:
  - **Weapons**: Damage, fire rate, heat dissipation
  - **Shields**: Capacity, regeneration rate, resistance
  - **Engines**: Speed, acceleration, fuel efficiency
  - **Hull**: Armor, integrity, repair systems
  - **Sensors**: Range, accuracy, targeting
  - **Cargo**: Capacity, organization, protection
- Upgrade tiers (I, II, III, IV, V)
- Credit costs scale with tier
- Installation time/requirements
- Visual changes for upgraded components

### **4. Reputation System** 🏆
- Multiple factions:
  - **United Earth Fleet**: Military, law enforcement
  - **Free Traders Guild**: Merchants, smugglers
  - **Explorer's Society**: Scientists, adventurers
  - **Pirate Clans**: Outlaws, raiders
  - **Corporate Syndicate**: Mega-corporations
- Reputation levels: Hostile → Unfriendly → Neutral → Friendly → Allied → Honored
- Reputation affects:
  - Mission availability
  - Shop prices
  - NPC behavior
  - Access to restricted areas
- Actions affect reputation (combat, trading, missions)

### **5. Achievement System** 🏅
- Tracked achievements:
  - Combat (kills, damage, survival)
  - Exploration (distance, discoveries, planets visited)
  - Trading (profit, deals, rare items)
  - Missions (completed, success rate, difficulty)
  - Special (secrets, easter eggs, challenges)
- Achievement rewards (titles, credits, unlocks)
- Progress tracking
- Achievement notifications

---

## 📁 Files to Create

### **New Files**:
1. `js/systems/progression.js` (~400 lines) - Player leveling and XP
2. `js/systems/skillTree.js` (~500 lines) - Skill system
3. `js/systems/upgrades.js` (~400 lines) - Ship upgrade system
4. `js/systems/reputation.js` (~300 lines) - Faction reputation
5. `js/systems/achievements.js` (~300 lines) - Achievement tracking
6. `js/ui/progressionUI.js` (~400 lines) - UI for progression systems

### **Files to Modify**:
1. `js/main.js` - Initialize progression systems
2. `js/ui/cockpit.js` - Add level/XP display
3. `index.html` - Add new script tags

---

## 🎮 Implementation Steps

### **Step 1: Player Leveling System** (Priority: HIGH)

#### **Features**:
- XP tracking and accumulation
- Level calculation (exponential curve)
- Level-up detection and rewards
- XP sources (combat, exploration, trading, missions)
- Persistent storage (save/load)

#### **XP Formula**:
```javascript
XP_Required(level) = 100 * (level ^ 1.5)
// Level 1→2: 100 XP
// Level 2→3: 283 XP
// Level 5→6: 1,118 XP
// Level 10→11: 3,162 XP
// Level 20→21: 8,944 XP
```

#### **XP Sources**:
- Enemy kill: 10-100 XP (based on enemy type)
- Mission complete: 50-500 XP (based on difficulty)
- Discovery: 25-200 XP (planets, stations, secrets)
- Trade: 1-10 XP per 1000 credits profit
- Survival: 5 XP per minute

#### **Level-Up Rewards**:
- Credits: 100 * level
- Skill points: 1-3 (based on level milestones)
- Unlocks: New ships, weapons, areas (at specific levels)

---

### **Step 2: Skill Tree System** (Priority: HIGH)

#### **Skill Categories** (6 trees):

**Combat Tree** (15 skills):
- Weapon Damage I-V (+10% per level)
- Fire Rate I-V (+8% per level)
- Critical Hit I-III (+5% crit chance per level)
- Weapon Heat I-III (-15% heat per level)
- Multi-Target I-II (hit multiple enemies)

**Defense Tree** (15 skills):
- Shield Capacity I-V (+20% per level)
- Shield Regen I-V (+15% per level)
- Armor I-V (+10% damage reduction per level)
- Emergency Shield I-II (auto-activate at low health)
- Damage Resistance I-III (-5% damage per level)

**Engineering Tree** (15 skills):
- Engine Power I-V (+12% speed per level)
- Energy Efficiency I-V (-10% energy cost per level)
- Repair Speed I-V (+20% repair rate per level)
- Auto-Repair I-III (passive hull repair)
- Overcharge I-II (temporary power boost)

**Piloting Tree** (15 skills):
- Maneuverability I-V (+15% turn rate per level)
- Acceleration I-V (+12% acceleration per level)
- Evasion I-V (+8% dodge chance per level)
- Afterburner I-III (speed boost ability)
- Precision I-III (+10% accuracy per level)

**Trading Tree** (12 skills):
- Negotiation I-V (+5% better prices per level)
- Cargo Capacity I-V (+20% capacity per level)
- Market Intel I-III (see price trends)
- Smuggling I-II (avoid scans)

**Exploration Tree** (12 skills):
- Sensor Range I-V (+25% range per level)
- Fuel Efficiency I-V (-15% fuel use per level)
- Discovery Bonus I-V (+20% XP from discoveries)
- Scanner I-III (detect hidden objects)

#### **Skill Point Allocation**:
- 1 skill point per level (levels 1-50)
- Bonus points at milestones (levels 10, 20, 30, 40, 50)
- Total available: 55 skill points at max level
- Total skills: 84 skills (can't max everything - choices matter)

---

### **Step 3: Ship Upgrade System** (Priority: MEDIUM)

#### **Upgradeable Components**:

**Weapons** (5 tiers):
- Tier I: +10% damage, +5% fire rate (500 credits)
- Tier II: +25% damage, +12% fire rate (2,000 credits)
- Tier III: +45% damage, +20% fire rate (5,000 credits)
- Tier IV: +70% damage, +30% fire rate (12,000 credits)
- Tier V: +100% damage, +45% fire rate (25,000 credits)

**Shields** (5 tiers):
- Tier I: +20% capacity, +10% regen (600 credits)
- Tier II: +45% capacity, +25% regen (2,500 credits)
- Tier III: +75% capacity, +45% regen (6,000 credits)
- Tier IV: +110% capacity, +70% regen (14,000 credits)
- Tier V: +150% capacity, +100% regen (30,000 credits)

**Engines** (5 tiers):
- Tier I: +15% speed, +10% acceleration (700 credits)
- Tier II: +35% speed, +25% acceleration (3,000 credits)
- Tier III: +60% speed, +45% acceleration (7,000 credits)
- Tier IV: +90% speed, +70% acceleration (16,000 credits)
- Tier V: +125% speed, +100% acceleration (35,000 credits)

**Hull** (5 tiers):
- Tier I: +25% armor, +10% integrity (800 credits)
- Tier II: +55% armor, +25% integrity (3,500 credits)
- Tier III: +90% armor, +45% integrity (8,000 credits)
- Tier IV: +130% armor, +70% integrity (18,000 credits)
- Tier V: +175% armor, +100% integrity (40,000 credits)

#### **Upgrade Requirements**:
- Credits (cost)
- Player level (minimum level for each tier)
- Reputation (some upgrades require faction standing)
- Time (instant for now, could add installation time)

---

### **Step 4: Reputation System** (Priority: MEDIUM)

#### **Factions** (5 major factions):

**United Earth Fleet**:
- Military and law enforcement
- Gain: Kill pirates, complete military missions
- Lose: Attack civilians, smuggling, piracy
- Benefits: Military contracts, better weapons, safe passage

**Free Traders Guild**:
- Merchants and traders
- Gain: Trading, delivery missions, market activity
- Lose: Piracy, attacking traders
- Benefits: Better prices, trade routes, cargo upgrades

**Explorer's Society**:
- Scientists and adventurers
- Gain: Discoveries, exploration missions, scanning
- Lose: Destroying natural phenomena
- Benefits: Exploration bonuses, sensor upgrades, data sales

**Pirate Clans**:
- Outlaws and raiders
- Gain: Piracy, smuggling, attacking convoys
- Lose: Helping authorities, killing pirates
- Benefits: Black market access, stolen goods, hideouts

**Corporate Syndicate**:
- Mega-corporations
- Gain: Corporate missions, resource delivery
- Lose: Attacking corporate ships
- Benefits: High-paying contracts, advanced tech, investments

#### **Reputation Levels**:
- **Hostile** (-1000 to -500): Attacked on sight
- **Unfriendly** (-500 to -100): No services, high prices
- **Neutral** (-100 to +100): Standard services
- **Friendly** (+100 to +500): Discounts, better missions
- **Allied** (+500 to +1000): Special missions, rare items
- **Honored** (+1000+): Unique rewards, faction ships

---

### **Step 5: Achievement System** (Priority: LOW)

#### **Achievement Categories**:

**Combat Achievements** (20 achievements):
- First Blood (first kill)
- Ace Pilot (10 kills)
- Squadron Buster (50 kills)
- Fleet Destroyer (100 kills)
- Legendary Warrior (500 kills)
- Sharpshooter (90% accuracy over 100 shots)
- Survivor (survive 10 minutes at <10% health)
- Untouchable (complete mission without taking damage)

**Exploration Achievements** (15 achievements):
- First Steps (travel 10,000 units)
- Voyager (travel 100,000 units)
- Cosmic Wanderer (travel 1,000,000 units)
- Planet Spotter (discover 5 planets)
- System Mapper (discover 10 planets)
- Galaxy Explorer (discover 50 planets)

**Trading Achievements** (12 achievements):
- First Sale (complete first trade)
- Merchant (earn 10,000 credits from trading)
- Tycoon (earn 100,000 credits from trading)
- Market Master (complete 100 trades)

**Mission Achievements** (15 achievements):
- Mission Accomplished (complete first mission)
- Reliable (complete 10 missions)
- Professional (complete 50 missions)
- Elite Operative (complete 100 missions)
- Perfect Record (complete 10 missions with 100% success)

**Special Achievements** (10 achievements):
- Speed Demon (reach max speed)
- Tank (max out all defenses)
- Collector (own all weapon types)
- Rich (accumulate 1,000,000 credits)
- Max Level (reach level 50)

---

## 🎨 UI Integration

### **Cockpit Display Additions**:
- Level and XP bar (top-left corner)
- Skill points available indicator
- Achievement notification popup
- Level-up animation

### **New UI Screens**:
- **Skills Screen** (K key): Skill tree interface
- **Upgrades Screen** (U key): Ship upgrade menu
- **Reputation Screen** (R key): Faction standings
- **Achievements Screen** (H key): Achievement list

---

## ✅ Success Criteria

- [ ] Player gains XP from various sources
- [ ] Level-up system works correctly
- [ ] Skill tree is functional and balanced
- [ ] Ship upgrades apply correctly
- [ ] Reputation system tracks faction standings
- [ ] Achievements unlock and track progress
- [ ] All systems save/load properly
- [ ] UI is intuitive and responsive
- [ ] Performance remains at 60 FPS
- [ ] Systems integrate seamlessly with existing game

---

**Status**: 📋 **PLANNED - READY TO START**
**Starting with**: **Step 1 - Player Leveling System**
**First File**: `js/systems/progression.js`

Let's begin implementation!

