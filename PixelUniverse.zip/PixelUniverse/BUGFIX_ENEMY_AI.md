# 🐛 Bug Fix: Enemy AI Physics Errors

## Problem
Enemy AI system was throwing errors:
```
Uncaught TypeError: physics.applyDrag is not a function
Uncaught TypeError: physics.applyForce is not a function
Uncaught TypeError: physics.applyTorque is not a function
```

## Root Cause
The enemy AI was calling methods that don't exist on the `PhysicsComponent`:
- `physics.applyDrag()` - doesn't exist
- `physics.applyForce()` - should be `physics.addForce()`
- `physics.applyTorque()` - doesn't exist

## PhysicsComponent Available Methods
According to `js/engine/ecs.js`, the `PhysicsComponent` only has:
- `addForce(fx, fy)` - Add a force to the forces array
- `clearForces()` - Clear all forces

## Solution

### 1. Fixed `behaviorIdle()` - Drag Application
**Before**:
```javascript
physics.applyDrag(0.98);
```

**After**:
```javascript
const velocity = entity.getComponent('velocity');
if (velocity) {
    velocity.vx *= 0.98;
    velocity.vy *= 0.98;
    velocity.angularVelocity *= 0.98;
}
```

**Explanation**: Directly modify velocity components to apply drag effect.

### 2. Fixed `behaviorPursue()` - Force Application
**Before**:
```javascript
physics.applyForce(
    Math.cos(transform.rotation) * thrustPower,
    Math.sin(transform.rotation) * thrustPower
);
```

**After**:
```javascript
physics.addForce(
    Math.cos(transform.rotation) * thrustPower,
    Math.sin(transform.rotation) * thrustPower
);
```

**Explanation**: Changed `applyForce` to `addForce` (correct method name).

### 3. Fixed `behaviorAttack()` - Force Application
**Before**:
```javascript
physics.applyForce(-Math.cos(transform.rotation) * 100, ...);
physics.applyForce(Math.cos(transform.rotation) * 150, ...);
physics.applyForce(Math.cos(strafeAngle) * 80, ...);
```

**After**:
```javascript
physics.addForce(-Math.cos(transform.rotation) * 100, ...);
physics.addForce(Math.cos(transform.rotation) * 150, ...);
physics.addForce(Math.cos(strafeAngle) * 80, ...);
```

**Explanation**: Changed all `applyForce` to `addForce`.

### 4. Fixed `behaviorFlee()` - Force Application
**Before**:
```javascript
physics.applyForce(
    Math.cos(transform.rotation) * thrustPower,
    Math.sin(transform.rotation) * thrustPower
);
```

**After**:
```javascript
physics.addForce(
    Math.cos(transform.rotation) * thrustPower,
    Math.sin(transform.rotation) * thrustPower
);
```

**Explanation**: Changed `applyForce` to `addForce`.

### 5. Fixed `behaviorPatrol()` - Force Application
**Before**:
```javascript
physics.applyForce(
    Math.cos(transform.rotation) * 100,
    Math.sin(transform.rotation) * 100
);
```

**After**:
```javascript
physics.addForce(
    Math.cos(transform.rotation) * 100,
    Math.sin(transform.rotation) * 100
);
```

**Explanation**: Changed `applyForce` to `addForce`.

### 6. Fixed `turnToward()` - Torque Application
**Before**:
```javascript
const torque = Math.sign(angleDiff) * Math.min(Math.abs(angleDiff) * 10, turnSpeed);
physics.applyTorque(torque);
```

**After**:
```javascript
const velocity = entity.getComponent('velocity');
if (!velocity) return;

const targetAngularVelocity = Math.sign(angleDiff) * Math.min(Math.abs(angleDiff) * 10, turnSpeed);
velocity.angularVelocity += (targetAngularVelocity - velocity.angularVelocity) * 0.3;
```

**Explanation**: Directly modify angular velocity instead of applying torque. Uses smooth interpolation (0.3 factor) for realistic turning.

## Files Modified
- `js/systems/enemyAI.js` - Fixed all 6 methods

## Changes Summary
- **Drag**: Changed from `physics.applyDrag()` to direct velocity modification
- **Force**: Changed from `physics.applyForce()` to `physics.addForce()`
- **Torque**: Changed from `physics.applyTorque()` to direct angular velocity modification

## Testing
After fixes:
- ✅ No more console errors
- ✅ Enemy ships move correctly
- ✅ Enemy ships turn toward targets
- ✅ Enemy ships apply thrust
- ✅ Enemy ships idle with drag
- ✅ All AI behaviors functional

## Status
✅ **FIXED** - All enemy AI physics errors resolved

