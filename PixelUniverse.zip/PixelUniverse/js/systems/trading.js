/**
 * PixelVerse - Trading System
 * Station trading, dynamic prices, supply/demand
 * Retro sci-fi economy with market fluctuations
 */

class TradingSystem {
    constructor(inventorySystem) {
        this.inventorySystem = inventorySystem;
        
        // Trading stations
        this.stations = new Map(); // stationId -> station data
        
        // Market data
        this.marketData = new Map(); // stationId -> market prices
        
        // Initialize stations
        this.initializeStations();
    }

    /**
     * Initialize trading stations
     */
    initializeStations() {
        // Station 1: Mining Outpost
        this.createStation('mining_outpost', {
            name: 'Mining Outpost Alpha',
            type: 'mining',
            x: 2000,
            y: 1000,
            buyMultiplier: 0.8,  // Buys at 80% base price
            sellMultiplier: 1.2, // Sells at 120% base price
            specializes: ['iron_ore', 'copper_ore', 'titanium_ore'],
            inventory: {
                'iron_ore': 500,
                'copper_ore': 300,
                'titanium_ore': 100,
                'fuel_cell': 200
            }
        });
        
        // Station 2: Trade Hub
        this.createStation('trade_hub', {
            name: 'Central Trade Hub',
            type: 'trade',
            x: 1500,
            y: 1500,
            buyMultiplier: 0.9,
            sellMultiplier: 1.1,
            specializes: ['medical_supplies', 'luxury_goods'],
            inventory: {
                'medical_supplies': 200,
                'luxury_goods': 100,
                'fuel_cell': 500,
                'shield_generator_mk1': 10,
                'weapon_upgrade_mk1': 10,
                'engine_booster_mk1': 10
            }
        });
        
        // Station 3: Black Market
        this.createStation('black_market', {
            name: 'Shadow Station',
            type: 'black_market',
            x: 3000,
            y: 500,
            buyMultiplier: 1.5,  // Pays more for illegal goods
            sellMultiplier: 0.8, // Sells cheaper
            specializes: ['contraband'],
            inventory: {
                'contraband': 50,
                'weapon_upgrade_mk1': 20,
                'fuel_cell': 100
            }
        });
    }

    /**
     * Create trading station
     */
    createStation(stationId, config) {
        this.stations.set(stationId, {
            id: stationId,
            name: config.name,
            type: config.type,
            x: config.x,
            y: config.y,
            buyMultiplier: config.buyMultiplier,
            sellMultiplier: config.sellMultiplier,
            specializes: config.specializes || [],
            inventory: config.inventory || {},
            reputation: 0
        });
        
        // Initialize market prices
        this.updateMarketPrices(stationId);
    }

    /**
     * Update market prices for station
     */
    updateMarketPrices(stationId) {
        const station = this.stations.get(stationId);
        if (!station) return;
        
        const prices = {};
        
        // Calculate prices for all items
        for (const itemId in this.inventorySystem.itemDatabase) {
            const itemData = this.inventorySystem.itemDatabase[itemId];
            let basePrice = itemData.value;
            
            // Apply station multipliers
            const buyPrice = Math.floor(basePrice * station.buyMultiplier);
            const sellPrice = Math.floor(basePrice * station.sellMultiplier);
            
            // Apply specialization bonus
            if (station.specializes.includes(itemId)) {
                prices[itemId] = {
                    buy: Math.floor(buyPrice * 1.2),  // Pay more for specialized items
                    sell: Math.floor(sellPrice * 0.8) // Sell cheaper for specialized items
                };
            } else {
                prices[itemId] = {
                    buy: buyPrice,
                    sell: sellPrice
                };
            }
            
            // Add supply/demand variation
            const variation = 0.9 + Math.random() * 0.2; // 90% to 110%
            prices[itemId].buy = Math.floor(prices[itemId].buy * variation);
            prices[itemId].sell = Math.floor(prices[itemId].sell * variation);
        }
        
        this.marketData.set(stationId, prices);
    }

    /**
     * Buy item from station
     */
    buyFromStation(entity, stationId, itemId, quantity) {
        const station = this.stations.get(stationId);
        if (!station) return { success: false, message: 'Station not found' };
        
        const prices = this.marketData.get(stationId);
        if (!prices || !prices[itemId]) {
            return { success: false, message: 'Item not available' };
        }
        
        // Check station inventory
        if (!station.inventory[itemId] || station.inventory[itemId] < quantity) {
            return { success: false, message: 'Insufficient stock' };
        }
        
        const totalCost = prices[itemId].sell * quantity;
        
        // Check player credits
        const playerCredits = this.inventorySystem.getCredits(entity);
        if (playerCredits < totalCost) {
            return { success: false, message: 'Insufficient credits' };
        }
        
        // Execute transaction
        if (!this.inventorySystem.addItem(entity, itemId, quantity)) {
            return { success: false, message: 'Inventory full' };
        }
        
        this.inventorySystem.removeCredits(entity, totalCost);
        station.inventory[itemId] -= quantity;
        
        return {
            success: true,
            message: `Purchased ${quantity}x ${this.inventorySystem.getItemData(itemId).name}`,
            cost: totalCost
        };
    }

    /**
     * Sell item to station
     */
    sellToStation(entity, stationId, itemId, quantity) {
        const station = this.stations.get(stationId);
        if (!station) return { success: false, message: 'Station not found' };
        
        const prices = this.marketData.get(stationId);
        if (!prices || !prices[itemId]) {
            return { success: false, message: 'Station does not buy this item' };
        }
        
        // Check player inventory
        const playerQuantity = this.inventorySystem.getItemQuantity(entity, itemId);
        if (playerQuantity < quantity) {
            return { success: false, message: 'Insufficient items' };
        }
        
        const totalValue = prices[itemId].buy * quantity;
        
        // Execute transaction
        if (!this.inventorySystem.removeItem(entity, itemId, quantity)) {
            return { success: false, message: 'Failed to remove items' };
        }
        
        this.inventorySystem.addCredits(entity, totalValue);
        
        // Add to station inventory
        if (!station.inventory[itemId]) {
            station.inventory[itemId] = 0;
        }
        station.inventory[itemId] += quantity;
        
        return {
            success: true,
            message: `Sold ${quantity}x ${this.inventorySystem.getItemData(itemId).name}`,
            value: totalValue
        };
    }

    /**
     * Get station market prices
     */
    getMarketPrices(stationId) {
        return this.marketData.get(stationId);
    }

    /**
     * Get station data
     */
    getStation(stationId) {
        return this.stations.get(stationId);
    }

    /**
     * Get all stations
     */
    getAllStations() {
        return Array.from(this.stations.values());
    }

    /**
     * Get nearest station
     */
    getNearestStation(x, y) {
        let nearest = null;
        let minDistance = Infinity;
        
        for (const station of this.stations.values()) {
            const dx = station.x - x;
            const dy = station.y - y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance < minDistance) {
                minDistance = distance;
                nearest = station;
            }
        }
        
        return { station: nearest, distance: minDistance };
    }

    /**
     * Update market (called periodically)
     */
    update(deltaTime) {
        // Periodically update prices (every 60 seconds)
        // This would be implemented with a timer
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = TradingSystem;
}

