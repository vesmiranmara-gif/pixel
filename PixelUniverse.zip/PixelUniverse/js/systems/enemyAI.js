/**
 * PixelVerse - Enemy AI System
 * Handles enemy ship behavior, targeting, and combat tactics
 * Minimalistic AI with distinct behavior patterns
 */

class EnemyAISystem {
    constructor(entityManager, weaponSystem) {
        this.entityManager = entityManager;
        this.weaponSystem = weaponSystem;
        
        // AI states for each enemy
        this.aiStates = new Map(); // entity -> AI state
        
        // Player reference (for targeting)
        this.playerShip = null;
    }

    /**
     * Set player ship reference
     */
    setPlayerShip(player) {
        this.playerShip = player;
    }

    /**
     * Initialize AI for enemy ship
     */
    initializeAI(entity, behaviorType = 'aggressive', detectionRange = 800) {
        this.aiStates.set(entity, {
            behaviorType: behaviorType,  // aggressive, defensive, patrol, flee
            state: 'idle',                // idle, pursuing, attacking, fleeing, patrolling
            target: null,
            detectionRange: detectionRange,
            attackRange: 400,
            fleeThreshold: 0.3,           // Flee when health < 30%
            patrolPoint: null,
            patrolRadius: 300,
            lastFireTime: 0,
            fireInterval: 1.0,            // Fire every 1 second
            reactionTime: 0.5,            // Delay before reacting
            reactionTimer: 0
        });
    }

    /**
     * Update AI system
     */
    update(deltaTime) {
        for (const [entity, aiState] of this.aiStates) {
            // Check if entity still exists
            if (!entity.getComponent('transform')) {
                this.aiStates.delete(entity);
                continue;
            }
            
            // Update AI based on behavior type
            this.updateAI(entity, aiState, deltaTime);
        }
    }

    /**
     * Update individual AI
     */
    updateAI(entity, aiState, deltaTime) {
        const transform = entity.getComponent('transform');
        const velocity = entity.getComponent('velocity');
        const physics = entity.getComponent('physics');
        const health = entity.getComponent('health');
        
        if (!transform || !velocity || !physics) return;
        
        // Update reaction timer
        if (aiState.reactionTimer > 0) {
            aiState.reactionTimer -= deltaTime;
            return;
        }
        
        // Check health for flee behavior
        if (health && health.health / health.maxHealth < aiState.fleeThreshold) {
            aiState.state = 'fleeing';
        }
        
        // Detect player
        if (this.playerShip && aiState.state !== 'fleeing') {
            const playerTransform = this.playerShip.getComponent('transform');
            if (playerTransform) {
                const distance = this.getDistance(transform, playerTransform);
                
                if (distance < aiState.detectionRange) {
                    aiState.target = this.playerShip;
                    
                    if (distance < aiState.attackRange) {
                        aiState.state = 'attacking';
                    } else {
                        aiState.state = 'pursuing';
                    }
                } else if (aiState.state !== 'patrolling') {
                    aiState.state = 'idle';
                    aiState.target = null;
                }
            }
        }
        
        // Execute behavior based on state
        switch (aiState.state) {
            case 'idle':
                this.behaviorIdle(entity, aiState, deltaTime);
                break;
                
            case 'pursuing':
                this.behaviorPursue(entity, aiState, deltaTime);
                break;
                
            case 'attacking':
                this.behaviorAttack(entity, aiState, deltaTime);
                break;
                
            case 'fleeing':
                this.behaviorFlee(entity, aiState, deltaTime);
                break;
                
            case 'patrolling':
                this.behaviorPatrol(entity, aiState, deltaTime);
                break;
        }
    }

    /**
     * Idle behavior - slow drift
     */
    behaviorIdle(entity, aiState, deltaTime) {
        const velocity = entity.getComponent('velocity');

        // Apply slight drag (reduce velocity)
        if (velocity) {
            velocity.vx *= 0.98;
            velocity.vy *= 0.98;
            velocity.angularVelocity *= 0.98;
        }

        // Randomly start patrol
        if (Math.random() < 0.01) {
            const transform = entity.getComponent('transform');
            aiState.patrolPoint = {
                x: transform.x + (Math.random() - 0.5) * aiState.patrolRadius * 2,
                y: transform.y + (Math.random() - 0.5) * aiState.patrolRadius * 2
            };
            aiState.state = 'patrolling';
        }
    }

    /**
     * Pursue behavior - chase target
     */
    behaviorPursue(entity, aiState, deltaTime) {
        if (!aiState.target) {
            aiState.state = 'idle';
            return;
        }
        
        const transform = entity.getComponent('transform');
        const physics = entity.getComponent('physics');
        const targetTransform = aiState.target.getComponent('transform');
        
        if (!targetTransform) {
            aiState.target = null;
            aiState.state = 'idle';
            return;
        }
        
        // Calculate direction to target
        const dx = targetTransform.x - transform.x;
        const dy = targetTransform.y - transform.y;
        const targetAngle = Math.atan2(dy, dx);
        
        // Turn toward target
        this.turnToward(entity, targetAngle, deltaTime);

        // Thrust toward target
        const thrustPower = 200;
        physics.addForce(
            Math.cos(transform.rotation) * thrustPower,
            Math.sin(transform.rotation) * thrustPower
        );
    }

    /**
     * Attack behavior - maintain distance and fire
     */
    behaviorAttack(entity, aiState, deltaTime) {
        if (!aiState.target) {
            aiState.state = 'idle';
            return;
        }
        
        const transform = entity.getComponent('transform');
        const physics = entity.getComponent('physics');
        const targetTransform = aiState.target.getComponent('transform');
        
        if (!targetTransform) {
            aiState.target = null;
            aiState.state = 'idle';
            return;
        }
        
        // Calculate direction to target
        const dx = targetTransform.x - transform.x;
        const dy = targetTransform.y - transform.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        const targetAngle = Math.atan2(dy, dx);
        
        // Turn toward target
        this.turnToward(entity, targetAngle, deltaTime);
        
        // Maintain optimal attack distance (200-300 units)
        const optimalDistance = 250;
        if (distance < optimalDistance - 50) {
            // Too close - back away
            physics.addForce(
                -Math.cos(transform.rotation) * 100,
                -Math.sin(transform.rotation) * 100
            );
        } else if (distance > optimalDistance + 50) {
            // Too far - move closer
            physics.addForce(
                Math.cos(transform.rotation) * 150,
                Math.sin(transform.rotation) * 150
            );
        } else {
            // Strafe (move perpendicular)
            const strafeAngle = transform.rotation + Math.PI / 2;
            physics.addForce(
                Math.cos(strafeAngle) * 80,
                Math.sin(strafeAngle) * 80
            );
        }
        
        // Fire weapon
        aiState.lastFireTime += deltaTime;
        if (aiState.lastFireTime >= aiState.fireInterval) {
            // Check if facing target (within 15 degrees)
            const angleDiff = Math.abs(this.normalizeAngle(targetAngle - transform.rotation));
            if (angleDiff < Math.PI / 12) {
                this.weaponSystem.fireWeapon(entity, 'laser');
                aiState.lastFireTime = 0;
            }
        }
    }

    /**
     * Flee behavior - run away from target
     */
    behaviorFlee(entity, aiState, deltaTime) {
        if (!aiState.target) {
            aiState.state = 'idle';
            return;
        }
        
        const transform = entity.getComponent('transform');
        const physics = entity.getComponent('physics');
        const targetTransform = aiState.target.getComponent('transform');
        
        if (!targetTransform) {
            aiState.target = null;
            aiState.state = 'idle';
            return;
        }
        
        // Calculate direction away from target
        const dx = transform.x - targetTransform.x;
        const dy = transform.y - targetTransform.y;
        const fleeAngle = Math.atan2(dy, dx);
        
        // Turn away from target
        this.turnToward(entity, fleeAngle, deltaTime);

        // Full thrust away
        const thrustPower = 300;
        physics.addForce(
            Math.cos(transform.rotation) * thrustPower,
            Math.sin(transform.rotation) * thrustPower
        );
    }

    /**
     * Patrol behavior - move to patrol point
     */
    behaviorPatrol(entity, aiState, deltaTime) {
        if (!aiState.patrolPoint) {
            aiState.state = 'idle';
            return;
        }
        
        const transform = entity.getComponent('transform');
        const physics = entity.getComponent('physics');
        
        // Calculate direction to patrol point
        const dx = aiState.patrolPoint.x - transform.x;
        const dy = aiState.patrolPoint.y - transform.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance < 50) {
            // Reached patrol point
            aiState.patrolPoint = null;
            aiState.state = 'idle';
            return;
        }
        
        const targetAngle = Math.atan2(dy, dx);
        
        // Turn toward patrol point
        this.turnToward(entity, targetAngle, deltaTime);

        // Thrust toward patrol point
        physics.addForce(
            Math.cos(transform.rotation) * 100,
            Math.sin(transform.rotation) * 100
        );
    }

    /**
     * Turn toward target angle
     */
    turnToward(entity, targetAngle, deltaTime) {
        const transform = entity.getComponent('transform');
        const velocity = entity.getComponent('velocity');

        if (!velocity) return;

        // Calculate angle difference
        let angleDiff = this.normalizeAngle(targetAngle - transform.rotation);

        // Apply angular velocity to turn
        const turnSpeed = 3.0;
        const targetAngularVelocity = Math.sign(angleDiff) * Math.min(Math.abs(angleDiff) * 10, turnSpeed);

        // Smoothly adjust angular velocity
        velocity.angularVelocity += (targetAngularVelocity - velocity.angularVelocity) * 0.3;
    }

    /**
     * Normalize angle to -PI to PI
     */
    normalizeAngle(angle) {
        while (angle > Math.PI) angle -= Math.PI * 2;
        while (angle < -Math.PI) angle += Math.PI * 2;
        return angle;
    }

    /**
     * Get distance between two transforms
     */
    getDistance(transform1, transform2) {
        const dx = transform2.x - transform1.x;
        const dy = transform2.y - transform1.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    /**
     * Remove AI for entity
     */
    removeAI(entity) {
        this.aiStates.delete(entity);
    }

    /**
     * Get AI state for entity
     */
    getAIState(entity) {
        return this.aiStates.get(entity);
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = EnemyAISystem;
}

