/**
 * PixelVerse - Visual Effects System
 * Advanced effects for shields, warp drive, weapons, and environmental hazards
 * Minimalistic design with strong depth and warm plasma colors
 */

class VisualEffectsSystem {
    constructor(renderer) {
        this.renderer = renderer;
        this.activeEffects = [];
    }

    /**
     * Update all active effects
     */
    update(deltaTime) {
        for (let i = this.activeEffects.length - 1; i >= 0; i--) {
            const effect = this.activeEffects[i];
            effect.lifetime -= deltaTime;
            
            if (effect.update) {
                effect.update(deltaTime);
            }
            
            if (effect.lifetime <= 0) {
                this.activeEffects.splice(i, 1);
            }
        }
    }

    /**
     * Render all active effects
     */
    render(cameraX, cameraY) {
        for (const effect of this.activeEffects) {
            if (effect.render) {
                effect.render(this.renderer, cameraX, cameraY);
            }
        }
    }

    /**
     * Create shield barrier effect around ship
     */
    createShieldBarrier(x, y, radius, duration = 0.3) {
        const effect = {
            type: 'shield_barrier',
            x, y, radius,
            lifetime: duration,
            maxLifetime: duration,
            alpha: 1.0,
            
            update(deltaTime) {
                // Fade out
                this.alpha = this.lifetime / this.maxLifetime;
            },
            
            render(renderer, cameraX, cameraY) {
                const coords = renderer.getViewportCoords(this.x, this.y, cameraX, cameraY);
                if (!renderer.isInViewport(coords.x, coords.y)) return;
                
                const ctx = renderer.context;
                
                // Hexagonal shield pattern (minimalistic)
                ctx.save();
                ctx.globalAlpha = this.alpha * 0.4;
                ctx.strokeStyle = RETRO_PALETTE.statusBlue;
                ctx.lineWidth = 2;
                
                // Draw hexagon
                ctx.beginPath();
                for (let i = 0; i < 6; i++) {
                    const angle = (i / 6) * Math.PI * 2;
                    const px = coords.x + Math.cos(angle) * this.radius;
                    const py = coords.y + Math.sin(angle) * this.radius;
                    if (i === 0) ctx.moveTo(px, py);
                    else ctx.lineTo(px, py);
                }
                ctx.closePath();
                ctx.stroke();
                
                // Inner glow
                ctx.globalAlpha = this.alpha * 0.2;
                ctx.strokeStyle = RETRO_PALETTE.pureWhite;
                ctx.lineWidth = 1;
                ctx.stroke();
                
                ctx.restore();
            }
        };
        
        this.activeEffects.push(effect);
    }

    /**
     * Create warp charge effect
     */
    createWarpCharge(x, y, duration = 2.0) {
        const effect = {
            type: 'warp_charge',
            x, y,
            lifetime: duration,
            maxLifetime: duration,
            rings: [],
            
            update(deltaTime) {
                // Create expanding rings
                if (Math.random() < 0.3) {
                    this.rings.push({
                        radius: 5,
                        alpha: 1.0,
                        speed: 50
                    });
                }
                
                // Update rings
                for (let i = this.rings.length - 1; i >= 0; i--) {
                    const ring = this.rings[i];
                    ring.radius += ring.speed * deltaTime;
                    ring.alpha -= deltaTime * 2;
                    
                    if (ring.alpha <= 0) {
                        this.rings.splice(i, 1);
                    }
                }
            },
            
            render(renderer, cameraX, cameraY) {
                const coords = renderer.getViewportCoords(this.x, this.y, cameraX, cameraY);
                if (!renderer.isInViewport(coords.x, coords.y)) return;
                
                const ctx = renderer.context;
                
                // Render rings
                for (const ring of this.rings) {
                    ctx.save();
                    ctx.globalAlpha = ring.alpha;
                    ctx.strokeStyle = RETRO_PALETTE.statusBlue;
                    ctx.lineWidth = 2;
                    
                    ctx.beginPath();
                    ctx.arc(coords.x, coords.y, ring.radius, 0, Math.PI * 2);
                    ctx.stroke();
                    
                    // Inner white glow
                    ctx.globalAlpha = ring.alpha * 0.5;
                    ctx.strokeStyle = RETRO_PALETTE.pureWhite;
                    ctx.lineWidth = 1;
                    ctx.stroke();
                    
                    ctx.restore();
                }
                
                // Central glow
                const intensity = 1 - (this.lifetime / this.maxLifetime);
                ctx.save();
                ctx.globalAlpha = intensity * 0.6;
                ctx.fillStyle = RETRO_PALETTE.pureWhite;
                ctx.beginPath();
                ctx.arc(coords.x, coords.y, 8, 0, Math.PI * 2);
                ctx.fill();
                ctx.restore();
            }
        };
        
        this.activeEffects.push(effect);
    }

    /**
     * Create warp jump effect (star streaks)
     */
    createWarpJump(x, y, angle, duration = 1.0) {
        const effect = {
            type: 'warp_jump',
            x, y, angle,
            lifetime: duration,
            maxLifetime: duration,
            streaks: [],
            
            update(deltaTime) {
                // Create streaks
                if (this.streaks.length < 50) {
                    this.streaks.push({
                        offsetX: (Math.random() - 0.5) * 400,
                        offsetY: (Math.random() - 0.5) * 400,
                        length: 0,
                        maxLength: 100 + Math.random() * 200,
                        speed: 500 + Math.random() * 500
                    });
                }
                
                // Update streaks
                for (const streak of this.streaks) {
                    streak.length += streak.speed * deltaTime;
                    if (streak.length > streak.maxLength) {
                        streak.length = streak.maxLength;
                    }
                }
            },
            
            render(renderer, cameraX, cameraY) {
                const coords = renderer.getViewportCoords(this.x, this.y, cameraX, cameraY);
                
                const ctx = renderer.context;
                ctx.save();
                
                const intensity = this.lifetime / this.maxLifetime;
                ctx.globalAlpha = intensity;
                
                for (const streak of this.streaks) {
                    const startX = coords.x + streak.offsetX;
                    const startY = coords.y + streak.offsetY;
                    const endX = startX + Math.cos(this.angle) * streak.length;
                    const endY = startY + Math.sin(this.angle) * streak.length;
                    
                    ctx.strokeStyle = RETRO_PALETTE.statusBlue;
                    ctx.lineWidth = 1;
                    ctx.beginPath();
                    ctx.moveTo(startX, startY);
                    ctx.lineTo(endX, endY);
                    ctx.stroke();
                }
                
                ctx.restore();
            }
        };
        
        this.activeEffects.push(effect);
    }

    /**
     * Create weapon beam effect
     */
    createBeam(x1, y1, x2, y2, color = RETRO_PALETTE.alertRed, duration = 0.1) {
        const effect = {
            type: 'beam',
            x1, y1, x2, y2, color,
            lifetime: duration,
            maxLifetime: duration,
            
            render(renderer, cameraX, cameraY) {
                const coords1 = renderer.getViewportCoords(this.x1, this.y1, cameraX, cameraY);
                const coords2 = renderer.getViewportCoords(this.x2, this.y2, cameraX, cameraY);
                
                const ctx = renderer.context;
                const alpha = this.lifetime / this.maxLifetime;
                
                ctx.save();
                
                // Outer glow
                ctx.globalAlpha = alpha * 0.3;
                ctx.strokeStyle = this.color;
                ctx.lineWidth = 4;
                ctx.beginPath();
                ctx.moveTo(coords1.x, coords1.y);
                ctx.lineTo(coords2.x, coords2.y);
                ctx.stroke();
                
                // Core beam
                ctx.globalAlpha = alpha;
                ctx.strokeStyle = RETRO_PALETTE.pureWhite;
                ctx.lineWidth = 2;
                ctx.beginPath();
                ctx.moveTo(coords1.x, coords1.y);
                ctx.lineTo(coords2.x, coords2.y);
                ctx.stroke();
                
                ctx.restore();
            }
        };
        
        this.activeEffects.push(effect);
    }

    /**
     * Create muzzle flash effect
     */
    createMuzzleFlash(x, y, angle, duration = 0.05) {
        const effect = {
            type: 'muzzle_flash',
            x, y, angle,
            lifetime: duration,
            maxLifetime: duration,
            
            render(renderer, cameraX, cameraY) {
                const coords = renderer.getViewportCoords(this.x, this.y, cameraX, cameraY);
                if (!renderer.isInViewport(coords.x, coords.y)) return;
                
                const ctx = renderer.context;
                const alpha = this.lifetime / this.maxLifetime;
                
                ctx.save();
                ctx.translate(coords.x, coords.y);
                ctx.rotate(this.angle);
                
                // Flash shape (triangle)
                ctx.globalAlpha = alpha;
                ctx.fillStyle = RETRO_PALETTE.warningYellow;
                ctx.beginPath();
                ctx.moveTo(0, 0);
                ctx.lineTo(12, -4);
                ctx.lineTo(12, 4);
                ctx.closePath();
                ctx.fill();
                
                // White core
                ctx.globalAlpha = alpha * 0.8;
                ctx.fillStyle = RETRO_PALETTE.pureWhite;
                ctx.beginPath();
                ctx.moveTo(0, 0);
                ctx.lineTo(8, -2);
                ctx.lineTo(8, 2);
                ctx.closePath();
                ctx.fill();
                
                ctx.restore();
            }
        };
        
        this.activeEffects.push(effect);
    }

    /**
     * Clear all effects
     */
    clear() {
        this.activeEffects = [];
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = VisualEffectsSystem;
}

