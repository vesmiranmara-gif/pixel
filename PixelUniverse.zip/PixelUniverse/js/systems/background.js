/**
 * PixelVerse - Background System
 * Multi-layer parallax starfield with nebulae and cosmic phenomena
 * Minimalistic design with depth layering
 */

class BackgroundSystem {
    constructor(renderer) {
        this.renderer = renderer;

        // Starfield layers (parallax)
        this.starLayers = [];
        this.numLayers = 6; // Increased from 4 to 6

        // Star clusters
        this.starClusters = [];

        // Distant galaxies
        this.galaxies = [];

        // Nebulae
        this.nebulae = [];

        // Pixel nebulae (small, detailed)
        this.pixelNebulae = [];

        // Supernova remnants
        this.supernovaRemnants = [];

        // Dust clouds
        this.dustClouds = [];

        // Cosmic dust
        this.dustParticles = [];

        // Background color tint
        this.backgroundTint = this.getRandomBackgroundTint();

        // Generate background
        this.generateStarfield();
        this.generateStarClusters();
        this.generateGalaxies();
        this.generateNebulae();
        this.generatePixelNebulae();
        this.generateSupernovaRemnants();
        this.generateDustClouds();
        this.generateDust();
    }

    /**
     * Get random background tint (very dark, nearly black colors)
     */
    getRandomBackgroundTint() {
        const tints = [
            { r: 3, g: 0, b: 8 },     // Very dark purple
            { r: 8, g: 0, b: 3 },     // Very dark red/magenta
            { r: 0, g: 2, b: 8 },     // Very dark blue
            { r: 5, g: 0, b: 5 },     // Very dark purple-magenta
            { r: 2, g: 0, b: 6 },     // Very dark indigo
            { r: 0, g: 0, b: 0 }      // Pure black
        ];
        return tints[Math.floor(Math.random() * tints.length)];
    }

    /**
     * Generate multi-layer starfield (ULTRA ENHANCED - MASSIVE star count)
     */
    generateStarfield() {
        const width = this.renderer.baseWidth * 6;
        const height = this.renderer.baseHeight * 6;

        for (let layer = 0; layer < this.numLayers; layer++) {
            const stars = [];
            const depth = layer + 1; // 1 = farthest, 6 = nearest
            const parallaxFactor = 1 / (depth * 2);

            // ULTRA DENSE STAR COUNT for maximum richness
            // Layer 1 (farthest): ~2000 stars
            // Layer 6 (nearest): ~8000 stars
            const baseCount = 2000;
            const starCount = Math.floor(baseCount * Math.pow(1.4, depth - 1));

            for (let i = 0; i < starCount; i++) {
                const brightness = Math.random();

                // Varied star sizes based on depth and randomness
                let size = 1;
                if (depth >= 5) {
                    const sizeRoll = Math.random();
                    if (sizeRoll > 0.95) size = 4;      // Very rare large stars
                    else if (sizeRoll > 0.85) size = 3; // Rare medium-large stars
                    else if (sizeRoll > 0.6) size = 2;  // Common medium stars
                    else size = 1;                       // Most common small stars
                } else if (depth >= 3) {
                    size = Math.random() > 0.7 ? 2 : 1;
                }

                // Color variation for stars (blue, white, yellow, red)
                const colorType = Math.random();
                let starColor;
                if (colorType > 0.95) starColor = 'red';      // Rare red giants
                else if (colorType > 0.85) starColor = 'blue'; // Blue stars
                else if (colorType > 0.7) starColor = 'yellow'; // Yellow stars
                else starColor = 'white';                       // Most common white stars

                stars.push({
                    x: Math.random() * width - width / 2,
                    y: Math.random() * height - height / 2,
                    brightness: brightness,
                    size: size,
                    twinkle: Math.random() * Math.PI * 2,
                    twinkleSpeed: 0.2 + Math.random() * 1.5,
                    colorType: starColor
                });
            }

            this.starLayers.push({
                stars: stars,
                depth: depth,
                parallaxFactor: parallaxFactor,
                baseColor: this.getStarColor(depth)
            });
        }
    }

    /**
     * Generate star clusters (ULTRA ORGANIC - MASSIVE clusters)
     */
    generateStarClusters() {
        const width = this.renderer.baseWidth * 6;
        const height = this.renderer.baseHeight * 6;

        // Create 15-25 star clusters (ULTRA DENSE)
        const clusterCount = 15 + Math.floor(Math.random() * 11);

        for (let i = 0; i < clusterCount; i++) {
            const centerX = Math.random() * width - width / 2;
            const centerY = Math.random() * height - height / 2;
            const radius = 250 + Math.random() * 400; // Even larger clusters
            const starCount = 300 + Math.floor(Math.random() * 500); // Many more stars per cluster
            const stars = [];

            // Cluster color variation
            const clusterColorType = Math.random();
            let clusterColor;
            if (clusterColorType > 0.7) clusterColor = 'blue';
            else if (clusterColorType > 0.4) clusterColor = 'yellow';
            else clusterColor = 'white';

            // Create organic, irregular cluster shape
            for (let j = 0; j < starCount; j++) {
                const angle = Math.random() * Math.PI * 2;

                // TRIPLE Gaussian distribution for very organic, natural shape
                // This creates a smooth falloff from center with no hard edges
                const gaussian1 = Math.random();
                const gaussian2 = Math.random();
                const gaussian3 = Math.random();
                const gaussian4 = Math.random();
                const gaussian5 = Math.random();
                const distance = ((gaussian1 + gaussian2 + gaussian3 + gaussian4 + gaussian5) / 5) * radius;

                // Add random variation to radius for irregular shape
                const radiusVariation = 0.7 + Math.random() * 0.6; // 70% to 130% of radius
                const finalDistance = distance * radiusVariation;

                // Varied sizes in cluster
                const sizeRoll = Math.random();
                let size = 1;
                if (sizeRoll > 0.95) size = 3;
                else if (sizeRoll > 0.8) size = 2;

                stars.push({
                    x: centerX + Math.cos(angle) * finalDistance,
                    y: centerY + Math.sin(angle) * finalDistance,
                    brightness: 0.4 + Math.random() * 0.6,
                    size: size,
                    colorType: clusterColor
                });
            }

            this.starClusters.push({
                centerX: centerX,
                centerY: centerY,
                radius: radius,
                stars: stars,
                parallaxFactor: 0.15,
                colorType: clusterColor
            });
        }

        // Add MASSIVE amount of scattered "filler" stars to eliminate square appearance
        this.addFillerStars(width, height);
    }

    /**
     * Add scattered filler stars to fill empty space
     */
    addFillerStars(width, height) {
        const fillerCount = 3000; // ULTRA DENSE filler stars
        const fillerStars = [];

        for (let i = 0; i < fillerCount; i++) {
            const x = Math.random() * width - width / 2;
            const y = Math.random() * height - height / 2;

            // Varied sizes
            const sizeRoll = Math.random();
            let size = 1;
            if (sizeRoll > 0.98) size = 3;
            else if (sizeRoll > 0.9) size = 2;

            // Varied colors
            const colorRoll = Math.random();
            let colorType;
            if (colorRoll > 0.95) colorType = 'red';
            else if (colorRoll > 0.85) colorType = 'blue';
            else if (colorRoll > 0.7) colorType = 'yellow';
            else colorType = 'white';

            fillerStars.push({
                x: x,
                y: y,
                brightness: 0.3 + Math.random() * 0.7,
                size: size,
                colorType: colorType
            });
        }

        // Add as a special "filler" cluster
        this.starClusters.push({
            centerX: 0,
            centerY: 0,
            radius: width,
            stars: fillerStars,
            parallaxFactor: 0.1,
            colorType: 'white'
        });
    }

    /**
     * Generate distant galaxies (tiny pixel galaxies)
     */
    generateGalaxies() {
        const width = this.renderer.baseWidth * 2;
        const height = this.renderer.baseHeight * 2;

        // Create 15-25 tiny galaxies (ULTRA DENSE)
        const galaxyCount = 15 + Math.floor(Math.random() * 11);

        for (let i = 0; i < galaxyCount; i++) {
            const type = Math.random() > 0.5 ? 'spiral' : 'elliptical';

            this.galaxies.push({
                x: Math.random() * width - width / 2,
                y: Math.random() * height - height / 2,
                type: type,
                size: 3 + Math.floor(Math.random() * 4),
                rotation: Math.random() * Math.PI * 2,
                brightness: 0.3 + Math.random() * 0.4,
                parallaxFactor: 0.1
            });
        }
    }

    /**
     * Generate pixel nebulae (MORE, LARGER, more detailed)
     */
    generatePixelNebulae() {
        const width = this.renderer.baseWidth * 3;
        const height = this.renderer.baseHeight * 3;

        // Create 25-40 pixel nebulae (ULTRA DENSE)
        const nebulaCount = 25 + Math.floor(Math.random() * 16);

        for (let i = 0; i < nebulaCount; i++) {
            const pixels = [];
            const centerX = Math.random() * width - width / 2;
            const centerY = Math.random() * height - height / 2;
            const pixelCount = 200 + Math.floor(Math.random() * 300); // Maximum pixels
            const radius = 60 + Math.random() * 100; // Larger radius

            for (let j = 0; j < pixelCount; j++) {
                const angle = Math.random() * Math.PI * 2;
                // Gaussian distribution for organic shape
                const distance = (Math.random() + Math.random() + Math.random()) / 3 * radius;

                pixels.push({
                    x: centerX + Math.cos(angle) * distance,
                    y: centerY + Math.sin(angle) * distance,
                    alpha: 0.15 + Math.random() * 0.4 // More visible
                });
            }

            this.pixelNebulae.push({
                pixels: pixels,
                color: this.getNebulaColor(),
                parallaxFactor: 0.2
            });
        }
    }

    /**
     * Generate supernova remnants
     */
    generateSupernovaRemnants() {
        const width = this.renderer.baseWidth * 2;
        const height = this.renderer.baseHeight * 2;

        // Create 2-3 supernova remnants
        const remnantCount = 2 + Math.floor(Math.random() * 2);

        for (let i = 0; i < remnantCount; i++) {
            this.supernovaRemnants.push({
                x: Math.random() * width - width / 2,
                y: Math.random() * height - height / 2,
                radius: 60 + Math.random() * 80,
                innerRadius: 30 + Math.random() * 40,
                color: Math.random() > 0.5 ?
                    'rgba(204, 51, 51, 0.15)' :   // Red
                    'rgba(51, 102, 153, 0.15)',   // Blue
                parallaxFactor: 0.2,
                rotation: Math.random() * Math.PI * 2
            });
        }
    }

    /**
     * Generate dust clouds
     */
    generateDustClouds() {
        const width = this.renderer.baseWidth * 2;
        const height = this.renderer.baseHeight * 2;

        // Create 3-5 dust clouds
        const cloudCount = 3 + Math.floor(Math.random() * 3);

        for (let i = 0; i < cloudCount; i++) {
            this.dustClouds.push({
                x: Math.random() * width - width / 2,
                y: Math.random() * height - height / 2,
                width: 150 + Math.random() * 200,
                height: 100 + Math.random() * 150,
                alpha: 0.03 + Math.random() * 0.05,
                parallaxFactor: 0.4,
                rotation: Math.random() * Math.PI * 2
            });
        }
    }

    /**
     * Get star color based on depth (with slight color variation)
     */
    getStarColor(depth) {
        // Distant stars are dimmer and bluer
        // Near stars are brighter and whiter
        switch (depth) {
            case 1: return RETRO_PALETTE.voidMid;
            case 2: return RETRO_PALETTE.darkGray;
            case 3: return RETRO_PALETTE.shadowGray;
            case 4: return RETRO_PALETTE.mediumGray;
            case 5: return RETRO_PALETTE.lightGray;
            case 6: return RETRO_PALETTE.paleGray;
            default: return RETRO_PALETTE.darkGray;
        }
    }

    /**
     * Generate nebulae (gas clouds)
     */
    generateNebulae() {
        const width = this.renderer.baseWidth * 2;
        const height = this.renderer.baseHeight * 2;
        
        // Create 5-8 large nebulae (MORE and LARGER)
        const nebulaCount = 5 + Math.floor(Math.random() * 4);

        for (let i = 0; i < nebulaCount; i++) {
            this.nebulae.push({
                x: Math.random() * width - width / 2,
                y: Math.random() * height - height / 2,
                width: 400 + Math.random() * 600,  // Much larger
                height: 300 + Math.random() * 500, // Much larger
                color: this.getNebulaColor(),
                alpha: 0.08 + Math.random() * 0.15, // More visible
                parallaxFactor: 0.25,
                rotation: Math.random() * Math.PI * 2
            });
        }
    }

    /**
     * Get nebula color (RICH colors - purple, magenta, red, blue)
     */
    getNebulaColor() {
        const colors = [
            'rgba(80, 20, 120, 0.4)',    // Rich purple
            'rgba(120, 20, 80, 0.4)',    // Magenta
            'rgba(100, 10, 100, 0.4)',   // Deep purple
            'rgba(150, 30, 100, 0.4)',   // Pink-purple
            'rgba(120, 20, 150, 0.4)',   // Violet
            'rgba(150, 20, 50, 0.4)',    // Red-magenta
            'rgba(80, 30, 150, 0.4)',    // Blue-purple
            'rgba(50, 20, 100, 0.4)',    // Dark purple
            'rgba(100, 20, 120, 0.4)',   // Purple-magenta
            'rgba(60, 80, 150, 0.3)',    // Blue
            'rgba(150, 40, 40, 0.3)',    // Red
            'rgba(40, 60, 120, 0.3)'     // Deep blue
        ];
        return colors[Math.floor(Math.random() * colors.length)];
    }

    /**
     * Generate cosmic dust particles (MORE for depth)
     */
    generateDust() {
        const width = this.renderer.baseWidth * 3;
        const height = this.renderer.baseHeight * 3;

        // 150 dust particles instead of 50
        for (let i = 0; i < 150; i++) {
            this.dustParticles.push({
                x: Math.random() * width - width / 2,
                y: Math.random() * height - height / 2,
                vx: (Math.random() - 0.5) * 8,
                vy: (Math.random() - 0.5) * 8,
                size: 1,
                alpha: 0.08 + Math.random() * 0.25,
                parallaxFactor: 0.7 + Math.random() * 0.3 // Varied parallax
            });
        }
    }

    /**
     * Update background (dust movement, star twinkle)
     */
    update(deltaTime) {
        // Update star twinkle
        for (const layer of this.starLayers) {
            for (const star of layer.stars) {
                star.twinkle += deltaTime * star.twinkleSpeed;
                if (star.twinkle > Math.PI * 2) {
                    star.twinkle -= Math.PI * 2;
                }
            }
        }
        
        // Update dust particles
        for (const dust of this.dustParticles) {
            dust.x += dust.vx * deltaTime;
            dust.y += dust.vy * deltaTime;
            
            // Wrap around
            const width = this.renderer.baseWidth * 2;
            const height = this.renderer.baseHeight * 2;
            
            if (dust.x < -width / 2) dust.x += width;
            if (dust.x > width / 2) dust.x -= width;
            if (dust.y < -height / 2) dust.y += height;
            if (dust.y > height / 2) dust.y -= height;
        }
    }

    /**
     * Render background
     */
    render(cameraX, cameraY) {
        const ctx = this.renderer.context;

        // Clear with tinted void
        const tint = this.backgroundTint;
        ctx.fillStyle = `rgb(${tint.r}, ${tint.g}, ${tint.b})`;
        ctx.fillRect(0, 0, this.renderer.baseWidth, this.renderer.baseHeight);

        // Render distant galaxies (farthest back)
        this.renderGalaxies(ctx, cameraX, cameraY);

        // Render nebulae (very far back)
        this.renderNebulae(ctx, cameraX, cameraY);

        // Render supernova remnants
        this.renderSupernovaRemnants(ctx, cameraX, cameraY);

        // Render dust clouds
        this.renderDustClouds(ctx, cameraX, cameraY);

        // Render star clusters
        this.renderStarClusters(ctx, cameraX, cameraY);

        // Render pixel nebulae
        this.renderPixelNebulae(ctx, cameraX, cameraY);

        // Render star layers (back to front)
        for (let i = 0; i < this.starLayers.length; i++) {
            this.renderStarLayer(ctx, this.starLayers[i], cameraX, cameraY);
        }

        // Render dust (foreground)
        this.renderDust(ctx, cameraX, cameraY);
    }

    /**
     * Render nebulae
     */
    renderNebulae(ctx, cameraX, cameraY) {
        for (const nebula of this.nebulae) {
            const offsetX = cameraX * nebula.parallaxFactor;
            const offsetY = cameraY * nebula.parallaxFactor;
            
            const screenX = this.renderer.baseWidth / 2 + (nebula.x - offsetX);
            const screenY = this.renderer.baseHeight / 2 + (nebula.y - offsetY);
            
            // Skip if off-screen
            if (screenX + nebula.width < 0 || screenX > this.renderer.baseWidth ||
                screenY + nebula.height < 0 || screenY > this.renderer.baseHeight) {
                continue;
            }
            
            ctx.save();
            ctx.globalAlpha = nebula.alpha;
            
            // Create radial gradient for nebula
            const gradient = ctx.createRadialGradient(
                screenX, screenY, 0,
                screenX, screenY, nebula.width / 2
            );
            gradient.addColorStop(0, nebula.color);
            gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
            
            ctx.fillStyle = gradient;
            ctx.fillRect(
                screenX - nebula.width / 2,
                screenY - nebula.height / 2,
                nebula.width,
                nebula.height
            );
            
            ctx.restore();
        }
    }

    /**
     * Render star layer (with color variation)
     */
    renderStarLayer(ctx, layer, cameraX, cameraY) {
        const offsetX = cameraX * layer.parallaxFactor;
        const offsetY = cameraY * layer.parallaxFactor;

        for (const star of layer.stars) {
            const screenX = this.renderer.baseWidth / 2 + (star.x - offsetX);
            const screenY = this.renderer.baseHeight / 2 + (star.y - offsetY);

            // Skip if off-screen
            if (screenX < -10 || screenX > this.renderer.baseWidth + 10 ||
                screenY < -10 || screenY > this.renderer.baseHeight + 10) {
                continue;
            }

            // Twinkle effect
            const twinkleAlpha = 0.5 + Math.sin(star.twinkle) * 0.5;

            // Get star color based on type
            let starColor;
            switch (star.colorType) {
                case 'red':
                    starColor = 'rgb(255, 180, 180)'; // Pale red
                    break;
                case 'blue':
                    starColor = 'rgb(180, 200, 255)'; // Pale blue
                    break;
                case 'yellow':
                    starColor = 'rgb(255, 255, 200)'; // Pale yellow
                    break;
                default:
                    starColor = layer.baseColor; // White/gray
            }

            ctx.globalAlpha = star.brightness * twinkleAlpha;
            ctx.fillStyle = starColor;
            ctx.fillRect(
                Math.floor(screenX),
                Math.floor(screenY),
                star.size,
                star.size
            );
        }

        ctx.globalAlpha = 1.0;
    }

    /**
     * Render cosmic dust
     */
    renderDust(ctx, cameraX, cameraY) {
        for (const dust of this.dustParticles) {
            const offsetX = cameraX * dust.parallaxFactor;
            const offsetY = cameraY * dust.parallaxFactor;

            const screenX = this.renderer.baseWidth / 2 + (dust.x - offsetX);
            const screenY = this.renderer.baseHeight / 2 + (dust.y - offsetY);

            // Skip if off-screen
            if (screenX < 0 || screenX > this.renderer.baseWidth ||
                screenY < 0 || screenY > this.renderer.baseHeight) {
                continue;
            }

            ctx.globalAlpha = dust.alpha;
            ctx.fillStyle = RETRO_PALETTE.darkGray;
            ctx.fillRect(
                Math.floor(screenX),
                Math.floor(screenY),
                dust.size,
                dust.size
            );
        }

        ctx.globalAlpha = 1.0;
    }

    /**
     * Render star clusters (with color variation)
     */
    renderStarClusters(ctx, cameraX, cameraY) {
        for (const cluster of this.starClusters) {
            const offsetX = cameraX * cluster.parallaxFactor;
            const offsetY = cameraY * cluster.parallaxFactor;

            // Get cluster color
            let clusterColor;
            switch (cluster.colorType) {
                case 'blue':
                    clusterColor = 'rgb(180, 200, 255)';
                    break;
                case 'yellow':
                    clusterColor = 'rgb(255, 255, 200)';
                    break;
                default:
                    clusterColor = RETRO_PALETTE.paleGray;
            }

            for (const star of cluster.stars) {
                const screenX = this.renderer.baseWidth / 2 + (star.x - offsetX);
                const screenY = this.renderer.baseHeight / 2 + (star.y - offsetY);

                // Skip if off-screen
                if (screenX < -10 || screenX > this.renderer.baseWidth + 10 ||
                    screenY < -10 || screenY > this.renderer.baseHeight + 10) {
                    continue;
                }

                ctx.globalAlpha = star.brightness;
                ctx.fillStyle = clusterColor;
                ctx.fillRect(
                    Math.floor(screenX),
                    Math.floor(screenY),
                    star.size,
                    star.size
                );
            }
        }

        ctx.globalAlpha = 1.0;
    }

    /**
     * Render distant galaxies
     */
    renderGalaxies(ctx, cameraX, cameraY) {
        for (const galaxy of this.galaxies) {
            const offsetX = cameraX * galaxy.parallaxFactor;
            const offsetY = cameraY * galaxy.parallaxFactor;

            const screenX = this.renderer.baseWidth / 2 + (galaxy.x - offsetX);
            const screenY = this.renderer.baseHeight / 2 + (galaxy.y - offsetY);

            // Skip if off-screen
            if (screenX < -20 || screenX > this.renderer.baseWidth + 20 ||
                screenY < -20 || screenY > this.renderer.baseHeight + 20) {
                continue;
            }

            ctx.save();
            ctx.globalAlpha = galaxy.brightness;

            if (galaxy.type === 'spiral') {
                // Spiral galaxy (tiny cross pattern)
                ctx.fillStyle = RETRO_PALETTE.voidMid;
                ctx.fillRect(Math.floor(screenX) - 1, Math.floor(screenY), galaxy.size, 1);
                ctx.fillRect(Math.floor(screenX), Math.floor(screenY) - 1, 1, galaxy.size);
                ctx.fillRect(Math.floor(screenX), Math.floor(screenY), 2, 2); // Center
            } else {
                // Elliptical galaxy (tiny oval)
                ctx.fillStyle = RETRO_PALETTE.voidMid;
                ctx.fillRect(Math.floor(screenX), Math.floor(screenY), galaxy.size, galaxy.size - 1);
            }

            ctx.restore();
        }
    }

    /**
     * Render pixel nebulae
     */
    renderPixelNebulae(ctx, cameraX, cameraY) {
        for (const nebula of this.pixelNebulae) {
            const offsetX = cameraX * nebula.parallaxFactor;
            const offsetY = cameraY * nebula.parallaxFactor;

            ctx.fillStyle = nebula.color;

            for (const pixel of nebula.pixels) {
                const screenX = this.renderer.baseWidth / 2 + (pixel.x - offsetX);
                const screenY = this.renderer.baseHeight / 2 + (pixel.y - offsetY);

                // Skip if off-screen
                if (screenX < 0 || screenX > this.renderer.baseWidth ||
                    screenY < 0 || screenY > this.renderer.baseHeight) {
                    continue;
                }

                ctx.globalAlpha = pixel.alpha;
                ctx.fillRect(
                    Math.floor(screenX),
                    Math.floor(screenY),
                    1,
                    1
                );
            }
        }

        ctx.globalAlpha = 1.0;
    }

    /**
     * Render supernova remnants
     */
    renderSupernovaRemnants(ctx, cameraX, cameraY) {
        for (const remnant of this.supernovaRemnants) {
            const offsetX = cameraX * remnant.parallaxFactor;
            const offsetY = cameraY * remnant.parallaxFactor;

            const screenX = this.renderer.baseWidth / 2 + (remnant.x - offsetX);
            const screenY = this.renderer.baseHeight / 2 + (remnant.y - offsetY);

            // Skip if off-screen
            if (screenX + remnant.radius < 0 || screenX - remnant.radius > this.renderer.baseWidth ||
                screenY + remnant.radius < 0 || screenY - remnant.radius > this.renderer.baseHeight) {
                continue;
            }

            ctx.save();

            // Create ring gradient
            const gradient = ctx.createRadialGradient(
                screenX, screenY, remnant.innerRadius,
                screenX, screenY, remnant.radius
            );
            gradient.addColorStop(0, remnant.color);
            gradient.addColorStop(0.5, remnant.color);
            gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');

            ctx.fillStyle = gradient;
            ctx.fillRect(
                screenX - remnant.radius,
                screenY - remnant.radius,
                remnant.radius * 2,
                remnant.radius * 2
            );

            ctx.restore();
        }
    }

    /**
     * Render dust clouds
     */
    renderDustClouds(ctx, cameraX, cameraY) {
        for (const cloud of this.dustClouds) {
            const offsetX = cameraX * cloud.parallaxFactor;
            const offsetY = cameraY * cloud.parallaxFactor;

            const screenX = this.renderer.baseWidth / 2 + (cloud.x - offsetX);
            const screenY = this.renderer.baseHeight / 2 + (cloud.y - offsetY);

            // Skip if off-screen
            if (screenX + cloud.width < 0 || screenX > this.renderer.baseWidth ||
                screenY + cloud.height < 0 || screenY > this.renderer.baseHeight) {
                continue;
            }

            ctx.save();
            ctx.globalAlpha = cloud.alpha;

            // Create soft gradient
            const gradient = ctx.createRadialGradient(
                screenX, screenY, 0,
                screenX, screenY, cloud.width / 2
            );
            gradient.addColorStop(0, RETRO_PALETTE.darkGray);
            gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');

            ctx.fillStyle = gradient;
            ctx.fillRect(
                screenX - cloud.width / 2,
                screenY - cloud.height / 2,
                cloud.width,
                cloud.height
            );

            ctx.restore();
        }
    }

    /**
     * Add distant star (for variety)
     */
    addDistantStar(x, y, layer = 1) {
        if (layer < 1 || layer > this.numLayers) return;
        
        const starLayer = this.starLayers[layer - 1];
        starLayer.stars.push({
            x: x,
            y: y,
            brightness: Math.random(),
            size: 1,
            twinkle: Math.random() * Math.PI * 2,
            twinkleSpeed: 0.5 + Math.random() * 1.5
        });
    }

    /**
     * Clear and regenerate background
     */
    regenerate() {
        this.starLayers = [];
        this.starClusters = [];
        this.galaxies = [];
        this.nebulae = [];
        this.pixelNebulae = [];
        this.supernovaRemnants = [];
        this.dustClouds = [];
        this.dustParticles = [];

        this.backgroundTint = this.getRandomBackgroundTint();

        this.generateStarfield();
        this.generateStarClusters();
        this.generateGalaxies();
        this.generateNebulae();
        this.generatePixelNebulae();
        this.generateSupernovaRemnants();
        this.generateDustClouds();
        this.generateDust();
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = BackgroundSystem;
}

