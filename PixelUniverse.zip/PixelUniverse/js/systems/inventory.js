/**
 * PixelVerse - Inventory System
 * Manages ship cargo, items, resources, and equipment
 * Retro sci-fi inventory with weight/volume limits
 */

class InventorySystem {
    constructor() {
        // Inventory storage for each entity
        this.inventories = new Map(); // entity -> inventory
        
        // Item database
        this.itemDatabase = this.createItemDatabase();
    }

    /**
     * Create item database
     */
    createItemDatabase() {
        return {
            // Resources
            'iron_ore': {
                id: 'iron_ore',
                name: 'Iron Ore',
                type: 'resource',
                value: 10,
                weight: 1,
                stackable: true,
                maxStack: 100,
                description: 'Raw iron ore for manufacturing'
            },
            'copper_ore': {
                id: 'copper_ore',
                name: 'Copper Ore',
                type: 'resource',
                value: 15,
                weight: 1,
                stackable: true,
                maxStack: 100,
                description: 'Conductive copper ore'
            },
            'titanium_ore': {
                id: 'titanium_ore',
                name: 'Titanium Ore',
                type: 'resource',
                value: 50,
                weight: 2,
                stackable: true,
                maxStack: 50,
                description: 'Rare titanium ore for advanced hulls'
            },
            'fuel_cell': {
                id: 'fuel_cell',
                name: 'Fuel Cell',
                type: 'consumable',
                value: 25,
                weight: 0.5,
                stackable: true,
                maxStack: 200,
                description: 'Standard fuel cell for ship power'
            },
            
            // Equipment
            'shield_generator_mk1': {
                id: 'shield_generator_mk1',
                name: 'Shield Generator Mk1',
                type: 'equipment',
                slot: 'shield',
                value: 500,
                weight: 10,
                stackable: false,
                stats: { shieldBonus: 50 },
                description: 'Basic shield generator'
            },
            'weapon_upgrade_mk1': {
                id: 'weapon_upgrade_mk1',
                name: 'Weapon Upgrade Mk1',
                type: 'equipment',
                slot: 'weapon',
                value: 750,
                weight: 8,
                stackable: false,
                stats: { damageBonus: 25 },
                description: 'Weapon damage enhancement'
            },
            'engine_booster_mk1': {
                id: 'engine_booster_mk1',
                name: 'Engine Booster Mk1',
                type: 'equipment',
                slot: 'engine',
                value: 600,
                weight: 12,
                stackable: false,
                stats: { speedBonus: 20 },
                description: 'Engine thrust enhancement'
            },
            
            // Trade goods
            'medical_supplies': {
                id: 'medical_supplies',
                name: 'Medical Supplies',
                type: 'trade_good',
                value: 100,
                weight: 2,
                stackable: true,
                maxStack: 50,
                description: 'Essential medical supplies'
            },
            'luxury_goods': {
                id: 'luxury_goods',
                name: 'Luxury Goods',
                type: 'trade_good',
                value: 200,
                weight: 1,
                stackable: true,
                maxStack: 30,
                description: 'High-value luxury items'
            },
            'contraband': {
                id: 'contraband',
                name: 'Contraband',
                type: 'trade_good',
                value: 500,
                weight: 3,
                stackable: true,
                maxStack: 20,
                illegal: true,
                description: 'Illegal goods - high risk, high reward'
            }
        };
    }

    /**
     * Initialize inventory for entity
     */
    initializeInventory(entity, config = {}) {
        const inventory = {
            maxWeight: config.maxWeight || 100,
            maxVolume: config.maxVolume || 50,
            currentWeight: 0,
            currentVolume: 0,
            credits: config.credits || 1000,
            items: [], // Array of { itemId, quantity, equipped }
            equipment: {
                shield: null,
                weapon: null,
                engine: null,
                sensor: null
            }
        };
        
        this.inventories.set(entity, inventory);
        return inventory;
    }

    /**
     * Add item to inventory
     */
    addItem(entity, itemId, quantity = 1) {
        const inventory = this.inventories.get(entity);
        if (!inventory) return false;
        
        const itemData = this.itemDatabase[itemId];
        if (!itemData) return false;
        
        // Check weight/volume limits
        const totalWeight = itemData.weight * quantity;
        if (inventory.currentWeight + totalWeight > inventory.maxWeight) {
            return false; // Too heavy
        }
        
        // Find existing stack or create new
        if (itemData.stackable) {
            const existingItem = inventory.items.find(i => i.itemId === itemId);
            if (existingItem) {
                const newQuantity = existingItem.quantity + quantity;
                if (newQuantity <= itemData.maxStack) {
                    existingItem.quantity = newQuantity;
                    inventory.currentWeight += totalWeight;
                    return true;
                } else {
                    return false; // Stack full
                }
            }
        }
        
        // Add new item
        inventory.items.push({
            itemId: itemId,
            quantity: quantity,
            equipped: false
        });
        
        inventory.currentWeight += totalWeight;
        return true;
    }

    /**
     * Remove item from inventory
     */
    removeItem(entity, itemId, quantity = 1) {
        const inventory = this.inventories.get(entity);
        if (!inventory) return false;
        
        const itemData = this.itemDatabase[itemId];
        if (!itemData) return false;
        
        const itemIndex = inventory.items.findIndex(i => i.itemId === itemId);
        if (itemIndex === -1) return false;
        
        const item = inventory.items[itemIndex];
        
        if (item.quantity < quantity) return false;
        
        item.quantity -= quantity;
        inventory.currentWeight -= itemData.weight * quantity;
        
        // Remove if quantity is 0
        if (item.quantity <= 0) {
            inventory.items.splice(itemIndex, 1);
        }
        
        return true;
    }

    /**
     * Get item quantity
     */
    getItemQuantity(entity, itemId) {
        const inventory = this.inventories.get(entity);
        if (!inventory) return 0;
        
        const item = inventory.items.find(i => i.itemId === itemId);
        return item ? item.quantity : 0;
    }

    /**
     * Add credits
     */
    addCredits(entity, amount) {
        const inventory = this.inventories.get(entity);
        if (!inventory) return false;
        
        inventory.credits += amount;
        return true;
    }

    /**
     * Remove credits
     */
    removeCredits(entity, amount) {
        const inventory = this.inventories.get(entity);
        if (!inventory) return false;
        
        if (inventory.credits < amount) return false;
        
        inventory.credits -= amount;
        return true;
    }

    /**
     * Get credits
     */
    getCredits(entity) {
        const inventory = this.inventories.get(entity);
        return inventory ? inventory.credits : 0;
    }

    /**
     * Equip item
     */
    equipItem(entity, itemId) {
        const inventory = this.inventories.get(entity);
        if (!inventory) return false;
        
        const itemData = this.itemDatabase[itemId];
        if (!itemData || itemData.type !== 'equipment') return false;
        
        const item = inventory.items.find(i => i.itemId === itemId);
        if (!item) return false;
        
        // Unequip current item in slot
        if (inventory.equipment[itemData.slot]) {
            this.unequipItem(entity, itemData.slot);
        }
        
        // Equip new item
        inventory.equipment[itemData.slot] = itemId;
        item.equipped = true;
        
        return true;
    }

    /**
     * Unequip item
     */
    unequipItem(entity, slot) {
        const inventory = this.inventories.get(entity);
        if (!inventory) return false;
        
        const itemId = inventory.equipment[slot];
        if (!itemId) return false;
        
        const item = inventory.items.find(i => i.itemId === itemId);
        if (item) {
            item.equipped = false;
        }
        
        inventory.equipment[slot] = null;
        return true;
    }

    /**
     * Get inventory
     */
    getInventory(entity) {
        return this.inventories.get(entity);
    }

    /**
     * Get item data
     */
    getItemData(itemId) {
        return this.itemDatabase[itemId];
    }

    /**
     * Get all items in inventory
     */
    getItems(entity) {
        const inventory = this.inventories.get(entity);
        if (!inventory) return [];
        
        return inventory.items.map(item => ({
            ...item,
            data: this.itemDatabase[item.itemId]
        }));
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = InventorySystem;
}

