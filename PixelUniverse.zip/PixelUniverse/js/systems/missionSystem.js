/**
 * PixelVerse - Mission System
 * Quest management, objectives, rewards
 * Retro sci-fi mission structure
 */

class MissionSystem {
    constructor(inventorySystem) {
        this.inventorySystem = inventorySystem;
        
        // Active missions for each entity
        this.activeMissions = new Map(); // entity -> array of missions
        
        // Available missions
        this.availableMissions = [];
        
        // Mission templates
        this.missionTemplates = this.createMissionTemplates();
        
        // Generate initial missions
        this.generateMissions(5);
    }

    /**
     * Create mission templates
     */
    createMissionTemplates() {
        return {
            'cargo_delivery': {
                type: 'cargo_delivery',
                name: 'Cargo Delivery',
                description: 'Deliver cargo to destination',
                objectives: [
                    { type: 'deliver', itemId: null, quantity: 0, destination: null }
                ],
                rewards: {
                    credits: 500,
                    reputation: 10
                },
                difficulty: 'easy'
            },
            'bounty_hunt': {
                type: 'bounty_hunt',
                name: 'Bounty Hunt',
                description: 'Eliminate target ship',
                objectives: [
                    { type: 'destroy', targetType: 'enemy', count: 1 }
                ],
                rewards: {
                    credits: 1000,
                    reputation: 20
                },
                difficulty: 'medium'
            },
            'resource_collection': {
                type: 'resource_collection',
                name: 'Resource Collection',
                description: 'Collect resources',
                objectives: [
                    { type: 'collect', itemId: null, quantity: 0 }
                ],
                rewards: {
                    credits: 300,
                    reputation: 5
                },
                difficulty: 'easy'
            },
            'patrol': {
                type: 'patrol',
                name: 'Patrol Route',
                description: 'Patrol designated area',
                objectives: [
                    { type: 'visit', locations: [] }
                ],
                rewards: {
                    credits: 400,
                    reputation: 8
                },
                difficulty: 'easy'
            },
            'escort': {
                type: 'escort',
                name: 'Escort Mission',
                description: 'Escort ship to destination',
                objectives: [
                    { type: 'escort', targetId: null, destination: null }
                ],
                rewards: {
                    credits: 800,
                    reputation: 15
                },
                difficulty: 'medium'
            }
        };
    }

    /**
     * Generate random missions
     */
    generateMissions(count) {
        const templateKeys = Object.keys(this.missionTemplates);
        
        for (let i = 0; i < count; i++) {
            const templateKey = templateKeys[Math.floor(Math.random() * templateKeys.length)];
            const template = this.missionTemplates[templateKey];
            
            const mission = this.createMissionFromTemplate(template);
            this.availableMissions.push(mission);
        }
    }

    /**
     * Create mission from template
     */
    createMissionFromTemplate(template) {
        const mission = {
            id: this.generateMissionId(),
            type: template.type,
            name: template.name,
            description: template.description,
            objectives: JSON.parse(JSON.stringify(template.objectives)), // Deep copy
            rewards: { ...template.rewards },
            difficulty: template.difficulty,
            status: 'available',
            progress: {}
        };
        
        // Customize mission based on type
        switch (template.type) {
            case 'cargo_delivery':
                const items = ['iron_ore', 'copper_ore', 'medical_supplies'];
                const itemId = items[Math.floor(Math.random() * items.length)];
                mission.objectives[0].itemId = itemId;
                mission.objectives[0].quantity = 10 + Math.floor(Math.random() * 20);
                mission.objectives[0].destination = 'trade_hub';
                mission.description = `Deliver ${mission.objectives[0].quantity}x ${itemId} to Trade Hub`;
                break;
                
            case 'resource_collection':
                const resources = ['iron_ore', 'copper_ore', 'titanium_ore'];
                const resourceId = resources[Math.floor(Math.random() * resources.length)];
                mission.objectives[0].itemId = resourceId;
                mission.objectives[0].quantity = 20 + Math.floor(Math.random() * 30);
                mission.description = `Collect ${mission.objectives[0].quantity}x ${resourceId}`;
                break;
                
            case 'bounty_hunt':
                mission.objectives[0].count = 1 + Math.floor(Math.random() * 3);
                mission.description = `Destroy ${mission.objectives[0].count} enemy ships`;
                mission.rewards.credits = 1000 * mission.objectives[0].count;
                break;
        }
        
        return mission;
    }

    /**
     * Generate unique mission ID
     */
    generateMissionId() {
        return 'mission_' + Date.now() + '_' + Math.floor(Math.random() * 10000);
    }

    /**
     * Accept mission
     */
    acceptMission(entity, missionId) {
        const missionIndex = this.availableMissions.findIndex(m => m.id === missionId);
        if (missionIndex === -1) {
            return { success: false, message: 'Mission not found' };
        }
        
        const mission = this.availableMissions[missionIndex];
        
        // Check if player already has this mission
        const activeMissions = this.activeMissions.get(entity) || [];
        if (activeMissions.find(m => m.id === missionId)) {
            return { success: false, message: 'Mission already accepted' };
        }
        
        // Add to active missions
        mission.status = 'active';
        activeMissions.push(mission);
        this.activeMissions.set(entity, activeMissions);
        
        // Remove from available
        this.availableMissions.splice(missionIndex, 1);
        
        return { success: true, message: `Mission accepted: ${mission.name}` };
    }

    /**
     * Complete mission
     */
    completeMission(entity, missionId) {
        const activeMissions = this.activeMissions.get(entity) || [];
        const missionIndex = activeMissions.findIndex(m => m.id === missionId);
        
        if (missionIndex === -1) {
            return { success: false, message: 'Mission not found' };
        }
        
        const mission = activeMissions[missionIndex];
        
        // Check if all objectives are complete
        if (!this.checkMissionComplete(mission)) {
            return { success: false, message: 'Mission objectives not complete' };
        }
        
        // Award rewards
        if (mission.rewards.credits) {
            this.inventorySystem.addCredits(entity, mission.rewards.credits);
        }

        if (mission.rewards.items) {
            for (const itemReward of mission.rewards.items) {
                this.inventorySystem.addItem(entity, itemReward.itemId, itemReward.quantity);
            }
        }

        // Award XP (if callback is set)
        if (this.onMissionComplete) {
            this.onMissionComplete(mission, entity);
        }

        // Remove from active missions
        activeMissions.splice(missionIndex, 1);
        this.activeMissions.set(entity, activeMissions);

        // Generate new mission
        this.generateMissions(1);

        return {
            success: true,
            message: `Mission complete: ${mission.name}`,
            rewards: mission.rewards
        };
    }

    /**
     * Check if mission is complete
     */
    checkMissionComplete(mission) {
        for (const objective of mission.objectives) {
            if (!mission.progress[objective.type]) {
                return false;
            }
            
            switch (objective.type) {
                case 'collect':
                case 'deliver':
                    if (mission.progress[objective.type] < objective.quantity) {
                        return false;
                    }
                    break;
                    
                case 'destroy':
                    if (mission.progress[objective.type] < objective.count) {
                        return false;
                    }
                    break;
            }
        }
        
        return true;
    }

    /**
     * Update mission progress
     */
    updateProgress(entity, objectiveType, value) {
        const activeMissions = this.activeMissions.get(entity) || [];
        
        for (const mission of activeMissions) {
            for (const objective of mission.objectives) {
                if (objective.type === objectiveType) {
                    if (!mission.progress[objectiveType]) {
                        mission.progress[objectiveType] = 0;
                    }
                    mission.progress[objectiveType] += value;
                }
            }
        }
    }

    /**
     * Get active missions
     */
    getActiveMissions(entity) {
        return this.activeMissions.get(entity) || [];
    }

    /**
     * Get available missions
     */
    getAvailableMissions() {
        return this.availableMissions;
    }

    /**
     * Abandon mission
     */
    abandonMission(entity, missionId) {
        const activeMissions = this.activeMissions.get(entity) || [];
        const missionIndex = activeMissions.findIndex(m => m.id === missionId);
        
        if (missionIndex === -1) {
            return { success: false, message: 'Mission not found' };
        }
        
        const mission = activeMissions[missionIndex];
        
        // Remove from active
        activeMissions.splice(missionIndex, 1);
        this.activeMissions.set(entity, activeMissions);
        
        // Add back to available
        mission.status = 'available';
        mission.progress = {};
        this.availableMissions.push(mission);
        
        return { success: true, message: `Mission abandoned: ${mission.name}` };
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = MissionSystem;
}

