/**
 * PixelVerse - Player Progression System
 * Handles player leveling, XP, and progression tracking
 */

class ProgressionSystem {
    constructor() {
        // Player stats
        this.level = 1;
        this.xp = 0;
        this.totalXP = 0;
        this.skillPoints = 0;
        
        // Level configuration
        this.maxLevel = 50;
        this.xpCurve = 1.5; // Exponential curve factor
        this.baseXP = 100; // XP required for level 2
        
        // XP sources and multipliers
        this.xpSources = {
            enemyKill: { base: 50, multiplier: 1.0 },
            missionComplete: { base: 200, multiplier: 1.0 },
            discovery: { base: 100, multiplier: 1.0 },
            trade: { base: 5, multiplier: 1.0 }, // Per 1000 credits
            survival: { base: 5, multiplier: 1.0 } // Per minute
        };
        
        // Level-up rewards
        this.levelUpRewards = {
            credits: (level) => 100 * level,
            skillPoints: (level) => {
                // Bonus skill points at milestones
                if (level % 10 === 0) return 3;
                if (level % 5 === 0) return 2;
                return 1;
            }
        };
        
        // Statistics tracking
        this.stats = {
            enemiesKilled: 0,
            missionsCompleted: 0,
            planetsDiscovered: 0,
            distanceTraveled: 0,
            creditsEarned: 0,
            damageDealt: 0,
            damageTaken: 0,
            timePlayed: 0
        };
        
        // Level-up callback
        this.onLevelUp = null;
        
        // XP gain callback (for notifications)
        this.onXPGain = null;
    }

    /**
     * Calculate XP required for a specific level
     */
    getXPForLevel(level) {
        if (level <= 1) return 0;
        return Math.floor(this.baseXP * Math.pow(level, this.xpCurve));
    }

    /**
     * Get XP required for next level
     */
    getXPForNextLevel() {
        return this.getXPForLevel(this.level + 1);
    }

    /**
     * Get XP required for current level
     */
    getXPForCurrentLevel() {
        return this.getXPForLevel(this.level);
    }

    /**
     * Get XP progress percentage for current level
     */
    getXPProgress() {
        if (this.level >= this.maxLevel) return 1.0;
        
        const currentLevelXP = this.getXPForCurrentLevel();
        const nextLevelXP = this.getXPForNextLevel();
        const xpIntoLevel = this.totalXP - currentLevelXP;
        const xpNeeded = nextLevelXP - currentLevelXP;
        
        return Math.min(1.0, xpIntoLevel / xpNeeded);
    }

    /**
     * Get XP remaining until next level
     */
    getXPRemaining() {
        if (this.level >= this.maxLevel) return 0;
        return this.getXPForNextLevel() - this.totalXP;
    }

    /**
     * Award XP to player
     */
    awardXP(amount, source = 'unknown') {
        if (this.level >= this.maxLevel) return;
        
        // Apply multiplier if source is known
        if (this.xpSources[source]) {
            amount *= this.xpSources[source].multiplier;
        }
        
        amount = Math.floor(amount);
        this.xp += amount;
        this.totalXP += amount;
        
        // Trigger XP gain callback
        if (this.onXPGain) {
            this.onXPGain(amount, source);
        }
        
        // Check for level up
        this.checkLevelUp();
    }

    /**
     * Award XP for enemy kill
     */
    awardKillXP(enemyType = 'basic', enemyLevel = 1) {
        const baseXP = this.xpSources.enemyKill.base;
        const levelMultiplier = 1 + (enemyLevel - 1) * 0.2;
        
        // Enemy type multipliers
        const typeMultipliers = {
            basic: 1.0,
            elite: 1.5,
            boss: 3.0,
            miniboss: 2.0
        };
        
        const typeMultiplier = typeMultipliers[enemyType] || 1.0;
        const xp = baseXP * levelMultiplier * typeMultiplier;
        
        this.stats.enemiesKilled++;
        this.awardXP(xp, 'enemyKill');
    }

    /**
     * Award XP for mission completion
     */
    awardMissionXP(difficulty = 'normal', success = true) {
        const baseXP = this.xpSources.missionComplete.base;
        
        // Difficulty multipliers
        const difficultyMultipliers = {
            easy: 0.7,
            normal: 1.0,
            hard: 1.5,
            extreme: 2.0
        };
        
        const difficultyMultiplier = difficultyMultipliers[difficulty] || 1.0;
        const successMultiplier = success ? 1.0 : 0.5;
        const xp = baseXP * difficultyMultiplier * successMultiplier;
        
        if (success) {
            this.stats.missionsCompleted++;
        }
        
        this.awardXP(xp, 'missionComplete');
    }

    /**
     * Award XP for discovery
     */
    awardDiscoveryXP(discoveryType = 'planet') {
        const baseXP = this.xpSources.discovery.base;
        
        // Discovery type multipliers
        const typeMultipliers = {
            planet: 1.0,
            station: 1.2,
            anomaly: 1.5,
            artifact: 2.0,
            secret: 3.0
        };
        
        const typeMultiplier = typeMultipliers[discoveryType] || 1.0;
        const xp = baseXP * typeMultiplier;
        
        if (discoveryType === 'planet') {
            this.stats.planetsDiscovered++;
        }
        
        this.awardXP(xp, 'discovery');
    }

    /**
     * Award XP for trading
     */
    awardTradeXP(profit) {
        const xpPerThousand = this.xpSources.trade.base;
        const xp = (profit / 1000) * xpPerThousand;
        
        this.stats.creditsEarned += profit;
        this.awardXP(xp, 'trade');
    }

    /**
     * Award XP for survival time
     */
    awardSurvivalXP(minutes) {
        const xpPerMinute = this.xpSources.survival.base;
        const xp = minutes * xpPerMinute;
        
        this.awardXP(xp, 'survival');
    }

    /**
     * Check if player should level up
     */
    checkLevelUp() {
        if (this.level >= this.maxLevel) return;
        
        const xpNeeded = this.getXPForNextLevel();
        
        while (this.totalXP >= xpNeeded && this.level < this.maxLevel) {
            this.levelUp();
        }
    }

    /**
     * Level up the player
     */
    levelUp() {
        this.level++;
        
        // Award skill points
        const skillPointsGained = this.levelUpRewards.skillPoints(this.level);
        this.skillPoints += skillPointsGained;
        
        // Award credits (if game has credit system)
        const creditsGained = this.levelUpRewards.credits(this.level);
        
        // Trigger level-up callback
        if (this.onLevelUp) {
            this.onLevelUp(this.level, {
                skillPoints: skillPointsGained,
                credits: creditsGained
            });
        }
        
        console.log(`Level Up! Now level ${this.level}`);
        console.log(`Gained ${skillPointsGained} skill points`);
        console.log(`Gained ${creditsGained} credits`);
    }

    /**
     * Spend skill points
     */
    spendSkillPoints(amount) {
        if (this.skillPoints >= amount) {
            this.skillPoints -= amount;
            return true;
        }
        return false;
    }

    /**
     * Update statistics
     */
    updateStat(stat, value) {
        if (this.stats.hasOwnProperty(stat)) {
            this.stats[stat] += value;
        }
    }

    /**
     * Get player statistics
     */
    getStats() {
        return { ...this.stats };
    }

    /**
     * Get progression summary
     */
    getSummary() {
        return {
            level: this.level,
            xp: this.xp,
            totalXP: this.totalXP,
            xpForNextLevel: this.getXPForNextLevel(),
            xpRemaining: this.getXPRemaining(),
            xpProgress: this.getXPProgress(),
            skillPoints: this.skillPoints,
            stats: this.getStats()
        };
    }

    /**
     * Save progression data
     */
    save() {
        return {
            level: this.level,
            xp: this.xp,
            totalXP: this.totalXP,
            skillPoints: this.skillPoints,
            stats: this.stats
        };
    }

    /**
     * Load progression data
     */
    load(data) {
        if (!data) return;
        
        this.level = data.level || 1;
        this.xp = data.xp || 0;
        this.totalXP = data.totalXP || 0;
        this.skillPoints = data.skillPoints || 0;
        
        if (data.stats) {
            this.stats = { ...this.stats, ...data.stats };
        }
    }

    /**
     * Reset progression (for testing or new game+)
     */
    reset() {
        this.level = 1;
        this.xp = 0;
        this.totalXP = 0;
        this.skillPoints = 0;
        
        // Reset stats
        for (const key in this.stats) {
            this.stats[key] = 0;
        }
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ProgressionSystem;
}

