/**
 * PixelVerse - Warp Drive System
 * FTL travel with charge-up, warp tunnel effects, and cooldown
 * Retro sci-fi aesthetic with visual and audio feedback
 */

class WarpDriveSystem {
    constructor(visualEffects, audioManager) {
        this.visualEffects = visualEffects;
        this.audioManager = audioManager;
        
        // Warp states
        this.warpStates = new Map(); // entity -> warp state
    }

    /**
     * Initialize warp drive for entity
     */
    initializeWarpDrive(entity, chargeTime = 2.0, cooldownTime = 5.0, warpSpeed = 2000) {
        this.warpStates.set(entity, {
            state: 'idle',           // idle, charging, warping, cooldown
            chargeTime: chargeTime,  // Time to charge warp
            chargeProgress: 0,       // 0-1
            warpDuration: 1.0,       // Duration of warp
            warpProgress: 0,         // 0-1
            cooldownTime: cooldownTime,
            cooldownProgress: 0,     // 0-1
            warpSpeed: warpSpeed,    // Speed during warp
            targetX: 0,
            targetY: 0,
            originalVelocity: { vx: 0, vy: 0 }
        });
    }

    /**
     * Start charging warp drive
     */
    startWarpCharge(entity, targetX, targetY) {
        const warpState = this.warpStates.get(entity);
        if (!warpState) return false;
        
        // Can only charge if idle
        if (warpState.state !== 'idle') return false;
        
        // Store target and original velocity
        const velocity = entity.getComponent('velocity');
        if (velocity) {
            warpState.originalVelocity.vx = velocity.vx;
            warpState.originalVelocity.vy = velocity.vy;
        }
        
        warpState.targetX = targetX;
        warpState.targetY = targetY;
        warpState.state = 'charging';
        warpState.chargeProgress = 0;
        
        // Visual effect - warp charge
        const transform = entity.getComponent('transform');
        if (transform && this.visualEffects) {
            this.visualEffects.createWarpCharge(transform.x, transform.y, warpState.chargeTime);
        }
        
        return true;
    }

    /**
     * Cancel warp charge
     */
    cancelWarpCharge(entity) {
        const warpState = this.warpStates.get(entity);
        if (!warpState) return;
        
        if (warpState.state === 'charging') {
            warpState.state = 'idle';
            warpState.chargeProgress = 0;
        }
    }

    /**
     * Update warp drive system
     */
    update(deltaTime) {
        for (const [entity, warpState] of this.warpStates) {
            switch (warpState.state) {
                case 'charging':
                    this.updateCharging(entity, warpState, deltaTime);
                    break;
                    
                case 'warping':
                    this.updateWarping(entity, warpState, deltaTime);
                    break;
                    
                case 'cooldown':
                    this.updateCooldown(entity, warpState, deltaTime);
                    break;
            }
        }
    }

    /**
     * Update charging state
     */
    updateCharging(entity, warpState, deltaTime) {
        warpState.chargeProgress += deltaTime / warpState.chargeTime;
        
        if (warpState.chargeProgress >= 1.0) {
            // Charge complete - start warp
            this.startWarp(entity, warpState);
        }
    }

    /**
     * Start warp
     */
    startWarp(entity, warpState) {
        warpState.state = 'warping';
        warpState.warpProgress = 0;
        
        const transform = entity.getComponent('transform');
        const velocity = entity.getComponent('velocity');
        
        if (!transform || !velocity) return;
        
        // Calculate warp direction
        const dx = warpState.targetX - transform.x;
        const dy = warpState.targetY - transform.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance > 0) {
            // Set velocity to warp speed in direction of target
            velocity.vx = (dx / distance) * warpState.warpSpeed;
            velocity.vy = (dy / distance) * warpState.warpSpeed;
        }
        
        // Visual effect - warp tunnel
        if (this.visualEffects) {
            this.visualEffects.createWarpTunnel(transform.x, transform.y, Math.atan2(dy, dx), warpState.warpDuration);
        }
        
        // Audio effect
        if (this.audioManager) {
            // Play warp sound (to be implemented)
        }
    }

    /**
     * Update warping state
     */
    updateWarping(entity, warpState, deltaTime) {
        warpState.warpProgress += deltaTime / warpState.warpDuration;
        
        if (warpState.warpProgress >= 1.0) {
            // Warp complete - start cooldown
            this.endWarp(entity, warpState);
        }
    }

    /**
     * End warp
     */
    endWarp(entity, warpState) {
        warpState.state = 'cooldown';
        warpState.cooldownProgress = 0;
        
        const velocity = entity.getComponent('velocity');
        if (velocity) {
            // Restore original velocity (or reduce it)
            velocity.vx = warpState.originalVelocity.vx * 0.5;
            velocity.vy = warpState.originalVelocity.vy * 0.5;
        }
    }

    /**
     * Update cooldown state
     */
    updateCooldown(entity, warpState, deltaTime) {
        warpState.cooldownProgress += deltaTime / warpState.cooldownTime;
        
        if (warpState.cooldownProgress >= 1.0) {
            // Cooldown complete - back to idle
            warpState.state = 'idle';
            warpState.cooldownProgress = 0;
        }
    }

    /**
     * Get warp state for entity
     */
    getWarpState(entity) {
        return this.warpStates.get(entity);
    }

    /**
     * Check if entity can warp
     */
    canWarp(entity) {
        const warpState = this.warpStates.get(entity);
        return warpState && warpState.state === 'idle';
    }

    /**
     * Get charge progress (0-1)
     */
    getChargeProgress(entity) {
        const warpState = this.warpStates.get(entity);
        if (!warpState) return 0;
        
        if (warpState.state === 'charging') {
            return warpState.chargeProgress;
        }
        
        return 0;
    }

    /**
     * Get cooldown progress (0-1)
     */
    getCooldownProgress(entity) {
        const warpState = this.warpStates.get(entity);
        if (!warpState) return 0;
        
        if (warpState.state === 'cooldown') {
            return warpState.cooldownProgress;
        }
        
        return 0;
    }

    /**
     * Render warp UI indicators
     */
    renderWarpIndicator(renderer, entity, x, y) {
        const warpState = this.warpStates.get(entity);
        if (!warpState) return;
        
        const ctx = renderer.context;
        
        // Render based on state
        switch (warpState.state) {
            case 'charging':
                // Charging bar
                ctx.fillStyle = 'rgba(100, 200, 255, 0.5)';
                ctx.fillRect(x - 20, y - 30, 40 * warpState.chargeProgress, 4);
                ctx.strokeStyle = 'rgba(100, 200, 255, 0.8)';
                ctx.strokeRect(x - 20, y - 30, 40, 4);
                break;
                
            case 'warping':
                // Warp active indicator
                ctx.fillStyle = 'rgba(100, 200, 255, 0.8)';
                ctx.fillRect(x - 3, y - 30, 6, 6);
                break;
                
            case 'cooldown':
                // Cooldown bar
                ctx.fillStyle = 'rgba(255, 100, 100, 0.5)';
                ctx.fillRect(x - 20, y - 30, 40 * (1 - warpState.cooldownProgress), 4);
                ctx.strokeStyle = 'rgba(255, 100, 100, 0.8)';
                ctx.strokeRect(x - 20, y - 30, 40, 4);
                break;
        }
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = WarpDriveSystem;
}

