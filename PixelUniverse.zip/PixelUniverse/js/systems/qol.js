/**
 * PixelVerse - Quality of Life Improvements
 * Auto-save, tutorials, hints, shortcuts, and convenience features
 */

class QualityOfLife {
    constructor() {
        // Auto-save
        this.autoSaveEnabled = true;
        this.autoSaveInterval = 60000; // 1 minute
        this.lastAutoSave = Date.now();
        
        // Tutorials
        this.tutorialsEnabled = true;
        this.tutorialsShown = new Set();
        
        // Hints
        this.hintsEnabled = true;
        this.hintQueue = [];
        this.currentHint = null;
        this.hintDuration = 5000; // 5 seconds
        this.hintTimer = 0;
        
        // Shortcuts
        this.shortcuts = {
            'toggleHUD': 'F1',
            'toggleTerminal': '`',
            'toggleMap': 'M',
            'quickSave': 'F5',
            'quickLoad': 'F9',
            'screenshot': 'F12',
            'toggleFullscreen': 'F11'
        };
        
        // Notifications
        this.notifications = [];
        this.maxNotifications = 5;
        
        // Settings
        this.settings = {
            showFPS: true,
            showHints: true,
            showTutorials: true,
            autoSave: true,
            confirmQuit: true,
            pauseOnFocusLoss: true
        };
    }

    /**
     * Update QoL systems
     */
    update(deltaTime) {
        // Auto-save
        if (this.autoSaveEnabled && Date.now() - this.lastAutoSave > this.autoSaveInterval) {
            this.autoSave();
        }
        
        // Update hint timer
        if (this.currentHint) {
            this.hintTimer += deltaTime * 1000;
            if (this.hintTimer >= this.hintDuration) {
                this.currentHint = null;
                this.hintTimer = 0;
                
                // Show next hint
                if (this.hintQueue.length > 0) {
                    this.showHint(this.hintQueue.shift());
                }
            }
        }
        
        // Update notifications
        for (let i = this.notifications.length - 1; i >= 0; i--) {
            this.notifications[i].timer += deltaTime * 1000;
            if (this.notifications[i].timer >= this.notifications[i].duration) {
                this.notifications.splice(i, 1);
            }
        }
    }

    /**
     * Auto-save game
     */
    autoSave() {
        if (!this.autoSaveEnabled) return;
        
        try {
            // Save to localStorage
            const saveData = this.createSaveData();
            localStorage.setItem('pixelverse_autosave', JSON.stringify(saveData));
            this.lastAutoSave = Date.now();
            this.showNotification('Game auto-saved', 'success', 2000);
            console.log('Auto-save complete');
        } catch (error) {
            console.error('Auto-save failed:', error);
            this.showNotification('Auto-save failed', 'error', 3000);
        }
    }

    /**
     * Create save data
     */
    createSaveData() {
        return {
            timestamp: Date.now(),
            version: '1.1.0',
            // Add game state data here
            player: {
                credits: 1000,
                position: { x: 0, y: 0 },
                health: 100,
                shield: 100
            },
            settings: this.settings
        };
    }

    /**
     * Load save data
     */
    loadSave() {
        try {
            const saveData = localStorage.getItem('pixelverse_autosave');
            if (saveData) {
                const data = JSON.parse(saveData);
                console.log('Save loaded:', data);
                this.showNotification('Game loaded', 'success', 2000);
                return data;
            }
        } catch (error) {
            console.error('Load failed:', error);
            this.showNotification('Load failed', 'error', 3000);
        }
        return null;
    }

    /**
     * Show tutorial
     */
    showTutorial(tutorialId, message) {
        if (!this.tutorialsEnabled) return;
        if (this.tutorialsShown.has(tutorialId)) return;
        
        this.tutorialsShown.add(tutorialId);
        this.showNotification(message, 'tutorial', 10000);
        console.log('Tutorial:', tutorialId, message);
    }

    /**
     * Show hint
     */
    showHint(message) {
        if (!this.hintsEnabled) return;
        
        if (this.currentHint) {
            // Queue hint
            this.hintQueue.push(message);
        } else {
            this.currentHint = message;
            this.hintTimer = 0;
        }
    }

    /**
     * Show notification
     */
    showNotification(message, type = 'info', duration = 3000) {
        const notification = {
            message: message,
            type: type, // info, success, warning, error, tutorial
            duration: duration,
            timer: 0
        };
        
        this.notifications.push(notification);
        
        // Limit notifications
        if (this.notifications.length > this.maxNotifications) {
            this.notifications.shift();
        }
    }

    /**
     * Get current hint
     */
    getCurrentHint() {
        return this.currentHint;
    }

    /**
     * Get notifications
     */
    getNotifications() {
        return this.notifications;
    }

    /**
     * Clear notifications
     */
    clearNotifications() {
        this.notifications = [];
    }

    /**
     * Toggle setting
     */
    toggleSetting(setting) {
        if (this.settings[setting] !== undefined) {
            this.settings[setting] = !this.settings[setting];
            this.showNotification(`${setting}: ${this.settings[setting] ? 'ON' : 'OFF'}`, 'info', 2000);
            return this.settings[setting];
        }
        return null;
    }

    /**
     * Get shortcut key
     */
    getShortcut(action) {
        return this.shortcuts[action] || null;
    }

    /**
     * Set shortcut key
     */
    setShortcut(action, key) {
        if (this.shortcuts[action] !== undefined) {
            this.shortcuts[action] = key;
            this.showNotification(`Shortcut ${action} set to ${key}`, 'success', 2000);
            return true;
        }
        return false;
    }

    /**
     * Show contextual hints based on game state
     */
    checkContextualHints(gameState) {
        // Low health hint
        if (gameState.playerHealth < 30 && !this.tutorialsShown.has('low_health')) {
            this.showTutorial('low_health', 'WARNING: Hull integrity critical! Find a station to repair.');
        }
        
        // Low fuel hint
        if (gameState.fuel < 20 && !this.tutorialsShown.has('low_fuel')) {
            this.showTutorial('low_fuel', 'HINT: Fuel running low. Purchase fuel cells at a station.');
        }
        
        // Weapon overheat hint
        if (gameState.weaponOverheated && !this.tutorialsShown.has('weapon_overheat')) {
            this.showTutorial('weapon_overheat', 'HINT: Weapons overheated! Wait for cooling or manage fire rate.');
        }
        
        // First enemy encounter
        if (gameState.enemyNearby && !this.tutorialsShown.has('first_combat')) {
            this.showTutorial('first_combat', 'COMBAT: Enemy detected! Use SPACE to fire weapons.');
        }
        
        // First station approach
        if (gameState.nearStation && !this.tutorialsShown.has('first_station')) {
            this.showTutorial('first_station', 'STATION: Press ` to open terminal and access trading.');
        }
    }

    /**
     * Export settings
     */
    exportSettings() {
        return {
            settings: this.settings,
            shortcuts: this.shortcuts,
            tutorialsShown: Array.from(this.tutorialsShown)
        };
    }

    /**
     * Import settings
     */
    importSettings(data) {
        if (data.settings) this.settings = data.settings;
        if (data.shortcuts) this.shortcuts = data.shortcuts;
        if (data.tutorialsShown) this.tutorialsShown = new Set(data.tutorialsShown);
        this.showNotification('Settings imported', 'success', 2000);
    }
}

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = QualityOfLife;
}

