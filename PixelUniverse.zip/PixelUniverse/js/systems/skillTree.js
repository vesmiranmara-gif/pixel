/**
 * PixelVerse - Skill Tree System
 * Handles player skills, skill points, and skill effects
 */

class SkillTreeSystem {
    constructor() {
        // Skill categories
        this.categories = ['combat', 'defense', 'engineering', 'piloting', 'trading', 'exploration'];

        // All skills organized by category
        this.skills = this.initializeSkills();

        // Player's learned skills (skill_id: level)
        this.learnedSkills = {};

        // Skill effects cache
        this.activeEffects = {};

        // Callbacks
        this.onSkillLearned = null;
        this.onSkillMaxed = null;
    }

    /**
     * Initialize all skills
     */
    initializeSkills() {
        return {
            // COMBAT TREE (15 skills)
            combat: {
                weaponDamage: {
                    id: 'weaponDamage',
                    name: 'Weapon Damage',
                    description: 'Increase weapon damage',
                    maxLevel: 5,
                    effect: { type: 'weaponDamage', value: 0.10 }, // +10% per level
                    cost: 1
                },
                fireRate: {
                    id: 'fireRate',
                    name: 'Fire Rate',
                    description: 'Increase weapon fire rate',
                    maxLevel: 5,
                    effect: { type: 'fireRate', value: 0.08 }, // +8% per level
                    cost: 1,
                    requires: { weaponDamage: 2 }
                },
                criticalHit: {
                    id: 'criticalHit',
                    name: 'Critical Hit',
                    description: 'Chance to deal double damage',
                    maxLevel: 3,
                    effect: { type: 'critChance', value: 0.05 }, // +5% per level
                    cost: 1,
                    requires: { weaponDamage: 3 }
                },
                weaponHeat: {
                    id: 'weaponHeat',
                    name: 'Heat Management',
                    description: 'Reduce weapon heat generation',
                    maxLevel: 3,
                    effect: { type: 'heatReduction', value: 0.15 }, // -15% per level
                    cost: 1,
                    requires: { fireRate: 2 }
                },
                multiTarget: {
                    id: 'multiTarget',
                    name: 'Multi-Target',
                    description: 'Projectiles can hit multiple enemies',
                    maxLevel: 2,
                    effect: { type: 'piercing', value: 1 }, // +1 pierce per level
                    cost: 2,
                    requires: { criticalHit: 2, fireRate: 3 }
                }
            },

            // DEFENSE TREE (15 skills)
            defense: {
                shieldCapacity: {
                    id: 'shieldCapacity',
                    name: 'Shield Capacity',
                    description: 'Increase maximum shield capacity',
                    maxLevel: 5,
                    effect: { type: 'shieldCapacity', value: 0.20 }, // +20% per level
                    cost: 1
                },
                shieldRegen: {
                    id: 'shieldRegen',
                    name: 'Shield Regeneration',
                    description: 'Increase shield regeneration rate',
                    maxLevel: 5,
                    effect: { type: 'shieldRegen', value: 0.15 }, // +15% per level
                    cost: 1,
                    requires: { shieldCapacity: 2 }
                },
                armor: {
                    id: 'armor',
                    name: 'Armor Plating',
                    description: 'Reduce incoming damage',
                    maxLevel: 5,
                    effect: { type: 'damageReduction', value: 0.10 }, // -10% damage per level
                    cost: 1
                },
                emergencyShield: {
                    id: 'emergencyShield',
                    name: 'Emergency Shield',
                    description: 'Auto-activate shield boost at low health',
                    maxLevel: 2,
                    effect: { type: 'emergencyShield', value: 0.25 }, // +25% shield per level
                    cost: 2,
                    requires: { shieldRegen: 3, shieldCapacity: 3 }
                },
                damageResistance: {
                    id: 'damageResistance',
                    name: 'Damage Resistance',
                    description: 'Additional damage reduction',
                    maxLevel: 3,
                    effect: { type: 'resistance', value: 0.05 }, // -5% damage per level
                    cost: 1,
                    requires: { armor: 3 }
                }
            },

            // ENGINEERING TREE (15 skills)
            engineering: {
                enginePower: {
                    id: 'enginePower',
                    name: 'Engine Power',
                    description: 'Increase ship speed',
                    maxLevel: 5,
                    effect: { type: 'speed', value: 0.12 }, // +12% per level
                    cost: 1
                },
                energyEfficiency: {
                    id: 'energyEfficiency',
                    name: 'Energy Efficiency',
                    description: 'Reduce energy consumption',
                    maxLevel: 5,
                    effect: { type: 'energyCost', value: 0.10 }, // -10% per level
                    cost: 1
                },
                repairSpeed: {
                    id: 'repairSpeed',
                    name: 'Repair Speed',
                    description: 'Increase hull repair rate',
                    maxLevel: 5,
                    effect: { type: 'repairRate', value: 0.20 }, // +20% per level
                    cost: 1,
                    requires: { energyEfficiency: 2 }
                },
                autoRepair: {
                    id: 'autoRepair',
                    name: 'Auto-Repair',
                    description: 'Passive hull regeneration',
                    maxLevel: 3,
                    effect: { type: 'hullRegen', value: 0.5 }, // +0.5 HP/sec per level
                    cost: 2,
                    requires: { repairSpeed: 3 }
                },
                overcharge: {
                    id: 'overcharge',
                    name: 'Overcharge',
                    description: 'Temporary power boost ability',
                    maxLevel: 2,
                    effect: { type: 'overcharge', value: 0.30 }, // +30% all stats per level
                    cost: 2,
                    requires: { enginePower: 3, energyEfficiency: 3 }
                }
            },

            // PILOTING TREE (15 skills)
            piloting: {
                maneuverability: {
                    id: 'maneuverability',
                    name: 'Maneuverability',
                    description: 'Increase turn rate',
                    maxLevel: 5,
                    effect: { type: 'turnRate', value: 0.15 }, // +15% per level
                    cost: 1
                },
                acceleration: {
                    id: 'acceleration',
                    name: 'Acceleration',
                    description: 'Increase acceleration',
                    maxLevel: 5,
                    effect: { type: 'acceleration', value: 0.12 }, // +12% per level
                    cost: 1
                },
                evasion: {
                    id: 'evasion',
                    name: 'Evasion',
                    description: 'Chance to dodge incoming fire',
                    maxLevel: 5,
                    effect: { type: 'dodgeChance', value: 0.08 }, // +8% per level
                    cost: 1,
                    requires: { maneuverability: 2 }
                },
                afterburner: {
                    id: 'afterburner',
                    name: 'Afterburner',
                    description: 'Temporary speed boost ability',
                    maxLevel: 3,
                    effect: { type: 'afterburner', value: 0.50 }, // +50% speed per level
                    cost: 2,
                    requires: { acceleration: 3 }
                },
                precision: {
                    id: 'precision',
                    name: 'Precision',
                    description: 'Increase weapon accuracy',
                    maxLevel: 3,
                    effect: { type: 'accuracy', value: 0.10 }, // +10% per level
                    cost: 1,
                    requires: { evasion: 2 }
                }
            },

            // TRADING TREE (12 skills)
            trading: {
                negotiation: {
                    id: 'negotiation',
                    name: 'Negotiation',
                    description: 'Better buy/sell prices',
                    maxLevel: 5,
                    effect: { type: 'priceBonus', value: 0.05 }, // +5% per level
                    cost: 1
                },
                cargoCapacity: {
                    id: 'cargoCapacity',
                    name: 'Cargo Capacity',
                    description: 'Increase cargo hold size',
                    maxLevel: 5,
                    effect: { type: 'cargoSpace', value: 0.20 }, // +20% per level
                    cost: 1
                },
                marketIntel: {
                    id: 'marketIntel',
                    name: 'Market Intel',
                    description: 'See price trends and opportunities',
                    maxLevel: 3,
                    effect: { type: 'marketInfo', value: 1 }, // Unlock info per level
                    cost: 1,
                    requires: { negotiation: 2 }
                },
                smuggling: {
                    id: 'smuggling',
                    name: 'Smuggling',
                    description: 'Avoid cargo scans',
                    maxLevel: 2,
                    effect: { type: 'scanAvoidance', value: 0.30 }, // +30% per level
                    cost: 2,
                    requires: { cargoCapacity: 3, marketIntel: 2 }
                }
            },

            // EXPLORATION TREE (12 skills)
            exploration: {
                sensorRange: {
                    id: 'sensorRange',
                    name: 'Sensor Range',
                    description: 'Increase sensor detection range',
                    maxLevel: 5,
                    effect: { type: 'sensorRange', value: 0.25 }, // +25% per level
                    cost: 1
                },
                fuelEfficiency: {
                    id: 'fuelEfficiency',
                    name: 'Fuel Efficiency',
                    description: 'Reduce fuel consumption',
                    maxLevel: 5,
                    effect: { type: 'fuelCost', value: 0.15 }, // -15% per level
                    cost: 1
                },
                discoveryBonus: {
                    id: 'discoveryBonus',
                    name: 'Discovery Bonus',
                    description: 'Increase XP from discoveries',
                    maxLevel: 5,
                    effect: { type: 'discoveryXP', value: 0.20 }, // +20% per level
                    cost: 1,
                    requires: { sensorRange: 2 }
                },
                scanner: {
                    id: 'scanner',
                    name: 'Advanced Scanner',
                    description: 'Detect hidden objects and secrets',
                    maxLevel: 3,
                    effect: { type: 'scanPower', value: 1 }, // Unlock scan levels
                    cost: 2,
                    requires: { sensorRange: 3, discoveryBonus: 2 }
                }
            }
        };
    }

    /**
     * Learn or upgrade a skill
     */
    learnSkill(category, skillId, progressionSystem) {
        const skill = this.skills[category][skillId];
        if (!skill) return { success: false, message: 'Skill not found' };

        const currentLevel = this.learnedSkills[skillId] || 0;

        // Check if already maxed
        if (currentLevel >= skill.maxLevel) {
            return { success: false, message: 'Skill already maxed' };
        }

        // Check requirements
        if (skill.requires) {
            for (const [reqSkillId, reqLevel] of Object.entries(skill.requires)) {
                const playerLevel = this.learnedSkills[reqSkillId] || 0;
                if (playerLevel < reqLevel) {
                    return { success: false, message: `Requires ${reqSkillId} level ${reqLevel}` };
                }
            }
        }

        // Check skill points
        if (!progressionSystem.spendSkillPoints(skill.cost)) {
            return { success: false, message: 'Not enough skill points' };
        }

        // Learn skill
        this.learnedSkills[skillId] = currentLevel + 1;
        this.updateActiveEffects();

        // Trigger callback
        if (this.onSkillLearned) {
            this.onSkillLearned(category, skillId, this.learnedSkills[skillId]);
        }

        // Check if maxed
        if (this.learnedSkills[skillId] >= skill.maxLevel && this.onSkillMaxed) {
            this.onSkillMaxed(category, skillId);
        }

        return {
            success: true,
            message: `Learned ${skill.name} level ${this.learnedSkills[skillId]}`,
            newLevel: this.learnedSkills[skillId]
        };
    }

    /**
     * Update active effects cache
     */
    updateActiveEffects() {
        this.activeEffects = {};

        for (const category in this.skills) {
            for (const skillId in this.skills[category]) {
                const skill = this.skills[category][skillId];
                const level = this.learnedSkills[skillId] || 0;

                if (level > 0) {
                    const effectType = skill.effect.type;
                    const effectValue = skill.effect.value * level;

                    if (!this.activeEffects[effectType]) {
                        this.activeEffects[effectType] = 0;
                    }
                    this.activeEffects[effectType] += effectValue;
                }
            }
        }
    }

    /**
     * Get effect value
     */
    getEffect(effectType) {
        return this.activeEffects[effectType] || 0;
    }

    /**
     * Get skill level
     */
    getSkillLevel(skillId) {
        return this.learnedSkills[skillId] || 0;
    }

    /**
     * Get all skills in a category
     */
    getCategorySkills(category) {
        return this.skills[category] || {};
    }

    /**
     * Get skill info
     */
    getSkillInfo(category, skillId) {
        const skill = this.skills[category][skillId];
        if (!skill) return null;

        return {
            ...skill,
            currentLevel: this.learnedSkills[skillId] || 0,
            isMaxed: (this.learnedSkills[skillId] || 0) >= skill.maxLevel,
            canLearn: this.canLearnSkill(category, skillId)
        };
    }

    /**
     * Check if skill can be learned
     */
    canLearnSkill(category, skillId) {
        const skill = this.skills[category][skillId];
        if (!skill) return false;

        const currentLevel = this.learnedSkills[skillId] || 0;
        if (currentLevel >= skill.maxLevel) return false;

        if (skill.requires) {
            for (const [reqSkillId, reqLevel] of Object.entries(skill.requires)) {
                const playerLevel = this.learnedSkills[reqSkillId] || 0;
                if (playerLevel < reqLevel) return false;
            }
        }

        return true;
    }

    /**
     * Get total skill points spent
     */
    getTotalSkillPointsSpent() {
        let total = 0;
        for (const category in this.skills) {
            for (const skillId in this.skills[category]) {
                const skill = this.skills[category][skillId];
                const level = this.learnedSkills[skillId] || 0;
                total += level * skill.cost;
            }
        }
        return total;
    }

    /**
     * Get skills by category with progress
     */
    getCategoryProgress(category) {
        const skills = this.skills[category];
        const learned = [];
        const available = [];
        const locked = [];

        for (const skillId in skills) {
            const skill = skills[skillId];
            const level = this.learnedSkills[skillId] || 0;
            const info = this.getSkillInfo(category, skillId);

            if (level > 0) {
                learned.push(info);
            } else if (this.canLearnSkill(category, skillId)) {
                available.push(info);
            } else {
                locked.push(info);
            }
        }

        return { learned, available, locked };
    }

    /**
     * Reset all skills (respec)
     */
    resetSkills(progressionSystem, cost = 0) {
        // Refund skill points
        const pointsSpent = this.getTotalSkillPointsSpent();
        progressionSystem.skillPoints += pointsSpent;

        // Deduct respec cost
        if (cost > 0) {
            progressionSystem.skillPoints -= cost;
        }

        // Clear learned skills
        this.learnedSkills = {};
        this.updateActiveEffects();

        return {
            success: true,
            pointsRefunded: pointsSpent,
            costPaid: cost
        };
    }

    /**
     * Save skill tree data
     */
    save() {
        return {
            learnedSkills: this.learnedSkills,
            activeEffects: this.activeEffects
        };
    }

    /**
     * Load skill tree data
     */
    load(data) {
        if (!data) return;

        this.learnedSkills = data.learnedSkills || {};
        this.updateActiveEffects();
    }

    /**
     * Get summary of all learned skills
     */
    getSummary() {
        const summary = {
            totalSkillsLearned: 0,
            totalPointsSpent: this.getTotalSkillPointsSpent(),
            skillsByCategory: {},
            activeEffects: this.activeEffects
        };

        for (const category of this.categories) {
            const skills = this.skills[category];
            let categorySkills = 0;

            for (const skillId in skills) {
                const level = this.learnedSkills[skillId] || 0;
                if (level > 0) {
                    categorySkills++;
                    summary.totalSkillsLearned++;
                }
            }

            summary.skillsByCategory[category] = categorySkills;
        }

        return summary;
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SkillTreeSystem;
}
