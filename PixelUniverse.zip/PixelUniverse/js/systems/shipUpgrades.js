/**
 * PixelVerse - Ship Upgrade System
 * Handles ship component upgrades, tiers, and stat bonuses
 */

class ShipUpgradeSystem {
    constructor(inventorySystem) {
        this.inventorySystem = inventorySystem;

        // Upgrade components
        this.components = ['weapons', 'shields', 'engines', 'hull', 'sensors'];

        // Upgrade tiers (1-5)
        this.tiers = this.initializeTiers();

        // Player's current upgrades (component: tier)
        this.currentUpgrades = {
            weapons: 1,
            shields: 1,
            engines: 1,
            hull: 1,
            sensors: 1
        };

        // Callbacks
        this.onUpgrade = null;
        this.onMaxTier = null;
    }

    /**
     * Initialize upgrade tiers
     */
    initializeTiers() {
        return {
            weapons: {
                1: {
                    tier: 1,
                    name: 'Basic Weapons',
                    description: 'Standard laser weapons',
                    cost: 0,
                    levelRequired: 1,
                    stats: {
                        damage: 1.0,
                        fireRate: 1.0,
                        heat: 1.0
                    }
                },
                2: {
                    tier: 2,
                    name: 'Enhanced Weapons',
                    description: 'Improved laser systems',
                    cost: 1000,
                    levelRequired: 5,
                    stats: {
                        damage: 1.25,
                        fireRate: 1.15,
                        heat: 0.9
                    }
                },
                3: {
                    tier: 3,
                    name: 'Advanced Weapons',
                    description: 'Military-grade weapons',
                    cost: 3000,
                    levelRequired: 10,
                    stats: {
                        damage: 1.5,
                        fireRate: 1.3,
                        heat: 0.8
                    }
                },
                4: {
                    tier: 4,
                    name: 'Elite Weapons',
                    description: 'Cutting-edge weapon tech',
                    cost: 7500,
                    levelRequired: 20,
                    stats: {
                        damage: 1.8,
                        fireRate: 1.5,
                        heat: 0.7
                    }
                },
                5: {
                    tier: 5,
                    name: 'Legendary Weapons',
                    description: 'Experimental prototype weapons',
                    cost: 15000,
                    levelRequired: 35,
                    stats: {
                        damage: 2.2,
                        fireRate: 1.8,
                        heat: 0.6
                    }
                }
            },

            shields: {
                1: {
                    tier: 1,
                    name: 'Basic Shields',
                    description: 'Standard shield generator',
                    cost: 0,
                    levelRequired: 1,
                    stats: {
                        capacity: 1.0,
                        regenRate: 1.0,
                        regenDelay: 1.0
                    }
                },
                2: {
                    tier: 2,
                    name: 'Enhanced Shields',
                    description: 'Improved shield capacity',
                    cost: 1200,
                    levelRequired: 5,
                    stats: {
                        capacity: 1.3,
                        regenRate: 1.2,
                        regenDelay: 0.9
                    }
                },
                3: {
                    tier: 3,
                    name: 'Advanced Shields',
                    description: 'Military-grade shields',
                    cost: 3500,
                    levelRequired: 10,
                    stats: {
                        capacity: 1.6,
                        regenRate: 1.4,
                        regenDelay: 0.8
                    }
                },
                4: {
                    tier: 4,
                    name: 'Elite Shields',
                    description: 'Rapid-regenerating shields',
                    cost: 8000,
                    levelRequired: 20,
                    stats: {
                        capacity: 2.0,
                        regenRate: 1.7,
                        regenDelay: 0.7
                    }
                },
                5: {
                    tier: 5,
                    name: 'Legendary Shields',
                    description: 'Experimental shield matrix',
                    cost: 16000,
                    levelRequired: 35,
                    stats: {
                        capacity: 2.5,
                        regenRate: 2.0,
                        regenDelay: 0.5
                    }
                }
            },

            engines: {
                1: {
                    tier: 1,
                    name: 'Basic Engines',
                    description: 'Standard propulsion',
                    cost: 0,
                    levelRequired: 1,
                    stats: {
                        speed: 1.0,
                        acceleration: 1.0,
                        turnRate: 1.0
                    }
                },
                2: {
                    tier: 2,
                    name: 'Enhanced Engines',
                    description: 'Improved thrust systems',
                    cost: 800,
                    levelRequired: 5,
                    stats: {
                        speed: 1.2,
                        acceleration: 1.15,
                        turnRate: 1.1
                    }
                },
                3: {
                    tier: 3,
                    name: 'Advanced Engines',
                    description: 'High-performance engines',
                    cost: 2500,
                    levelRequired: 10,
                    stats: {
                        speed: 1.4,
                        acceleration: 1.3,
                        turnRate: 1.25
                    }
                },
                4: {
                    tier: 4,
                    name: 'Elite Engines',
                    description: 'Racing-grade propulsion',
                    cost: 6000,
                    levelRequired: 20,
                    stats: {
                        speed: 1.7,
                        acceleration: 1.5,
                        turnRate: 1.4
                    }
                },
                5: {
                    tier: 5,
                    name: 'Legendary Engines',
                    description: 'Experimental warp engines',
                    cost: 12000,
                    levelRequired: 35,
                    stats: {
                        speed: 2.0,
                        acceleration: 1.8,
                        turnRate: 1.6
                    }
                }
            },

            hull: {
                1: {
                    tier: 1,
                    name: 'Basic Hull',
                    description: 'Standard hull plating',
                    cost: 0,
                    levelRequired: 1,
                    stats: {
                        health: 1.0,
                        armor: 1.0,
                        mass: 1.0
                    }
                },
                2: {
                    tier: 2,
                    name: 'Reinforced Hull',
                    description: 'Strengthened hull structure',
                    cost: 1500,
                    levelRequired: 5,
                    stats: {
                        health: 1.3,
                        armor: 1.15,
                        mass: 1.05
                    }
                },
                3: {
                    tier: 3,
                    name: 'Armored Hull',
                    description: 'Military-grade armor plating',
                    cost: 4000,
                    levelRequired: 10,
                    stats: {
                        health: 1.6,
                        armor: 1.3,
                        mass: 1.1
                    }
                },
                4: {
                    tier: 4,
                    name: 'Fortified Hull',
                    description: 'Heavy armor and reinforcement',
                    cost: 9000,
                    levelRequired: 20,
                    stats: {
                        health: 2.0,
                        armor: 1.5,
                        mass: 1.15
                    }
                },
                5: {
                    tier: 5,
                    name: 'Legendary Hull',
                    description: 'Experimental composite armor',
                    cost: 18000,
                    levelRequired: 35,
                    stats: {
                        health: 2.5,
                        armor: 1.8,
                        mass: 1.1
                    }
                }
            },

            sensors: {
                1: {
                    tier: 1,
                    name: 'Basic Sensors',
                    description: 'Standard sensor array',
                    cost: 0,
                    levelRequired: 1,
                    stats: {
                        range: 1.0,
                        accuracy: 1.0,
                        scanSpeed: 1.0
                    }
                },
                2: {
                    tier: 2,
                    name: 'Enhanced Sensors',
                    description: 'Improved detection range',
                    cost: 600,
                    levelRequired: 5,
                    stats: {
                        range: 1.3,
                        accuracy: 1.15,
                        scanSpeed: 1.2
                    }
                },
                3: {
                    tier: 3,
                    name: 'Advanced Sensors',
                    description: 'Long-range sensor suite',
                    cost: 2000,
                    levelRequired: 10,
                    stats: {
                        range: 1.6,
                        accuracy: 1.3,
                        scanSpeed: 1.4
                    }
                },
                4: {
                    tier: 4,
                    name: 'Elite Sensors',
                    description: 'Military-grade sensors',
                    cost: 5000,
                    levelRequired: 20,
                    stats: {
                        range: 2.0,
                        accuracy: 1.5,
                        scanSpeed: 1.7
                    }
                },
                5: {
                    tier: 5,
                    name: 'Legendary Sensors',
                    description: 'Experimental quantum sensors',
                    cost: 10000,
                    levelRequired: 35,
                    stats: {
                        range: 2.5,
                        accuracy: 1.8,
                        scanSpeed: 2.0
                    }
                }
            }
        };
    }

    /**
     * Upgrade a component
     */
    upgradeComponent(component, entity, progressionSystem) {
        if (!this.components.includes(component)) {
            return { success: false, message: 'Invalid component' };
        }

        const currentTier = this.currentUpgrades[component];
        const nextTier = currentTier + 1;

        // Check if already max tier
        if (nextTier > 5) {
            return { success: false, message: 'Already at maximum tier' };
        }

        const upgrade = this.tiers[component][nextTier];

        // Check level requirement
        if (progressionSystem.level < upgrade.levelRequired) {
            return {
                success: false,
                message: `Requires level ${upgrade.levelRequired}`
            };
        }

        // Check credits
        if (!this.inventorySystem.removeCredits(entity, upgrade.cost)) {
            return {
                success: false,
                message: `Not enough credits (need ${upgrade.cost})`
            };
        }

        // Apply upgrade
        this.currentUpgrades[component] = nextTier;

        // Trigger callback
        if (this.onUpgrade) {
            this.onUpgrade(component, nextTier, upgrade);
        }

        // Check if maxed
        if (nextTier === 5 && this.onMaxTier) {
            this.onMaxTier(component);
        }

        return {
            success: true,
            message: `Upgraded to ${upgrade.name}`,
            tier: nextTier,
            upgrade: upgrade
        };
    }

    /**
     * Get component tier
     */
    getComponentTier(component) {
        return this.currentUpgrades[component] || 1;
    }

    /**
     * Get component info
     */
    getComponentInfo(component, tier = null) {
        if (!this.components.includes(component)) return null;

        const currentTier = tier || this.currentUpgrades[component];
        return this.tiers[component][currentTier];
    }

    /**
     * Get next upgrade info
     */
    getNextUpgradeInfo(component) {
        const currentTier = this.currentUpgrades[component];
        const nextTier = currentTier + 1;

        if (nextTier > 5) return null;

        return this.tiers[component][nextTier];
    }

    /**
     * Can upgrade component
     */
    canUpgrade(component, entity, progressionSystem) {
        const currentTier = this.currentUpgrades[component];
        const nextTier = currentTier + 1;

        if (nextTier > 5) return false;

        const upgrade = this.tiers[component][nextTier];

        // Check level
        if (progressionSystem.level < upgrade.levelRequired) return false;

        // Check credits
        const inventory = this.inventorySystem.getInventory(entity);
        if (!inventory || inventory.credits < upgrade.cost) return false;

        return true;
    }

    /**
     * Get all component stats
     */
    getAllStats() {
        const stats = {};

        for (const component of this.components) {
            const tier = this.currentUpgrades[component];
            const info = this.tiers[component][tier];
            stats[component] = info.stats;
        }

        return stats;
    }

    /**
     * Get combined stat multiplier
     */
    getStatMultiplier(statType) {
        let multiplier = 1.0;

        for (const component of this.components) {
            const tier = this.currentUpgrades[component];
            const info = this.tiers[component][tier];

            if (info.stats[statType]) {
                multiplier *= info.stats[statType];
            }
        }

        return multiplier;
    }

    /**
     * Get total upgrade cost
     */
    getTotalUpgradeCost() {
        let total = 0;

        for (const component of this.components) {
            const tier = this.currentUpgrades[component];

            for (let t = 2; t <= tier; t++) {
                total += this.tiers[component][t].cost;
            }
        }

        return total;
    }

    /**
     * Get upgrade progress
     */
    getUpgradeProgress() {
        const progress = {
            totalTiers: 0,
            maxTiers: this.components.length * 5,
            components: {}
        };

        for (const component of this.components) {
            const tier = this.currentUpgrades[component];
            progress.totalTiers += tier;
            progress.components[component] = {
                tier: tier,
                maxed: tier === 5
            };
        }

        progress.percentComplete = (progress.totalTiers / progress.maxTiers) * 100;

        return progress;
    }

    /**
     * Save upgrade data
     */
    save() {
        return {
            currentUpgrades: this.currentUpgrades
        };
    }

    /**
     * Load upgrade data
     */
    load(data) {
        if (!data) return;

        this.currentUpgrades = data.currentUpgrades || {
            weapons: 1,
            shields: 1,
            engines: 1,
            hull: 1,
            sensors: 1
        };
    }

    /**
     * Get summary
     */
    getSummary() {
        const summary = {
            totalCostSpent: this.getTotalUpgradeCost(),
            progress: this.getUpgradeProgress(),
            components: {}
        };

        for (const component of this.components) {
            const tier = this.currentUpgrades[component];
            const info = this.tiers[component][tier];

            summary.components[component] = {
                name: info.name,
                tier: tier,
                stats: info.stats
            };
        }

        return summary;
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ShipUpgradeSystem;
}
