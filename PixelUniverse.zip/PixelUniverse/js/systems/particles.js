/**
 * PixelVerse - Particle System
 * Handles all particle effects (engine exhaust, explosions, sparks, etc.)
 */

class ParticleSystem extends System {
    constructor() {
        super();
        this.maxParticles = 1000;
        this.particlePool = [];
        
        // Initialize particle pool
        for (let i = 0; i < this.maxParticles; i++) {
            this.particlePool.push({
                active: false,
                x: 0,
                y: 0,
                vx: 0,
                vy: 0,
                lifetime: 0,
                maxLifetime: 0,
                color: RETRO_PALETTE.pureWhite,
                size: 1,
                startSize: 1,
                endSize: 1,
                alpha: 1.0
            });
        }
    }

    /**
     * Create a particle effect
     */
    createEffect(type, x, y, options = {}) {
        const effectConfig = this.getEffectConfig(type);
        if (!effectConfig) return;
        
        const count = options.count || effectConfig.count || 10;
        
        for (let i = 0; i < count; i++) {
            this.emitParticle(x, y, effectConfig, options);
        }
    }

    /**
     * Get effect configuration
     * Enhanced with warm plasma colors (yellow-orange-red-white progression)
     */
    getEffectConfig(type) {
        const configs = {
            // Chemical engine - warm plasma progression
            engine_exhaust_chemical: {
                colors: [RETRO_PALETTE.pureWhite, RETRO_PALETTE.warningYellow, RETRO_PALETTE.vintageAmber, RETRO_PALETTE.cautionOrange, RETRO_PALETTE.alertRed],
                lifetime: 0.6,
                velocity: { min: -120, max: -60 },
                size: { start: 3, end: 1 },
                count: 4,
                glow: true
            },
            // Ion engine - cool blue plasma
            engine_exhaust_ion: {
                colors: [RETRO_PALETTE.pureWhite, RETRO_PALETTE.paleGray, RETRO_PALETTE.statusBlue, RETRO_PALETTE.voidMid],
                lifetime: 1.2,
                velocity: { min: -80, max: -40 },
                size: { start: 2, end: 0 },
                count: 2,
                glow: true
            },
            // Plasma engine - intense white-yellow core
            engine_exhaust_plasma: {
                colors: [RETRO_PALETTE.pureWhite, RETRO_PALETTE.warningYellow, RETRO_PALETTE.statusBlue],
                lifetime: 0.8,
                velocity: { min: -100, max: -50 },
                size: { start: 2, end: 1 },
                count: 3,
                glow: true
            },
            // Explosion - warm plasma burst
            explosion: {
                colors: [RETRO_PALETTE.pureWhite, RETRO_PALETTE.warningYellow, RETRO_PALETTE.vintageAmber, RETRO_PALETTE.cautionOrange, RETRO_PALETTE.alertRed, RETRO_PALETTE.bloodRed],
                lifetime: 0.4,
                velocity: { min: -250, max: 250 },
                size: { start: 4, end: 1 },
                count: 25,
                glow: true
            },
            // Small explosion
            explosion_small: {
                colors: [RETRO_PALETTE.warningYellow, RETRO_PALETTE.vintageAmber, RETRO_PALETTE.alertRed],
                lifetime: 0.3,
                velocity: { min: -150, max: 150 },
                size: { start: 2, end: 1 },
                count: 12,
                glow: true
            },
            // Sparks - bright yellow-white
            spark: {
                colors: [RETRO_PALETTE.pureWhite, RETRO_PALETTE.warningYellow, RETRO_PALETTE.vintageAmber],
                lifetime: 0.25,
                velocity: { min: -180, max: 180 },
                size: { start: 1, end: 1 },
                count: 15,
                glow: false
            },
            // Hull breach - sparks and debris
            hull_breach: {
                colors: [RETRO_PALETTE.pureWhite, RETRO_PALETTE.warningYellow, RETRO_PALETTE.alertRed, RETRO_PALETTE.hullPrimary],
                lifetime: 0.4,
                velocity: { min: -200, max: 200 },
                size: { start: 2, end: 0 },
                count: 20,
                glow: false
            },
            // Shield impact - blue energy
            shield_impact: {
                colors: [RETRO_PALETTE.pureWhite, RETRO_PALETTE.statusBlue, RETRO_PALETTE.voidMid],
                lifetime: 0.2,
                velocity: { min: -100, max: 100 },
                size: { start: 2, end: 0 },
                count: 10,
                glow: true
            },
            // Warp charge - building energy
            warp_charge: {
                colors: [RETRO_PALETTE.statusBlue, RETRO_PALETTE.paleGray, RETRO_PALETTE.pureWhite],
                lifetime: 0.5,
                velocity: { min: -50, max: 50 },
                size: { start: 1, end: 2 },
                count: 8,
                glow: true
            },
            // Debris - gray chunks
            debris: {
                colors: [RETRO_PALETTE.hullPrimary, RETRO_PALETTE.hullSecondary, RETRO_PALETTE.darkGray],
                lifetime: 1.0,
                velocity: { min: -100, max: 100 },
                size: { start: 2, end: 2 },
                count: 8,
                glow: false
            },
            // Smoke - dark gray dissipation
            smoke: {
                colors: [RETRO_PALETTE.darkGray, RETRO_PALETTE.shadowGray, RETRO_PALETTE.voidBlack],
                lifetime: 1.5,
                velocity: { min: -30, max: 30 },
                size: { start: 2, end: 4 },
                count: 5,
                glow: false
            }
        };

        return configs[type];
    }

    /**
     * Emit a single particle
     */
    emitParticle(x, y, config, options) {
        // Find inactive particle
        const particle = this.particlePool.find(p => !p.active);
        if (!particle) return;
        
        // Activate particle
        particle.active = true;
        particle.x = x;
        particle.y = y;
        
        // Random velocity
        const angle = options.angle !== undefined ? options.angle : Math.random() * Math.PI * 2;
        const speed = config.velocity.min + Math.random() * (config.velocity.max - config.velocity.min);
        particle.vx = Math.cos(angle) * speed;
        particle.vy = Math.sin(angle) * speed;
        
        // Lifetime
        particle.lifetime = config.lifetime;
        particle.maxLifetime = config.lifetime;
        
        // Color
        particle.color = config.colors[Math.floor(Math.random() * config.colors.length)];
        
        // Size
        particle.startSize = config.size.start;
        particle.endSize = config.size.end;
        particle.size = particle.startSize;
        
        // Alpha
        particle.alpha = 1.0;
    }

    /**
     * Update all particles
     */
    update(deltaTime) {
        for (const particle of this.particlePool) {
            if (!particle.active) continue;
            
            // Update lifetime
            particle.lifetime -= deltaTime;
            
            if (particle.lifetime <= 0) {
                particle.active = false;
                continue;
            }
            
            // Update position
            particle.x += particle.vx * deltaTime;
            particle.y += particle.vy * deltaTime;
            
            // Update size and alpha
            const t = 1 - (particle.lifetime / particle.maxLifetime);
            particle.size = particle.startSize + (particle.endSize - particle.startSize) * t;
            particle.alpha = 1 - t;
        }
    }

    /**
     * Render all particles
     */
    render(renderer, cameraX, cameraY) {
        for (const particle of this.particlePool) {
            if (!particle.active) continue;
            
            const coords = renderer.getViewportCoords(particle.x, particle.y, cameraX, cameraY);
            
            if (!renderer.isInViewport(coords.x, coords.y)) continue;
            
            // Draw particle
            const size = Math.max(1, Math.floor(particle.size));
            const color = PaletteUtils.withAlpha(particle.color, particle.alpha);
            
            renderer.drawRect(coords.x, coords.y, size, size, color);
        }
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ParticleSystem;
}

