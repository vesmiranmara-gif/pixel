/**
 * PixelVerse - Realistic Star System Generator
 * Generates star systems with realistic astronomical distances and sizes
 * Scale: 1600px = 1 AU (Astronomical Unit)
 * Player ship = 30px, Asteroid = 25px
 */

class StarSystemGenerator {
    constructor() {
        // Adjusted scale for gameplay: 400px = 1 AU (more compact but still proportional)
        this.AU = 400;
        this.systems = [];

        // Body type definitions with realistic sizes (scaled up for visibility)
        this.bodyTypes = {
            // Stars (visible but not overwhelming)
            star: {
                yellow: { size: 300, mass: 1.0, temp: 5778 },
                red: { size: 250, mass: 0.5, temp: 3500 },
                blue: { size: 350, mass: 2.0, temp: 10000 },
                white: { size: 280, mass: 1.2, temp: 7500 }
            },

            // Planets (scaled up for better visibility)
            planet: {
                tiny: { size: 40, type: 'rocky' },       // Mercury-like
                small: { size: 60, type: 'rocky' },      // Mars-like
                medium: { size: 100, type: 'earthlike' }, // Earth-like
                large: { size: 250, type: 'gasGiant' },  // Uranus-like
                huge: { size: 450, type: 'gasGiant' }    // Jupiter-like
            },

            // Moons (scaled up)
            moon: {
                tiny: { size: 15 },
                small: { size: 25 },
                medium: { size: 40 }
            },

            // Other bodies
            asteroid: { size: 20 },
            comet: { size: 12 },
            dwarfPlanet: { size: 35 }
        };
    }

    /**
     * Generate a complete star system
     */
    generateSystem(seed = Math.random()) {
        const system = {
            seed: seed,
            name: this.generateSystemName(seed),
            centralBody: null,
            planets: [],
            asteroidBelt: null,
            comets: [],
            type: this.selectSystemType(seed)
        };

        // Generate central body (star, binary stars, or black hole)
        system.centralBody = this.generateCentralBody(system.type, seed);

        // Generate planets based on system type
        const planetCount = this.getPlanetCount(system.type, seed);
        for (let i = 0; i < planetCount; i++) {
            const planet = this.generatePlanet(i, planetCount, seed + i);
            system.planets.push(planet);
        }

        // Add asteroid belt (50% chance)
        if (Math.random() < 0.5) {
            system.asteroidBelt = this.generateAsteroidBelt(system.planets, seed);
        }

        // Add comets (2-5)
        const cometCount = 2 + Math.floor(Math.random() * 4);
        for (let i = 0; i < cometCount; i++) {
            system.comets.push(this.generateComet(seed + 1000 + i));
        }

        return system;
    }

    /**
     * Select system type
     */
    selectSystemType(seed) {
        const rand = this.seededRandom(seed);
        if (rand < 0.7) return 'single'; // 70% single star
        if (rand < 0.9) return 'binary'; // 20% binary stars
        if (rand < 0.95) return 'trinary'; // 5% trinary stars
        return 'exotic'; // 5% black hole/pulsar
    }

    /**
     * Generate central body
     */
    generateCentralBody(type, seed) {
        const rand = this.seededRandom(seed + 0.1);
        
        if (type === 'single') {
            // Single star
            const starType = this.selectStarType(rand);
            return {
                type: 'star',
                subtype: starType,
                size: this.bodyTypes.star[starType].size,
                mass: this.bodyTypes.star[starType].mass,
                x: 0,
                y: 0,
                seed: seed
            };
        } else if (type === 'binary') {
            // Binary star system
            const separation = this.AU * 0.3; // 0.3 AU apart
            const star1Type = this.selectStarType(rand);
            const star2Type = this.selectStarType(rand + 0.5);
            
            return {
                type: 'binary',
                stars: [
                    {
                        type: 'star',
                        subtype: star1Type,
                        size: this.bodyTypes.star[star1Type].size,
                        x: -separation / 2,
                        y: 0,
                        seed: seed
                    },
                    {
                        type: 'star',
                        subtype: star2Type,
                        size: this.bodyTypes.star[star2Type].size,
                        x: separation / 2,
                        y: 0,
                        seed: seed + 0.5
                    }
                ]
            };
        } else if (type === 'trinary') {
            // Trinary star system (rare)
            const separation = this.AU * 0.4;
            return {
                type: 'trinary',
                stars: [
                    {
                        type: 'star',
                        subtype: 'yellow',
                        size: this.bodyTypes.star.yellow.size,
                        x: 0,
                        y: 0,
                        seed: seed
                    },
                    {
                        type: 'star',
                        subtype: 'red',
                        size: this.bodyTypes.star.red.size,
                        x: separation * Math.cos(0),
                        y: separation * Math.sin(0),
                        seed: seed + 0.3
                    },
                    {
                        type: 'star',
                        subtype: 'red',
                        size: this.bodyTypes.star.red.size,
                        x: separation * Math.cos(Math.PI * 2 / 3),
                        y: separation * Math.sin(Math.PI * 2 / 3),
                        seed: seed + 0.6
                    }
                ]
            };
        } else {
            // Exotic (black hole or pulsar)
            return {
                type: rand < 0.5 ? 'blackhole' : 'pulsar',
                size: 400,
                x: 0,
                y: 0,
                seed: seed
            };
        }
    }

    /**
     * Select star type
     */
    selectStarType(rand) {
        if (rand < 0.6) return 'yellow'; // 60% yellow (like our Sun)
        if (rand < 0.8) return 'red';    // 20% red dwarf
        if (rand < 0.95) return 'white'; // 15% white
        return 'blue';                    // 5% blue giant
    }

    /**
     * Get planet count based on system type
     */
    getPlanetCount(type, seed) {
        const rand = this.seededRandom(seed + 0.2);
        if (type === 'exotic') return Math.floor(2 + rand * 4); // 2-5 planets
        if (type === 'binary') return Math.floor(3 + rand * 5); // 3-7 planets
        return Math.floor(4 + rand * 8); // 4-11 planets for single star
    }

    /**
     * Generate a planet
     */
    generatePlanet(index, totalPlanets, seed) {
        const rand = this.seededRandom(seed);
        
        // Calculate orbital distance (realistic spacing)
        // Inner planets: 0.4-1.5 AU
        // Middle planets: 2-5 AU
        // Outer planets: 6-30 AU
        let distance;
        const position = index / totalPlanets;
        
        if (position < 0.3) {
            // Inner system
            distance = this.AU * (0.4 + position * 3);
        } else if (position < 0.6) {
            // Middle system
            distance = this.AU * (2 + (position - 0.3) * 10);
        } else {
            // Outer system
            distance = this.AU * (6 + (position - 0.6) * 60);
        }

        // Select planet type based on distance (inner = rocky, outer = gas)
        let planetSize, planetType;
        if (distance < this.AU * 1.5) {
            // Inner rocky planets
            planetSize = rand < 0.5 ? 'tiny' : 'small';
            planetType = rand < 0.3 ? 'lava' : 'rocky';
        } else if (distance < this.AU * 3) {
            // Habitable zone
            planetSize = 'medium';
            planetType = rand < 0.4 ? 'earthlike' : 'rocky';
        } else if (distance < this.AU * 10) {
            // Gas giants
            planetSize = rand < 0.5 ? 'large' : 'huge';
            planetType = 'gasGiant';
        } else {
            // Outer ice worlds
            planetSize = rand < 0.7 ? 'small' : 'medium';
            planetType = 'ice';
        }

        const size = this.bodyTypes.planet[planetSize].size;
        
        // Random orbital angle
        const angle = this.seededRandom(seed + 0.5) * Math.PI * 2;
        
        const planet = {
            type: 'planet',
            subtype: planetType,
            size: size,
            distance: distance,
            angle: angle,
            x: Math.cos(angle) * distance,
            y: Math.sin(angle) * distance,
            orbitalSpeed: this.calculateOrbitalSpeed(distance),
            seed: seed,
            moons: []
        };

        // Add moons (larger planets have more moons)
        const moonCount = this.getMoonCount(planetSize, seed);
        for (let i = 0; i < moonCount; i++) {
            planet.moons.push(this.generateMoon(planet, i, seed + 100 + i));
        }

        return planet;
    }

    /**
     * Calculate realistic orbital speed (Kepler's laws)
     */
    calculateOrbitalSpeed(distance) {
        // v = sqrt(GM/r), simplified for game
        // Closer planets orbit faster
        const baseSpeed = 0.0001;
        return baseSpeed / Math.sqrt(distance / this.AU);
    }

    /**
     * Get moon count
     */
    getMoonCount(planetSize, seed) {
        const rand = this.seededRandom(seed + 0.7);
        if (planetSize === 'tiny') return 0;
        if (planetSize === 'small') return rand < 0.3 ? 1 : 0;
        if (planetSize === 'medium') return Math.floor(rand * 3); // 0-2
        if (planetSize === 'large') return Math.floor(1 + rand * 4); // 1-4
        if (planetSize === 'huge') return Math.floor(2 + rand * 6); // 2-7
        return 0;
    }

    /**
     * Generate a moon
     */
    generateMoon(planet, index, seed) {
        const rand = this.seededRandom(seed);
        const moonSize = rand < 0.6 ? 'tiny' : (rand < 0.9 ? 'small' : 'medium');
        const size = this.bodyTypes.moon[moonSize].size;
        
        // Moon orbital distance (proportional to planet size)
        const distance = planet.size * (2 + index * 1.5);
        const angle = this.seededRandom(seed + 0.3) * Math.PI * 2;
        
        return {
            type: 'moon',
            size: size,
            distance: distance,
            angle: angle,
            orbitalSpeed: 0.001 + rand * 0.002,
            seed: seed
        };
    }

    /**
     * Generate asteroid belt
     */
    generateAsteroidBelt(planets, seed) {
        // Place between Mars and Jupiter equivalent (2-4 AU)
        const innerRadius = this.AU * 2.5;
        const outerRadius = this.AU * 4;
        const asteroidCount = 50 + Math.floor(this.seededRandom(seed) * 100);
        
        const asteroids = [];
        for (let i = 0; i < asteroidCount; i++) {
            const rand = this.seededRandom(seed + i * 0.01);
            const distance = innerRadius + rand * (outerRadius - innerRadius);
            const angle = this.seededRandom(seed + i * 0.02) * Math.PI * 2;
            
            asteroids.push({
                type: 'asteroid',
                size: this.bodyTypes.asteroid.size * (0.5 + rand * 1),
                distance: distance,
                angle: angle,
                x: Math.cos(angle) * distance,
                y: Math.sin(angle) * distance,
                orbitalSpeed: this.calculateOrbitalSpeed(distance),
                seed: seed + i
            });
        }
        
        return {
            innerRadius: innerRadius,
            outerRadius: outerRadius,
            asteroids: asteroids
        };
    }

    /**
     * Generate comet
     */
    generateComet(seed) {
        const rand = this.seededRandom(seed);
        // Comets have highly elliptical orbits
        const perihelion = this.AU * (0.5 + rand * 2); // Closest point
        const aphelion = this.AU * (20 + rand * 80);   // Farthest point
        const angle = this.seededRandom(seed + 0.5) * Math.PI * 2;
        
        return {
            type: 'comet',
            size: this.bodyTypes.comet.size,
            perihelion: perihelion,
            aphelion: aphelion,
            angle: angle,
            orbitalSpeed: 0.00005,
            seed: seed
        };
    }

    /**
     * Generate system name
     */
    generateSystemName(seed) {
        const prefixes = ['Alpha', 'Beta', 'Gamma', 'Delta', 'Epsilon', 'Zeta', 'Eta', 'Theta'];
        const suffixes = ['Centauri', 'Draconis', 'Orionis', 'Cygni', 'Aquilae', 'Lyrae', 'Pegasi'];
        
        const prefix = prefixes[Math.floor(this.seededRandom(seed) * prefixes.length)];
        const suffix = suffixes[Math.floor(this.seededRandom(seed + 0.5) * suffixes.length)];
        
        return `${prefix} ${suffix}`;
    }

    /**
     * Seeded random number generator
     */
    seededRandom(seed) {
        const x = Math.sin(seed) * 10000;
        return x - Math.floor(x);
    }
}

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = StarSystemGenerator;
}

