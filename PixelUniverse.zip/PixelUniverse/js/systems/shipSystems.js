/**
 * PixelVerse - Ship Systems Management
 * Power distribution, shield management, damage model, system failures
 * Retro sci-fi ship management with tactical depth
 */

class ShipSystemsManager {
    constructor(entityManager) {
        this.entityManager = entityManager;
        
        // Ship system states for each entity
        this.shipSystems = new Map(); // entity -> system state
    }

    /**
     * Initialize ship systems for entity
     */
    initializeSystems(entity, config = {}) {
        const systems = {
            // Power system
            power: {
                total: config.totalPower || 100,
                available: config.totalPower || 100,
                regenRate: config.powerRegen || 5.0, // per second
                distribution: {
                    shields: 30,
                    weapons: 30,
                    engines: 30,
                    sensors: 10
                }
            },
            
            // Shield system
            shields: {
                enabled: true,
                efficiency: 1.0,
                regenRate: 1.0,
                powerDraw: 2.0, // per second when active
                damaged: false,
                repairProgress: 0
            },
            
            // Weapon system
            weapons: {
                enabled: true,
                efficiency: 1.0,
                heatLevel: 0, // 0-100
                coolingRate: 10.0, // per second
                overheated: false,
                damaged: false,
                repairProgress: 0
            },
            
            // Engine system
            engines: {
                enabled: true,
                efficiency: 1.0,
                thrustMultiplier: 1.0,
                damaged: false,
                repairProgress: 0
            },
            
            // Sensor system
            sensors: {
                enabled: true,
                efficiency: 1.0,
                range: 1000,
                damaged: false,
                repairProgress: 0
            },
            
            // Hull integrity
            hull: {
                integrity: 100,
                maxIntegrity: 100,
                breaches: [],
                criticalThreshold: 25
            },
            
            // System health
            systemHealth: {
                shields: 100,
                weapons: 100,
                engines: 100,
                sensors: 100
            },
            
            // Repair system
            repair: {
                autoRepair: true,
                repairRate: 5.0, // per second
                repairPriority: ['hull', 'shields', 'engines', 'weapons', 'sensors']
            }
        };
        
        this.shipSystems.set(entity, systems);
        return systems;
    }

    /**
     * Update all ship systems
     */
    update(deltaTime) {
        for (const [entity, systems] of this.shipSystems) {
            // Check if entity still exists
            if (!entity.getComponent('transform')) {
                this.shipSystems.delete(entity);
                continue;
            }
            
            // Update power system
            this.updatePowerSystem(entity, systems, deltaTime);
            
            // Update shield system
            this.updateShieldSystem(entity, systems, deltaTime);
            
            // Update weapon system
            this.updateWeaponSystem(entity, systems, deltaTime);
            
            // Update engine system
            this.updateEngineSystem(entity, systems, deltaTime);
            
            // Update sensor system
            this.updateSensorSystem(entity, systems, deltaTime);
            
            // Update hull integrity
            this.updateHullIntegrity(entity, systems, deltaTime);
            
            // Auto-repair systems
            if (systems.repair.autoRepair) {
                this.autoRepairSystems(entity, systems, deltaTime);
            }
        }
    }

    /**
     * Update power system
     */
    updatePowerSystem(entity, systems, deltaTime) {
        const power = systems.power;
        
        // Regenerate power
        power.available = Math.min(power.total, power.available + power.regenRate * deltaTime);
        
        // Calculate power consumption
        let powerDraw = 0;
        
        if (systems.shields.enabled) {
            powerDraw += systems.shields.powerDraw;
        }
        
        // Deduct power
        power.available = Math.max(0, power.available - powerDraw * deltaTime);
        
        // Disable systems if no power
        if (power.available <= 0) {
            systems.shields.enabled = false;
        }
    }

    /**
     * Update shield system
     */
    updateShieldSystem(entity, systems, deltaTime) {
        const health = entity.getComponent('health');
        if (!health) return;
        
        const shields = systems.shields;
        
        // Shield regeneration (if enabled and has power)
        if (shields.enabled && systems.power.available > 0 && !shields.damaged) {
            const regenAmount = shields.regenRate * shields.efficiency * deltaTime;
            health.shield = Math.min(health.maxShield, health.shield + regenAmount);
        }
        
        // Disable shields if damaged
        if (shields.damaged) {
            shields.enabled = false;
        }
    }

    /**
     * Update weapon system
     */
    updateWeaponSystem(entity, systems, deltaTime) {
        const weapons = systems.weapons;
        
        // Cool down weapons
        if (weapons.heatLevel > 0) {
            weapons.heatLevel = Math.max(0, weapons.heatLevel - weapons.coolingRate * deltaTime);
        }
        
        // Check overheat
        if (weapons.heatLevel >= 100) {
            weapons.overheated = true;
        } else if (weapons.heatLevel < 50) {
            weapons.overheated = false;
        }
        
        // Disable weapons if damaged or overheated
        if (weapons.damaged || weapons.overheated) {
            weapons.enabled = false;
        } else {
            weapons.enabled = true;
        }
    }

    /**
     * Update engine system
     */
    updateEngineSystem(entity, systems, deltaTime) {
        const engines = systems.engines;
        const physics = entity.getComponent('physics');
        
        if (!physics) return;
        
        // Apply engine efficiency to drag
        if (engines.damaged) {
            engines.efficiency = 0.5;
            engines.thrustMultiplier = 0.5;
        } else {
            engines.efficiency = 1.0;
            engines.thrustMultiplier = 1.0;
        }
    }

    /**
     * Update sensor system
     */
    updateSensorSystem(entity, systems, deltaTime) {
        const sensors = systems.sensors;
        
        // Reduce sensor range if damaged
        if (sensors.damaged) {
            sensors.range = 500;
            sensors.efficiency = 0.5;
        } else {
            sensors.range = 1000;
            sensors.efficiency = 1.0;
        }
    }

    /**
     * Update hull integrity
     */
    updateHullIntegrity(entity, systems, deltaTime) {
        const health = entity.getComponent('health');
        if (!health) return;
        
        const hull = systems.hull;
        
        // Update hull integrity based on health
        hull.integrity = (health.health / health.maxHealth) * hull.maxIntegrity;
        
        // Check for critical damage
        if (hull.integrity < hull.criticalThreshold) {
            // Random system failures
            if (Math.random() < 0.01) {
                this.causeSystemFailure(entity, systems);
            }
        }
    }

    /**
     * Auto-repair damaged systems
     */
    autoRepairSystems(entity, systems, deltaTime) {
        const repair = systems.repair;
        
        for (const systemName of repair.repairPriority) {
            const system = systems[systemName];
            
            if (!system) continue;
            
            // Repair damaged systems
            if (system.damaged) {
                system.repairProgress += repair.repairRate * deltaTime;
                
                if (system.repairProgress >= 100) {
                    system.damaged = false;
                    system.repairProgress = 0;
                    console.log(`${systemName} repaired!`);
                }
                
                // Only repair one system at a time
                break;
            }
        }
    }

    /**
     * Cause random system failure
     */
    causeSystemFailure(entity, systems) {
        const systemNames = ['shields', 'weapons', 'engines', 'sensors'];
        const randomSystem = systemNames[Math.floor(Math.random() * systemNames.length)];
        
        const system = systems[randomSystem];
        if (system && !system.damaged) {
            system.damaged = true;
            system.repairProgress = 0;
            console.log(`WARNING: ${randomSystem} system failure!`);
        }
    }

    /**
     * Apply damage to ship systems
     */
    applySystemDamage(entity, damageAmount) {
        const systems = this.shipSystems.get(entity);
        if (!systems) return;
        
        // Random chance to damage a system
        if (Math.random() < 0.3) {
            const systemNames = ['shields', 'weapons', 'engines', 'sensors'];
            const randomSystem = systemNames[Math.floor(Math.random() * systemNames.length)];
            
            const system = systems[randomSystem];
            if (system) {
                systems.systemHealth[randomSystem] = Math.max(0, systems.systemHealth[randomSystem] - damageAmount);
                
                if (systems.systemHealth[randomSystem] <= 0) {
                    system.damaged = true;
                }
            }
        }
    }

    /**
     * Get ship systems for entity
     */
    getSystems(entity) {
        return this.shipSystems.get(entity);
    }

    /**
     * Set power distribution
     */
    setPowerDistribution(entity, distribution) {
        const systems = this.shipSystems.get(entity);
        if (!systems) return;
        
        systems.power.distribution = distribution;
    }

    /**
     * Toggle system
     */
    toggleSystem(entity, systemName) {
        const systems = this.shipSystems.get(entity);
        if (!systems || !systems[systemName]) return;
        
        systems[systemName].enabled = !systems[systemName].enabled;
    }

    /**
     * Get weapon heat for firing
     */
    addWeaponHeat(entity, heatAmount) {
        const systems = this.shipSystems.get(entity);
        if (!systems) return;
        
        systems.weapons.heatLevel = Math.min(100, systems.weapons.heatLevel + heatAmount);
    }

    /**
     * Check if weapons can fire
     */
    canFireWeapons(entity) {
        const systems = this.shipSystems.get(entity);
        if (!systems) return true;
        
        return systems.weapons.enabled && !systems.weapons.overheated && !systems.weapons.damaged;
    }

    /**
     * Get engine thrust multiplier
     */
    getEngineThrustMultiplier(entity) {
        const systems = this.shipSystems.get(entity);
        if (!systems) return 1.0;
        
        return systems.engines.thrustMultiplier;
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ShipSystemsManager;
}

