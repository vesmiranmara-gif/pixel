/**
 * PixelVerse - Achievement System
 * Handles achievements, tracking, and rewards
 */

class AchievementSystem {
    constructor() {
        // Achievement categories
        this.categories = ['combat', 'exploration', 'trading', 'progression', 'special'];

        // All achievements
        this.achievements = this.initializeAchievements();

        // Unlocked achievements (achievement_id: timestamp)
        this.unlocked = {};

        // Progress tracking (achievement_id: progress)
        this.progress = {};

        // Callbacks
        this.onAchievementUnlocked = null;
        this.onCategoryComplete = null;
    }

    /**
     * Initialize all achievements
     */
    initializeAchievements() {
        return {
            // COMBAT ACHIEVEMENTS (20)
            firstBlood: {
                id: 'firstBlood',
                name: 'First Blood',
                description: 'Destroy your first enemy',
                category: 'combat',
                icon: '⚔️',
                requirement: { type: 'kills', value: 1 },
                reward: { credits: 100, xp: 50 }
            },
            killer: {
                id: 'killer',
                name: 'Killer',
                description: 'Destroy 10 enemies',
                category: 'combat',
                icon: '⚔️',
                requirement: { type: 'kills', value: 10 },
                reward: { credits: 500, xp: 200 }
            },
            destroyer: {
                id: 'destroyer',
                name: 'Destroyer',
                description: 'Destroy 50 enemies',
                category: 'combat',
                icon: '⚔️',
                requirement: { type: 'kills', value: 50 },
                reward: { credits: 2000, xp: 500 }
            },
            terminator: {
                id: 'terminator',
                name: 'Terminator',
                description: 'Destroy 100 enemies',
                category: 'combat',
                icon: '⚔️',
                requirement: { type: 'kills', value: 100 },
                reward: { credits: 5000, xp: 1000 }
            },
            warMachine: {
                id: 'warMachine',
                name: 'War Machine',
                description: 'Destroy 500 enemies',
                category: 'combat',
                icon: '⚔️',
                requirement: { type: 'kills', value: 500 },
                reward: { credits: 20000, xp: 5000 }
            },
            sharpshooter: {
                id: 'sharpshooter',
                name: 'Sharpshooter',
                description: 'Deal 10,000 damage',
                category: 'combat',
                icon: '🎯',
                requirement: { type: 'damageDealt', value: 10000 },
                reward: { credits: 1000, xp: 300 }
            },
            survivor: {
                id: 'survivor',
                name: 'Survivor',
                description: 'Survive 10 minutes in combat',
                category: 'combat',
                icon: '🛡️',
                requirement: { type: 'survivalTime', value: 600 },
                reward: { credits: 1500, xp: 400 }
            },
            untouchable: {
                id: 'untouchable',
                name: 'Untouchable',
                description: 'Destroy 5 enemies without taking damage',
                category: 'combat',
                icon: '✨',
                requirement: { type: 'killStreak', value: 5 },
                reward: { credits: 3000, xp: 800 }
            },

            // EXPLORATION ACHIEVEMENTS (15)
            explorer: {
                id: 'explorer',
                name: 'Explorer',
                description: 'Discover your first planet',
                category: 'exploration',
                icon: '🌍',
                requirement: { type: 'planetsDiscovered', value: 1 },
                reward: { credits: 200, xp: 100 }
            },
            pathfinder: {
                id: 'pathfinder',
                name: 'Pathfinder',
                description: 'Discover 10 planets',
                category: 'exploration',
                icon: '🌍',
                requirement: { type: 'planetsDiscovered', value: 10 },
                reward: { credits: 2000, xp: 500 }
            },
            cartographer: {
                id: 'cartographer',
                name: 'Cartographer',
                description: 'Discover 50 planets',
                category: 'exploration',
                icon: '🌍',
                requirement: { type: 'planetsDiscovered', value: 50 },
                reward: { credits: 10000, xp: 2000 }
            },
            traveler: {
                id: 'traveler',
                name: 'Traveler',
                description: 'Travel 100,000 units',
                category: 'exploration',
                icon: '🚀',
                requirement: { type: 'distanceTraveled', value: 100000 },
                reward: { credits: 1000, xp: 300 }
            },
            voyager: {
                id: 'voyager',
                name: 'Voyager',
                description: 'Travel 1,000,000 units',
                category: 'exploration',
                icon: '🚀',
                requirement: { type: 'distanceTraveled', value: 1000000 },
                reward: { credits: 10000, xp: 2000 }
            },
            scanner: {
                id: 'scanner',
                name: 'Scanner',
                description: 'Scan 100 objects',
                category: 'exploration',
                icon: '🔭',
                requirement: { type: 'objectsScanned', value: 100 },
                reward: { credits: 1500, xp: 400 }
            },

            // TRADING ACHIEVEMENTS (15)
            merchant: {
                id: 'merchant',
                name: 'Merchant',
                description: 'Complete your first trade',
                category: 'trading',
                icon: '💰',
                requirement: { type: 'tradesCompleted', value: 1 },
                reward: { credits: 100, xp: 50 }
            },
            trader: {
                id: 'trader',
                name: 'Trader',
                description: 'Complete 50 trades',
                category: 'trading',
                icon: '💰',
                requirement: { type: 'tradesCompleted', value: 50 },
                reward: { credits: 2000, xp: 500 }
            },
            tycoon: {
                id: 'tycoon',
                name: 'Tycoon',
                description: 'Complete 500 trades',
                category: 'trading',
                icon: '💰',
                requirement: { type: 'tradesCompleted', value: 500 },
                reward: { credits: 20000, xp: 5000 }
            },
            wealthy: {
                id: 'wealthy',
                name: 'Wealthy',
                description: 'Earn 10,000 credits',
                category: 'trading',
                icon: '💎',
                requirement: { type: 'creditsEarned', value: 10000 },
                reward: { credits: 1000, xp: 300 }
            },
            millionaire: {
                id: 'millionaire',
                name: 'Millionaire',
                description: 'Earn 1,000,000 credits',
                category: 'trading',
                icon: '💎',
                requirement: { type: 'creditsEarned', value: 1000000 },
                reward: { credits: 50000, xp: 10000 }
            },
            profiteer: {
                id: 'profiteer',
                name: 'Profiteer',
                description: 'Make 10,000 credits profit in one trade',
                category: 'trading',
                icon: '📈',
                requirement: { type: 'biggestProfit', value: 10000 },
                reward: { credits: 5000, xp: 1000 }
            },

            // PROGRESSION ACHIEVEMENTS (15)
            levelUp: {
                id: 'levelUp',
                name: 'Level Up',
                description: 'Reach level 5',
                category: 'progression',
                icon: '⭐',
                requirement: { type: 'level', value: 5 },
                reward: { credits: 500, xp: 0 }
            },
            veteran: {
                id: 'veteran',
                name: 'Veteran',
                description: 'Reach level 10',
                category: 'progression',
                icon: '⭐',
                requirement: { type: 'level', value: 10 },
                reward: { credits: 2000, xp: 0 }
            },
            expert: {
                id: 'expert',
                name: 'Expert',
                description: 'Reach level 25',
                category: 'progression',
                icon: '⭐',
                requirement: { type: 'level', value: 25 },
                reward: { credits: 10000, xp: 0 }
            },
            master: {
                id: 'master',
                name: 'Master',
                description: 'Reach level 50',
                category: 'progression',
                icon: '⭐',
                requirement: { type: 'level', value: 50 },
                reward: { credits: 50000, xp: 0 }
            },
            skilled: {
                id: 'skilled',
                name: 'Skilled',
                description: 'Learn 10 skills',
                category: 'progression',
                icon: '📚',
                requirement: { type: 'skillsLearned', value: 10 },
                reward: { credits: 2000, xp: 500 }
            },
            upgraded: {
                id: 'upgraded',
                name: 'Upgraded',
                description: 'Upgrade all components to tier 2',
                category: 'progression',
                icon: '🔧',
                requirement: { type: 'allUpgradesTier', value: 2 },
                reward: { credits: 5000, xp: 1000 }
            },
            maxed: {
                id: 'maxed',
                name: 'Maxed Out',
                description: 'Upgrade all components to tier 5',
                category: 'progression',
                icon: '🔧',
                requirement: { type: 'allUpgradesTier', value: 5 },
                reward: { credits: 50000, xp: 10000 }
            },

            // SPECIAL ACHIEVEMENTS (10)
            timePlayed: {
                id: 'timePlayed',
                name: 'Dedicated',
                description: 'Play for 1 hour',
                category: 'special',
                icon: '⏰',
                requirement: { type: 'timePlayed', value: 3600 },
                reward: { credits: 1000, xp: 300 }
            },
            completionist: {
                id: 'completionist',
                name: 'Completionist',
                description: 'Unlock 50% of achievements',
                category: 'special',
                icon: '🏆',
                requirement: { type: 'achievementsUnlocked', value: 0.5 },
                reward: { credits: 10000, xp: 5000 }
            },
            perfectionist: {
                id: 'perfectionist',
                name: 'Perfectionist',
                description: 'Unlock all achievements',
                category: 'special',
                icon: '🏆',
                requirement: { type: 'achievementsUnlocked', value: 1.0 },
                reward: { credits: 100000, xp: 50000 }
            },
            allied: {
                id: 'allied',
                name: 'Allied',
                description: 'Reach Allied status with any faction',
                category: 'special',
                icon: '🤝',
                requirement: { type: 'factionAllied', value: 1 },
                reward: { credits: 2000, xp: 500 }
            },
            diplomat: {
                id: 'diplomat',
                name: 'Diplomat',
                description: 'Reach Allied status with all factions',
                category: 'special',
                icon: '🤝',
                requirement: { type: 'allFactionsAllied', value: 1 },
                reward: { credits: 50000, xp: 10000 }
            }
        };
    }

    /**
     * Update progress for an achievement
     */
    updateProgress(type, value) {
        let unlockedAny = false;

        for (const achievementId in this.achievements) {
            const achievement = this.achievements[achievementId];

            // Skip if already unlocked
            if (this.unlocked[achievementId]) continue;

            // Check if this achievement tracks this type
            if (achievement.requirement.type !== type) continue;

            // Update progress
            this.progress[achievementId] = value;

            // Check if unlocked
            if (this.checkUnlock(achievementId)) {
                this.unlockAchievement(achievementId);
                unlockedAny = true;
            }
        }

        return unlockedAny;
    }

    /**
     * Check if achievement should unlock
     */
    checkUnlock(achievementId) {
        const achievement = this.achievements[achievementId];
        if (!achievement) return false;

        const progress = this.progress[achievementId] || 0;
        const required = achievement.requirement.value;

        // Special handling for percentage-based achievements
        if (achievement.requirement.type === 'achievementsUnlocked') {
            const totalAchievements = Object.keys(this.achievements).length;
            const unlockedCount = Object.keys(this.unlocked).length;
            const percentage = unlockedCount / totalAchievements;
            return percentage >= required;
        }

        return progress >= required;
    }

    /**
     * Unlock achievement
     */
    unlockAchievement(achievementId) {
        const achievement = this.achievements[achievementId];
        if (!achievement) return false;

        // Already unlocked
        if (this.unlocked[achievementId]) return false;

        // Unlock it
        this.unlocked[achievementId] = Date.now();

        // Trigger callback
        if (this.onAchievementUnlocked) {
            this.onAchievementUnlocked(achievement);
        }

        // Check if category complete
        if (this.isCategoryComplete(achievement.category) && this.onCategoryComplete) {
            this.onCategoryComplete(achievement.category);
        }

        return true;
    }

    /**
     * Check if achievement is unlocked
     */
    isUnlocked(achievementId) {
        return !!this.unlocked[achievementId];
    }

    /**
     * Get achievement progress
     */
    getProgress(achievementId) {
        const achievement = this.achievements[achievementId];
        if (!achievement) return 0;

        const progress = this.progress[achievementId] || 0;
        const required = achievement.requirement.value;

        return Math.min(1.0, progress / required);
    }

    /**
     * Get achievement info
     */
    getAchievementInfo(achievementId) {
        const achievement = this.achievements[achievementId];
        if (!achievement) return null;

        return {
            ...achievement,
            unlocked: this.isUnlocked(achievementId),
            unlockedAt: this.unlocked[achievementId] || null,
            progress: this.getProgress(achievementId),
            currentValue: this.progress[achievementId] || 0
        };
    }

    /**
     * Get achievements by category
     */
    getAchievementsByCategory(category) {
        const achievements = [];

        for (const achievementId in this.achievements) {
            const achievement = this.achievements[achievementId];
            if (achievement.category === category) {
                achievements.push(this.getAchievementInfo(achievementId));
            }
        }

        return achievements;
    }

    /**
     * Check if category is complete
     */
    isCategoryComplete(category) {
        const categoryAchievements = this.getAchievementsByCategory(category);
        return categoryAchievements.every(a => a.unlocked);
    }

    /**
     * Get category progress
     */
    getCategoryProgress(category) {
        const categoryAchievements = this.getAchievementsByCategory(category);
        const unlocked = categoryAchievements.filter(a => a.unlocked).length;
        const total = categoryAchievements.length;

        return {
            unlocked: unlocked,
            total: total,
            percentage: (unlocked / total) * 100,
            complete: unlocked === total
        };
    }

    /**
     * Get overall progress
     */
    getOverallProgress() {
        const totalAchievements = Object.keys(this.achievements).length;
        const unlockedCount = Object.keys(this.unlocked).length;

        return {
            unlocked: unlockedCount,
            total: totalAchievements,
            percentage: (unlockedCount / totalAchievements) * 100
        };
    }

    /**
     * Get recent achievements
     */
    getRecentAchievements(count = 5) {
        const recent = [];

        for (const achievementId in this.unlocked) {
            recent.push({
                ...this.getAchievementInfo(achievementId),
                unlockedAt: this.unlocked[achievementId]
            });
        }

        // Sort by unlock time (most recent first)
        recent.sort((a, b) => b.unlockedAt - a.unlockedAt);

        return recent.slice(0, count);
    }

    /**
     * Save achievement data
     */
    save() {
        return {
            unlocked: this.unlocked,
            progress: this.progress
        };
    }

    /**
     * Load achievement data
     */
    load(data) {
        if (!data) return;

        this.unlocked = data.unlocked || {};
        this.progress = data.progress || {};
    }

    /**
     * Get summary
     */
    getSummary() {
        const summary = {
            overall: this.getOverallProgress(),
            categories: {},
            recent: this.getRecentAchievements(5)
        };

        for (const category of this.categories) {
            summary.categories[category] = this.getCategoryProgress(category);
        }

        return summary;
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AchievementSystem;
}
