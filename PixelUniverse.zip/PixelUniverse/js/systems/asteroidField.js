/**
 * PixelVerse - Asteroid Field System
 * Procedural asteroid field generation with density zones
 * Minimalistic design with varied compositions
 */

class AsteroidFieldSystem {
    constructor(entityManager, spriteManager, environmentFactory) {
        this.entityManager = entityManager;
        this.spriteManager = spriteManager;
        this.environmentFactory = environmentFactory;
        
        this.fields = [];
    }

    /**
     * Create asteroid field
     */
    createField(centerX, centerY, radius, density = 'medium', composition = 'mixed') {
        const field = {
            centerX: centerX,
            centerY: centerY,
            radius: radius,
            density: density,
            composition: composition,
            asteroids: []
        };
        
        // Calculate asteroid count based on density
        const densityMultiplier = {
            'sparse': 0.5,
            'medium': 1.0,
            'dense': 2.0,
            'very_dense': 3.0
        };
        
        const baseCount = Math.floor((radius / 50) * 10);
        const count = Math.floor(baseCount * (densityMultiplier[density] || 1.0));
        
        // Generate asteroids
        for (let i = 0; i < count; i++) {
            const asteroid = this.createAsteroid(centerX, centerY, radius, composition);
            if (asteroid) {
                field.asteroids.push(asteroid);
            }
        }
        
        this.fields.push(field);
        return field;
    }

    /**
     * Create single asteroid in field
     */
    createAsteroid(centerX, centerY, radius, composition) {
        // Random position within radius
        const angle = Math.random() * Math.PI * 2;
        const distance = Math.random() * radius;
        const x = centerX + Math.cos(angle) * distance;
        const y = centerY + Math.sin(angle) * distance;
        
        // Determine composition
        let comp;
        if (composition === 'mixed') {
            const types = ['iron', 'ice', 'mineral', 'organic'];
            comp = types[Math.floor(Math.random() * types.length)];
        } else {
            comp = composition;
        }
        
        // Only use 32px size (we only have 32px sprites)
        let size = 32;
        
        // Create asteroid entity
        return this.environmentFactory.createAsteroid(x, y, size, comp);
    }

    /**
     * Create belt (ring-shaped field)
     */
    createBelt(centerX, centerY, innerRadius, outerRadius, density = 'medium', composition = 'mixed') {
        const field = {
            centerX: centerX,
            centerY: centerY,
            innerRadius: innerRadius,
            outerRadius: outerRadius,
            density: density,
            composition: composition,
            asteroids: [],
            type: 'belt'
        };
        
        // Calculate asteroid count
        const densityMultiplier = {
            'sparse': 0.5,
            'medium': 1.0,
            'dense': 2.0,
            'very_dense': 3.0
        };
        
        const beltWidth = outerRadius - innerRadius;
        const circumference = Math.PI * (innerRadius + outerRadius);
        const baseCount = Math.floor((circumference / 50) * (beltWidth / 50) * 10);
        const count = Math.floor(baseCount * (densityMultiplier[density] || 1.0));
        
        // Generate asteroids in belt
        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const distance = innerRadius + Math.random() * beltWidth;
            const x = centerX + Math.cos(angle) * distance;
            const y = centerY + Math.sin(angle) * distance;
            
            // Determine composition
            let comp;
            if (composition === 'mixed') {
                const types = ['iron', 'ice', 'mineral', 'organic'];
                comp = types[Math.floor(Math.random() * types.length)];
            } else {
                comp = composition;
            }
            
            // Only use 32px size (we only have 32px sprites)
            let size = 32;
            
            const asteroid = this.environmentFactory.createAsteroid(x, y, size, comp);
            if (asteroid) {
                // Add orbital velocity for belt
                const velocity = asteroid.getComponent('velocity');
                if (velocity) {
                    const orbitalSpeed = 20 / distance * 1000;
                    velocity.vx = -Math.sin(angle) * orbitalSpeed;
                    velocity.vy = Math.cos(angle) * orbitalSpeed;
                }
                
                field.asteroids.push(asteroid);
            }
        }
        
        this.fields.push(field);
        return field;
    }

    /**
     * Create cluster (tight group)
     */
    createCluster(centerX, centerY, radius, count = 10, composition = 'mixed') {
        const field = {
            centerX: centerX,
            centerY: centerY,
            radius: radius,
            count: count,
            composition: composition,
            asteroids: [],
            type: 'cluster'
        };
        
        for (let i = 0; i < count; i++) {
            // Gaussian distribution for tighter clustering
            const angle = Math.random() * Math.PI * 2;
            const distance = (Math.random() + Math.random()) / 2 * radius; // Bias toward center
            const x = centerX + Math.cos(angle) * distance;
            const y = centerY + Math.sin(angle) * distance;
            
            // Determine composition
            let comp;
            if (composition === 'mixed') {
                const types = ['iron', 'ice', 'mineral', 'organic'];
                comp = types[Math.floor(Math.random() * types.length)];
            } else {
                comp = composition;
            }
            
            // Clusters tend to have similar-sized asteroids
            const size = 32;
            
            const asteroid = this.environmentFactory.createAsteroid(x, y, size, comp);
            if (asteroid) {
                field.asteroids.push(asteroid);
            }
        }
        
        this.fields.push(field);
        return field;
    }

    /**
     * Create debris field (from destroyed ship/station)
     */
    createDebrisField(centerX, centerY, radius, count = 15) {
        const field = {
            centerX: centerX,
            centerY: centerY,
            radius: radius,
            count: count,
            asteroids: [],
            type: 'debris'
        };
        
        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const distance = Math.random() * radius;
            const x = centerX + Math.cos(angle) * distance;
            const y = centerY + Math.sin(angle) * distance;
            
            // Mix of derelicts and asteroids
            let entity;
            if (Math.random() < 0.3) {
                // Derelict ship fragment
                entity = this.environmentFactory.createDerelict(x, y, 32);
            } else {
                // Metal asteroid (32px)
                entity = this.environmentFactory.createAsteroid(x, y, 32, 'iron');
            }
            
            if (entity) {
                // Add random velocity (explosion scatter)
                const velocity = entity.getComponent('velocity');
                if (velocity) {
                    velocity.vx = (Math.random() - 0.5) * 50;
                    velocity.vy = (Math.random() - 0.5) * 50;
                    velocity.angularVelocity = (Math.random() - 0.5) * 2;
                }
                
                field.asteroids.push(entity);
            }
        }
        
        this.fields.push(field);
        return field;
    }

    /**
     * Remove field
     */
    removeField(field) {
        // Remove all asteroids in field
        for (const asteroid of field.asteroids) {
            this.entityManager.removeEntity(asteroid);
        }
        
        // Remove field from list
        const index = this.fields.indexOf(field);
        if (index > -1) {
            this.fields.splice(index, 1);
        }
    }

    /**
     * Clear all fields
     */
    clearAll() {
        for (const field of this.fields) {
            for (const asteroid of field.asteroids) {
                this.entityManager.removeEntity(asteroid);
            }
        }
        
        this.fields = [];
    }

    /**
     * Get field at position
     */
    getFieldAt(x, y) {
        for (const field of this.fields) {
            const dx = x - field.centerX;
            const dy = y - field.centerY;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (field.type === 'belt') {
                if (distance >= field.innerRadius && distance <= field.outerRadius) {
                    return field;
                }
            } else {
                if (distance <= field.radius) {
                    return field;
                }
            }
        }
        
        return null;
    }

    /**
     * Update fields (optional - for dynamic fields)
     */
    update(deltaTime) {
        // Future: Add dynamic field behavior
        // - Asteroids slowly drifting
        // - Fields expanding/contracting
        // - New asteroids spawning
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AsteroidFieldSystem;
}

