/**
 * PixelVerse - Reputation System
 * Handles faction relationships, reputation levels, and rewards/penalties
 */

class ReputationSystem {
    constructor() {
        // Factions
        this.factions = ['federation', 'pirates', 'traders', 'scientists', 'rebels'];
        
        // Reputation levels (-100 to +100)
        this.reputation = {
            federation: 0,
            pirates: 0,
            traders: 0,
            scientists: 0,
            rebels: 0
        };
        
        // Reputation thresholds
        this.thresholds = {
            hostile: -75,      // Hostile: -100 to -75
            unfriendly: -50,   // Unfriendly: -74 to -50
            neutral: -25,      // Neutral: -49 to -25
            friendly: 0,       // Friendly: -24 to 0
            allied: 25,        // Allied: 1 to 25
            honored: 50,       // Honored: 26 to 50
            revered: 75,       // Revered: 51 to 75
            exalted: 100       // Exalted: 76 to 100
        };
        
        // Faction relationships (how factions feel about each other)
        this.relationships = {
            federation: { pirates: -1.0, traders: 0.5, scientists: 0.8, rebels: -0.6 },
            pirates: { federation: -1.0, traders: -0.3, scientists: -0.5, rebels: 0.4 },
            traders: { federation: 0.5, pirates: -0.3, scientists: 0.3, rebels: 0.0 },
            scientists: { federation: 0.8, pirates: -0.5, traders: 0.3, rebels: -0.2 },
            rebels: { federation: -0.6, pirates: 0.4, traders: 0.0, scientists: -0.2 }
        };
        
        // Faction info
        this.factionInfo = {
            federation: {
                name: 'Galactic Federation',
                description: 'The official governing body of known space',
                color: '#4488ff',
                icon: '🛡️'
            },
            pirates: {
                name: 'Pirate Syndicate',
                description: 'Outlaws and raiders of the void',
                color: '#ff4444',
                icon: '☠️'
            },
            traders: {
                name: 'Merchant Guild',
                description: 'Independent traders and merchants',
                color: '#ffaa00',
                icon: '💰'
            },
            scientists: {
                name: 'Research Collective',
                description: 'Scientists and explorers',
                color: '#44ff88',
                icon: '🔬'
            },
            rebels: {
                name: 'Freedom Alliance',
                description: 'Rebels fighting for independence',
                color: '#ff8844',
                icon: '⚡'
            }
        };
        
        // Callbacks
        this.onReputationChange = null;
        this.onStatusChange = null;
    }

    /**
     * Gain reputation with a faction
     */
    gainReputation(faction, amount) {
        if (!this.factions.includes(faction)) return;

        const oldStatus = this.getStatus(faction);
        const oldRep = this.reputation[faction];

        // Apply reputation gain
        this.reputation[faction] = Math.min(100, this.reputation[faction] + amount);

        // Apply relationship effects (allied factions gain, enemies lose)
        for (const otherFaction of this.factions) {
            if (otherFaction === faction) continue;

            const relationship = this.relationships[faction][otherFaction];
            if (relationship !== 0) {
                const effect = amount * relationship * 0.3; // 30% of the gain/loss
                this.reputation[otherFaction] = Math.max(-100, Math.min(100, 
                    this.reputation[otherFaction] + effect
                ));
            }
        }

        const newStatus = this.getStatus(faction);

        // Trigger callbacks
        if (this.onReputationChange) {
            this.onReputationChange(faction, oldRep, this.reputation[faction]);
        }

        if (oldStatus !== newStatus && this.onStatusChange) {
            this.onStatusChange(faction, oldStatus, newStatus);
        }

        return {
            faction: faction,
            oldRep: oldRep,
            newRep: this.reputation[faction],
            change: this.reputation[faction] - oldRep,
            oldStatus: oldStatus,
            newStatus: newStatus,
            statusChanged: oldStatus !== newStatus
        };
    }

    /**
     * Lose reputation with a faction
     */
    loseReputation(faction, amount) {
        return this.gainReputation(faction, -amount);
    }

    /**
     * Get reputation status
     */
    getStatus(faction) {
        const rep = this.reputation[faction];

        if (rep >= 76) return 'exalted';
        if (rep >= 51) return 'revered';
        if (rep >= 26) return 'honored';
        if (rep >= 1) return 'allied';
        if (rep >= -24) return 'friendly';
        if (rep >= -49) return 'neutral';
        if (rep >= -74) return 'unfriendly';
        return 'hostile';
    }

    /**
     * Get status display name
     */
    getStatusName(status) {
        const names = {
            hostile: 'Hostile',
            unfriendly: 'Unfriendly',
            neutral: 'Neutral',
            friendly: 'Friendly',
            allied: 'Allied',
            honored: 'Honored',
            revered: 'Revered',
            exalted: 'Exalted'
        };
        return names[status] || 'Unknown';
    }

    /**
     * Get status color
     */
    getStatusColor(status) {
        const colors = {
            hostile: '#ff0000',
            unfriendly: '#ff6600',
            neutral: '#ffaa00',
            friendly: '#ffff00',
            allied: '#88ff00',
            honored: '#00ff88',
            revered: '#00ffff',
            exalted: '#8800ff'
        };
        return colors[status] || '#ffffff';
    }

    /**
     * Get reputation value
     */
    getReputation(faction) {
        return this.reputation[faction] || 0;
    }

    /**
     * Get all reputations
     */
    getAllReputations() {
        const result = {};
        for (const faction of this.factions) {
            result[faction] = {
                value: this.reputation[faction],
                status: this.getStatus(faction),
                statusName: this.getStatusName(this.getStatus(faction)),
                info: this.factionInfo[faction]
            };
        }
        return result;
    }

    /**
     * Check if hostile with faction
     */
    isHostile(faction) {
        return this.reputation[faction] <= this.thresholds.hostile;
    }

    /**
     * Check if friendly with faction
     */
    isFriendly(faction) {
        return this.reputation[faction] >= this.thresholds.friendly;
    }

    /**
     * Check if allied with faction
     */
    isAllied(faction) {
        return this.reputation[faction] >= this.thresholds.allied;
    }

    /**
     * Get reputation rewards
     */
    getRewards(faction) {
        const status = this.getStatus(faction);
        const rewards = {
            hostile: {
                priceMultiplier: 1.5,    // 50% more expensive
                missionAccess: false,
                stationAccess: false,
                specialItems: false
            },
            unfriendly: {
                priceMultiplier: 1.25,   // 25% more expensive
                missionAccess: false,
                stationAccess: true,
                specialItems: false
            },
            neutral: {
                priceMultiplier: 1.1,    // 10% more expensive
                missionAccess: false,
                stationAccess: true,
                specialItems: false
            },
            friendly: {
                priceMultiplier: 1.0,    // Normal prices
                missionAccess: true,
                stationAccess: true,
                specialItems: false
            },
            allied: {
                priceMultiplier: 0.95,   // 5% discount
                missionAccess: true,
                stationAccess: true,
                specialItems: false
            },
            honored: {
                priceMultiplier: 0.9,    // 10% discount
                missionAccess: true,
                stationAccess: true,
                specialItems: true
            },
            revered: {
                priceMultiplier: 0.85,   // 15% discount
                missionAccess: true,
                stationAccess: true,
                specialItems: true
            },
            exalted: {
                priceMultiplier: 0.8,    // 20% discount
                missionAccess: true,
                stationAccess: true,
                specialItems: true
            }
        };

        return rewards[status] || rewards.neutral;
    }

    /**
     * Get price multiplier for faction
     */
    getPriceMultiplier(faction) {
        return this.getRewards(faction).priceMultiplier;
    }

    /**
     * Can access faction missions
     */
    canAccessMissions(faction) {
        return this.getRewards(faction).missionAccess;
    }

    /**
     * Can access faction stations
     */
    canAccessStations(faction) {
        return this.getRewards(faction).stationAccess;
    }

    /**
     * Can access special items
     */
    canAccessSpecialItems(faction) {
        return this.getRewards(faction).specialItems;
    }

    /**
     * Get faction relationship
     */
    getRelationship(faction1, faction2) {
        if (faction1 === faction2) return 1.0;
        return this.relationships[faction1][faction2] || 0;
    }

    /**
     * Save reputation data
     */
    save() {
        return {
            reputation: this.reputation
        };
    }

    /**
     * Load reputation data
     */
    load(data) {
        if (!data) return;

        this.reputation = data.reputation || {
            federation: 0,
            pirates: 0,
            traders: 0,
            scientists: 0,
            rebels: 0
        };
    }

    /**
     * Get summary
     */
    getSummary() {
        const summary = {
            factions: {},
            hostile: [],
            friendly: [],
            allied: []
        };

        for (const faction of this.factions) {
            const status = this.getStatus(faction);
            const info = {
                name: this.factionInfo[faction].name,
                reputation: this.reputation[faction],
                status: status,
                statusName: this.getStatusName(status)
            };

            summary.factions[faction] = info;

            if (this.isHostile(faction)) {
                summary.hostile.push(faction);
            } else if (this.isAllied(faction)) {
                summary.allied.push(faction);
            } else if (this.isFriendly(faction)) {
                summary.friendly.push(faction);
            }
        }

        return summary;
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ReputationSystem;
}

