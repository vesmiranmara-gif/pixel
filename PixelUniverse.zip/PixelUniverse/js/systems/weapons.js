/**
 * PixelVerse - Weapon System
 * Handles weapon firing, projectiles, and weapon types
 * Minimalistic design with retro sci-fi aesthetic
 */

class WeaponSystem {
    constructor(entityManager, particleSystem, visualEffects, audioManager) {
        this.entityManager = entityManager;
        this.particleSystem = particleSystem;
        this.visualEffects = visualEffects;
        this.audioManager = audioManager;
        this.shipSystemsManager = null; // Set externally

        this.projectiles = [];
        
        // Weapon definitions
        this.weaponTypes = {
            laser: {
                name: 'Laser Cannon',
                damage: 15,
                fireRate: 0.3,
                projectileSpeed: 600,
                energyCost: 5,
                color: RETRO_PALETTE.alertRed,
                sound: 'laser'
            },
            plasma: {
                name: 'Plasma Gun',
                damage: 25,
                fireRate: 0.5,
                projectileSpeed: 400,
                energyCost: 10,
                color: RETRO_PALETTE.statusBlue,
                sound: 'plasma'
            },
            railgun: {
                name: 'Railgun',
                damage: 50,
                fireRate: 1.5,
                projectileSpeed: 1200,
                energyCost: 20,
                color: RETRO_PALETTE.warningYellow,
                sound: 'railgun'
            },
            missile: {
                name: 'Missile Launcher',
                damage: 40,
                fireRate: 2.0,
                projectileSpeed: 300,
                energyCost: 15,
                color: RETRO_PALETTE.cautionOrange,
                sound: 'missile',
                homing: true
            }
        };
    }

    /**
     * Fire weapon from entity
     */
    fireWeapon(entity, weaponType = 'laser', targetX = null, targetY = null) {
        const transform = entity.getComponent('transform');
        const weapon = entity.getComponent('weapon');

        if (!transform) return null;

        // Check ship systems (if available)
        if (this.shipSystemsManager) {
            if (!this.shipSystemsManager.canFireWeapons(entity)) {
                return null; // Weapons disabled, damaged, or overheated
            }
        }

        // Check cooldown
        if (weapon && weapon.cooldown > 0) {
            return null;
        }
        
        const weaponData = this.weaponTypes[weaponType];
        if (!weaponData) return null;
        
        // Calculate weapon mount position (front of ship)
        const mountX = transform.x + Math.cos(transform.rotation) * 25;
        const mountY = transform.y + Math.sin(transform.rotation) * 25;
        
        // Create projectile
        const projectile = this.createProjectile(
            mountX,
            mountY,
            transform.rotation,
            weaponType,
            entity,
            targetX,
            targetY
        );
        
        // Muzzle flash effect
        this.visualEffects.createMuzzleFlash(mountX, mountY, transform.rotation, 0.05);

        // Particle effect
        this.particleSystem.createEffect('spark', mountX, mountY, {
            angle: transform.rotation,
            count: 5
        });

        // Play weapon sound
        if (this.audioManager) {
            switch (weaponType) {
                case 'laser':
                    this.audioManager.playLaser();
                    break;
                case 'plasma':
                    this.audioManager.playPlasma();
                    break;
                case 'railgun':
                    this.audioManager.playRailgun();
                    break;
                case 'missile':
                    this.audioManager.playMissile();
                    break;
            }
        }

        // Set cooldown
        if (weapon) {
            weapon.cooldown = weaponData.fireRate;
        }

        // Add weapon heat (if ship systems available)
        if (this.shipSystemsManager) {
            this.shipSystemsManager.addWeaponHeat(entity, 10); // Add 10 heat per shot
        }

        return projectile;
    }

    /**
     * Create projectile entity
     */
    createProjectile(x, y, angle, weaponType, owner, targetX = null, targetY = null) {
        const weaponData = this.weaponTypes[weaponType];
        
        const projectile = this.entityManager.createEntity();
        
        // Calculate velocity
        const vx = Math.cos(angle) * weaponData.projectileSpeed;
        const vy = Math.sin(angle) * weaponData.projectileSpeed;
        
        projectile
            .addComponent('transform', new TransformComponent(x, y, angle, 1))
            .addComponent('velocity', new VelocityComponent(vx, vy, 0))
            .addComponent('projectile', {
                damage: weaponData.damage,
                weaponType: weaponType,
                owner: owner,
                lifetime: 3.0, // 3 seconds
                color: weaponData.color,
                homing: weaponData.homing || false,
                targetX: targetX,
                targetY: targetY
            });
        
        this.projectiles.push(projectile);
        
        return projectile;
    }

    /**
     * Update weapon system
     */
    update(deltaTime) {
        // Update projectiles
        for (let i = this.projectiles.length - 1; i >= 0; i--) {
            const projectile = this.projectiles[i];
            const projectileComp = projectile.getComponent('projectile');
            
            if (!projectileComp) {
                this.projectiles.splice(i, 1);
                continue;
            }
            
            // Update lifetime
            projectileComp.lifetime -= deltaTime;
            
            if (projectileComp.lifetime <= 0) {
                // Remove expired projectile
                this.entityManager.removeEntity(projectile);
                this.projectiles.splice(i, 1);
                continue;
            }
            
            // Homing behavior
            if (projectileComp.homing && projectileComp.targetX !== null && projectileComp.targetY !== null) {
                this.updateHomingProjectile(projectile, deltaTime);
            }
            
            // Trail effect
            const transform = projectile.getComponent('transform');
            if (transform && Math.random() < 0.3) {
                this.particleSystem.createEffect('spark', transform.x, transform.y, {
                    count: 1,
                    velocity: { min: -50, max: 50 }
                });
            }

            // Check collision with all entities that have health
            const entities = this.entityManager.getEntitiesWithComponents('health');
            for (const target of entities) {
                if (this.checkCollision(projectile, target)) {
                    this.handleHit(projectile, target);
                    break; // Projectile destroyed, stop checking
                }
            }
        }
        
        // Update weapon cooldowns
        const entities = this.entityManager.getEntitiesWithComponents('weapon');
        for (const entity of entities) {
            const weapon = entity.getComponent('weapon');
            if (weapon && weapon.cooldown > 0) {
                weapon.cooldown -= deltaTime;
                if (weapon.cooldown < 0) weapon.cooldown = 0;
            }
        }
    }

    /**
     * Update homing projectile
     */
    updateHomingProjectile(projectile, deltaTime) {
        const transform = projectile.getComponent('transform');
        const velocity = projectile.getComponent('velocity');
        const projectileComp = projectile.getComponent('projectile');
        
        if (!transform || !velocity || !projectileComp) return;
        
        // Calculate angle to target
        const dx = projectileComp.targetX - transform.x;
        const dy = projectileComp.targetY - transform.y;
        const targetAngle = Math.atan2(dy, dx);
        
        // Gradually turn toward target
        const turnSpeed = 3.0; // radians per second
        let angleDiff = targetAngle - transform.rotation;
        
        // Normalize angle difference
        while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
        while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;
        
        // Turn
        const turnAmount = Math.sign(angleDiff) * Math.min(Math.abs(angleDiff), turnSpeed * deltaTime);
        transform.rotation += turnAmount;
        
        // Update velocity
        const weaponData = this.weaponTypes[projectileComp.weaponType];
        velocity.vx = Math.cos(transform.rotation) * weaponData.projectileSpeed;
        velocity.vy = Math.sin(transform.rotation) * weaponData.projectileSpeed;
    }

    /**
     * Render projectiles
     */
    render(renderer, cameraX, cameraY) {
        for (const projectile of this.projectiles) {
            const transform = projectile.getComponent('transform');
            const projectileComp = projectile.getComponent('projectile');
            
            if (!transform || !projectileComp) continue;
            
            const coords = renderer.getViewportCoords(transform.x, transform.y, cameraX, cameraY);
            if (!renderer.isInViewport(coords.x, coords.y)) continue;
            
            const ctx = renderer.context;
            
            ctx.save();
            ctx.translate(coords.x, coords.y);
            ctx.rotate(transform.rotation);
            
            // Draw projectile based on type
            if (projectileComp.weaponType === 'missile') {
                // Missile (small triangle)
                ctx.fillStyle = projectileComp.color;
                ctx.beginPath();
                ctx.moveTo(6, 0);
                ctx.lineTo(-3, -2);
                ctx.lineTo(-3, 2);
                ctx.closePath();
                ctx.fill();
                
                // Exhaust
                ctx.fillStyle = RETRO_PALETTE.warningYellow;
                ctx.fillRect(-4, -1, 2, 2);
            } else {
                // Energy projectile (elongated oval)
                ctx.fillStyle = projectileComp.color;
                ctx.fillRect(-2, -1, 8, 2);
                
                // Core glow
                ctx.fillStyle = RETRO_PALETTE.pureWhite;
                ctx.fillRect(0, -1, 4, 2);
            }
            
            ctx.restore();
        }
    }

    /**
     * Check projectile collision with entity
     */
    checkCollision(projectile, target) {
        const projectileTransform = projectile.getComponent('transform');
        const targetTransform = target.getComponent('transform');
        const projectileComp = projectile.getComponent('projectile');
        
        if (!projectileTransform || !targetTransform || !projectileComp) return false;
        
        // Don't hit owner
        if (projectileComp.owner === target) return false;
        
        // Simple distance check (assume 20px collision radius)
        const dx = projectileTransform.x - targetTransform.x;
        const dy = projectileTransform.y - targetTransform.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        return distance < 20;
    }

    /**
     * Handle projectile hit
     */
    handleHit(projectile, target) {
        const projectileComp = projectile.getComponent('projectile');
        const targetHealth = target.getComponent('health');
        const transform = projectile.getComponent('transform');

        if (!projectileComp || !transform) return;

        // Apply damage and check if target died
        let targetDied = false;
        if (targetHealth) {
            targetDied = targetHealth.takeDamage(projectileComp.damage);

            // If target died and was killed by player, award XP
            if (targetDied && projectileComp.owner && this.onEnemyKilled) {
                this.onEnemyKilled(target, projectileComp.owner);
            }
        }

        // Impact effects
        this.particleSystem.createEffect('spark', transform.x, transform.y, {
            count: 10
        });

        // If target died, create explosion
        if (targetDied) {
            const targetTransform = target.getComponent('transform');
            if (targetTransform) {
                this.particleSystem.createEffect('explosion', targetTransform.x, targetTransform.y, {
                    count: 30
                });

                // Play explosion sound
                if (this.audioManager) {
                    this.audioManager.playExplosion();
                }
            }

            // Remove target entity
            this.entityManager.removeEntity(target);
        }

        // Remove projectile
        this.entityManager.removeEntity(projectile);
        const index = this.projectiles.indexOf(projectile);
        if (index > -1) {
            this.projectiles.splice(index, 1);
        }
    }

    /**
     * Get all projectiles
     */
    getProjectiles() {
        return this.projectiles;
    }

    /**
     * Clear all projectiles
     */
    clearAll() {
        for (const projectile of this.projectiles) {
            this.entityManager.removeEntity(projectile);
        }
        this.projectiles = [];
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = WeaponSystem;
}

