/**
 * PixelVerse - Enhanced Thruster System
 * Handles directional thrust particles and maneuvering thrusters
 * Task 3.2: Enhanced Engine & Maneuvering Thrusters
 */

class EnhancedThrusterSystem {
    constructor(particleSystem) {
        this.particleSystem = particleSystem;
        
        // Thruster configurations for different ship sizes
        this.thrusterConfigs = {
            // Small ships (fighters, scouts)
            small: {
                mainEngine: { offset: 16, spread: 8, particlesPerFrame: 3 },
                leftThruster: { offset: { x: 8, y: -6 }, particlesPerFrame: 2 },
                rightThruster: { offset: { x: 8, y: 6 }, particlesPerFrame: 2 },
                frontThruster: { offset: { x: -12, y: 0 }, particlesPerFrame: 2 }
            },
            // Medium ships (frigates, corvettes)
            medium: {
                mainEngine: { offset: 20, spread: 12, particlesPerFrame: 5 },
                leftThruster: { offset: { x: 10, y: -8 }, particlesPerFrame: 3 },
                rightThruster: { offset: { x: 10, y: 8 }, particlesPerFrame: 3 },
                frontThruster: { offset: { x: -16, y: 0 }, particlesPerFrame: 3 }
            },
            // Large ships (transports, capital ships)
            large: {
                mainEngine: { offset: 30, spread: 16, particlesPerFrame: 8 },
                leftThruster: { offset: { x: 15, y: -12 }, particlesPerFrame: 4 },
                rightThruster: { offset: { x: 15, y: 12 }, particlesPerFrame: 4 },
                frontThruster: { offset: { x: -24, y: 0 }, particlesPerFrame: 4 }
            }
        };
    }

    /**
     * Emit main engine thrust particles (directional, no wind effect)
     * @param {number} x - Ship x position
     * @param {number} y - Ship y position
     * @param {number} rotation - Ship rotation in radians
     * @param {number} thrustIntensity - Thrust intensity (0.0 to 1.0)
     * @param {string} shipSize - Ship size ('small', 'medium', 'large')
     * @param {string} engineType - Engine type ('chemical', 'ion', 'plasma')
     */
    emitMainEngineThrust(x, y, rotation, thrustIntensity, shipSize = 'medium', engineType = 'chemical') {
        const config = this.thrusterConfigs[shipSize] || this.thrusterConfigs.medium;
        const mainEngine = config.mainEngine;
        
        // Calculate engine position (rear of ship)
        const engineX = x - Math.cos(rotation) * mainEngine.offset;
        const engineY = y - Math.sin(rotation) * mainEngine.offset;
        
        // Calculate particle count based on intensity
        const particleCount = Math.ceil(mainEngine.particlesPerFrame * thrustIntensity);
        
        // Emit particles in thrust direction (opposite to ship facing)
        const thrustAngle = rotation + Math.PI;
        
        for (let i = 0; i < particleCount; i++) {
            // Add slight spread to particles
            const spreadAngle = thrustAngle + (Math.random() - 0.5) * (mainEngine.spread * Math.PI / 180);
            
            // Calculate particle velocity based on thrust direction and intensity
            const baseVelocity = 80 + thrustIntensity * 60;
            const velocityX = Math.cos(spreadAngle) * baseVelocity;
            const velocityY = Math.sin(spreadAngle) * baseVelocity;
            
            // Create particle with directional velocity
            this.createDirectionalThrustParticle(
                engineX,
                engineY,
                velocityX,
                velocityY,
                thrustIntensity,
                engineType
            );
        }
    }

    /**
     * Emit left maneuvering thruster (fires when turning right)
     * @param {number} x - Ship x position
     * @param {number} y - Ship y position
     * @param {number} rotation - Ship rotation in radians
     * @param {number} turnIntensity - Turn intensity (0.0 to 1.0)
     * @param {string} shipSize - Ship size ('small', 'medium', 'large')
     */
    emitLeftThruster(x, y, rotation, turnIntensity, shipSize = 'medium') {
        const config = this.thrusterConfigs[shipSize] || this.thrusterConfigs.medium;
        const thruster = config.leftThruster;
        
        // Calculate thruster position (left side of ship)
        const thrusterX = x + Math.cos(rotation) * thruster.offset.x + Math.cos(rotation + Math.PI / 2) * thruster.offset.y;
        const thrusterY = y + Math.sin(rotation) * thruster.offset.x + Math.sin(rotation + Math.PI / 2) * thruster.offset.y;
        
        // Calculate particle count based on intensity
        const particleCount = Math.ceil(thruster.particlesPerFrame * turnIntensity);
        
        // Thrust direction (perpendicular to ship, pointing left)
        const thrustAngle = rotation + Math.PI / 2;
        
        for (let i = 0; i < particleCount; i++) {
            const spreadAngle = thrustAngle + (Math.random() - 0.5) * 0.3;
            const baseVelocity = 60 + turnIntensity * 40;
            const velocityX = Math.cos(spreadAngle) * baseVelocity;
            const velocityY = Math.sin(spreadAngle) * baseVelocity;
            
            this.createManeuveringThrustParticle(
                thrusterX,
                thrusterY,
                velocityX,
                velocityY,
                turnIntensity
            );
        }
    }

    /**
     * Emit right maneuvering thruster (fires when turning left)
     * @param {number} x - Ship x position
     * @param {number} y - Ship y position
     * @param {number} rotation - Ship rotation in radians
     * @param {number} turnIntensity - Turn intensity (0.0 to 1.0)
     * @param {string} shipSize - Ship size ('small', 'medium', 'large')
     */
    emitRightThruster(x, y, rotation, turnIntensity, shipSize = 'medium') {
        const config = this.thrusterConfigs[shipSize] || this.thrusterConfigs.medium;
        const thruster = config.rightThruster;
        
        // Calculate thruster position (right side of ship)
        const thrusterX = x + Math.cos(rotation) * thruster.offset.x + Math.cos(rotation - Math.PI / 2) * thruster.offset.y;
        const thrusterY = y + Math.sin(rotation) * thruster.offset.x + Math.sin(rotation - Math.PI / 2) * thruster.offset.y;
        
        // Calculate particle count based on intensity
        const particleCount = Math.ceil(thruster.particlesPerFrame * turnIntensity);
        
        // Thrust direction (perpendicular to ship, pointing right)
        const thrustAngle = rotation - Math.PI / 2;
        
        for (let i = 0; i < particleCount; i++) {
            const spreadAngle = thrustAngle + (Math.random() - 0.5) * 0.3;
            const baseVelocity = 60 + turnIntensity * 40;
            const velocityX = Math.cos(spreadAngle) * baseVelocity;
            const velocityY = Math.sin(spreadAngle) * baseVelocity;
            
            this.createManeuveringThrustParticle(
                thrusterX,
                thrusterY,
                velocityX,
                velocityY,
                turnIntensity
            );
        }
    }

    /**
     * Emit front maneuvering thrusters (fires when braking/reversing)
     * @param {number} x - Ship x position
     * @param {number} y - Ship y position
     * @param {number} rotation - Ship rotation in radians
     * @param {number} brakeIntensity - Brake intensity (0.0 to 1.0)
     * @param {string} shipSize - Ship size ('small', 'medium', 'large')
     */
    emitFrontThrusters(x, y, rotation, brakeIntensity, shipSize = 'medium') {
        const config = this.thrusterConfigs[shipSize] || this.thrusterConfigs.medium;
        const thruster = config.frontThruster;
        
        // Calculate thruster position (front of ship)
        const thrusterX = x + Math.cos(rotation) * thruster.offset.x;
        const thrusterY = y + Math.sin(rotation) * thruster.offset.x;
        
        // Calculate particle count based on intensity
        const particleCount = Math.ceil(thruster.particlesPerFrame * brakeIntensity);
        
        // Thrust direction (forward from ship)
        const thrustAngle = rotation;
        
        for (let i = 0; i < particleCount; i++) {
            const spreadAngle = thrustAngle + (Math.random() - 0.5) * 0.4;
            const baseVelocity = 50 + brakeIntensity * 30;
            const velocityX = Math.cos(spreadAngle) * baseVelocity;
            const velocityY = Math.sin(spreadAngle) * baseVelocity;
            
            this.createManeuveringThrustParticle(
                thrusterX,
                thrusterY,
                velocityX,
                velocityY,
                brakeIntensity
            );
        }
    }

    /**
     * Create a directional thrust particle (main engine)
     */
    createDirectionalThrustParticle(x, y, velocityX, velocityY, intensity, engineType) {
        // Use the existing particle system's createEffect method
        let effectType;

        switch (engineType) {
            case 'ion':
                effectType = 'engine_exhaust_ion';
                break;
            case 'plasma':
                effectType = 'engine_exhaust_plasma';
                break;
            case 'chemical':
            default:
                effectType = 'engine_exhaust_chemical';
                break;
        }

        // Calculate angle from velocity
        const angle = Math.atan2(velocityY, velocityX);

        // Create particle using existing system
        this.particleSystem.createEffect(effectType, x, y, {
            angle: angle,
            count: 1
        });
    }

    /**
     * Create a maneuvering thrust particle (smaller, shorter-lived)
     */
    createManeuveringThrustParticle(x, y, velocityX, velocityY, intensity) {
        // Calculate angle from velocity
        const angle = Math.atan2(velocityY, velocityX);

        // Use ion engine effect for maneuvering thrusters (blue-white)
        this.particleSystem.createEffect('engine_exhaust_ion', x, y, {
            angle: angle,
            count: 1
        });
    }

    /**
     * Update thruster system for a ship entity
     * @param {Entity} ship - Ship entity
     * @param {Object} controls - Control inputs { thrust, turnLeft, turnRight, brake }
     * @param {string} shipSize - Ship size ('small', 'medium', 'large')
     * @param {string} engineType - Engine type ('chemical', 'ion', 'plasma')
     */
    updateShipThrusters(ship, controls, shipSize = 'medium', engineType = 'chemical') {
        const transform = ship.getComponent('transform');
        if (!transform) return;
        
        // Main engine thrust
        if (controls.thrust > 0) {
            this.emitMainEngineThrust(
                transform.x,
                transform.y,
                transform.rotation,
                controls.thrust,
                shipSize,
                engineType
            );
        }
        
        // Left maneuvering thruster (fires when turning right)
        if (controls.turnRight > 0) {
            this.emitLeftThruster(
                transform.x,
                transform.y,
                transform.rotation,
                controls.turnRight,
                shipSize
            );
        }
        
        // Right maneuvering thruster (fires when turning left)
        if (controls.turnLeft > 0) {
            this.emitRightThruster(
                transform.x,
                transform.y,
                transform.rotation,
                controls.turnLeft,
                shipSize
            );
        }
        
        // Front thrusters (fires when braking)
        if (controls.brake > 0) {
            this.emitFrontThrusters(
                transform.x,
                transform.y,
                transform.rotation,
                controls.brake,
                shipSize
            );
        }
    }
}

