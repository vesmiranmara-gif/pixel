/**
 * PixelVerse - Faction System
 * Reputation, relationships, faction-specific content
 * Retro sci-fi faction dynamics
 */

class FactionSystem {
    constructor() {
        // Player reputation with each faction
        this.playerReputation = new Map(); // entity -> faction reputations
        
        // Faction data
        this.factions = this.createFactions();
        
        // Faction relationships
        this.relationships = this.createRelationships();
    }

    /**
     * Create factions
     */
    createFactions() {
        return {
            'federation': {
                id: 'federation',
                name: 'Galactic Federation',
                description: 'Lawful governing body of known space',
                color: '#4488FF',
                homeStation: 'trade_hub',
                traits: ['lawful', 'organized', 'diplomatic'],
                hostileTo: ['pirates', 'rebels']
            },
            'traders': {
                id: 'traders',
                name: 'Merchant Guild',
                description: 'Independent traders and merchants',
                color: '#FFAA44',
                homeStation: 'trade_hub',
                traits: ['neutral', 'profit-focused', 'opportunistic'],
                hostileTo: ['pirates']
            },
            'miners': {
                id: 'miners',
                name: 'Mining Consortium',
                description: 'Resource extraction specialists',
                color: '#888888',
                homeStation: 'mining_outpost',
                traits: ['industrial', 'hardworking', 'isolated'],
                hostileTo: ['pirates']
            },
            'pirates': {
                id: 'pirates',
                name: 'Pirate Clans',
                description: 'Outlaws and raiders',
                color: '#FF4444',
                homeStation: 'black_market',
                traits: ['hostile', 'aggressive', 'opportunistic'],
                hostileTo: ['federation', 'traders', 'miners']
            },
            'rebels': {
                id: 'rebels',
                name: 'Free Colonies',
                description: 'Independent colonies resisting Federation control',
                color: '#44FF88',
                homeStation: 'black_market',
                traits: ['independent', 'defiant', 'resourceful'],
                hostileTo: ['federation']
            }
        };
    }

    /**
     * Create faction relationships
     */
    createRelationships() {
        return {
            'federation': {
                'traders': 50,    // Friendly
                'miners': 30,     // Neutral-friendly
                'pirates': -100,  // Hostile
                'rebels': -80     // Hostile
            },
            'traders': {
                'federation': 50,
                'miners': 40,
                'pirates': -60,
                'rebels': 0
            },
            'miners': {
                'federation': 30,
                'traders': 40,
                'pirates': -70,
                'rebels': 10
            },
            'pirates': {
                'federation': -100,
                'traders': -60,
                'miners': -70,
                'rebels': 20
            },
            'rebels': {
                'federation': -80,
                'traders': 0,
                'miners': 10,
                'pirates': 20
            }
        };
    }

    /**
     * Initialize reputation for entity
     */
    initializeReputation(entity) {
        const reputation = {
            'federation': 0,
            'traders': 0,
            'miners': 0,
            'pirates': -50,  // Start hostile with pirates
            'rebels': 0
        };
        
        this.playerReputation.set(entity, reputation);
        return reputation;
    }

    /**
     * Get reputation with faction
     */
    getReputation(entity, factionId) {
        const reputation = this.playerReputation.get(entity);
        if (!reputation) return 0;
        
        return reputation[factionId] || 0;
    }

    /**
     * Modify reputation
     */
    modifyReputation(entity, factionId, amount) {
        const reputation = this.playerReputation.get(entity);
        if (!reputation) return;
        
        if (!reputation[factionId]) {
            reputation[factionId] = 0;
        }
        
        reputation[factionId] += amount;
        
        // Clamp between -100 and 100
        reputation[factionId] = Math.max(-100, Math.min(100, reputation[factionId]));
        
        // Affect relationships with other factions
        const faction = this.factions[factionId];
        if (faction && faction.hostileTo) {
            for (const hostileFaction of faction.hostileTo) {
                if (reputation[hostileFaction] !== undefined) {
                    // Gaining rep with one faction loses rep with hostile factions
                    reputation[hostileFaction] -= amount * 0.5;
                    reputation[hostileFaction] = Math.max(-100, Math.min(100, reputation[hostileFaction]));
                }
            }
        }
    }

    /**
     * Get reputation level name
     */
    getReputationLevel(reputation) {
        if (reputation >= 80) return 'Revered';
        if (reputation >= 60) return 'Honored';
        if (reputation >= 40) return 'Friendly';
        if (reputation >= 20) return 'Liked';
        if (reputation >= -20) return 'Neutral';
        if (reputation >= -40) return 'Disliked';
        if (reputation >= -60) return 'Unfriendly';
        if (reputation >= -80) return 'Hostile';
        return 'Hated';
    }

    /**
     * Check if faction is hostile
     */
    isHostile(entity, factionId) {
        const reputation = this.getReputation(entity, factionId);
        return reputation < -40;
    }

    /**
     * Check if faction is friendly
     */
    isFriendly(entity, factionId) {
        const reputation = this.getReputation(entity, factionId);
        return reputation > 40;
    }

    /**
     * Get faction data
     */
    getFaction(factionId) {
        return this.factions[factionId];
    }

    /**
     * Get all factions
     */
    getAllFactions() {
        return Object.values(this.factions);
    }

    /**
     * Get player reputation summary
     */
    getReputationSummary(entity) {
        const reputation = this.playerReputation.get(entity);
        if (!reputation) return [];
        
        const summary = [];
        for (const factionId in reputation) {
            const faction = this.factions[factionId];
            if (faction) {
                summary.push({
                    faction: faction,
                    reputation: reputation[factionId],
                    level: this.getReputationLevel(reputation[factionId]),
                    hostile: this.isHostile(entity, factionId),
                    friendly: this.isFriendly(entity, factionId)
                });
            }
        }
        
        return summary;
    }

    /**
     * Get faction relationship
     */
    getFactionRelationship(factionId1, factionId2) {
        if (!this.relationships[factionId1]) return 0;
        return this.relationships[factionId1][factionId2] || 0;
    }

    /**
     * Award reputation for action
     */
    awardReputationForAction(entity, action, targetFaction = null) {
        switch (action) {
            case 'mission_complete':
                if (targetFaction) {
                    this.modifyReputation(entity, targetFaction, 10);
                }
                break;
                
            case 'destroy_pirate':
                this.modifyReputation(entity, 'federation', 5);
                this.modifyReputation(entity, 'traders', 3);
                this.modifyReputation(entity, 'pirates', -10);
                break;
                
            case 'trade':
                this.modifyReputation(entity, 'traders', 1);
                break;
                
            case 'mine_resources':
                this.modifyReputation(entity, 'miners', 2);
                break;
                
            case 'smuggle':
                this.modifyReputation(entity, 'federation', -5);
                this.modifyReputation(entity, 'pirates', 3);
                this.modifyReputation(entity, 'rebels', 2);
                break;
        }
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = FactionSystem;
}

