/**
 * PixelVerse - Enhanced Celestial Bodies System
 * Large-scale planets, moons, and stars with detailed surface features
 */

class CelestialBodySystem {
    constructor(ctx, width, height, celestialRenderer, starSystemGenerator) {
        this.ctx = ctx;
        this.width = width;
        this.height = height;

        // New enhanced renderers
        this.celestialRenderer = celestialRenderer;
        this.starSystemGenerator = starSystemGenerator;

        // Celestial bodies
        this.bodies = [];

        // Pre-rendered canvases for performance
        this.bodyCanvases = new Map();

        // Current star system
        this.currentSystem = null;

        // Body types (kept for compatibility)
        this.bodyTypes = {
            rocky: { colors: ['#8B7355', '#A0826D', '#6B5344'], features: ['craters', 'mountains', 'plains'] },
            earthlike: { colors: ['#4A90E2', '#2ECC71', '#ECF0F1'], features: ['seas', 'plains', 'mountains', 'rivers'] },
            gasGiant: { colors: ['#E67E22', '#D35400', '#F39C12'], features: ['bands', 'storms'] },
            ice: { colors: ['#ECF0F1', '#BDC3C7', '#D5DBDB'], features: ['craters', 'plains'] },
            lava: { colors: ['#E74C3C', '#C0392B', '#2C3E50'], features: ['volcanoes', 'lava'] },
            moon: { colors: ['#95A5A6', '#7F8C8D', '#BDC3C7'], features: ['craters'] }
        };

        // Star types (kept for compatibility)
        this.starTypes = {
            yellow: { color: '#FDB813', temp: 5800, size: 1.0 },
            red: { color: '#E74C3C', temp: 3500, size: 1.5 },
            blue: { color: '#3498DB', temp: 10000, size: 0.8 },
            white: { color: '#ECF0F1', temp: 7500, size: 0.9 }
        };
    }

    /**
     * Initialize celestial bodies in the scene with realistic star system
     */
    initialize() {
        this.bodies = [];

        // Generate realistic star system
        if (this.starSystemGenerator) {
            console.log('Using enhanced star system generator...');
            this.currentSystem = this.starSystemGenerator.generateSystem(Date.now());
            console.log(`Generated star system: ${this.currentSystem.name}`);
            console.log(`System type: ${this.currentSystem.type}`);
            console.log(`Planets: ${this.currentSystem.planets.length}`);

            // Create central body/bodies
            this.createCentralBody(this.currentSystem.centralBody);
            console.log(`Created central body`);

            // Create planets
            for (const planet of this.currentSystem.planets) {
                this.createPlanetFromData(planet);
            }
            console.log(`Created ${this.currentSystem.planets.length} planets`);

            // Create asteroid belt
            if (this.currentSystem.asteroidBelt) {
                this.createAsteroidBeltFromData(this.currentSystem.asteroidBelt);
                console.log(`Created asteroid belt with ${this.currentSystem.asteroidBelt.asteroids.length} asteroids`);
            }

            // Create comets
            for (const comet of this.currentSystem.comets) {
                this.createCometFromData(comet);
            }
            console.log(`Created ${this.currentSystem.comets.length} comets`);

            console.log(`✅ Initialized ${this.bodies.length} celestial bodies in ${this.currentSystem.name}`);
        } else {
            // Fallback to old system if generators not available
            console.warn('⚠️ Star system generator not available, using fallback');
            this.initializeFallback();
        }

        // Pre-render all bodies for performance
        this.preRenderBodies();
    }

    /**
     * Fallback initialization (old system)
     */
    initializeFallback() {
        this.createStar(0, 0, 'yellow', 400);
        this.createPlanet(80000, 20000, 'rocky', 120);
        this.createPlanet(-60000, -40000, 'earthlike', 200);
        this.createPlanet(120000, -80000, 'gasGiant', 300);
        this.createPlanet(-150000, 100000, 'ice', 150);
        this.createPlanet(200000, 150000, 'lava', 180);
        this.createMoon(this.bodies[2], 8000, 0, 50);
        this.createMoon(this.bodies[3], 12000, Math.PI, 70);
        console.log(`Initialized ${this.bodies.length} celestial bodies (fallback)`);
    }

    /**
     * Create central body from system data
     */
    createCentralBody(centralBody) {
        if (centralBody.type === 'star') {
            this.createEnhancedStar(centralBody.x, centralBody.y, centralBody.subtype, centralBody.size, centralBody.seed);
        } else if (centralBody.type === 'binary') {
            for (const star of centralBody.stars) {
                this.createEnhancedStar(star.x, star.y, star.subtype, star.size, star.seed);
            }
        } else if (centralBody.type === 'trinary') {
            for (const star of centralBody.stars) {
                this.createEnhancedStar(star.x, star.y, star.subtype, star.size, star.seed);
            }
        } else if (centralBody.type === 'blackhole') {
            this.createBlackHole(centralBody.x, centralBody.y, centralBody.size);
        } else if (centralBody.type === 'pulsar') {
            this.createPulsar(centralBody.x, centralBody.y, centralBody.size);
        }
    }

    /**
     * Create planet from system data
     */
    createPlanetFromData(planetData) {
        const planet = this.createEnhancedPlanet(
            planetData.x,
            planetData.y,
            planetData.subtype,
            planetData.size,
            planetData.seed
        );

        // Store orbital data
        planet.distance = planetData.distance;
        planet.angle = planetData.angle;
        planet.orbitalSpeed = planetData.orbitalSpeed;

        // Create moons
        for (const moonData of planetData.moons) {
            this.createEnhancedMoon(planet, moonData);
        }
    }

    /**
     * Create asteroid belt from system data
     */
    createAsteroidBeltFromData(beltData) {
        for (const asteroidData of beltData.asteroids) {
            this.createEnhancedAsteroid(
                asteroidData.x,
                asteroidData.y,
                asteroidData.size,
                asteroidData.seed
            );
        }
    }

    /**
     * Create comet from system data
     */
    createCometFromData(cometData) {
        // Calculate current position based on elliptical orbit
        const distance = cometData.perihelion; // Start at closest point
        const x = Math.cos(cometData.angle) * distance;
        const y = Math.sin(cometData.angle) * distance;

        this.createEnhancedComet(x, y, cometData.size, cometData.seed);
    }


    /**
     * Create enhanced star using new renderer
     */
    createEnhancedStar(x, y, type, size, seed) {
        const body = {
            id: this.generateId(),
            type: 'star',
            subtype: type,
            x: x,
            y: y,
            size: size,
            seed: seed,
            rotation: 0,
            rotationSpeed: 0.0001
        };

        this.bodies.push(body);
        return body;
    }

    /**
     * Create enhanced planet using new renderer
     */
    createEnhancedPlanet(x, y, type, size, seed) {
        const body = {
            id: this.generateId(),
            type: 'planet',
            subtype: type,
            x: x,
            y: y,
            size: size,
            seed: seed,
            rotation: 0,
            rotationSpeed: 0.0002,
            moons: []
        };

        this.bodies.push(body);
        return body;
    }

    /**
     * Create enhanced moon using new renderer
     */
    createEnhancedMoon(planet, moonData) {
        const angle = moonData.angle;
        const distance = moonData.distance;

        const moon = {
            id: this.generateId(),
            type: 'moon',
            x: planet.x + Math.cos(angle) * distance,
            y: planet.y + Math.sin(angle) * distance,
            size: moonData.size,
            seed: moonData.seed,
            parent: planet,
            distance: distance,
            angle: angle,
            orbitalSpeed: moonData.orbitalSpeed,
            rotation: 0,
            rotationSpeed: 0.0003
        };

        planet.moons.push(moon);
        this.bodies.push(moon);
        return moon;
    }

    /**
     * Create enhanced asteroid
     */
    createEnhancedAsteroid(x, y, size, seed) {
        const body = {
            id: this.generateId(),
            type: 'asteroid',
            x: x,
            y: y,
            size: size,
            seed: seed,
            rotation: Math.random() * Math.PI * 2,
            rotationSpeed: 0.001 + Math.random() * 0.002
        };

        this.bodies.push(body);
        return body;
    }

    /**
     * Create enhanced comet
     */
    createEnhancedComet(x, y, size, seed) {
        const body = {
            id: this.generateId(),
            type: 'comet',
            x: x,
            y: y,
            size: size,
            seed: seed,
            tailLength: 100 + Math.random() * 200
        };

        this.bodies.push(body);
        return body;
    }

    /**
     * Create black hole
     */
    createBlackHole(x, y, size) {
        const body = {
            id: this.generateId(),
            type: 'blackhole',
            x: x,
            y: y,
            size: size,
            rotation: 0,
            rotationSpeed: 0.002
        };

        this.bodies.push(body);
        return body;
    }

    /**
     * Create pulsar
     */
    createPulsar(x, y, size) {
        const body = {
            id: this.generateId(),
            type: 'pulsar',
            x: x,
            y: y,
            size: size,
            pulsePhase: 0,
            pulseSpeed: 0.05
        };

        this.bodies.push(body);
        return body;
    }

    /**
     * Generate unique ID for body
     */
    generateId() {
        if (!this.nextId) this.nextId = 1;
        return this.nextId++;
    }


    /**
     * Create a star
     */
    createStar(x, y, type, size) {
        const starData = this.starTypes[type];
        const body = {
            id: `star_${this.bodies.length}`,
            type: 'star',
            subType: type,
            x: x,
            y: y,
            size: size,
            color: starData.color,
            temperature: starData.temp,
            rotation: 0,
            rotationSpeed: 0.0001,
            features: this.generateStarFeatures(size, type),
            animationTime: 0
        };
        this.bodies.push(body);
        return body;
    }

    /**
     * Create a planet
     */
    createPlanet(x, y, type, size) {
        const typeData = this.bodyTypes[type];
        const body = {
            id: `planet_${this.bodies.length}`,
            type: 'planet',
            subType: type,
            x: x,
            y: y,
            size: size,
            colors: typeData.colors,
            rotation: Math.random() * Math.PI * 2,
            rotationSpeed: 0.0002 + Math.random() * 0.0003,
            features: this.generatePlanetFeatures(size, type, typeData.features),
            atmosphere: type === 'earthlike' || type === 'gasGiant',
            atmosphereColor: type === 'earthlike' ? 'rgba(135, 206, 250, 0.3)' : 'rgba(230, 126, 34, 0.3)',
            moons: []
        };
        this.bodies.push(body);
        return body;
    }

    /**
     * Create a moon orbiting a planet
     */
    createMoon(planet, distance, angle, size) {
        const body = {
            id: `moon_${this.bodies.length}`,
            type: 'moon',
            subType: 'moon',
            parent: planet,
            orbitDistance: distance,
            orbitAngle: angle,
            orbitSpeed: 0.0005,
            size: size,
            colors: this.bodyTypes.moon.colors,
            rotation: Math.random() * Math.PI * 2,
            rotationSpeed: 0.0003,
            features: this.generatePlanetFeatures(size, 'moon', ['craters'])
        };

        // Calculate initial position
        body.x = planet.x + Math.cos(angle) * distance;
        body.y = planet.y + Math.sin(angle) * distance;

        planet.moons.push(body);
        this.bodies.push(body);
        return body;
    }

    /**
     * Generate star surface features
     */
    generateStarFeatures(size, type) {
        const features = {
            sunspots: [],
            flares: []
        };

        // Generate sunspots (more detailed for smaller stars)
        const spotCount = Math.floor(size / 50) + 5; // More sunspots
        for (let i = 0; i < spotCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const distance = Math.random() * size * 0.4;
            features.sunspots.push({
                x: Math.cos(angle) * distance,
                y: Math.sin(angle) * distance,
                size: size * 0.03 + Math.random() * size * 0.05, // Scale with star
                intensity: 0.3 + Math.random() * 0.4
            });
        }

        // Generate solar flares (more flares)
        const flareCount = 6 + Math.floor(Math.random() * 4);
        for (let i = 0; i < flareCount; i++) {
            features.flares.push({
                angle: Math.random() * Math.PI * 2,
                length: size * 0.4 + Math.random() * size * 0.3, // Longer flares
                width: 2 + Math.random() * 4, // Thinner flares
                phase: Math.random() * Math.PI * 2
            });
        }

        return features;
    }

    /**
     * Generate planet surface features
     */
    generatePlanetFeatures(size, type, featureTypes) {
        const features = {
            craters: [],
            mountains: [],
            volcanoes: [],
            rivers: [],
            seas: [],
            plains: [],
            bands: [],
            storms: []
        };

        // Generate features based on type (more detailed for smaller planets)
        if (featureTypes.includes('craters')) {
            const craterCount = Math.floor(size / 15) + 8; // More craters
            for (let i = 0; i < craterCount; i++) {
                const angle = Math.random() * Math.PI * 2;
                const distance = Math.random() * size * 0.45;
                features.craters.push({
                    x: Math.cos(angle) * distance,
                    y: Math.sin(angle) * distance,
                    size: 2 + Math.random() * 8 // Smaller craters
                });
            }
        }

        if (featureTypes.includes('mountains')) {
            const mountainCount = Math.floor(size / 30) + 5; // More mountains
            for (let i = 0; i < mountainCount; i++) {
                const angle = Math.random() * Math.PI * 2;
                const distance = Math.random() * size * 0.4;
                features.mountains.push({
                    x: Math.cos(angle) * distance,
                    y: Math.sin(angle) * distance,
                    height: 3 + Math.random() * 6, // Smaller mountains
                    width: 4 + Math.random() * 6
                });
            }
        }

        if (featureTypes.includes('volcanoes')) {
            const volcanoCount = Math.floor(size / 40) + 3; // More volcanoes
            for (let i = 0; i < volcanoCount; i++) {
                const angle = Math.random() * Math.PI * 2;
                const distance = Math.random() * size * 0.4;
                features.volcanoes.push({
                    x: Math.cos(angle) * distance,
                    y: Math.sin(angle) * distance,
                    size: 3 + Math.random() * 5, // Smaller volcanoes
                    active: Math.random() > 0.5
                });
            }
        }

        if (featureTypes.includes('seas')) {
            const seaCount = 3 + Math.floor(Math.random() * 4); // More seas
            for (let i = 0; i < seaCount; i++) {
                const angle = Math.random() * Math.PI * 2;
                const distance = Math.random() * size * 0.3;
                features.seas.push({
                    x: Math.cos(angle) * distance,
                    y: Math.sin(angle) * distance,
                    size: size * 0.15 + Math.random() * size * 0.2 // Scale with planet size
                });
            }
        }

        if (featureTypes.includes('rivers')) {
            const riverCount = 5 + Math.floor(Math.random() * 5); // More rivers
            for (let i = 0; i < riverCount; i++) {
                const points = [];
                let x = (Math.random() - 0.5) * size * 0.6;
                let y = (Math.random() - 0.5) * size * 0.6;
                for (let j = 0; j < 12; j++) { // More points for smoother rivers
                    points.push({ x, y });
                    x += (Math.random() - 0.5) * (size * 0.08);
                    y += (Math.random() - 0.5) * (size * 0.08);
                }
                features.rivers.push({ points });
            }
        }

        if (featureTypes.includes('bands')) {
            const bandCount = 8 + Math.floor(Math.random() * 6); // More bands
            for (let i = 0; i < bandCount; i++) {
                features.bands.push({
                    y: -size * 0.4 + (i / bandCount) * size * 0.8,
                    height: size * 0.06 + Math.random() * size * 0.04, // Thinner bands
                    colorIndex: Math.floor(Math.random() * 3)
                });
            }
        }

        if (featureTypes.includes('storms')) {
            const stormCount = 2 + Math.floor(Math.random() * 2); // More storms
            for (let i = 0; i < stormCount; i++) {
                const angle = Math.random() * Math.PI * 2;
                const distance = Math.random() * size * 0.3;
                features.storms.push({
                    x: Math.cos(angle) * distance,
                    y: Math.sin(angle) * distance,
                    size: size * 0.15 + Math.random() * size * 0.2, // Scale with planet
                    rotation: 0,
                    rotationSpeed: 0.001 + Math.random() * 0.002
                });
            }
        }

        return features;
    }

    /**
     * Pre-render bodies to canvases for performance
     */
    preRenderBodies() {
        for (const body of this.bodies) {
            // Pre-render all bodies including moons
            this.preRenderBody(body);
        }
        console.log(`Pre-rendered ${this.bodyCanvases.size} celestial bodies`);
    }

    /**
     * Pre-render a single body to canvas
     */
    preRenderBody(body) {
        // Use enhanced renderer if available
        if (this.celestialRenderer && body.seed !== undefined) {
            let canvas;

            try {
                if (body.type === 'star') {
                    console.log(`Rendering star: ${body.subtype}, size: ${body.size}`);
                    canvas = this.celestialRenderer.renderStar(body.size, body.subtype, body.seed);
                } else if (body.type === 'planet') {
                    console.log(`Rendering planet: ${body.subtype}, size: ${body.size}`);
                    canvas = this.celestialRenderer.getCelestialBody(body.subtype, body.size, body.seed);
                } else if (body.type === 'moon') {
                    console.log(`Rendering moon: size: ${body.size}`);
                    // Render moons as rocky bodies
                    canvas = this.celestialRenderer.renderRockyPlanet(body.size, null, body.seed);
                } else if (body.type === 'asteroid') {
                    // Render asteroids as rocky bodies
                    canvas = this.celestialRenderer.renderRockyPlanet(body.size, null, body.seed);
                } else {
                    // Fallback to old rendering
                    canvas = this.preRenderBodyFallback(body);
                }

                if (canvas) {
                    this.bodyCanvases.set(body.id, canvas);
                    console.log(`✅ Pre-rendered ${body.type} (ID: ${body.id})`);
                } else {
                    console.warn(`⚠️ Failed to render ${body.type} (ID: ${body.id})`);
                }
            } catch (error) {
                console.error(`❌ Error rendering ${body.type}:`, error);
                // Fallback to old rendering
                const canvas = this.preRenderBodyFallback(body);
                this.bodyCanvases.set(body.id, canvas);
            }
        } else {
            // Fallback to old rendering
            console.log(`Using fallback rendering for ${body.type}`);
            const canvas = this.preRenderBodyFallback(body);
            this.bodyCanvases.set(body.id, canvas);
        }
    }

    /**
     * Fallback pre-render method
     */
    preRenderBodyFallback(body) {
        const canvas = document.createElement('canvas');
        const size = body.size + 200; // Extra space for atmosphere/corona
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');

        // Render body to canvas
        ctx.save();
        ctx.translate(size / 2, size / 2);

        if (body.type === 'star') {
            this.renderStarToCanvas(ctx, body, 0, 0);
        } else if (body.type === 'planet') {
            this.renderPlanetToCanvas(ctx, body, 0, 0);
        }

        ctx.restore();
        return canvas;
    }

    /**
     * Render star to canvas
     */
    renderStarToCanvas(ctx, star, x, y) {
        const size = star.size;

        // Corona (outer glow)
        const coronaGradient = ctx.createRadialGradient(x, y, size * 0.5, x, y, size * 0.8);
        coronaGradient.addColorStop(0, star.color);
        coronaGradient.addColorStop(0.5, star.color + '80');
        coronaGradient.addColorStop(1, star.color + '00');
        ctx.fillStyle = coronaGradient;
        ctx.beginPath();
        ctx.arc(x, y, size * 0.8, 0, Math.PI * 2);
        ctx.fill();

        // Main star body with plasma texture
        const gradient = ctx.createRadialGradient(x - size * 0.2, y - size * 0.2, 0, x, y, size * 0.5);
        gradient.addColorStop(0, '#FFFFFF');
        gradient.addColorStop(0.3, star.color);
        gradient.addColorStop(1, this.darkenColor(star.color, 0.5));
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(x, y, size * 0.5, 0, Math.PI * 2);
        ctx.fill();

        // Sunspots
        ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
        for (const spot of star.features.sunspots) {
            ctx.beginPath();
            ctx.arc(x + spot.x, y + spot.y, spot.size, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    /**
     * Render planet to canvas
     */
    renderPlanetToCanvas(ctx, planet, x, y) {
        const size = planet.size;

        // Atmosphere (if applicable)
        if (planet.atmosphere) {
            const atmGradient = ctx.createRadialGradient(x, y, size * 0.45, x, y, size * 0.6);
            atmGradient.addColorStop(0, planet.atmosphereColor.replace('0.3', '0'));
            atmGradient.addColorStop(0.7, planet.atmosphereColor);
            atmGradient.addColorStop(1, planet.atmosphereColor.replace('0.3', '0'));
            ctx.fillStyle = atmGradient;
            ctx.beginPath();
            ctx.arc(x, y, size * 0.6, 0, Math.PI * 2);
            ctx.fill();
        }

        // Main planet body
        const gradient = ctx.createRadialGradient(x - size * 0.2, y - size * 0.2, 0, x, y, size * 0.5);
        gradient.addColorStop(0, this.lightenColor(planet.colors[0], 0.3));
        gradient.addColorStop(0.5, planet.colors[0]);
        gradient.addColorStop(1, this.darkenColor(planet.colors[0], 0.3));
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(x, y, size * 0.5, 0, Math.PI * 2);
        ctx.fill();

        // Render surface features based on type
        if (planet.subType === 'gasGiant') {
            this.renderGasGiantFeatures(ctx, planet, x, y);
        } else {
            this.renderRockyFeatures(ctx, planet, x, y);
        }
    }

    /**
     * Render gas giant features (bands and storms)
     */
    renderGasGiantFeatures(ctx, planet, x, y) {
        const size = planet.size;

        // Save context and clip to circular planet
        ctx.save();
        ctx.beginPath();
        ctx.arc(x, y, size * 0.5, 0, Math.PI * 2);
        ctx.clip();

        // Cloud bands (now clipped to circle)
        for (const band of planet.features.bands) {
            const color = planet.colors[band.colorIndex];
            ctx.fillStyle = color;
            ctx.fillRect(x - size * 0.5, y + band.y, size, band.height);
        }

        ctx.restore();

        // Storms (Great Red Spot style) - drawn on top
        for (const storm of planet.features.storms) {
            ctx.save();
            ctx.translate(x + storm.x, y + storm.y);
            ctx.rotate(storm.rotation);

            const stormGradient = ctx.createRadialGradient(0, 0, 0, 0, 0, storm.size);
            stormGradient.addColorStop(0, this.lightenColor(planet.colors[1], 0.2));
            stormGradient.addColorStop(0.5, planet.colors[1]);
            stormGradient.addColorStop(1, this.darkenColor(planet.colors[1], 0.3));
            ctx.fillStyle = stormGradient;
            ctx.beginPath();
            ctx.ellipse(0, 0, storm.size, storm.size * 0.6, 0, 0, Math.PI * 2);
            ctx.fill();

            ctx.restore();
        }
    }

    /**
     * Render rocky planet features
     */
    renderRockyFeatures(ctx, planet, x, y) {
        // Craters
        ctx.fillStyle = this.darkenColor(planet.colors[0], 0.3);
        for (const crater of planet.features.craters) {
            ctx.beginPath();
            ctx.arc(x + crater.x, y + crater.y, crater.size, 0, Math.PI * 2);
            ctx.fill();

            // Crater rim highlight
            ctx.strokeStyle = this.lightenColor(planet.colors[0], 0.2);
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.arc(x + crater.x - 1, y + crater.y - 1, crater.size, Math.PI, Math.PI * 1.5);
            ctx.stroke();
        }

        // Mountains
        ctx.fillStyle = this.lightenColor(planet.colors[0], 0.2);
        for (const mountain of planet.features.mountains) {
            ctx.beginPath();
            ctx.moveTo(x + mountain.x, y + mountain.y - mountain.height);
            ctx.lineTo(x + mountain.x - mountain.width / 2, y + mountain.y);
            ctx.lineTo(x + mountain.x + mountain.width / 2, y + mountain.y);
            ctx.closePath();
            ctx.fill();
        }

        // Volcanoes
        for (const volcano of planet.features.volcanoes) {
            // Cone
            ctx.fillStyle = this.darkenColor(planet.colors[0], 0.2);
            ctx.beginPath();
            ctx.moveTo(x + volcano.x, y + volcano.y - volcano.size);
            ctx.lineTo(x + volcano.x - volcano.size * 0.7, y + volcano.y);
            ctx.lineTo(x + volcano.x + volcano.size * 0.7, y + volcano.y);
            ctx.closePath();
            ctx.fill();

            // Lava (if active)
            if (volcano.active) {
                ctx.fillStyle = '#E74C3C';
                ctx.beginPath();
                ctx.arc(x + volcano.x, y + volcano.y - volcano.size * 0.5, volcano.size * 0.3, 0, Math.PI * 2);
                ctx.fill();
            }
        }

        // Seas
        if (planet.features.seas.length > 0) {
            ctx.fillStyle = planet.subType === 'earthlike' ? '#3498DB' : planet.colors[1];
            for (const sea of planet.features.seas) {
                ctx.beginPath();
                ctx.arc(x + sea.x, y + sea.y, sea.size, 0, Math.PI * 2);
                ctx.fill();
            }
        }

        // Rivers
        if (planet.features.rivers.length > 0) {
            ctx.strokeStyle = planet.subType === 'earthlike' ? '#3498DB' : planet.colors[1];
            ctx.lineWidth = 2;
            for (const river of planet.features.rivers) {
                ctx.beginPath();
                ctx.moveTo(x + river.points[0].x, y + river.points[0].y);
                for (let i = 1; i < river.points.length; i++) {
                    ctx.lineTo(x + river.points[i].x, y + river.points[i].y);
                }
                ctx.stroke();
            }
        }
    }


    /**
     * Update celestial bodies (rotation, orbits, animations)
     */
    update(deltaTime) {
        for (const body of this.bodies) {
            // Update rotation
            if (body.rotationSpeed) {
                body.rotation = (body.rotation || 0) + body.rotationSpeed * deltaTime;
            }

            // Update animation time for stars
            if (body.type === 'star') {
                body.animationTime = (body.animationTime || 0) + deltaTime;
            }

            // Update planet orbits (realistic orbital mechanics)
            if (body.type === 'planet' && body.orbitalSpeed && body.distance) {
                body.angle = (body.angle || 0) + body.orbitalSpeed * deltaTime;
                body.x = Math.cos(body.angle) * body.distance;
                body.y = Math.sin(body.angle) * body.distance;
            }

            // Update moon orbits
            if (body.type === 'moon' && body.parent) {
                body.angle = (body.angle || 0) + body.orbitalSpeed * deltaTime;
                body.x = body.parent.x + Math.cos(body.angle) * body.distance;
                body.y = body.parent.y + Math.sin(body.angle) * body.distance;
            }

            // Update asteroid orbits
            if (body.type === 'asteroid' && body.orbitalSpeed && body.distance) {
                body.angle = (body.angle || 0) + body.orbitalSpeed * deltaTime;
                body.x = Math.cos(body.angle) * body.distance;
                body.y = Math.sin(body.angle) * body.distance;
            }

            // Update pulsar pulse
            if (body.type === 'pulsar') {
                body.pulsePhase = (body.pulsePhase || 0) + body.pulseSpeed * deltaTime;
            }

            // Update black hole rotation
            if (body.type === 'blackhole') {
                body.rotation = (body.rotation || 0) + body.rotationSpeed * deltaTime;
            }

            // Update storm rotations for gas giants
            if (body.type === 'planet' && body.subType === 'gasGiant' && body.features && body.features.storms) {
                for (const storm of body.features.storms) {
                    storm.rotation += storm.rotationSpeed * deltaTime;
                }
            }
        }
    }


    /**
     * Render black hole
     */
    renderBlackHole(ctx, body, screenX, screenY) {
        const radius = body.size / 2;

        // Event horizon (black circle)
        ctx.fillStyle = '#000000';
        ctx.beginPath();
        ctx.arc(screenX, screenY, radius * 0.6, 0, Math.PI * 2);
        ctx.fill();

        // Accretion disk
        const diskGradient = ctx.createRadialGradient(screenX, screenY, radius * 0.6, screenX, screenY, radius * 1.5);
        diskGradient.addColorStop(0, 'rgba(255, 150, 50, 0.8)');
        diskGradient.addColorStop(0.5, 'rgba(255, 100, 0, 0.4)');
        diskGradient.addColorStop(1, 'rgba(255, 50, 0, 0)');

        ctx.save();
        ctx.translate(screenX, screenY);
        ctx.rotate(body.rotation || 0);

        // Draw disk as ellipse
        ctx.scale(1, 0.3);
        ctx.fillStyle = diskGradient;
        ctx.beginPath();
        ctx.arc(0, 0, radius * 1.5, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();

        // Gravitational lensing effect (glow)
        const lensGradient = ctx.createRadialGradient(screenX, screenY, radius * 0.6, screenX, screenY, radius * 2);
        lensGradient.addColorStop(0, 'rgba(100, 100, 255, 0.3)');
        lensGradient.addColorStop(1, 'rgba(100, 100, 255, 0)');
        ctx.fillStyle = lensGradient;
        ctx.beginPath();
        ctx.arc(screenX, screenY, radius * 2, 0, Math.PI * 2);
        ctx.fill();
    }

    /**
     * Render pulsar
     */
    renderPulsar(ctx, body, screenX, screenY) {
        const radius = body.size / 2;
        const pulse = Math.sin(body.pulsePhase || 0);
        const pulseIntensity = (pulse + 1) / 2; // 0 to 1

        // Core
        const coreGradient = ctx.createRadialGradient(screenX, screenY, 0, screenX, screenY, radius * 0.5);
        coreGradient.addColorStop(0, `rgba(255, 255, 255, ${0.8 + pulseIntensity * 0.2})`);
        coreGradient.addColorStop(0.5, `rgba(200, 220, 255, ${0.6 + pulseIntensity * 0.4})`);
        coreGradient.addColorStop(1, `rgba(150, 180, 255, ${0.3 + pulseIntensity * 0.3})`);
        ctx.fillStyle = coreGradient;
        ctx.beginPath();
        ctx.arc(screenX, screenY, radius * 0.5, 0, Math.PI * 2);
        ctx.fill();

        // Beams
        if (pulseIntensity > 0.5) {
            ctx.save();
            ctx.translate(screenX, screenY);
            ctx.rotate(body.rotation || 0);

            const beamLength = radius * 3 * pulseIntensity;
            const beamGradient = ctx.createLinearGradient(0, 0, 0, -beamLength);
            beamGradient.addColorStop(0, `rgba(150, 200, 255, ${pulseIntensity * 0.8})`);
            beamGradient.addColorStop(1, 'rgba(150, 200, 255, 0)');

            // Draw two beams
            ctx.fillStyle = beamGradient;
            ctx.fillRect(-radius * 0.2, -beamLength, radius * 0.4, beamLength);
            ctx.fillRect(-radius * 0.2, 0, radius * 0.4, beamLength);

            ctx.restore();
        }

        // Magnetic field lines
        ctx.strokeStyle = `rgba(100, 150, 255, ${0.3 + pulseIntensity * 0.3})`;
        ctx.lineWidth = 2;
        for (let i = 0; i < 4; i++) {
            const angle = (i / 4) * Math.PI * 2;
            ctx.beginPath();
            ctx.arc(screenX, screenY, radius * (1 + i * 0.3), angle, angle + Math.PI);
            ctx.stroke();
        }
    }

    /**
     * Render comet with tail
     */
    renderComet(ctx, body, screenX, screenY, camera) {
        const radius = body.size / 2;

        // Comet nucleus
        ctx.fillStyle = '#888888';
        ctx.beginPath();
        ctx.arc(screenX, screenY, radius, 0, Math.PI * 2);
        ctx.fill();

        // Coma (glow around nucleus)
        const comaGradient = ctx.createRadialGradient(screenX, screenY, radius, screenX, screenY, radius * 3);
        comaGradient.addColorStop(0, 'rgba(200, 220, 255, 0.5)');
        comaGradient.addColorStop(1, 'rgba(200, 220, 255, 0)');
        ctx.fillStyle = comaGradient;
        ctx.beginPath();
        ctx.arc(screenX, screenY, radius * 3, 0, Math.PI * 2);
        ctx.fill();

        // Tail (points away from star)
        const tailLength = body.tailLength || 200;
        const tailAngle = Math.atan2(body.y, body.x) + Math.PI; // Away from center

        ctx.save();
        ctx.translate(screenX, screenY);
        ctx.rotate(tailAngle);

        const tailGradient = ctx.createLinearGradient(0, 0, tailLength, 0);
        tailGradient.addColorStop(0, 'rgba(200, 220, 255, 0.6)');
        tailGradient.addColorStop(0.5, 'rgba(200, 220, 255, 0.3)');
        tailGradient.addColorStop(1, 'rgba(200, 220, 255, 0)');

        ctx.fillStyle = tailGradient;
        ctx.beginPath();
        ctx.moveTo(0, -radius * 2);
        ctx.lineTo(tailLength, -radius * 0.5);
        ctx.lineTo(tailLength, radius * 0.5);
        ctx.lineTo(0, radius * 2);
        ctx.closePath();
        ctx.fill();

        ctx.restore();
    }


    /**
     * Render celestial bodies
     */
    render(camera) {
        const ctx = this.ctx;

        // Render orbits first (behind bodies)
        this.renderOrbits(camera);

        for (const body of this.bodies) {
            // Calculate screen position
            const screenX = body.x - camera.x + this.width / 2;
            const screenY = body.y - camera.y + this.height / 2;

            // Culling - skip if off-screen (with margin)
            const margin = body.size + 500;
            if (screenX < -margin || screenX > this.width + margin ||
                screenY < -margin || screenY > this.height + margin) {
                continue;
            }

            // Handle special body types
            if (body.type === 'blackhole') {
                this.renderBlackHole(ctx, body, screenX, screenY);
                continue;
            } else if (body.type === 'pulsar') {
                this.renderPulsar(ctx, body, screenX, screenY);
                continue;
            } else if (body.type === 'comet') {
                this.renderComet(ctx, body, screenX, screenY, camera);
                continue;
            }

            ctx.save();
            ctx.translate(screenX, screenY);
            ctx.rotate(body.rotation || 0);

            // Render from pre-rendered canvas or render in real-time
            if (body.type === 'moon') {
                this.renderMoon(ctx, body);
            } else {
                const canvas = this.bodyCanvases.get(body.id);
                if (canvas) {
                    ctx.drawImage(canvas, -canvas.width / 2, -canvas.height / 2);
                }
            }

            // Render solar flares for stars (animated)
            if (body.type === 'star') {
                this.renderSolarFlares(ctx, body);
            }

            ctx.restore();
        }
    }

    /**
     * Render moon in real-time (small enough for real-time rendering)
     */
    renderMoon(ctx, moon) {
        // Enhanced moons use pre-rendered canvas
        if (!moon.colors || !moon.features) {
            // Use pre-rendered canvas if available
            const canvas = this.bodyCanvases.get(moon.id);
            if (canvas) {
                ctx.drawImage(canvas, -canvas.width / 2, -canvas.height / 2);
            } else {
                // Fallback: simple gray circle
                const size = moon.size;
                ctx.fillStyle = '#888888';
                ctx.beginPath();
                ctx.arc(0, 0, size / 2, 0, Math.PI * 2);
                ctx.fill();
            }
            return;
        }

        const size = moon.size;

        // Main body
        const gradient = ctx.createRadialGradient(-size * 0.2, -size * 0.2, 0, 0, 0, size * 0.5);
        gradient.addColorStop(0, this.lightenColor(moon.colors[0], 0.3));
        gradient.addColorStop(0.5, moon.colors[0]);
        gradient.addColorStop(1, this.darkenColor(moon.colors[0], 0.3));
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(0, 0, size * 0.5, 0, Math.PI * 2);
        ctx.fill();

        // Craters
        ctx.fillStyle = this.darkenColor(moon.colors[0], 0.3);
        for (const crater of moon.features.craters) {
            ctx.beginPath();
            ctx.arc(crater.x, crater.y, crater.size, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    /**
     * Render animated solar flares
     */
    renderSolarFlares(ctx, star) {
        // Skip if no features (enhanced stars render flares differently)
        if (!star.features || !star.features.flares) {
            return;
        }

        const size = star.size;
        const time = star.animationTime || 0;

        for (const flare of star.features.flares) {
            const phase = Math.sin(time + flare.phase) * 0.5 + 0.5;
            const length = flare.length * (0.7 + phase * 0.3);

            const x1 = Math.cos(flare.angle) * size * 0.5;
            const y1 = Math.sin(flare.angle) * size * 0.5;
            const x2 = Math.cos(flare.angle) * (size * 0.5 + length);
            const y2 = Math.sin(flare.angle) * (size * 0.5 + length);

            const gradient = ctx.createLinearGradient(x1, y1, x2, y2);
            gradient.addColorStop(0, star.color);
            gradient.addColorStop(0.5, star.color + '80');
            gradient.addColorStop(1, star.color + '00');

            ctx.strokeStyle = gradient;
            ctx.lineWidth = flare.width * phase;
            ctx.beginPath();
            ctx.moveTo(x1, y1);
            ctx.lineTo(x2, y2);
            ctx.stroke();
        }
    }


    /**
     * Render orbital paths
     */
    renderOrbits(camera) {
        const ctx = this.ctx;
        ctx.save();

        // Render planet orbits
        for (const body of this.bodies) {
            if (body.type === 'planet' && body.distance) {
                const screenX = -camera.x;
                const screenY = -camera.y;

                // Draw orbit circle
                ctx.strokeStyle = 'rgba(100, 100, 150, 0.3)';
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.arc(screenX, screenY, body.distance, 0, Math.PI * 2);
                ctx.stroke();
            }

            // Render moon orbits
            if (body.type === 'moon' && body.parent && body.distance) {
                const parentScreenX = body.parent.x - camera.x;
                const parentScreenY = body.parent.y - camera.y;

                // Draw moon orbit circle
                ctx.strokeStyle = 'rgba(150, 150, 180, 0.2)';
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.arc(parentScreenX, parentScreenY, body.distance, 0, Math.PI * 2);
                ctx.stroke();
            }
        }

        ctx.restore();
    }


    /**
     * Helper: Lighten color
     */
    lightenColor(color, amount) {
        const num = parseInt(color.replace('#', ''), 16);
        const r = Math.min(255, ((num >> 16) & 0xff) + amount * 255);
        const g = Math.min(255, ((num >> 8) & 0xff) + amount * 255);
        const b = Math.min(255, (num & 0xff) + amount * 255);
        return `rgb(${r}, ${g}, ${b})`;
    }

    /**
     * Helper: Darken color
     */
    darkenColor(color, amount) {
        const num = parseInt(color.replace('#', ''), 16);
        const r = Math.max(0, ((num >> 16) & 0xff) * (1 - amount));
        const g = Math.max(0, ((num >> 8) & 0xff) * (1 - amount));
        const b = Math.max(0, (num & 0xff) * (1 - amount));
        return `rgb(${r}, ${g}, ${b})`;
    }

    /**
     * Get all bodies
     */
    getBodies() {
        return this.bodies;
    }

    /**
     * Get body by ID
     */
    getBodyById(id) {
        return this.bodies.find(b => b.id === id);
    }
}
