/**
 * PixelVerse - Visual Polish System
 * Enhanced visual effects, screen shake, color grading, post-processing
 */

class VisualPolish {
    constructor(renderer) {
        this.renderer = renderer;
        
        // Screen shake
        this.screenShake = {
            active: false,
            intensity: 0,
            duration: 0,
            timer: 0,
            offsetX: 0,
            offsetY: 0
        };
        
        // Camera effects
        this.cameraZoom = 1.0;
        this.targetZoom = 1.0;
        this.zoomSpeed = 0.1;
        
        // Color grading
        this.colorGrading = {
            enabled: true,
            brightness: 1.0,
            contrast: 1.0,
            saturation: 1.0,
            tint: { r: 0, g: 0, b: 0 }
        };
        
        // Vignette
        this.vignette = {
            enabled: true,
            intensity: 0.3,
            radius: 0.7
        };
        
        // Chromatic aberration
        this.chromaticAberration = {
            enabled: false,
            intensity: 2.0
        };
        
        // Motion blur
        this.motionBlur = {
            enabled: false,
            intensity: 0.5
        };
        
        // Bloom/Glow
        this.bloom = {
            enabled: true,
            threshold: 0.8,
            intensity: 0.5
        };
        
        // Damage overlay
        this.damageOverlay = {
            active: false,
            intensity: 0,
            color: 'rgba(255, 0, 0, 0.3)'
        };
        
        // Speed lines
        this.speedLines = {
            active: false,
            intensity: 0,
            lines: []
        };
    }

    /**
     * Update visual effects
     */
    update(deltaTime) {
        // Update screen shake
        if (this.screenShake.active) {
            this.screenShake.timer += deltaTime;
            
            if (this.screenShake.timer >= this.screenShake.duration) {
                this.screenShake.active = false;
                this.screenShake.offsetX = 0;
                this.screenShake.offsetY = 0;
            } else {
                const progress = this.screenShake.timer / this.screenShake.duration;
                const intensity = this.screenShake.intensity * (1 - progress);
                
                this.screenShake.offsetX = (Math.random() - 0.5) * intensity;
                this.screenShake.offsetY = (Math.random() - 0.5) * intensity;
            }
        }
        
        // Update camera zoom
        if (Math.abs(this.cameraZoom - this.targetZoom) > 0.01) {
            this.cameraZoom += (this.targetZoom - this.cameraZoom) * this.zoomSpeed;
        }
        
        // Update damage overlay
        if (this.damageOverlay.active) {
            this.damageOverlay.intensity *= 0.95;
            if (this.damageOverlay.intensity < 0.01) {
                this.damageOverlay.active = false;
            }
        }
        
        // Update speed lines
        if (this.speedLines.active) {
            this.speedLines.intensity *= 0.98;
            if (this.speedLines.intensity < 0.01) {
                this.speedLines.active = false;
                this.speedLines.lines = [];
            }
        }
    }

    /**
     * Trigger screen shake
     */
    shake(intensity = 10, duration = 0.3) {
        this.screenShake.active = true;
        this.screenShake.intensity = intensity;
        this.screenShake.duration = duration;
        this.screenShake.timer = 0;
    }

    /**
     * Set camera zoom
     */
    setZoom(zoom, smooth = true) {
        if (smooth) {
            this.targetZoom = zoom;
        } else {
            this.cameraZoom = zoom;
            this.targetZoom = zoom;
        }
    }

    /**
     * Apply damage flash
     */
    damageFlash(intensity = 0.5) {
        this.damageOverlay.active = true;
        this.damageOverlay.intensity = intensity;
    }

    /**
     * Activate speed lines
     */
    activateSpeedLines(intensity = 1.0, count = 20) {
        this.speedLines.active = true;
        this.speedLines.intensity = intensity;
        this.speedLines.lines = [];
        
        const width = this.renderer.canvas.width;
        const height = this.renderer.canvas.height;
        
        for (let i = 0; i < count; i++) {
            this.speedLines.lines.push({
                x: Math.random() * width,
                y: Math.random() * height,
                length: 50 + Math.random() * 100,
                speed: 500 + Math.random() * 500,
                angle: Math.PI // Pointing backward
            });
        }
    }

    /**
     * Render post-processing effects
     */
    renderPostProcessing(ctx) {
        // Apply vignette
        if (this.vignette.enabled) {
            this.renderVignette(ctx);
        }
        
        // Apply damage overlay
        if (this.damageOverlay.active) {
            this.renderDamageOverlay(ctx);
        }
        
        // Apply speed lines
        if (this.speedLines.active) {
            this.renderSpeedLines(ctx);
        }
    }

    /**
     * Render vignette effect
     */
    renderVignette(ctx) {
        const width = ctx.canvas.width;
        const height = ctx.canvas.height;
        const centerX = width / 2;
        const centerY = height / 2;
        const radius = Math.max(width, height) * this.vignette.radius;
        
        const gradient = ctx.createRadialGradient(centerX, centerY, radius * 0.5, centerX, centerY, radius);
        gradient.addColorStop(0, 'rgba(0, 0, 0, 0)');
        gradient.addColorStop(1, `rgba(0, 0, 0, ${this.vignette.intensity})`);
        
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, width, height);
    }

    /**
     * Render damage overlay
     */
    renderDamageOverlay(ctx) {
        const width = ctx.canvas.width;
        const height = ctx.canvas.height;
        
        ctx.fillStyle = `rgba(255, 0, 0, ${this.damageOverlay.intensity * 0.3})`;
        ctx.fillRect(0, 0, width, height);
        
        // Damage vignette
        const centerX = width / 2;
        const centerY = height / 2;
        const radius = Math.max(width, height);
        
        const gradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, radius);
        gradient.addColorStop(0, 'rgba(255, 0, 0, 0)');
        gradient.addColorStop(1, `rgba(255, 0, 0, ${this.damageOverlay.intensity * 0.5})`);
        
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, width, height);
    }

    /**
     * Render speed lines
     */
    renderSpeedLines(ctx) {
        ctx.strokeStyle = `rgba(255, 255, 255, ${this.speedLines.intensity * 0.3})`;
        ctx.lineWidth = 2;
        
        for (const line of this.speedLines.lines) {
            ctx.beginPath();
            ctx.moveTo(line.x, line.y);
            ctx.lineTo(
                line.x + Math.cos(line.angle) * line.length,
                line.y + Math.sin(line.angle) * line.length
            );
            ctx.stroke();
        }
    }

    /**
     * Get screen shake offset
     */
    getShakeOffset() {
        return {
            x: this.screenShake.offsetX,
            y: this.screenShake.offsetY
        };
    }

    /**
     * Get camera zoom
     */
    getZoom() {
        return this.cameraZoom;
    }

    /**
     * Enable/disable effect
     */
    toggleEffect(effectName) {
        if (this[effectName] && this[effectName].enabled !== undefined) {
            this[effectName].enabled = !this[effectName].enabled;
            return this[effectName].enabled;
        }
        return null;
    }

    /**
     * Set effect intensity
     */
    setEffectIntensity(effectName, intensity) {
        if (this[effectName] && this[effectName].intensity !== undefined) {
            this[effectName].intensity = intensity;
            return true;
        }
        return false;
    }

    /**
     * Reset all effects
     */
    reset() {
        this.screenShake.active = false;
        this.screenShake.offsetX = 0;
        this.screenShake.offsetY = 0;
        this.damageOverlay.active = false;
        this.speedLines.active = false;
        this.cameraZoom = 1.0;
        this.targetZoom = 1.0;
    }
}

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = VisualPolish;
}

