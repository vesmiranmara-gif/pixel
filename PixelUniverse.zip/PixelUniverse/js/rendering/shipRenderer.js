/**
 * PixelVerse - Enhanced Ship Renderer
 * Isometric, highly detailed pixel art ships with hundreds of tiny pixels
 */

class ShipRenderer {
    constructor() {
        this.cache = new Map();
    }

    /**
     * Render player fighter ship (top-down, ULTRA pixelated, points RIGHT)
     * Ship points RIGHT (positive X), engines on LEFT side
     * Rotation 0 = pointing right, matches game's rotation system
     * MAXIMUM DETAIL VERSION
     */
    renderPlayerFighter(size = 64) {
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');

        // Draw pixel by pixel for MAXIMUM detail
        const pixels = [];
        const cx = size / 2;
        const cy = size / 2;

        // Extended color palette - 12 hull shades for maximum depth
        const c = {
            hull1: '#0a1a2a',      // Deepest shadow
            hull2: '#1a2a3a',      // Very dark hull
            hull3: '#2a3a4a',      // Dark hull
            hull4: '#3a4a5a',      // Medium-dark hull
            hull5: '#4a5a6a',      // Medium hull
            hull6: '#5a6a7a',      // Medium-light hull
            hull7: '#6a7a8a',      // Light hull
            hull8: '#7a8a9a',      // Very light hull
            hull9: '#8a9aaa',      // Brightest hull
            cockpit1: '#0a1a2a',   // Darkest cockpit
            cockpit2: '#1a2a3a',   // Dark cockpit
            cockpit3: '#2a4a6a',   // Medium cockpit
            cockpit4: '#4a6a8a',   // Bright cockpit
            cockpit5: '#6a8aaa',   // Very bright cockpit
            cockpit6: '#8aaacc',   // Cockpit glow
            cockpit7: '#aaccee',   // Bright glow
            wing1: '#0a1a2a',      // Darkest wing
            wing2: '#1a2a3a',      // Dark wing
            wing3: '#2a3a4a',      // Medium-dark wing
            wing4: '#3a4a5a',      // Medium wing
            wing5: '#4a5a6a',      // Light wing
            engine1: '#000000',    // Black engine
            engine2: '#0a0a1a',    // Very dark engine
            engine3: '#1a1a2a',    // Dark engine
            engine4: '#2a2a3a',    // Medium engine
            engineGlow1: '#ff3300', // Deep orange
            engineGlow2: '#ff6600', // Orange glow
            engineGlow3: '#ff8833', // Light orange
            engineGlow4: '#ffaa66', // Very light orange
            accent1: '#4a3a2a',    // Dark accent
            accent2: '#5a4a3a',    // Medium accent
            accent3: '#6a5a4a',    // Light accent
            panel: '#0a0a0a',      // Panel lines
            rivet1: '#6a6a6a',     // Dark rivet
            rivet2: '#8a8a8a',     // Medium rivet
            rivet3: '#aaaaaa',     // Bright rivet
            weapon: '#3a2a1a',     // Weapon hardpoint
            vent: '#1a1a1a'        // Vents
        };

        // Ship points RIGHT (positive X direction)
        // Nose at right, engines on left
        // X-axis: negative (left/engines) to positive (right/nose)
        // Y-axis: negative (top) to positive (bottom)
        // SIZE: 64x64 for MAXIMUM detail

        // ENGINES (LEFT SIDE) - Highly detailed engine pods
        // Main engine pods at x = -28 to -20
        for (let x = -28; x <= -20; x++) {
            // Top engine pod (Y = -8 to -3)
            for (let y = -8; y <= -3; y++) {
                let color;
                if (x === -28 || x === -20) {
                    color = c.engine1; // Outer edge
                } else if (x === -27 || x === -21) {
                    color = c.engine2; // Inner edge
                } else if (y === -8 || y === -3) {
                    color = c.engine2; // Top/bottom edge
                } else if (x >= -24 && x <= -23) {
                    color = c.engine4; // Center (lighter)
                } else {
                    color = c.engine3; // Main body
                }
                pixels.push({ x: x, y: y, c: color });
            }

            // Bottom engine pod (Y = 3 to 8)
            for (let y = 3; y <= 8; y++) {
                let color;
                if (x === -28 || x === -20) {
                    color = c.engine1;
                } else if (x === -27 || x === -21) {
                    color = c.engine2;
                } else if (y === 8 || y === 3) {
                    color = c.engine2;
                } else if (x >= -24 && x <= -23) {
                    color = c.engine4;
                } else {
                    color = c.engine3;
                }
                pixels.push({ x: x, y: y, c: color });
            }
        }

        // Engine exhausts (very left edge) - Multi-layer glow
        for (let y = -8; y <= -3; y++) {
            pixels.push({ x: -29, y: y, c: c.engineGlow2 });
            pixels.push({ x: -30, y: y, c: c.engineGlow3 });
            pixels.push({ x: -31, y: y, c: c.engineGlow4 });
            // Inner glow
            if (y >= -7 && y <= -4) {
                pixels.push({ x: -29, y: y, c: c.engineGlow1 });
            }
        }
        for (let y = 3; y <= 8; y++) {
            pixels.push({ x: -29, y: y, c: c.engineGlow2 });
            pixels.push({ x: -30, y: y, c: c.engineGlow3 });
            pixels.push({ x: -31, y: y, c: c.engineGlow4 });
            if (y >= 4 && y <= 7) {
                pixels.push({ x: -29, y: y, c: c.engineGlow1 });
            }
        }

        // Engine vents (detail)
        for (let x = -27; x <= -21; x += 2) {
            pixels.push({ x: x, y: -7, c: c.vent });
            pixels.push({ x: x, y: -4, c: c.vent });
            pixels.push({ x: x, y: 4, c: c.vent });
            pixels.push({ x: x, y: 7, c: c.vent });
        }

        // REAR HULL (x = -19 to -10) - Highly detailed with gradients
        for (let x = -19; x <= -10; x++) {
            for (let y = -10; y <= 10; y++) {
                let color;
                const absY = Math.abs(y);

                // Outer edges (darkest)
                if (absY === 10) {
                    color = c.hull1;
                } else if (absY === 9) {
                    color = c.hull2;
                } else if (absY === 8) {
                    color = c.hull3;
                } else if (absY === 7) {
                    color = c.hull4;
                } else if (absY <= 2) {
                    // Center line (brightest)
                    if (y === 0) {
                        color = c.hull7;
                    } else if (absY === 1) {
                        color = c.hull6;
                    } else {
                        color = c.hull5;
                    }
                } else {
                    // Mid sections
                    if (absY <= 4) {
                        color = c.hull5;
                    } else {
                        color = c.hull4;
                    }
                }
                pixels.push({ x: x, y: y, c: color });
            }
        }

        // WINGS (x = -14 to -4) - Extended and detailed
        for (let x = -14; x <= -4; x++) {
            // Top wing (Y = -16 to -11)
            for (let y = -16; y <= -11; y++) {
                let color;
                if (y === -16) {
                    color = c.wing1; // Outer edge
                } else if (y === -15) {
                    color = c.wing2;
                } else if (y === -14) {
                    color = c.wing3;
                } else if (y === -13) {
                    color = c.wing4;
                } else {
                    color = c.wing5; // Inner edge
                }
                pixels.push({ x: x, y: y, c: color });

                // Wing details (panel lines)
                if ((x + y) % 3 === 0) {
                    pixels.push({ x: x, y: y, c: c.panel });
                }
            }

            // Bottom wing (Y = 11 to 16)
            for (let y = 11; y <= 16; y++) {
                let color;
                if (y === 16) {
                    color = c.wing1;
                } else if (y === 15) {
                    color = c.wing2;
                } else if (y === 14) {
                    color = c.wing3;
                } else if (y === 13) {
                    color = c.wing4;
                } else {
                    color = c.wing5;
                }
                pixels.push({ x: x, y: y, c: color });

                if ((x + y) % 3 === 0) {
                    pixels.push({ x: x, y: y, c: c.panel });
                }
            }
        }

        // Wing weapon hardpoints
        for (let x = -12; x <= -10; x += 2) {
            pixels.push({ x: x, y: -14, c: c.weapon });
            pixels.push({ x: x, y: -13, c: c.weapon });
            pixels.push({ x: x, y: 13, c: c.weapon });
            pixels.push({ x: x, y: 14, c: c.weapon });
        }

        // MAIN HULL (x = -9 to 12) - Tapers forward with detailed shading
        for (let x = -9; x <= 12; x++) {
            // Calculate width based on position (wider at back, narrower at front)
            let width;
            if (x <= 0) {
                width = 10; // Full width at rear
            } else if (x <= 6) {
                width = 10 - Math.floor(x / 2); // Gradual taper
            } else {
                width = 10 - Math.floor(x / 1.5); // Faster taper
            }
            width = Math.max(3, width);

            for (let y = -width; y <= width; y++) {
                let color;
                const absY = Math.abs(y);

                // Gradient shading from center to edges
                if (absY === width) {
                    color = c.hull2; // Outer edge
                } else if (absY === width - 1) {
                    color = c.hull3;
                } else if (absY === width - 2) {
                    color = c.hull4;
                } else if (y === 0) {
                    color = c.hull7; // Center line (brightest)
                } else if (absY === 1) {
                    color = c.hull6;
                } else if (absY === 2) {
                    color = c.hull5;
                } else {
                    color = c.hull4;
                }
                pixels.push({ x: x, y: y, c: color });
            }
        }

        // COCKPIT (x = 4 to 14) - Detailed canopy
        for (let x = 4; x <= 14; x++) {
            let width;
            if (x <= 8) {
                width = 5;
            } else {
                width = Math.max(2, 5 - Math.floor((x - 8) / 2));
            }

            for (let y = -width; y <= width; y++) {
                let color;
                const absY = Math.abs(y);

                // Cockpit glass with gradient
                if (absY === width) {
                    color = c.cockpit1; // Frame
                } else if (absY === width - 1) {
                    color = c.cockpit2;
                } else if (x >= 8 && x <= 12 && absY <= 2) {
                    // Bright glow in center
                    if (absY === 0) {
                        color = c.cockpit7;
                    } else if (absY === 1) {
                        color = c.cockpit6;
                    } else {
                        color = c.cockpit5;
                    }
                } else if (absY <= 2) {
                    color = c.cockpit4;
                } else {
                    color = c.cockpit3;
                }
                pixels.push({ x: x, y: y, c: color });
            }
        }

        // NOSE (x = 15 to 28) - Sharp pointed nose with detail
        for (let x = 15; x <= 28; x++) {
            const width = Math.max(0, Math.floor((28 - x) / 2));

            for (let y = -width; y <= width; y++) {
                let color;
                const absY = Math.abs(y);

                if (width === 0) {
                    color = c.hull9; // Tip (brightest)
                } else if (absY === width) {
                    color = c.hull4; // Edges
                } else if (y === 0) {
                    color = c.hull8; // Center line
                } else if (absY === 1) {
                    color = c.hull7;
                } else {
                    color = c.hull6;
                }
                pixels.push({ x: x, y: y, c: color });
            }
        }

        // DETAILS - Panel lines
        for (let x = -12; x <= 4; x += 4) {
            for (let y = -6; y <= 6; y += 3) {
                pixels.push({ x: x, y: y, c: c.panel });
            }
        }

        // Rivets
        const rivetPositions = [
            { x: -14, y: -7 }, { x: -14, y: 7 },
            { x: -10, y: -7 }, { x: -10, y: 7 },
            { x: -6, y: -7 }, { x: -6, y: 7 },
            { x: -2, y: -7 }, { x: -2, y: 7 },
            { x: 2, y: -7 }, { x: 2, y: 7 },
            { x: 6, y: -4 }, { x: 6, y: 4 }
        ];
        rivetPositions.forEach(pos => {
            pixels.push({ x: pos.x, y: pos.y, c: c.rivet });
        });

        // Wing tips accent
        pixels.push({ x: -2, y: -12, c: c.accent });
        pixels.push({ x: -2, y: 12, c: c.accent });

        // Draw all pixels
        pixels.forEach(p => {
            ctx.fillStyle = p.c;
            ctx.fillRect(cx + p.x, cy + p.y, 1, 1);
        });

        // Add subtle noise for texture
        this.addPixelDetails(ctx, size);

        return canvas;
    }

    /**
     * Render enemy scout ship (small, fast, points UP)
     */
    renderEnemyScout(size = 32) {
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');

        const pixels = [];
        const cx = size / 2;
        const cy = size / 2;

        const c = {
            hull1: '#4a2a2a',
            hull2: '#5a3a3a',
            hull3: '#6a4a4a',
            cockpit: '#3a2a2a',
            engine: '#2a1a1a',
            engineGlow: '#ff3300'
        };

        // Small triangular scout - points UP
        // Nose (top)
        pixels.push({ x: 0, y: -12, c: c.hull3 });

        // Row -11
        pixels.push({ x: -1, y: -11, c: c.hull2 });
        pixels.push({ x: 0, y: -11, c: c.hull3 });
        pixels.push({ x: 1, y: -11, c: c.hull2 });

        // Cockpit area
        for (let y = -10; y <= -8; y++) {
            pixels.push({ x: -1, y: y, c: c.hull2 });
            pixels.push({ x: 0, y: y, c: c.cockpit });
            pixels.push({ x: 1, y: y, c: c.hull2 });
            pixels.push({ x: -2, y: y, c: c.hull1 });
            pixels.push({ x: 2, y: y, c: c.hull1 });
        }

        // Main hull widens
        for (let y = -7; y <= 0; y++) {
            const width = 2 + Math.floor((y + 7) / 2);
            for (let x = -width; x <= width; x++) {
                if (x === 0) {
                    pixels.push({ x: x, y: y, c: c.hull3 });
                } else if (Math.abs(x) === width) {
                    pixels.push({ x: x, y: y, c: c.hull1 });
                } else {
                    pixels.push({ x: x, y: y, c: c.hull2 });
                }
            }
        }

        // Engine section (bottom)
        for (let y = 1; y <= 4; y++) {
            const width = Math.max(1, 4 - y);
            for (let x = -width; x <= width; x++) {
                pixels.push({ x: x, y: y, c: c.engine });
            }
        }

        // Engine glow (very bottom)
        pixels.push({ x: -1, y: 5, c: c.engineGlow });
        pixels.push({ x: 0, y: 5, c: c.engineGlow });
        pixels.push({ x: 1, y: 5, c: c.engineGlow });
        pixels.push({ x: 0, y: 6, c: c.engineGlow });

        // Draw pixels
        pixels.forEach(p => {
            ctx.fillStyle = p.c;
            ctx.fillRect(cx + p.x, cy + p.y, 1, 1);
        });

        this.addPixelDetails(ctx, size);
        return canvas;
    }

    /**
     * Render enemy fighter (standard, points UP)
     */
    renderEnemyFighter(size = 40) {
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');

        const pixels = [];
        const cx = size / 2;
        const cy = size / 2;

        const c = {
            hull1: '#3a2a2a',
            hull2: '#4a3a3a',
            hull3: '#5a4a4a',
            cockpit: '#2a2a3a',
            wing1: '#3a2a2a',
            wing2: '#4a3a3a',
            engine: '#2a1a1a',
            engineGlow: '#ff4400'
        };

        // Pointed nose (top)
        pixels.push({ x: 0, y: -16, c: c.hull3 });

        for (let y = -15; y <= -14; y++) {
            pixels.push({ x: -1, y: y, c: c.hull2 });
            pixels.push({ x: 0, y: y, c: c.hull3 });
            pixels.push({ x: 1, y: y, c: c.hull2 });
        }

        // Cockpit section
        for (let y = -13; y <= -10; y++) {
            pixels.push({ x: -2, y: y, c: c.hull1 });
            pixels.push({ x: -1, y: y, c: c.hull2 });
            pixels.push({ x: 0, y: y, c: c.cockpit });
            pixels.push({ x: 1, y: y, c: c.hull2 });
            pixels.push({ x: 2, y: y, c: c.hull1 });
        }

        // Main hull with wings
        for (let y = -9; y <= 2; y++) {
            // Main hull
            for (let x = -3; x <= 3; x++) {
                if (x === 0) {
                    pixels.push({ x: x, y: y, c: c.hull3 });
                } else if (Math.abs(x) === 3) {
                    pixels.push({ x: x, y: y, c: c.hull1 });
                } else {
                    pixels.push({ x: x, y: y, c: c.hull2 });
                }
            }

            // Wings (extend from -6 to 6)
            if (y >= -6 && y <= 0) {
                // Left wing
                for (let x = -6; x <= -4; x++) {
                    pixels.push({ x: x, y: y, c: x === -6 ? c.wing1 : c.wing2 });
                }
                // Right wing
                for (let x = 4; x <= 6; x++) {
                    pixels.push({ x: x, y: y, c: x === 6 ? c.wing1 : c.wing2 });
                }
            }
        }

        // Engine section (bottom)
        for (let y = 3; y <= 6; y++) {
            // Left engine
            pixels.push({ x: -4, y: y, c: c.engine });
            pixels.push({ x: -3, y: y, c: c.engine });

            // Right engine
            pixels.push({ x: 3, y: y, c: c.engine });
            pixels.push({ x: 4, y: y, c: c.engine });

            // Center hull narrows
            if (y <= 5) {
                pixels.push({ x: -1, y: y, c: c.hull2 });
                pixels.push({ x: 0, y: y, c: c.hull3 });
                pixels.push({ x: 1, y: y, c: c.hull2 });
            }
        }

        // Engine exhausts (very bottom)
        pixels.push({ x: -4, y: 7, c: c.engineGlow });
        pixels.push({ x: -3, y: 7, c: c.engineGlow });
        pixels.push({ x: 3, y: 7, c: c.engineGlow });
        pixels.push({ x: 4, y: 7, c: c.engineGlow });
        pixels.push({ x: -4, y: 8, c: c.engineGlow });
        pixels.push({ x: -3, y: 8, c: c.engineGlow });
        pixels.push({ x: 3, y: 8, c: c.engineGlow });
        pixels.push({ x: 4, y: 8, c: c.engineGlow });

        // Draw pixels
        pixels.forEach(p => {
            ctx.fillStyle = p.c;
            ctx.fillRect(cx + p.x, cy + p.y, 1, 1);
        });

        this.addPixelDetails(ctx, size);
        return canvas;
    }

    /**
     * Render enemy bomber (slow, powerful, points UP)
     */
    renderEnemyBomber(size = 52) {
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');

        const pixels = [];
        const cx = size / 2;
        const cy = size / 2;

        const c = {
            hull1: '#2a2a2a',
            hull2: '#3a3a3a',
            hull3: '#4a4a4a',
            weapon1: '#3a2a1a',
            weapon2: '#4a3a2a',
            cockpit: '#2a2a3a',
            engine: '#1a1a1a',
            engineGlow: '#ff6600'
        };

        // Wide blunt nose (top)
        for (let y = -20; y <= -18; y++) {
            for (let x = -3; x <= 3; x++) {
                if (Math.abs(x) === 3) {
                    pixels.push({ x: x, y: y, c: c.hull1 });
                } else {
                    pixels.push({ x: x, y: y, c: c.hull3 });
                }
            }
        }

        // Cockpit
        for (let y = -17; y <= -14; y++) {
            for (let x = -4; x <= 4; x++) {
                if (Math.abs(x) === 4) {
                    pixels.push({ x: x, y: y, c: c.hull1 });
                } else if (Math.abs(x) <= 1) {
                    pixels.push({ x: x, y: y, c: c.cockpit });
                } else {
                    pixels.push({ x: x, y: y, c: c.hull2 });
                }
            }
        }

        // Main hull with weapon pods
        for (let y = -13; y <= 6; y++) {
            // Main hull
            for (let x = -5; x <= 5; x++) {
                if (Math.abs(x) === 5) {
                    pixels.push({ x: x, y: y, c: c.hull1 });
                } else if (x === 0) {
                    pixels.push({ x: x, y: y, c: c.hull3 });
                } else {
                    pixels.push({ x: x, y: y, c: c.hull2 });
                }
            }

            // Weapon pods (extend from hull)
            if (y >= -8 && y <= 4) {
                // Left weapon pod
                for (let x = -8; x <= -6; x++) {
                    pixels.push({ x: x, y: y, c: x === -8 ? c.weapon1 : c.weapon2 });
                }
                // Right weapon pod
                for (let x = 6; x <= 8; x++) {
                    pixels.push({ x: x, y: y, c: x === 8 ? c.weapon1 : c.weapon2 });
                }
            }
        }

        // Engine section (bottom) - large and powerful
        for (let y = 7; y <= 12; y++) {
            // Left engine
            for (let x = -7; x <= -3; x++) {
                pixels.push({ x: x, y: y, c: c.engine });
            }
            // Right engine
            for (let x = 3; x <= 7; x++) {
                pixels.push({ x: x, y: y, c: c.engine });
            }
            // Center
            if (y <= 10) {
                for (let x = -2; x <= 2; x++) {
                    pixels.push({ x: x, y: y, c: c.hull2 });
                }
            }
        }

        // Large engine exhausts (very bottom)
        for (let y = 13; y <= 14; y++) {
            for (let x = -7; x <= -3; x++) {
                pixels.push({ x: x, y: y, c: c.engineGlow });
            }
            for (let x = 3; x <= 7; x++) {
                pixels.push({ x: x, y: y, c: c.engineGlow });
            }
        }

        // Draw pixels
        pixels.forEach(p => {
            ctx.fillStyle = p.c;
            ctx.fillRect(cx + p.x, cy + p.y, 1, 1);
        });

        this.addPixelDetails(ctx, size);
        return canvas;
    }

    /**
     * Render enemy heavy fighter (armored, points UP)
     */
    renderEnemyHeavyFighter(size = 48) {
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');

        const pixels = [];
        const cx = size / 2;
        const cy = size / 2;

        const c = {
            armor1: '#2a2a2a',
            armor2: '#3a3a3a',
            armor3: '#4a4a4a',
            armor4: '#5a5a5a',
            cockpit: '#2a2a3a',
            engine: '#1a1a1a',
            engineGlow: '#ff5500'
        };

        // Blunt armored nose (top)
        for (let y = -18; y <= -16; y++) {
            for (let x = -2; x <= 2; x++) {
                if (Math.abs(x) === 2) {
                    pixels.push({ x: x, y: y, c: c.armor1 });
                } else {
                    pixels.push({ x: x, y: y, c: c.armor3 });
                }
            }
        }

        // Cockpit
        for (let y = -15; y <= -12; y++) {
            pixels.push({ x: -3, y: y, c: c.armor1 });
            pixels.push({ x: -2, y: y, c: c.armor2 });
            pixels.push({ x: -1, y: y, c: c.cockpit });
            pixels.push({ x: 0, y: y, c: c.cockpit });
            pixels.push({ x: 1, y: y, c: c.cockpit });
            pixels.push({ x: 2, y: y, c: c.armor2 });
            pixels.push({ x: 3, y: y, c: c.armor1 });
        }

        // Heavy armored hull
        for (let y = -11; y <= 4; y++) {
            for (let x = -5; x <= 5; x++) {
                if (Math.abs(x) === 5) {
                    pixels.push({ x: x, y: y, c: c.armor1 });
                } else if (Math.abs(x) === 4) {
                    pixels.push({ x: x, y: y, c: c.armor2 });
                } else if (x === 0) {
                    pixels.push({ x: x, y: y, c: c.armor4 });
                } else {
                    pixels.push({ x: x, y: y, c: c.armor3 });
                }
            }

            // Armor plates (visual detail)
            if (y % 4 === 0) {
                pixels.push({ x: -3, y: y, c: c.armor1 });
                pixels.push({ x: 3, y: y, c: c.armor1 });
            }
        }

        // Engine section (bottom) - wide and powerful
        for (let y = 5; y <= 10; y++) {
            // Left engine
            for (let x = -6; x <= -3; x++) {
                pixels.push({ x: x, y: y, c: c.engine });
            }
            // Right engine
            for (let x = 3; x <= 6; x++) {
                pixels.push({ x: x, y: y, c: c.engine });
            }
            // Center
            if (y <= 8) {
                for (let x = -2; x <= 2; x++) {
                    pixels.push({ x: x, y: y, c: c.armor2 });
                }
            }
        }

        // Heavy engine exhausts (very bottom)
        for (let y = 11; y <= 12; y++) {
            for (let x = -6; x <= -3; x++) {
                pixels.push({ x: x, y: y, c: c.engineGlow });
            }
            for (let x = 3; x <= 6; x++) {
                pixels.push({ x: x, y: y, c: c.engineGlow });
            }
        }

        // Draw pixels
        pixels.forEach(p => {
            ctx.fillStyle = p.c;
            ctx.fillRect(cx + p.x, cy + p.y, 1, 1);
        });

        this.addPixelDetails(ctx, size);
        return canvas;
    }

    /**
     * Helper: Draw isometric shape
     */
    drawIsometricShape(ctx, points, color) {
        if (points.length < 3) return;

        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.moveTo(points[0].x, points[0].y);
        for (let i = 1; i < points.length; i++) {
            ctx.lineTo(points[i].x, points[i].y);
        }
        ctx.closePath();
        ctx.fill();
    }

    /**
     * Helper: Add pixel-level details
     */
    addPixelDetails(ctx, size, colors) {
        const imageData = ctx.getImageData(0, 0, size, size);
        const data = imageData.data;

        // Add noise and variation to non-transparent pixels
        for (let i = 0; i < data.length; i += 4) {
            if (data[i + 3] > 0) { // If not transparent
                const noise = (Math.random() - 0.5) * 10;
                data[i] = Math.max(0, Math.min(255, data[i] + noise));
                data[i + 1] = Math.max(0, Math.min(255, data[i + 1] + noise));
                data[i + 2] = Math.max(0, Math.min(255, data[i + 2] + noise));
            }
        }

        ctx.putImageData(imageData, 0, 0);
    }

    /**
     * Get or create cached ship
     */
    getShip(type, size) {
        const key = `${type}_${size}`;
        if (this.cache.has(key)) return this.cache.get(key);

        let canvas;
        switch (type) {
            case 'playerFighter':
                canvas = this.renderPlayerFighter(size);
                break;
            case 'enemyScout':
                canvas = this.renderEnemyScout(size);
                break;
            case 'enemyFighter':
                canvas = this.renderEnemyFighter(size);
                break;
            case 'enemyHeavyFighter':
                canvas = this.renderEnemyHeavyFighter(size);
                break;
            case 'enemyBomber':
                canvas = this.renderEnemyBomber(size);
                break;
            default:
                canvas = this.renderPlayerFighter(size);
        }

        this.cache.set(key, canvas);
        return canvas;
    }
}

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ShipRenderer;
}

