/**
 * PixelVerse - Enhanced Celestial Body Renderer
 * Realistic, detailed, isometric pixel art celestial bodies
 */

class CelestialRenderer {
    constructor() {
        this.cache = new Map();
        this.noiseCache = new Map();
    }

    /**
     * Generate realistic noise for terrain with high detail
     */
    generateNoise(seed, octaves = 8) {
        const key = `${seed}_${octaves}`;
        if (this.noiseCache.has(key)) return this.noiseCache.get(key);

        const noise = (x, y) => {
            const n = Math.sin(x * 12.9898 + y * 78.233 + seed) * 43758.5453;
            return n - Math.floor(n);
        };

        const fbm = (x, y) => {
            let value = 0;
            let amplitude = 1;
            let frequency = 1;
            let maxValue = 0;

            for (let i = 0; i < octaves; i++) {
                value += noise(x * frequency, y * frequency) * amplitude;
                maxValue += amplitude;
                amplitude *= 0.5;
                frequency *= 2;
            }

            return value / maxValue;
        };

        this.noiseCache.set(key, fbm);
        return fbm;
    }

    /**
     * Render rocky planet with highly detailed terrain
     */
    renderRockyPlanet(size, colors, seed) {
        const canvas = document.createElement('canvas');
        const radius = size / 2;
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');

        const noise = this.generateNoise(seed, 10); // More octaves for detail
        const imageData = ctx.createImageData(size, size);
        const data = imageData.data;

        // Expanded color palette for rocky terrain (more variations)
        const terrainColors = [
            { r: 60, g: 50, b: 45 },    // Very dark rock
            { r: 75, g: 65, b: 55 },    // Dark rock
            { r: 90, g: 75, b: 65 },    // Deep shadow
            { r: 105, g: 90, b: 75 },   // Shadow rock
            { r: 120, g: 100, b: 85 },  // Medium rock
            { r: 135, g: 115, b: 95 },  // Medium-light rock
            { r: 150, g: 130, b: 110 }, // Light rock
            { r: 165, g: 145, b: 125 }, // Bright rock
            { r: 180, g: 160, b: 140 }, // Very bright rock
            { r: 145, g: 125, b: 105 }, // Reddish rock
            { r: 130, g: 110, b: 90 },  // Brown rock
            { r: 110, g: 95, b: 80 }    // Dark brown rock
        ];

        for (let y = 0; y < size; y++) {
            for (let x = 0; x < size; x++) {
                const dx = x - radius;
                const dy = y - radius;
                const distance = Math.sqrt(dx * dx + dy * dy);

                if (distance <= radius) {
                    // Calculate 3D sphere position
                    const z = Math.sqrt(radius * radius - dx * dx - dy * dy);
                    const nx = dx / radius;
                    const ny = dy / radius;
                    const nz = z / radius;

                    // Lighting (from top-left)
                    const lightX = -0.5, lightY = -0.5, lightZ = 0.7;
                    const lightDot = Math.max(0, nx * lightX + ny * lightY + nz * lightZ);

                    // Multi-layer terrain noise with high detail
                    const scale1 = size / 100; // Large features
                    const scale2 = size / 50;  // Medium features
                    const scale3 = size / 25;  // Small features
                    const scale4 = size / 12;  // Tiny features
                    const scale5 = size / 6;   // Micro features

                    const terrainNoise = noise(x * scale1, y * scale1);
                    const detailNoise = noise(x * scale2, y * scale2);
                    const fineNoise = noise(x * scale3, y * scale3);
                    const microNoise = noise(x * scale4, y * scale4);
                    const pixelNoise = noise(x * scale5, y * scale5);

                    // Combine noises with different weights
                    const combined = terrainNoise * 0.35 +
                                   detailNoise * 0.25 +
                                   fineNoise * 0.20 +
                                   microNoise * 0.12 +
                                   pixelNoise * 0.08;

                    // Select color based on terrain height
                    let colorIndex = Math.floor(combined * terrainColors.length);
                    colorIndex = Math.max(0, Math.min(terrainColors.length - 1, colorIndex));
                    const baseColor = terrainColors[colorIndex];

                    // Add color variation per pixel
                    const colorVariation = (pixelNoise - 0.5) * 15;

                    // Apply lighting
                    const brightness = 0.3 + lightDot * 0.7;

                    // Edge darkening for sphere effect
                    const edgeFactor = 1 - Math.pow(distance / radius, 2);
                    const finalBrightness = brightness * (0.5 + edgeFactor * 0.5);

                    // Craters with more detail
                    const craterNoise1 = noise(x * scale2 + 100, y * scale2 + 100);
                    const craterNoise2 = noise(x * scale3 + 200, y * scale3 + 200);
                    const isCrater = craterNoise1 > 0.88 || craterNoise2 > 0.92;
                    const craterDepth = isCrater ? Math.max(craterNoise1, craterNoise2) * 0.4 : 0;

                    const idx = (y * size + x) * 4;
                    data[idx] = Math.max(0, Math.min(255, (baseColor.r + colorVariation) * (finalBrightness - craterDepth)));
                    data[idx + 1] = Math.max(0, Math.min(255, (baseColor.g + colorVariation) * (finalBrightness - craterDepth)));
                    data[idx + 2] = Math.max(0, Math.min(255, (baseColor.b + colorVariation) * (finalBrightness - craterDepth)));
                    data[idx + 3] = 255;
                } else {
                    const idx = (y * size + x) * 4;
                    data[idx + 3] = 0; // Transparent
                }
            }
        }

        ctx.putImageData(imageData, 0, 0);
        return canvas;
    }

    /**
     * Render Earth-like planet with highly detailed oceans, continents, clouds
     */
    renderEarthlikePlanet(size, seed) {
        const canvas = document.createElement('canvas');
        const radius = size / 2;
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');

        const noise = this.generateNoise(seed, 10);
        const cloudNoise = this.generateNoise(seed + 1000, 8);
        const imageData = ctx.createImageData(size, size);
        const data = imageData.data;

        // Expanded color palettes
        const oceanColors = [
            { r: 10, g: 25, b: 60 },   // Very deep ocean
            { r: 15, g: 35, b: 75 },   // Deep ocean
            { r: 20, g: 45, b: 90 },   // Deep water
            { r: 25, g: 55, b: 105 },  // Ocean
            { r: 30, g: 65, b: 120 },  // Medium ocean
            { r: 35, g: 75, b: 135 },  // Shallow ocean
            { r: 40, g: 85, b: 150 }   // Very shallow
        ];

        const landColors = [
            { r: 45, g: 75, b: 30 },   // Dark lowland
            { r: 55, g: 90, b: 35 },   // Lowland
            { r: 65, g: 105, b: 40 },  // Low plains
            { r: 75, g: 120, b: 45 },  // Plains
            { r: 85, g: 135, b: 50 },  // High plains
            { r: 95, g: 145, b: 55 },  // Hills
            { r: 110, g: 155, b: 65 }, // High hills
            { r: 125, g: 165, b: 80 }, // Low mountains
            { r: 140, g: 170, b: 95 }, // Mountains
            { r: 160, g: 175, b: 120 }, // High mountains
            { r: 180, g: 185, b: 160 }, // Snow line
            { r: 200, g: 200, b: 200 }  // Snow peaks
        ];

        for (let y = 0; y < size; y++) {
            for (let x = 0; x < size; x++) {
                const dx = x - radius;
                const dy = y - radius;
                const distance = Math.sqrt(dx * dx + dy * dy);

                if (distance <= radius) {
                    const z = Math.sqrt(radius * radius - dx * dx - dy * dy);
                    const nx = dx / radius;
                    const ny = dy / radius;
                    const nz = z / radius;

                    // Lighting
                    const lightX = -0.5, lightY = -0.5, lightZ = 0.7;
                    const lightDot = Math.max(0, nx * lightX + ny * lightY + nz * lightZ);

                    // Multi-layer terrain height with high detail
                    const scale1 = size / 80;
                    const scale2 = size / 40;
                    const scale3 = size / 20;
                    const scale4 = size / 10;
                    const scale5 = size / 5;

                    const terrainHeight = noise(x * scale1, y * scale1);
                    const detailNoise = noise(x * scale2, y * scale2);
                    const fineNoise = noise(x * scale3, y * scale3);
                    const microNoise = noise(x * scale4, y * scale4);
                    const pixelNoise = noise(x * scale5, y * scale5);

                    const height = terrainHeight * 0.40 +
                                 detailNoise * 0.25 +
                                 fineNoise * 0.18 +
                                 microNoise * 0.10 +
                                 pixelNoise * 0.07;

                    let baseColor;
                    if (height < 0.42) {
                        // Ocean - more detailed depth
                        const oceanDepth = (0.42 - height) / 0.42;
                        const colorIndex = Math.floor(oceanDepth * oceanColors.length);
                        baseColor = oceanColors[Math.min(colorIndex, oceanColors.length - 1)];

                        // Add ocean texture
                        const oceanTexture = (pixelNoise - 0.5) * 8;
                        baseColor = {
                            r: Math.max(0, baseColor.r + oceanTexture),
                            g: Math.max(0, baseColor.g + oceanTexture),
                            b: Math.max(0, baseColor.b + oceanTexture)
                        };
                    } else {
                        // Land - more detailed elevation
                        const landHeight = (height - 0.42) / 0.58;
                        const colorIndex = Math.floor(landHeight * landColors.length);
                        baseColor = landColors[Math.min(colorIndex, landColors.length - 1)];

                        // Add land texture
                        const landTexture = (pixelNoise - 0.5) * 12;
                        baseColor = {
                            r: Math.max(0, baseColor.r + landTexture),
                            g: Math.max(0, baseColor.g + landTexture),
                            b: Math.max(0, baseColor.b + landTexture)
                        };
                    }

                    // Detailed clouds
                    const cloudValue = cloudNoise(x * scale2 + Date.now() * 0.00001, y * scale2);
                    const cloudDetail = cloudNoise(x * scale4, y * scale4);
                    const combinedCloud = cloudValue * 0.7 + cloudDetail * 0.3;
                    const hasCloud = combinedCloud > 0.62;
                    const cloudBrightness = hasCloud ? (combinedCloud - 0.62) * 2.5 : 0;

                    // Apply lighting
                    const brightness = 0.3 + lightDot * 0.7;
                    const edgeFactor = 1 - Math.pow(distance / radius, 2);
                    const finalBrightness = brightness * (0.5 + edgeFactor * 0.5);

                    const idx = (y * size + x) * 4;
                    if (hasCloud) {
                        // Blend cloud with surface
                        const cloudR = 240 + pixelNoise * 15;
                        const cloudG = 245 + pixelNoise * 10;
                        const cloudB = 250 + pixelNoise * 5;
                        const blend = cloudBrightness * 0.75;
                        data[idx] = baseColor.r * finalBrightness * (1 - blend) + cloudR * blend;
                        data[idx + 1] = baseColor.g * finalBrightness * (1 - blend) + cloudG * blend;
                        data[idx + 2] = baseColor.b * finalBrightness * (1 - blend) + cloudB * blend;
                    } else {
                        data[idx] = baseColor.r * finalBrightness;
                        data[idx + 1] = baseColor.g * finalBrightness;
                        data[idx + 2] = baseColor.b * finalBrightness;
                    }
                    data[idx + 3] = 255;
                } else {
                    const idx = (y * size + x) * 4;
                    data[idx + 3] = 0;
                }
            }
        }

        ctx.putImageData(imageData, 0, 0);
        return canvas;
    }

    /**
     * Render gas giant with highly detailed bands and storms
     */
    renderGasGiant(size, seed) {
        const canvas = document.createElement('canvas');
        const radius = size / 2;
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');

        const noise = this.generateNoise(seed, 10);
        const turbulence = this.generateNoise(seed + 500, 12);
        const imageData = ctx.createImageData(size, size);
        const data = imageData.data;

        // Expanded gas giant color bands
        const bandColors = [
            { r: 230, g: 200, b: 160 }, // Very light band
            { r: 220, g: 185, b: 145 }, // Light band
            { r: 210, g: 170, b: 130 }, // Light-medium band
            { r: 200, g: 160, b: 120 }, // Medium-light band
            { r: 190, g: 150, b: 110 }, // Medium band
            { r: 180, g: 140, b: 100 }, // Medium-dark band
            { r: 170, g: 130, b: 90 },  // Dark band
            { r: 160, g: 120, b: 80 },  // Darker band
            { r: 150, g: 110, b: 70 },  // Very dark band
            { r: 140, g: 100, b: 65 },  // Darkest band
            { r: 195, g: 155, b: 115 }, // Reddish band
            { r: 185, g: 145, b: 105 }  // Brown band
        ];

        for (let y = 0; y < size; y++) {
            for (let x = 0; x < size; x++) {
                const dx = x - radius;
                const dy = y - radius;
                const distance = Math.sqrt(dx * dx + dy * dy);

                if (distance <= radius) {
                    const z = Math.sqrt(radius * radius - dx * dx - dy * dy);
                    const nx = dx / radius;
                    const ny = dy / radius;
                    const nz = z / radius;

                    // Lighting
                    const lightX = -0.5, lightY = -0.5, lightZ = 0.7;
                    const lightDot = Math.max(0, nx * lightX + ny * lightY + nz * lightZ);

                    // Multi-layer horizontal bands with high detail turbulence
                    const bandPosition = (ny + 1) / 2; // 0 to 1

                    const scale1 = size / 50;
                    const scale2 = size / 25;
                    const scale3 = size / 12;
                    const scale4 = size / 6;

                    const turbValue1 = turbulence(x * scale1, y * scale1 * 0.3) * 0.25;
                    const turbValue2 = turbulence(x * scale2, y * scale2 * 0.3) * 0.15;
                    const turbValue3 = turbulence(x * scale3, y * scale3 * 0.3) * 0.08;
                    const turbValue4 = turbulence(x * scale4, y * scale4 * 0.3) * 0.04;

                    const distortedBand = bandPosition + turbValue1 + turbValue2 + turbValue3 + turbValue4;

                    // Select band color with more variation
                    const bandIndex = Math.floor(distortedBand * 30) % bandColors.length;
                    let baseColor = bandColors[bandIndex];

                    // Add swirls and micro-details
                    const swirlNoise = noise(x * scale2, y * scale2);
                    const microDetail = noise(x * scale4, y * scale4);
                    const detailVariation = 0.75 + swirlNoise * 0.3 + microDetail * 0.15;

                    // Add pixel-level color variation
                    const pixelVariation = (microDetail - 0.5) * 20;
                    baseColor = {
                        r: Math.max(0, Math.min(255, baseColor.r + pixelVariation)),
                        g: Math.max(0, Math.min(255, baseColor.g + pixelVariation)),
                        b: Math.max(0, Math.min(255, baseColor.b + pixelVariation))
                    };

                    // Great Red Spot effect with more detail
                    const spotX = radius * 0.3;
                    const spotY = radius * 0.2;
                    const spotDist = Math.sqrt((dx - spotX) * (dx - spotX) + (dy - spotY) * (dy - spotY));
                    const isInSpot = spotDist < radius * 0.18;
                    const spotEffect = isInSpot ? Math.max(0, 1 - spotDist / (radius * 0.18)) : 0;
                    const spotTurbulence = noise(x * scale3 + 50, y * scale3 + 50) * 0.3;

                    // Apply lighting and sphere shading
                    const brightness = 0.3 + lightDot * 0.7;
                    const edgeFactor = 1 - Math.pow(distance / radius, 2);
                    const finalBrightness = brightness * (0.5 + edgeFactor * 0.5) * detailVariation;

                    const idx = (y * size + x) * 4;
                    if (spotEffect > 0) {
                        // Red spot with turbulent edges
                        const spotBrightness = spotEffect * (0.9 + spotTurbulence);
                        data[idx] = (baseColor.r * finalBrightness * (1 - spotBrightness) + 210 * spotBrightness);
                        data[idx + 1] = (baseColor.g * finalBrightness * (1 - spotBrightness) + 85 * spotBrightness);
                        data[idx + 2] = (baseColor.b * finalBrightness * (1 - spotBrightness) + 65 * spotBrightness);
                    } else {
                        data[idx] = baseColor.r * finalBrightness;
                        data[idx + 1] = baseColor.g * finalBrightness;
                        data[idx + 2] = baseColor.b * finalBrightness;
                    }
                    data[idx + 3] = 255;
                } else {
                    const idx = (y * size + x) * 4;
                    data[idx + 3] = 0;
                }
            }
        }

        ctx.putImageData(imageData, 0, 0);
        return canvas;
    }

    /**
     * Render ice planet with frozen surface
     */
    renderIcePlanet(size, seed) {
        const canvas = document.createElement('canvas');
        const radius = size / 2;
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');

        const noise = this.generateNoise(seed, 6);
        const crackNoise = this.generateNoise(seed + 200, 8);
        const imageData = ctx.createImageData(size, size);
        const data = imageData.data;

        // Ice colors
        const iceColors = [
            { r: 200, g: 220, b: 255 }, // Bright ice
            { r: 180, g: 200, b: 240 }, // Ice
            { r: 160, g: 180, b: 220 }, // Dark ice
            { r: 140, g: 160, b: 200 }, // Deep ice
            { r: 220, g: 235, b: 255 }  // Snow
        ];

        for (let y = 0; y < size; y++) {
            for (let x = 0; x < size; x++) {
                const dx = x - radius;
                const dy = y - radius;
                const distance = Math.sqrt(dx * dx + dy * dy);

                if (distance <= radius) {
                    const z = Math.sqrt(radius * radius - dx * dx - dy * dy);
                    const nx = dx / radius;
                    const ny = dy / radius;
                    const nz = z / radius;

                    const lightX = -0.5, lightY = -0.5, lightZ = 0.7;
                    const lightDot = Math.max(0, nx * lightX + ny * lightY + nz * lightZ);

                    // Ice terrain
                    const iceHeight = noise(x / size * 8, y / size * 8);
                    const cracks = crackNoise(x / size * 32, y / size * 32);
                    const hasCrack = cracks > 0.7;

                    const colorIndex = Math.floor(iceHeight * iceColors.length);
                    let baseColor = iceColors[Math.min(colorIndex, iceColors.length - 1)];

                    // Darken cracks
                    if (hasCrack) {
                        baseColor = { r: baseColor.r * 0.5, g: baseColor.g * 0.5, b: baseColor.b * 0.5 };
                    }

                    const brightness = 0.4 + lightDot * 0.6;
                    const edgeFactor = 1 - Math.pow(distance / radius, 2);
                    const finalBrightness = brightness * (0.6 + edgeFactor * 0.4);

                    const idx = (y * size + x) * 4;
                    data[idx] = baseColor.r * finalBrightness;
                    data[idx + 1] = baseColor.g * finalBrightness;
                    data[idx + 2] = baseColor.b * finalBrightness;
                    data[idx + 3] = 255;
                } else {
                    const idx = (y * size + x) * 4;
                    data[idx + 3] = 0;
                }
            }
        }

        ctx.putImageData(imageData, 0, 0);
        return canvas;
    }

    /**
     * Render lava planet with molten surface
     */
    renderLavaPlanet(size, seed) {
        const canvas = document.createElement('canvas');
        const radius = size / 2;
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');

        const noise = this.generateNoise(seed, 6);
        const lavaFlow = this.generateNoise(seed + 300, 4);
        const imageData = ctx.createImageData(size, size);
        const data = imageData.data;

        // Lava colors
        const lavaColors = [
            { r: 255, g: 100, b: 0 },   // Bright lava
            { r: 220, g: 60, b: 0 },    // Hot lava
            { r: 180, g: 40, b: 0 },    // Cooling lava
            { r: 100, g: 20, b: 0 },    // Dark crust
            { r: 60, g: 10, b: 0 }      // Solid crust
        ];

        for (let y = 0; y < size; y++) {
            for (let x = 0; x < size; x++) {
                const dx = x - radius;
                const dy = y - radius;
                const distance = Math.sqrt(dx * dx + dy * dy);

                if (distance <= radius) {
                    const z = Math.sqrt(radius * radius - dx * dx - dy * dy);
                    const nx = dx / radius;
                    const ny = dy / radius;
                    const nz = z / radius;

                    const lightX = -0.5, lightY = -0.5, lightZ = 0.7;
                    const lightDot = Math.max(0, nx * lightX + ny * lightY + nz * lightZ);

                    // Lava flow pattern
                    const flow = lavaFlow(x / size * 6, y / size * 6);
                    const heat = noise(x / size * 12, y / size * 12);
                    const combined = flow * 0.6 + heat * 0.4;

                    const colorIndex = Math.floor(combined * lavaColors.length);
                    const baseColor = lavaColors[Math.min(colorIndex, lavaColors.length - 1)];

                    // Add glow to hot areas
                    const isHot = combined > 0.6;
                    const glow = isHot ? (combined - 0.6) * 2 : 0;

                    const brightness = 0.5 + lightDot * 0.5 + glow * 0.3;
                    const edgeFactor = 1 - Math.pow(distance / radius, 2);
                    const finalBrightness = brightness * (0.5 + edgeFactor * 0.5);

                    const idx = (y * size + x) * 4;
                    data[idx] = Math.min(255, baseColor.r * finalBrightness);
                    data[idx + 1] = Math.min(255, baseColor.g * finalBrightness);
                    data[idx + 2] = Math.min(255, baseColor.b * finalBrightness);
                    data[idx + 3] = 255;
                } else {
                    const idx = (y * size + x) * 4;
                    data[idx + 3] = 0;
                }
            }
        }

        ctx.putImageData(imageData, 0, 0);
        return canvas;
    }

    /**
     * Render star with corona and surface detail
     */
    renderStar(size, type, seed) {
        const canvas = document.createElement('canvas');
        const radius = size / 2;
        canvas.width = size * 1.5; // Extra space for corona
        canvas.height = size * 1.5;
        const ctx = canvas.getContext('2d');
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;

        const noise = this.generateNoise(seed, 5);
        const flareNoise = this.generateNoise(seed + 400, 3);

        // Star colors by type
        const starColors = {
            yellow: { core: { r: 255, g: 255, b: 200 }, surface: { r: 255, g: 220, b: 100 } },
            red: { core: { r: 255, g: 150, b: 100 }, surface: { r: 255, g: 100, b: 50 } },
            blue: { core: { r: 200, g: 220, b: 255 }, surface: { r: 150, g: 180, b: 255 } },
            white: { core: { r: 255, g: 255, b: 255 }, surface: { r: 240, g: 240, b: 255 } }
        };

        const colors = starColors[type] || starColors.yellow;

        // Draw corona (glow)
        const coronaGradient = ctx.createRadialGradient(centerX, centerY, radius * 0.8, centerX, centerY, radius * 1.3);
        coronaGradient.addColorStop(0, `rgba(${colors.surface.r}, ${colors.surface.g}, ${colors.surface.b}, 0.3)`);
        coronaGradient.addColorStop(0.5, `rgba(${colors.surface.r}, ${colors.surface.g}, ${colors.surface.b}, 0.1)`);
        coronaGradient.addColorStop(1, `rgba(${colors.surface.r}, ${colors.surface.g}, ${colors.surface.b}, 0)`);
        ctx.fillStyle = coronaGradient;
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Draw star surface with detail
        const imageData = ctx.createImageData(canvas.width, canvas.height);
        const data = imageData.data;

        for (let y = 0; y < canvas.height; y++) {
            for (let x = 0; x < canvas.width; x++) {
                const dx = x - centerX;
                const dy = y - centerY;
                const distance = Math.sqrt(dx * dx + dy * dy);

                if (distance <= radius) {
                    // Surface turbulence
                    const turbulence = noise(x / size * 8, y / size * 8);
                    const detail = noise(x / size * 16, y / size * 16);
                    const combined = turbulence * 0.7 + detail * 0.3;

                    // Blend between core and surface color
                    const distFactor = distance / radius;
                    const t = distFactor * (0.8 + combined * 0.4);

                    const r = colors.core.r * (1 - t) + colors.surface.r * t;
                    const g = colors.core.g * (1 - t) + colors.surface.g * t;
                    const b = colors.core.b * (1 - t) + colors.surface.b * t;

                    // Add brightness variation
                    const brightness = 0.8 + combined * 0.4;

                    const idx = (y * canvas.width + x) * 4;
                    data[idx] = Math.min(255, r * brightness);
                    data[idx + 1] = Math.min(255, g * brightness);
                    data[idx + 2] = Math.min(255, b * brightness);
                    data[idx + 3] = 255;
                }
            }
        }

        ctx.putImageData(imageData, 0, 0);

        // Add solar flares
        for (let i = 0; i < 8; i++) {
            const angle = (i / 8) * Math.PI * 2;
            const flareLength = radius * (0.3 + flareNoise(i, 0) * 0.2);
            const flareX = centerX + Math.cos(angle) * radius;
            const flareY = centerY + Math.sin(angle) * radius;
            const flareEndX = centerX + Math.cos(angle) * (radius + flareLength);
            const flareEndY = centerY + Math.sin(angle) * (radius + flareLength);

            const flareGradient = ctx.createLinearGradient(flareX, flareY, flareEndX, flareEndY);
            flareGradient.addColorStop(0, `rgba(${colors.surface.r}, ${colors.surface.g}, ${colors.surface.b}, 0.6)`);
            flareGradient.addColorStop(1, `rgba(${colors.surface.r}, ${colors.surface.g}, ${colors.surface.b}, 0)`);

            ctx.strokeStyle = flareGradient;
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(flareX, flareY);
            ctx.lineTo(flareEndX, flareEndY);
            ctx.stroke();
        }

        return canvas;
    }

    /**
     * Get or create cached celestial body
     */
    getCelestialBody(type, size, seed) {
        const key = `${type}_${size}_${seed}`;
        if (this.cache.has(key)) return this.cache.get(key);

        let canvas;
        switch (type) {
            case 'rocky':
                canvas = this.renderRockyPlanet(size, null, seed);
                break;
            case 'earthlike':
                canvas = this.renderEarthlikePlanet(size, seed);
                break;
            case 'gasGiant':
                canvas = this.renderGasGiant(size, seed);
                break;
            case 'ice':
                canvas = this.renderIcePlanet(size, seed);
                break;
            case 'lava':
                canvas = this.renderLavaPlanet(size, seed);
                break;
            case 'star':
                canvas = this.renderStar(size, 'yellow', seed);
                break;
            default:
                canvas = this.renderRockyPlanet(size, null, seed);
        }

        this.cache.set(key, canvas);
        return canvas;
    }
}

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = CelestialRenderer;
}
