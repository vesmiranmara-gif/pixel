/**
 * PixelVerse - Enhanced Station Renderer
 * Isometric, highly detailed pixel art space stations
 */

class StationRenderer {
    constructor() {
        this.cache = new Map();
    }

    /**
     * Render small trading outpost
     */
    renderTradingOutpost(size = 80) {
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');

        const centerX = size / 2;
        const centerY = size / 2;

        const colors = {
            darkMetal: '#2a2a2a',
            metal: '#3a3a3a',
            lightMetal: '#4a4a4a',
            highlight: '#5a5a5a',
            window: '#4a6a8a',
            windowGlow: '#6a8aaa',
            solar: '#1a2a4a',
            solarHighlight: '#2a4a6a',
            antenna: '#5a5a5a'
        };

        ctx.save();
        ctx.translate(centerX, centerY);

        // Central hub (isometric cube)
        this.drawIsometricCube(ctx, 0, 0, 20, 20, 20, colors);

        // Docking arms (4 directions)
        // Top arm
        this.drawIsometricBox(ctx, 0, -25, 6, 15, 6, colors.metal, colors.darkMetal);
        
        // Right arm
        this.drawIsometricBox(ctx, 25, 0, 15, 6, 6, colors.lightMetal, colors.metal);
        
        // Bottom arm
        this.drawIsometricBox(ctx, 0, 25, 6, 15, 6, colors.metal, colors.darkMetal);
        
        // Left arm
        this.drawIsometricBox(ctx, -25, 0, 15, 6, 6, colors.darkMetal, colors.metal);

        // Windows on central hub
        ctx.fillStyle = colors.window;
        ctx.fillRect(-8, -6, 3, 3);
        ctx.fillRect(-2, -6, 3, 3);
        ctx.fillRect(4, -6, 3, 3);
        ctx.fillRect(-8, 0, 3, 3);
        ctx.fillRect(4, 0, 3, 3);

        // Window glow
        ctx.fillStyle = colors.windowGlow;
        ctx.fillRect(-7, -5, 1, 1);
        ctx.fillRect(-1, -5, 1, 1);
        ctx.fillRect(5, -5, 1, 1);

        // Solar panels
        this.drawSolarPanel(ctx, -15, -15, 8, 12, colors);
        this.drawSolarPanel(ctx, 15, -15, 8, 12, colors);
        this.drawSolarPanel(ctx, -15, 15, 8, 12, colors);
        this.drawSolarPanel(ctx, 15, 15, 8, 12, colors);

        // Communication antenna
        ctx.strokeStyle = colors.antenna;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(0, -10);
        ctx.lineTo(0, -30);
        ctx.stroke();

        // Antenna dish
        ctx.fillStyle = colors.metal;
        ctx.fillRect(-3, -32, 6, 4);

        // Add pixel details
        this.addPixelDetails(ctx, size);

        ctx.restore();
        return canvas;
    }

    /**
     * Render large military station
     */
    renderMilitaryStation(size = 120) {
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');

        const centerX = size / 2;
        const centerY = size / 2;

        const colors = {
            darkMetal: '#2a2a2a',
            metal: '#3a3a3a',
            lightMetal: '#4a4a4a',
            armor: '#3a3a4a',
            window: '#4a3a3a',
            weapon: '#4a2a2a',
            highlight: '#5a5a5a'
        };

        ctx.save();
        ctx.translate(centerX, centerY);

        // Central command tower
        this.drawIsometricCube(ctx, 0, 0, 25, 35, 25, colors);

        // Weapon platforms (4 corners)
        this.drawWeaponPlatform(ctx, -30, -30, colors);
        this.drawWeaponPlatform(ctx, 30, -30, colors);
        this.drawWeaponPlatform(ctx, -30, 30, colors);
        this.drawWeaponPlatform(ctx, 30, 30, colors);

        // Connecting struts
        ctx.strokeStyle = colors.metal;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(-15, -15);
        ctx.lineTo(-30, -30);
        ctx.moveTo(15, -15);
        ctx.lineTo(30, -30);
        ctx.moveTo(-15, 15);
        ctx.lineTo(-30, 30);
        ctx.moveTo(15, 15);
        ctx.lineTo(30, 30);
        ctx.stroke();

        // Windows on command tower
        for (let y = -12; y <= 12; y += 6) {
            for (let x = -8; x <= 8; x += 6) {
                ctx.fillStyle = colors.window;
                ctx.fillRect(x, y, 2, 2);
            }
        }

        // Radar dish on top
        ctx.fillStyle = colors.lightMetal;
        ctx.fillRect(-8, -20, 16, 2);
        ctx.fillRect(-6, -22, 12, 2);

        // Add pixel details
        this.addPixelDetails(ctx, size);

        ctx.restore();
        return canvas;
    }

    /**
     * Render research station
     */
    renderResearchStation(size = 100) {
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');

        const centerX = size / 2;
        const centerY = size / 2;

        const colors = {
            darkMetal: '#2a2a3a',
            metal: '#3a3a4a',
            lightMetal: '#4a4a5a',
            window: '#4a6a8a',
            windowGlow: '#6a8aaa',
            lab: '#3a4a5a',
            highlight: '#5a5a6a'
        };

        ctx.save();
        ctx.translate(centerX, centerY);

        // Central ring structure
        ctx.strokeStyle = colors.metal;
        ctx.lineWidth = 8;
        ctx.beginPath();
        ctx.arc(0, 0, 30, 0, Math.PI * 2);
        ctx.stroke();

        // Inner ring
        ctx.lineWidth = 4;
        ctx.strokeStyle = colors.lightMetal;
        ctx.beginPath();
        ctx.arc(0, 0, 25, 0, Math.PI * 2);
        ctx.stroke();

        // Laboratory modules (6 around the ring)
        for (let i = 0; i < 6; i++) {
            const angle = (i / 6) * Math.PI * 2;
            const x = Math.cos(angle) * 30;
            const y = Math.sin(angle) * 30;
            this.drawLabModule(ctx, x, y, colors);
        }

        // Central hub
        this.drawIsometricCube(ctx, 0, 0, 12, 12, 12, colors);

        // Observation dome
        ctx.fillStyle = colors.window;
        ctx.beginPath();
        ctx.arc(0, -6, 6, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = colors.windowGlow;
        ctx.beginPath();
        ctx.arc(-2, -8, 2, 0, Math.PI * 2);
        ctx.fill();

        // Add pixel details
        this.addPixelDetails(ctx, size);

        ctx.restore();
        return canvas;
    }

    /**
     * Helper: Draw isometric cube
     */
    drawIsometricCube(ctx, x, y, width, height, depth, colors) {
        // Top face
        ctx.fillStyle = colors.lightMetal || colors.metal;
        ctx.beginPath();
        ctx.moveTo(x, y - height);
        ctx.lineTo(x + width / 2, y - height + depth / 2);
        ctx.lineTo(x, y - height + depth);
        ctx.lineTo(x - width / 2, y - height + depth / 2);
        ctx.closePath();
        ctx.fill();

        // Left face
        ctx.fillStyle = colors.darkMetal || colors.metal;
        ctx.beginPath();
        ctx.moveTo(x - width / 2, y - height + depth / 2);
        ctx.lineTo(x, y - height + depth);
        ctx.lineTo(x, y + depth);
        ctx.lineTo(x - width / 2, y + depth / 2);
        ctx.closePath();
        ctx.fill();

        // Right face
        ctx.fillStyle = colors.metal;
        ctx.beginPath();
        ctx.moveTo(x + width / 2, y - height + depth / 2);
        ctx.lineTo(x, y - height + depth);
        ctx.lineTo(x, y + depth);
        ctx.lineTo(x + width / 2, y + depth / 2);
        ctx.closePath();
        ctx.fill();
    }

    /**
     * Helper: Draw isometric box
     */
    drawIsometricBox(ctx, x, y, width, height, depth, colorMain, colorShade) {
        ctx.fillStyle = colorMain;
        ctx.fillRect(x - width / 2, y - height / 2, width, height);
        
        ctx.fillStyle = colorShade;
        ctx.fillRect(x - width / 2, y - height / 2, width / 3, height);
    }

    /**
     * Helper: Draw solar panel
     */
    drawSolarPanel(ctx, x, y, width, height, colors) {
        // Panel frame
        ctx.strokeStyle = colors.metal;
        ctx.lineWidth = 1;
        ctx.strokeRect(x, y, width, height);

        // Solar cells
        ctx.fillStyle = colors.solar;
        ctx.fillRect(x + 1, y + 1, width - 2, height - 2);

        // Cell grid
        ctx.strokeStyle = colors.solarHighlight;
        ctx.lineWidth = 0.5;
        for (let i = 1; i < 3; i++) {
            ctx.beginPath();
            ctx.moveTo(x, y + (height / 3) * i);
            ctx.lineTo(x + width, y + (height / 3) * i);
            ctx.stroke();
        }
    }

    /**
     * Helper: Draw weapon platform
     */
    drawWeaponPlatform(ctx, x, y, colors) {
        // Platform base
        ctx.fillStyle = colors.armor;
        ctx.fillRect(x - 6, y - 6, 12, 12);

        // Weapon turret
        ctx.fillStyle = colors.weapon;
        ctx.fillRect(x - 3, y - 3, 6, 6);

        // Barrel
        ctx.fillStyle = colors.metal;
        ctx.fillRect(x - 1, y - 8, 2, 5);
    }

    /**
     * Helper: Draw lab module
     */
    drawLabModule(ctx, x, y, colors) {
        ctx.fillStyle = colors.lab;
        ctx.fillRect(x - 4, y - 4, 8, 8);

        ctx.fillStyle = colors.window;
        ctx.fillRect(x - 2, y - 2, 4, 4);
    }

    /**
     * Helper: Add pixel-level details
     */
    addPixelDetails(ctx, size) {
        const imageData = ctx.getImageData(0, 0, size, size);
        const data = imageData.data;

        for (let i = 0; i < data.length; i += 4) {
            if (data[i + 3] > 0) {
                const noise = (Math.random() - 0.5) * 8;
                data[i] = Math.max(0, Math.min(255, data[i] + noise));
                data[i + 1] = Math.max(0, Math.min(255, data[i + 1] + noise));
                data[i + 2] = Math.max(0, Math.min(255, data[i + 2] + noise));
            }
        }

        ctx.putImageData(imageData, 0, 0);
    }

    /**
     * Get or create cached station
     */
    getStation(type, size) {
        const key = `${type}_${size}`;
        if (this.cache.has(key)) return this.cache.get(key);

        let canvas;
        switch (type) {
            case 'trading':
                canvas = this.renderTradingOutpost(size);
                break;
            case 'military':
                canvas = this.renderMilitaryStation(size);
                break;
            case 'research':
                canvas = this.renderResearchStation(size);
                break;
            default:
                canvas = this.renderTradingOutpost(size);
        }

        this.cache.set(key, canvas);
        return canvas;
    }
}

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = StationRenderer;
}

