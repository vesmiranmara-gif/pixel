/**
 * PixelVerse - Terminal Interface
 * Retro CRT computer terminal with thick chassis, mechanical keyboard, and buttons
 * Based on 1970s-80s computer terminal aesthetic
 */

class TerminalInterface {
    constructor(renderer) {
        this.renderer = renderer;

        // Terminal state
        this.visible = false;
        this.messages = [];
        this.maxMessages = 20;
        this.currentInput = '';
        this.cursorBlink = 0;
        this.scrollOffset = 0;

        // Terminal dimensions (centered on screen)
        this.width = 800;
        this.height = 600;
        this.x = (renderer.baseWidth - this.width) / 2;
        this.y = (renderer.baseHeight - this.height) / 2;

        // CRT monitor area (inside thick chassis)
        this.screenPadding = 40; // Thick frame
        this.screenX = this.x + this.screenPadding;
        this.screenY = this.y + this.screenPadding;
        this.screenWidth = this.width - (this.screenPadding * 2);
        this.screenHeight = this.height - (this.screenPadding * 2) - 80; // Space for keyboard

        // Keyboard area
        this.keyboardY = this.screenY + this.screenHeight + 10;
        this.keyboardHeight = 60;

        // Text rendering
        this.fontSize = 10;
        this.lineHeight = 14;
        this.textPadding = 10;

        // Colors
        this.chassisColor = RETRO_PALETTE.hullPrimary;
        this.screenColor = RETRO_PALETTE.voidDeep;
        this.textColor = RETRO_PALETTE.vintageAmber; // Warm amber CRT glow
        this.highlightColor = RETRO_PALETTE.warningYellow;

        // Add welcome message
        this.addMessage('SYSTEM TERMINAL v2.1');
        this.addMessage('Type "help" for commands');
        this.addMessage('');
    }

    /**
     * Toggle terminal visibility
     */
    toggle() {
        this.visible = !this.visible;
    }

    /**
     * Show terminal
     */
    show() {
        this.visible = true;
    }

    /**
     * Hide terminal
     */
    hide() {
        this.visible = false;
    }

    /**
     * Add message to terminal
     */
    addMessage(text, color = null) {
        this.messages.push({
            text: text,
            color: color || this.textColor,
            timestamp: Date.now()
        });

        // Limit message history
        if (this.messages.length > this.maxMessages) {
            this.messages.shift();
        }

        // Auto-scroll to bottom
        this.scrollOffset = Math.max(0, this.messages.length - this.getVisibleLines());
    }

    /**
     * Get number of visible text lines
     */
    getVisibleLines() {
        return Math.floor((this.screenHeight - this.textPadding * 2) / this.lineHeight);
    }

    /**
     * Handle keyboard input
     */
    handleInput(key) {
        if (!this.visible) return;

        if (key === 'Enter') {
            this.executeCommand(this.currentInput);
            this.currentInput = '';
        } else if (key === 'Backspace') {
            this.currentInput = this.currentInput.slice(0, -1);
        } else if (key.length === 1) {
            this.currentInput += key;
        }
    }

    /**
     * Execute terminal command
     */
    executeCommand(command) {
        if (!command.trim()) return;

        // Echo command
        this.addMessage('> ' + command, this.highlightColor);

        const cmd = command.toLowerCase().trim();

        switch (cmd) {
            case 'help':
                this.addMessage('Available commands:');
                this.addMessage('  help    - Show this help');
                this.addMessage('  clear   - Clear terminal');
                this.addMessage('  status  - Show ship status');
                this.addMessage('  scan    - Scan surroundings');
                break;

            case 'clear':
                this.messages = [];
                break;

            case 'status':
                this.addMessage('Ship Status: OPERATIONAL');
                this.addMessage('Hull: 100%');
                this.addMessage('Shields: 50%');
                this.addMessage('Power: NOMINAL');
                break;

            case 'scan':
                this.addMessage('Scanning...');
                this.addMessage('Detected: 15 asteroids');
                this.addMessage('Detected: 1 planet');
                this.addMessage('Detected: 1 station');
                break;

            default:
                this.addMessage('Unknown command: ' + command);
                this.addMessage('Type "help" for available commands');
        }
    }

    /**
     * Update terminal (animations, cursor blink)
     */
    update(deltaTime) {
        if (!this.visible) return;

        this.cursorBlink += deltaTime;
        if (this.cursorBlink > 1.0) {
            this.cursorBlink = 0;
        }
    }

    /**
     * Render terminal
     */
    render() {
        if (!this.visible) return;

        const ctx = this.renderer.context;

        // Draw thick chassis (outer frame)
        this.drawChassis(ctx);

        // Draw CRT screen
        this.drawScreen(ctx);

        // Draw mechanical keyboard
        this.drawKeyboard(ctx);

        // Draw control buttons
        this.drawButtons(ctx);

        // Draw screen content
        this.drawContent(ctx);
    }

    /**
     * Draw thick chassis frame
     */
    drawChassis(ctx) {
        // Outer chassis (thick, industrial)
        ctx.fillStyle = this.chassisColor;
        ctx.fillRect(this.x, this.y, this.width, this.height);

        // Shadow for depth
        ctx.fillStyle = RETRO_PALETTE.hullShadow;
        ctx.fillRect(this.x + 2, this.y + 2, this.width, this.height);

        // Highlight edge (top-left)
        ctx.strokeStyle = RETRO_PALETTE.hullHighlight;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(this.x, this.y + this.height);
        ctx.lineTo(this.x, this.y);
        ctx.lineTo(this.x + this.width, this.y);
        ctx.stroke();

        // Panel lines on chassis
        for (let i = 1; i < 4; i++) {
            const y = this.y + (i * this.height / 4);
            ctx.strokeStyle = RETRO_PALETTE.hullShadow;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(this.x + 10, y);
            ctx.lineTo(this.x + this.width - 10, y);
            ctx.stroke();
        }

        // Screws in corners (industrial detail)
        const screwPositions = [
            [this.x + 10, this.y + 10],
            [this.x + this.width - 10, this.y + 10],
            [this.x + 10, this.y + this.height - 10],
            [this.x + this.width - 10, this.y + this.height - 10]
        ];

        for (const [sx, sy] of screwPositions) {
            ctx.fillStyle = RETRO_PALETTE.darkGray;
            ctx.fillRect(sx - 2, sy - 2, 4, 4);
            ctx.fillStyle = RETRO_PALETTE.voidBlack;
            ctx.fillRect(sx - 1, sy - 1, 2, 2);
        }
    }

    /**
     * Draw CRT screen area
     */
    drawScreen(ctx) {
        // Screen bezel (inner frame)
        ctx.fillStyle = RETRO_PALETTE.darkGray;
        ctx.fillRect(this.screenX - 4, this.screenY - 4, this.screenWidth + 8, this.screenHeight + 8);

        // CRT screen (dark background)
        ctx.fillStyle = this.screenColor;
        ctx.fillRect(this.screenX, this.screenY, this.screenWidth, this.screenHeight);

        // CRT glow effect (subtle)
        ctx.globalAlpha = 0.1;
        ctx.fillStyle = this.textColor;
        ctx.fillRect(this.screenX, this.screenY, this.screenWidth, this.screenHeight);
        ctx.globalAlpha = 1.0;

        // Scanlines
        ctx.globalAlpha = 0.15;
        ctx.fillStyle = RETRO_PALETTE.voidBlack;
        for (let y = this.screenY; y < this.screenY + this.screenHeight; y += 2) {
            ctx.fillRect(this.screenX, y, this.screenWidth, 1);
        }
        ctx.globalAlpha = 1.0;
    }

    /**
     * Draw mechanical keyboard
     */
    drawKeyboard(ctx) {
        const kbX = this.screenX;
        const kbY = this.keyboardY;
        const kbWidth = this.screenWidth;
        const kbHeight = this.keyboardHeight;

        // Keyboard base
        ctx.fillStyle = RETRO_PALETTE.hullSecondary;
        ctx.fillRect(kbX, kbY, kbWidth, kbHeight);

        // Shadow
        ctx.fillStyle = RETRO_PALETTE.hullShadow;
        ctx.fillRect(kbX + 1, kbY + 1, kbWidth, kbHeight);

        // Draw key rows (simplified)
        const keySize = 12;
        const keySpacing = 2;
        const rows = 4;
        const keysPerRow = Math.floor(kbWidth / (keySize + keySpacing));

        for (let row = 0; row < rows; row++) {
            for (let col = 0; col < keysPerRow; col++) {
                const keyX = kbX + 10 + col * (keySize + keySpacing);
                const keyY = kbY + 8 + row * (keySize + keySpacing);

                // Key cap
                ctx.fillStyle = RETRO_PALETTE.mediumGray;
                ctx.fillRect(keyX, keyY, keySize, keySize);

                // Key highlight
                ctx.fillStyle = RETRO_PALETTE.lightGray;
                ctx.fillRect(keyX, keyY, keySize, 1);
                ctx.fillRect(keyX, keyY, 1, keySize);
            }
        }
    }

    /**
     * Draw control buttons
     */
    drawButtons(ctx) {
        const buttonY = this.y + 15;
        const buttonSize = 16;
        const buttonSpacing = 8;

        // Power button (red)
        ctx.fillStyle = RETRO_PALETTE.alertRed;
        ctx.fillRect(this.x + this.width - 30, buttonY, buttonSize, buttonSize);
        ctx.fillStyle = RETRO_PALETTE.bloodRed;
        ctx.fillRect(this.x + this.width - 30 + 1, buttonY + 1, buttonSize - 2, buttonSize - 2);

        // Status LEDs
        const ledColors = [RETRO_PALETTE.statusBlue, RETRO_PALETTE.vintageAmber, RETRO_PALETTE.alienGreen];
        for (let i = 0; i < 3; i++) {
            const ledX = this.x + this.width - 80 - (i * (buttonSize + buttonSpacing));
            ctx.fillStyle = RETRO_PALETTE.darkGray;
            ctx.fillRect(ledX, buttonY, buttonSize, buttonSize);
            ctx.fillStyle = ledColors[i];
            ctx.fillRect(ledX + 4, buttonY + 4, 8, 8);
        }
    }

    /**
     * Draw screen content (text)
     */
    drawContent(ctx) {
        ctx.font = `${this.fontSize}px "DigitalDisco", "Courier New", monospace`;
        ctx.textBaseline = 'top';

        const visibleLines = this.getVisibleLines();
        const startIndex = Math.max(0, this.messages.length - visibleLines);

        let y = this.screenY + this.textPadding;

        for (let i = startIndex; i < this.messages.length; i++) {
            const message = this.messages[i];
            ctx.fillStyle = message.color;
            ctx.fillText(message.text, this.screenX + this.textPadding, y);
            y += this.lineHeight;
        }

        // Draw input line
        ctx.fillStyle = this.highlightColor;
        ctx.fillText('> ' + this.currentInput, this.screenX + this.textPadding, y);

        // Draw blinking cursor
        if (this.cursorBlink < 0.5) {
            const cursorX = this.screenX + this.textPadding + ctx.measureText('> ' + this.currentInput).width;
            ctx.fillRect(cursorX, y, 8, this.fontSize);
        }
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = TerminalInterface;
}

