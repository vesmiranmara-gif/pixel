/**
 * PixelVerse - Cockpit CRT Monitors
 * Square CRT monitors with deep recess, scanlines, and vintage amber displays
 */

class CockpitMonitors {
    constructor(ctx, colors, drawing) {
        this.ctx = ctx;
        this.colors = colors;
        this.drawing = drawing;
    }

    /**
     * Draw square CRT monitor with REAL 3D depth
     */
    drawCRTHousing(x, y, size, title) {
        const ctx = this.ctx;
        const depth = 25; // VERY DEEP!

        // EXTREME shadow layers (40 layers!)
        for (let i = 40; i >= 0; i--) {
            const ratio = i / 40;
            const alpha = 0.1 + ratio * 0.85;
            const offset = ratio * depth * 2;

            ctx.save();
            ctx.globalAlpha = alpha;
            ctx.fillStyle = '#000000';
            ctx.fillRect(
                x - offset - offset * 0.3,
                y - offset - offset * 0.3,
                size + offset * 2 + offset * 0.6,
                size + offset * 2 + offset * 0.6
            );
            ctx.restore();
        }

        // Draw 3D monitor box with real depth
        this.draw3DMonitorBox(x, y, size, depth);
        
        // Outer housing with COMPLEX gradient (MORE COLORS)
        const housingGradient = ctx.createLinearGradient(x - depth, y - depth, x + size + depth, y + size + depth);
        housingGradient.addColorStop(0, this.colors.metalBright);
        housingGradient.addColorStop(0.15, this.colors.metalLighter);
        housingGradient.addColorStop(0.3, this.colors.metalLight);
        housingGradient.addColorStop(0.5, this.colors.metalMid);
        housingGradient.addColorStop(0.7, this.colors.metalDark);
        housingGradient.addColorStop(0.85, this.colors.metalDarker);
        housingGradient.addColorStop(1, this.colors.metalDarkest);
        ctx.fillStyle = housingGradient;
        ctx.fillRect(x - depth, y - depth, size + depth * 2, size + depth * 2);
        
        // MULTIPLE housing highlights (top-left) for MORE DEPTH
        ctx.fillStyle = this.colors.highlightBrightest;
        ctx.fillRect(x - depth, y - depth, size + depth * 2, 3);
        ctx.fillRect(x - depth, y - depth, 3, size + depth * 2);

        ctx.fillStyle = this.colors.highlightBright;
        ctx.fillRect(x - depth + 3, y - depth + 3, size + depth * 2 - 6, 2);
        ctx.fillRect(x - depth + 3, y - depth + 3, 2, size + depth * 2 - 6);

        ctx.fillStyle = this.colors.highlightMid;
        ctx.fillRect(x - depth + 5, y - depth + 5, size + depth * 2 - 10, 1);
        ctx.fillRect(x - depth + 5, y - depth + 5, 1, size + depth * 2 - 10);

        // MULTIPLE housing shadows (bottom-right) for MORE DEPTH
        ctx.fillStyle = this.colors.shadowDeepest;
        ctx.fillRect(x - depth, y + size + depth - 3, size + depth * 2, 3);
        ctx.fillRect(x + size + depth - 3, y - depth, 3, size + depth * 2);

        ctx.fillStyle = this.colors.shadowDeep;
        ctx.fillRect(x - depth, y + size + depth - 6, size + depth * 2, 2);
        ctx.fillRect(x + size + depth - 6, y - depth, 2, size + depth * 2);

        ctx.fillStyle = this.colors.shadowMid;
        ctx.fillRect(x - depth, y + size + depth - 8, size + depth * 2, 1);
        ctx.fillRect(x + size + depth - 8, y - depth, 1, size + depth * 2);
        
        // Deep screen recess (multiple layers)
        ctx.fillStyle = this.colors.shadowDeepest;
        ctx.fillRect(x, y, size, size);
        
        ctx.fillStyle = this.colors.shadowDeeper;
        ctx.fillRect(x + 2, y + 2, size - 4, size - 4);
        
        ctx.fillStyle = this.colors.shadowDeep;
        ctx.fillRect(x + 4, y + 4, size - 8, size - 8);
        
        // Screen background with radial gradient (vintage amber CRT)
        const screenGradient = ctx.createRadialGradient(x + size/2, y + size/2, 0, x + size/2, y + size/2, size/2);
        screenGradient.addColorStop(0, this.colors.screenLight);
        screenGradient.addColorStop(0.5, this.colors.screenMid);
        screenGradient.addColorStop(0.8, this.colors.screenDark);
        screenGradient.addColorStop(1, this.colors.screenOff);
        ctx.fillStyle = screenGradient;
        ctx.fillRect(x + 6, y + 6, size - 12, size - 12);
        
        // Screen glow overlay
        ctx.save();
        ctx.globalAlpha = 0.3;
        ctx.fillStyle = this.colors.screenGlow;
        ctx.fillRect(x + 6, y + 6, size - 12, size - 12);
        ctx.restore();
        
        // Title bar (raised panel)
        const titleGradient = ctx.createLinearGradient(x + 6, y + 6, x + 6, y + 22);
        titleGradient.addColorStop(0, this.colors.metalLight);
        titleGradient.addColorStop(0.5, this.colors.metalMid);
        titleGradient.addColorStop(1, this.colors.metalDark);
        ctx.fillStyle = titleGradient;
        ctx.fillRect(x + 6, y + 6, size - 12, 16);
        
        // Title bar highlight
        ctx.fillStyle = this.colors.highlightBright;
        ctx.fillRect(x + 6, y + 6, size - 12, 1);
        
        // Title text (LARGE and BOLD)
        ctx.font = 'bold 10px "Courier New", monospace';
        ctx.fillStyle = this.colors.textBright;
        ctx.fillText(title, x + 10, y + 17);
        
        // Scanlines (subtle, every 3 pixels)
        ctx.save();
        ctx.globalAlpha = 0.12;
        for (let sy = y + 6; sy < y + size - 6; sy += 3) {
            ctx.fillStyle = this.colors.shadowLight;
            ctx.fillRect(x + 6, sy, size - 12, 1);
        }
        ctx.restore();
        
        // Screen curvature vignette
        const vignetteGradient = ctx.createRadialGradient(x + size/2, y + size/2, size/4, x + size/2, y + size/2, size/2);
        vignetteGradient.addColorStop(0, 'rgba(0, 0, 0, 0)');
        vignetteGradient.addColorStop(0.7, 'rgba(0, 0, 0, 0.1)');
        vignetteGradient.addColorStop(1, 'rgba(0, 0, 0, 0.5)');
        ctx.fillStyle = vignetteGradient;
        ctx.fillRect(x + 6, y + 6, size - 12, size - 12);
    }

    /**
     * Draw Monitor 1 - Ship Status
     */
    drawMonitor1(x, y, size, playerShip, shipSystems) {
        this.drawCRTHousing(x, y, size, 'SHIP STATUS');
        
        const contentX = x + 14;
        const contentY = y + 30;
        const barWidth = size - 28;
        
        if (shipSystems && shipSystems.systems) {
            // Hull - LARGE text and bars
            this.drawing.drawLargeText(contentX, contentY, 'HULL', this.colors.textBright, 11);
            const hull = shipSystems.systems.hull;
            if (hull) {
                const percent = (hull.current / hull.max) * 100;
                this.drawing.drawBar(contentX, contentY + 4, barWidth, 12, percent);
                this.drawing.drawLargeText(contentX + barWidth - 35, contentY + 14, `${percent.toFixed(0)}%`, this.colors.indicatorAmber, 10);
            }
            
            // Shields
            this.drawing.drawLargeText(contentX, contentY + 22, 'SHIELDS', this.colors.textBright, 11);
            const shields = shipSystems.systems.shields;
            if (shields) {
                const percent = (shields.current / shields.max) * 100;
                this.drawing.drawBar(contentX, contentY + 26, barWidth, 12, percent);
                this.drawing.drawLargeText(contentX + barWidth - 35, contentY + 36, `${percent.toFixed(0)}%`, this.colors.indicatorAmber, 10);
            }
            
            // Power
            this.drawing.drawLargeText(contentX, contentY + 44, 'POWER', this.colors.textBright, 11);
            const power = shipSystems.systems.power;
            if (power) {
                const percent = (power.current / power.max) * 100;
                this.drawing.drawBar(contentX, contentY + 48, barWidth, 12, percent);
                this.drawing.drawLargeText(contentX + barWidth - 35, contentY + 58, `${percent.toFixed(0)}%`, this.colors.indicatorAmber, 10);
            }
            
            // Weapons
            this.drawing.drawLargeText(contentX, contentY + 66, 'WEAPONS', this.colors.textBright, 11);
            const weapons = shipSystems.systems.weapons;
            if (weapons) {
                const percent = (weapons.current / weapons.max) * 100;
                this.drawing.drawBar(contentX, contentY + 70, barWidth, 12, percent);
                this.drawing.drawLargeText(contentX + barWidth - 35, contentY + 80, `${percent.toFixed(0)}%`, this.colors.indicatorAmber, 10);
            }
        }
    }

    /**
     * Draw Monitor 2 - Navigation/Radar
     */
    drawMonitor2(x, y, size, playerShip, time) {
        this.drawCRTHousing(x, y, size, 'NAVIGATION');
        
        const cx = x + size / 2;
        const cy = y + size / 2 + 8;
        const radius = 40; // LARGER radar
        
        const ctx = this.ctx;
        
        // Radar grid (THICKER lines)
        ctx.strokeStyle = this.colors.indicatorAmber;
        ctx.lineWidth = 2;
        
        // Outer circle
        ctx.beginPath();
        ctx.arc(cx, cy, radius, 0, Math.PI * 2);
        ctx.stroke();
        
        // Inner circles
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(cx, cy, radius * 0.66, 0, Math.PI * 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(cx, cy, radius * 0.33, 0, Math.PI * 2);
        ctx.stroke();
        
        // Crosshairs (THICKER)
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(cx - radius, cy);
        ctx.lineTo(cx + radius, cy);
        ctx.moveTo(cx, cy - radius);
        ctx.lineTo(cx, cy + radius);
        ctx.stroke();
        
        // Diagonal lines
        const diag = radius * 0.707;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(cx - diag, cy - diag);
        ctx.lineTo(cx + diag, cy + diag);
        ctx.moveTo(cx - diag, cy + diag);
        ctx.lineTo(cx + diag, cy - diag);
        ctx.stroke();
        
        // Player ship (LARGER)
        ctx.fillStyle = this.colors.indicatorAmber;
        ctx.fillRect(cx - 4, cy - 4, 8, 8);
        
        // Sweep line (animated)
        const sweepAngle = (time * 2) % (Math.PI * 2);
        ctx.save();
        ctx.globalAlpha = 0.5;
        ctx.strokeStyle = this.colors.indicatorAmber;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(cx + Math.cos(sweepAngle) * radius, cy + Math.sin(sweepAngle) * radius);
        ctx.stroke();
        ctx.restore();
    }

    /**
     * Draw Monitor 3 - Tactical Display
     */
    drawMonitor3(x, y, size, playerShip) {
        this.drawCRTHousing(x, y, size, 'TACTICAL');
        
        const contentX = x + 14;
        const contentY = y + 30;
        
        if (playerShip) {
            const physics = playerShip.getComponent('physics');
            const transform = playerShip.getComponent('transform');
            
            if (physics && transform) {
                const speed = Math.sqrt(physics.vx ** 2 + physics.vy ** 2);
                const heading = ((transform.rotation * 180 / Math.PI) + 360) % 360;
                
                // Speed (VERY LARGE)
                this.drawing.drawLargeText(contentX, contentY, 'VELOCITY', this.colors.textBright, 11);
                this.drawing.drawLargeText(contentX, contentY + 16, `${speed.toFixed(1)}`, this.colors.indicatorAmber, 16);
                this.drawing.drawText(contentX + 50, contentY + 16, 'm/s', this.colors.textDim, 9);
                
                // Heading (VERY LARGE)
                this.drawing.drawLargeText(contentX, contentY + 36, 'HEADING', this.colors.textBright, 11);
                this.drawing.drawLargeText(contentX, contentY + 52, `${heading.toFixed(1)}°`, this.colors.indicatorAmber, 16);
                
                // Coordinates
                this.drawing.drawLargeText(contentX, contentY + 72, 'POSITION', this.colors.textBright, 11);
                this.drawing.drawText(contentX, contentY + 84, `X: ${transform.x.toFixed(0)}`, this.colors.indicatorAmber, 9);
                this.drawing.drawText(contentX, contentY + 94, `Y: ${transform.y.toFixed(0)}`, this.colors.indicatorAmber, 9);
            }
        }
    }

    /**
     * Draw Monitor 4 - Systems Status
     */
    drawMonitor4(x, y, size, shipSystems, time) {
        this.drawCRTHousing(x, y, size, 'SYSTEMS');

        const contentX = x + 14;
        const contentY = y + 30;

        // System indicators (LARGER)
        const systems = [
            { name: 'POWER', status: 'ONLINE' },
            { name: 'SHIELDS', status: 'ONLINE' },
            { name: 'WEAPONS', status: 'ONLINE' },
            { name: 'ENGINES', status: 'ONLINE' },
            { name: 'SENSORS', status: 'ONLINE' },
            { name: 'COMMS', status: 'ONLINE' }
        ];

        systems.forEach((sys, i) => {
            const sy = contentY + i * 16;

            // Blinking indicator light (LARGER)
            const on = Math.sin(time * 3 + i * 0.5) > -0.5;
            this.drawing.drawLight(contentX, sy + 4, this.colors.indicatorAmber, on, 5);

            // System name (LARGER)
            this.drawing.drawLargeText(contentX + 16, sy + 8, sys.name, this.colors.textBright, 10);

            // Status (LARGER)
            this.drawing.drawText(contentX + 70, sy + 8, sys.status, this.colors.indicatorAmber, 8);
        });
    }

    /**
     * Draw 3D monitor box with REAL depth
     */
    draw3DMonitorBox(x, y, size, depth) {
        const ctx = this.ctx;
        const d3d = 12; // 3D extrusion depth

        // Calculate 3D points
        const front = {
            tl: { x: x - depth, y: y - depth },
            tr: { x: x + size + depth, y: y - depth },
            bl: { x: x - depth, y: y + size + depth },
            br: { x: x + size + depth, y: y + size + depth }
        };

        const back = {
            tl: { x: front.tl.x + d3d, y: front.tl.y - d3d },
            tr: { x: front.tr.x - d3d, y: front.tr.y - d3d },
            bl: { x: front.bl.x + d3d, y: front.bl.y - d3d },
            br: { x: front.br.x - d3d, y: front.br.y - d3d }
        };

        // TOP FACE (3D - angled)
        const topGradient = ctx.createLinearGradient(0, back.tl.y, 0, front.tl.y);
        topGradient.addColorStop(0, this.colors.metalBright);
        topGradient.addColorStop(0.3, this.colors.metalLighter);
        topGradient.addColorStop(0.6, this.colors.metalLight);
        topGradient.addColorStop(1, this.colors.metalMid);
        ctx.fillStyle = topGradient;
        ctx.beginPath();
        ctx.moveTo(front.tl.x, front.tl.y);
        ctx.lineTo(back.tl.x, back.tl.y);
        ctx.lineTo(back.tr.x, back.tr.y);
        ctx.lineTo(front.tr.x, front.tr.y);
        ctx.closePath();
        ctx.fill();

        // LEFT FACE (3D - angled)
        const leftGradient = ctx.createLinearGradient(front.tl.x, 0, back.tl.x, 0);
        leftGradient.addColorStop(0, this.colors.metalDark);
        leftGradient.addColorStop(0.5, this.colors.metalDarker);
        leftGradient.addColorStop(1, this.colors.metalDarkest);
        ctx.fillStyle = leftGradient;
        ctx.beginPath();
        ctx.moveTo(front.tl.x, front.tl.y);
        ctx.lineTo(back.tl.x, back.tl.y);
        ctx.lineTo(back.bl.x, back.bl.y);
        ctx.lineTo(front.bl.x, front.bl.y);
        ctx.closePath();
        ctx.fill();

        // RIGHT FACE (3D - angled)
        const rightGradient = ctx.createLinearGradient(back.tr.x, 0, front.tr.x, 0);
        rightGradient.addColorStop(0, this.colors.metalDarkest);
        rightGradient.addColorStop(0.5, this.colors.metalDarker);
        rightGradient.addColorStop(1, '#000000');
        ctx.fillStyle = rightGradient;
        ctx.beginPath();
        ctx.moveTo(front.tr.x, front.tr.y);
        ctx.lineTo(back.tr.x, back.tr.y);
        ctx.lineTo(back.br.x, back.br.y);
        ctx.lineTo(front.br.x, front.br.y);
        ctx.closePath();
        ctx.fill();

        // FRONT FACE (main housing) - with MANY color layers
        const frontGradient = ctx.createLinearGradient(front.tl.x, front.tl.y, front.br.x, front.br.y);
        frontGradient.addColorStop(0, this.colors.metalBright);
        frontGradient.addColorStop(0.1, this.colors.metalLighter);
        frontGradient.addColorStop(0.2, this.colors.metalLight);
        frontGradient.addColorStop(0.35, this.colors.metalMid);
        frontGradient.addColorStop(0.5, this.colors.metalDark);
        frontGradient.addColorStop(0.65, this.colors.metalDarker);
        frontGradient.addColorStop(0.8, this.colors.metalDarkest);
        frontGradient.addColorStop(0.9, '#0a0a0a');
        frontGradient.addColorStop(1, '#000000');
        ctx.fillStyle = frontGradient;
        ctx.fillRect(front.tl.x, front.tl.y, size + depth * 2, size + depth * 2);

        // EXTREME edge highlights (10 layers!)
        const highlights = [
            { color: 'rgba(120, 120, 120, 0.9)', width: 4 },
            { color: 'rgba(110, 110, 110, 0.7)', width: 3 },
            { color: 'rgba(100, 100, 100, 0.6)', width: 3 },
            { color: 'rgba(90, 90, 90, 0.5)', width: 2 },
            { color: 'rgba(80, 80, 80, 0.4)', width: 2 },
            { color: 'rgba(70, 70, 70, 0.3)', width: 1 },
            { color: 'rgba(60, 60, 60, 0.2)', width: 1 },
            { color: 'rgba(50, 50, 50, 0.15)', width: 1 },
            { color: 'rgba(40, 40, 40, 0.1)', width: 1 },
            { color: 'rgba(30, 30, 30, 0.05)', width: 1 }
        ];

        // Top edge highlights
        highlights.forEach(hl => {
            ctx.strokeStyle = hl.color;
            ctx.lineWidth = hl.width;
            ctx.beginPath();
            ctx.moveTo(back.tl.x, back.tl.y);
            ctx.lineTo(back.tr.x, back.tr.y);
            ctx.stroke();
        });

        // Left edge highlights
        for (let i = 0; i < 6; i++) {
            ctx.strokeStyle = i === 0 ? 'rgba(100, 100, 100, 0.6)' :
                             i === 1 ? 'rgba(90, 90, 90, 0.5)' :
                             i === 2 ? 'rgba(80, 80, 80, 0.4)' :
                             i === 3 ? 'rgba(70, 70, 70, 0.3)' :
                             i === 4 ? 'rgba(60, 60, 60, 0.2)' : 'rgba(50, 50, 50, 0.1)';
            ctx.lineWidth = 4 - Math.floor(i / 2);
            ctx.beginPath();
            ctx.moveTo(back.tl.x, back.tl.y);
            ctx.lineTo(back.bl.x, back.bl.y);
            ctx.stroke();
        }

        // Front housing highlights (multiple layers)
        for (let i = 0; i < 5; i++) {
            ctx.strokeStyle = i === 0 ? 'rgba(90, 90, 90, 0.5)' :
                             i === 1 ? 'rgba(80, 80, 80, 0.4)' :
                             i === 2 ? 'rgba(70, 70, 70, 0.3)' :
                             i === 3 ? 'rgba(60, 60, 60, 0.2)' : 'rgba(50, 50, 50, 0.1)';
            ctx.lineWidth = 3 - Math.floor(i / 2);
            ctx.strokeRect(front.tl.x + i, front.tl.y + i, size + depth * 2 - i * 2, size + depth * 2 - i * 2);
        }
    }
}

