/**
 * PixelVerse - HUD (Heads-Up Display)
 * Minimalistic holographic HUD with retro sci-fi aesthetic
 * Functional, industrial design with thick frames
 */

class HUD {
    constructor(renderer) {
        this.renderer = renderer;
        this.visible = true;

        // HUD colors (holographic blue-green tint)
        this.primaryColor = RETRO_PALETTE.statusBlue;
        this.secondaryColor = RETRO_PALETTE.paleGray;
        this.warningColor = RETRO_PALETTE.cautionOrange;
        this.criticalColor = RETRO_PALETTE.alertRed;
        this.textColor = RETRO_PALETTE.vintageAmber;

        // HUD elements visibility
        this.elements = {
            healthBar: true,
            shieldBar: true,
            speedometer: true,
            radar: true,
            targetInfo: true,
            warnings: true
        };

        // Animation
        this.pulseTimer = 0;
        this.warningBlink = 0;
    }

    /**
     * Update HUD animations
     */
    update(deltaTime) {
        this.pulseTimer += deltaTime;
        this.warningBlink += deltaTime;

        if (this.pulseTimer > Math.PI * 2) {
            this.pulseTimer = 0;
        }

        if (this.warningBlink > 1.0) {
            this.warningBlink = 0;
        }
    }

    /**
     * Render HUD
     */
    render(playerShip) {
        if (!this.visible || !playerShip) return;

        const ctx = this.renderer.context;

        // Get player components
        const health = playerShip.getComponent('health');
        const velocity = playerShip.getComponent('velocity');
        const transform = playerShip.getComponent('transform');

        // Render HUD elements
        if (this.elements.healthBar && health) {
            this.renderHealthBar(ctx, health);
        }

        if (this.elements.speedometer && velocity) {
            this.renderSpeedometer(ctx, velocity);
        }

        if (this.elements.radar && transform) {
            this.renderRadar(ctx, transform);
        }

        if (this.elements.targetInfo) {
            this.renderTargetInfo(ctx);
        }

        if (this.elements.warnings && health) {
            this.renderWarnings(ctx, health);
        }
    }

    /**
     * Render health and shield bars (top-left)
     */
    renderHealthBar(ctx, health) {
        const x = 20;
        const y = 20;
        const barWidth = 200;
        const barHeight = 16;
        const spacing = 6;

        // Hull integrity
        this.drawBar(
            ctx,
            x, y,
            barWidth, barHeight,
            health.health / health.maxHealth,
            'HULL',
            this.getHealthColor(health.health / health.maxHealth)
        );

        // Shield integrity
        if (health.maxShield > 0) {
            this.drawBar(
                ctx,
                x, y + barHeight + spacing,
                barWidth, barHeight,
                health.shield / health.maxShield,
                'SHIELD',
                this.primaryColor
            );
        }
    }

    /**
     * Draw a status bar with thick frame
     */
    drawBar(ctx, x, y, width, height, fillPercent, label, color) {
        // Thick outer frame
        ctx.strokeStyle = RETRO_PALETTE.hullPrimary;
        ctx.lineWidth = 3;
        ctx.strokeRect(x - 2, y - 2, width + 4, height + 4);

        // Inner frame
        ctx.strokeStyle = RETRO_PALETTE.darkGray;
        ctx.lineWidth = 1;
        ctx.strokeRect(x, y, width, height);

        // Background
        ctx.fillStyle = RETRO_PALETTE.voidDeep;
        ctx.fillRect(x + 1, y + 1, width - 2, height - 2);

        // Fill bar
        const fillWidth = (width - 2) * fillPercent;
        ctx.fillStyle = color;
        ctx.fillRect(x + 1, y + 1, fillWidth, height - 2);

        // Segmented appearance (every 20 pixels)
        ctx.strokeStyle = RETRO_PALETTE.voidBlack;
        ctx.lineWidth = 1;
        for (let i = 20; i < width; i += 20) {
            ctx.beginPath();
            ctx.moveTo(x + i, y);
            ctx.lineTo(x + i, y + height);
            ctx.stroke();
        }

        // Label
        ctx.font = '10px "DigitalDisco", "Courier New", monospace';
        ctx.fillStyle = this.textColor;
        ctx.textAlign = 'left';
        ctx.fillText(label, x, y - 12);

        // Percentage
        ctx.textAlign = 'right';
        ctx.fillText(Math.floor(fillPercent * 100) + '%', x + width, y - 12);
        ctx.textAlign = 'left';
    }

    /**
     * Get color based on health percentage
     */
    getHealthColor(percent) {
        if (percent > 0.6) return RETRO_PALETTE.alienGreen;
        if (percent > 0.3) return this.warningColor;
        return this.criticalColor;
    }

    /**
     * Render speedometer (bottom-left)
     */
    renderSpeedometer(ctx, velocity) {
        const x = 20;
        const y = this.renderer.baseHeight - 100;
        const size = 80;

        // Calculate speed
        const speed = Math.sqrt(velocity.vx * velocity.vx + velocity.vy * velocity.vy);
        const maxSpeed = 300;
        const speedPercent = Math.min(1, speed / maxSpeed);

        // Thick frame
        ctx.strokeStyle = RETRO_PALETTE.hullPrimary;
        ctx.lineWidth = 3;
        ctx.strokeRect(x - 2, y - 2, size + 4, size + 4);

        // Background
        ctx.fillStyle = RETRO_PALETTE.voidDeep;
        ctx.fillRect(x, y, size, size);

        // Speed arc (semi-circle gauge)
        const centerX = x + size / 2;
        const centerY = y + size - 10;
        const radius = size / 2 - 10;

        // Background arc
        ctx.strokeStyle = RETRO_PALETTE.darkGray;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, Math.PI, Math.PI * 2);
        ctx.stroke();

        // Speed arc
        ctx.strokeStyle = this.primaryColor;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(centerX, centerY, radius, Math.PI, Math.PI + (Math.PI * speedPercent));
        ctx.stroke();

        // Needle
        const needleAngle = Math.PI + (Math.PI * speedPercent);
        const needleLength = radius - 5;
        ctx.strokeStyle = this.textColor;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(
            centerX + Math.cos(needleAngle) * needleLength,
            centerY + Math.sin(needleAngle) * needleLength
        );
        ctx.stroke();

        // Speed value
        ctx.font = '12px "DigitalDisco", "Courier New", monospace';
        ctx.fillStyle = this.textColor;
        ctx.textAlign = 'center';
        ctx.fillText(Math.floor(speed), centerX, centerY - 15);
        ctx.font = '8px "DigitalDisco", "Courier New", monospace';
        ctx.fillText('m/s', centerX, centerY - 3);
        ctx.textAlign = 'left';
    }

    /**
     * Render radar (bottom-right)
     */
    renderRadar(ctx, transform) {
        const size = 120;
        const x = this.renderer.baseWidth - size - 20;
        const y = this.renderer.baseHeight - size - 20;

        // Thick frame
        ctx.strokeStyle = RETRO_PALETTE.hullPrimary;
        ctx.lineWidth = 3;
        ctx.strokeRect(x - 2, y - 2, size + 4, size + 4);

        // Background
        ctx.fillStyle = RETRO_PALETTE.voidDeep;
        ctx.fillRect(x, y, size, size);

        // Grid lines
        ctx.strokeStyle = RETRO_PALETTE.darkGray;
        ctx.lineWidth = 1;

        // Vertical center line
        ctx.beginPath();
        ctx.moveTo(x + size / 2, y);
        ctx.lineTo(x + size / 2, y + size);
        ctx.stroke();

        // Horizontal center line
        ctx.beginPath();
        ctx.moveTo(x, y + size / 2);
        ctx.lineTo(x + size, y + size / 2);
        ctx.stroke();

        // Circular range rings
        const centerX = x + size / 2;
        const centerY = y + size / 2;

        for (let r = 20; r < size / 2; r += 20) {
            ctx.beginPath();
            ctx.arc(centerX, centerY, r, 0, Math.PI * 2);
            ctx.stroke();
        }

        // Player ship (center dot)
        ctx.fillStyle = this.primaryColor;
        ctx.fillRect(centerX - 2, centerY - 2, 4, 4);

        // Sweep line (rotating)
        const sweepAngle = this.pulseTimer;
        ctx.strokeStyle = PaletteUtils.withAlpha(this.primaryColor, 0.3);
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(
            centerX + Math.cos(sweepAngle) * (size / 2 - 5),
            centerY + Math.sin(sweepAngle) * (size / 2 - 5)
        );
        ctx.stroke();

        // Label
        ctx.font = '8px "DigitalDisco", "Courier New", monospace';
        ctx.fillStyle = this.textColor;
        ctx.textAlign = 'center';
        ctx.fillText('RADAR', centerX, y - 8);
        ctx.textAlign = 'left';
    }

    /**
     * Render target info (top-right)
     */
    renderTargetInfo(ctx) {
        const x = this.renderer.baseWidth - 220;
        const y = 20;
        const width = 200;
        const height = 80;

        // Thick frame
        ctx.strokeStyle = RETRO_PALETTE.hullPrimary;
        ctx.lineWidth = 3;
        ctx.strokeRect(x - 2, y - 2, width + 4, height + 4);

        // Background
        ctx.fillStyle = RETRO_PALETTE.voidDeep;
        ctx.fillRect(x, y, width, height);

        // No target message
        ctx.font = '10px "DigitalDisco", "Courier New", monospace';
        ctx.fillStyle = this.secondaryColor;
        ctx.fillText('NO TARGET', x + 10, y + 20);
        ctx.fillText('ACQUIRED', x + 10, y + 35);

        // Crosshair icon
        const iconX = x + width - 40;
        const iconY = y + height / 2;
        ctx.strokeStyle = this.secondaryColor;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(iconX, iconY, 15, 0, Math.PI * 2);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(iconX - 20, iconY);
        ctx.lineTo(iconX + 20, iconY);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(iconX, iconY - 20);
        ctx.lineTo(iconX, iconY + 20);
        ctx.stroke();
    }

    /**
     * Render warning messages (center-top)
     */
    renderWarnings(ctx, health) {
        const warnings = [];

        // Check for critical conditions
        if (health.health < health.maxHealth * 0.3) {
            warnings.push('HULL CRITICAL');
        }

        if (health.shield === 0 && health.maxShield > 0) {
            warnings.push('SHIELDS DOWN');
        }

        if (warnings.length === 0) return;

        // Render warnings
        const y = 60;
        const centerX = this.renderer.baseWidth / 2;

        ctx.font = 'bold 14px "DigitalDisco", "Courier New", monospace';
        ctx.textAlign = 'center';

        for (let i = 0; i < warnings.length; i++) {
            const warningY = y + (i * 25);

            // Blinking effect
            if (this.warningBlink < 0.5) {
                // Background box
                const textWidth = ctx.measureText(warnings[i]).width;
                ctx.fillStyle = this.criticalColor;
                ctx.fillRect(centerX - textWidth / 2 - 10, warningY - 14, textWidth + 20, 20);

                // Text
                ctx.fillStyle = RETRO_PALETTE.pureWhite;
                ctx.fillText(warnings[i], centerX, warningY);
            }
        }

        ctx.textAlign = 'left';
    }

    /**
     * Toggle HUD visibility
     */
    toggle() {
        this.visible = !this.visible;
    }

    /**
     * Toggle specific HUD element
     */
    toggleElement(elementName) {
        if (this.elements.hasOwnProperty(elementName)) {
            this.elements[elementName] = !this.elements[elementName];
        }
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = HUD;
}

