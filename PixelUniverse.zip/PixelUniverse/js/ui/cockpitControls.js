/**
 * PixelVerse - Cockpit Controls
 * Buttons, levers, switches, wheels, and other interactive controls
 */

class CockpitControls {
    constructor(ctx, colors, drawing) {
        this.ctx = ctx;
        this.colors = colors;
        this.drawing = drawing;
    }

    /**
     * Draw recessed control panel background with REAL 3D depth
     */
    drawControlPanelBackground(x, y, w, h) {
        const ctx = this.ctx;
        const depth = 10; // Deeper recess
        const d3d = 6; // 3D extrusion

        // MANY shadow layers for extreme depth (20 layers!)
        for (let i = 20; i >= 0; i--) {
            const ratio = i / 20;
            const alpha = 0.15 + ratio * 0.8;
            const offset = ratio * depth * 1.5;

            ctx.save();
            ctx.globalAlpha = alpha;
            ctx.fillStyle = '#000000';
            ctx.fillRect(
                x - depth - offset,
                y - depth - offset,
                w + depth * 2 + offset * 2,
                h + depth * 2 + offset * 2
            );
            ctx.restore();
        }

        // Calculate 3D points
        const front = {
            tl: { x: x - depth, y: y - depth },
            tr: { x: x + w + depth, y: y - depth },
            bl: { x: x - depth, y: y + h + depth },
            br: { x: x + w + depth, y: y + h + depth }
        };

        const back = {
            tl: { x: front.tl.x + d3d, y: front.tl.y - d3d },
            tr: { x: front.tr.x - d3d, y: front.tr.y - d3d },
            bl: { x: front.bl.x + d3d, y: front.bl.y - d3d },
            br: { x: front.br.x - d3d, y: front.br.y - d3d }
        };

        // TOP FACE (3D)
        const topGradient = ctx.createLinearGradient(0, back.tl.y, 0, front.tl.y);
        topGradient.addColorStop(0, this.colors.metalMid);
        topGradient.addColorStop(0.5, this.colors.metalDark);
        topGradient.addColorStop(1, this.colors.metalDarker);
        ctx.fillStyle = topGradient;
        ctx.beginPath();
        ctx.moveTo(front.tl.x, front.tl.y);
        ctx.lineTo(back.tl.x, back.tl.y);
        ctx.lineTo(back.tr.x, back.tr.y);
        ctx.lineTo(front.tr.x, front.tr.y);
        ctx.closePath();
        ctx.fill();

        // LEFT FACE (3D)
        const leftGradient = ctx.createLinearGradient(front.tl.x, 0, back.tl.x, 0);
        leftGradient.addColorStop(0, this.colors.metalDarker);
        leftGradient.addColorStop(0.5, this.colors.metalDarkest);
        leftGradient.addColorStop(1, '#000000');
        ctx.fillStyle = leftGradient;
        ctx.beginPath();
        ctx.moveTo(front.tl.x, front.tl.y);
        ctx.lineTo(back.tl.x, back.tl.y);
        ctx.lineTo(back.bl.x, back.bl.y);
        ctx.lineTo(front.bl.x, front.bl.y);
        ctx.closePath();
        ctx.fill();

        // RIGHT FACE (3D)
        const rightGradient = ctx.createLinearGradient(back.tr.x, 0, front.tr.x, 0);
        rightGradient.addColorStop(0, '#000000');
        rightGradient.addColorStop(0.5, this.colors.metalDarkest);
        rightGradient.addColorStop(1, this.colors.metalDarker);
        ctx.fillStyle = rightGradient;
        ctx.beginPath();
        ctx.moveTo(front.tr.x, front.tr.y);
        ctx.lineTo(back.tr.x, back.tr.y);
        ctx.lineTo(back.br.x, back.br.y);
        ctx.lineTo(front.br.x, front.br.y);
        ctx.closePath();
        ctx.fill();

        // FRONT FACE (housing)
        const frontGradient = ctx.createLinearGradient(front.tl.x, front.tl.y, front.br.x, front.br.y);
        frontGradient.addColorStop(0, this.colors.metalDark);
        frontGradient.addColorStop(0.2, this.colors.metalDarker);
        frontGradient.addColorStop(0.4, this.colors.metalDarkest);
        frontGradient.addColorStop(0.6, '#000000');
        frontGradient.addColorStop(0.8, this.colors.metalDarkest);
        frontGradient.addColorStop(1, this.colors.metalDarker);
        ctx.fillStyle = frontGradient;
        ctx.fillRect(front.tl.x, front.tl.y, w + depth * 2, h + depth * 2);

        // Panel background (recessed)
        const panelGradient = ctx.createLinearGradient(x, y, x, y + h);
        panelGradient.addColorStop(0, this.colors.panelDark);
        panelGradient.addColorStop(0.3, this.colors.panelDeeper);
        panelGradient.addColorStop(0.5, this.colors.panelDeepest);
        panelGradient.addColorStop(0.7, this.colors.panelDeeper);
        panelGradient.addColorStop(1, this.colors.panelDark);
        ctx.fillStyle = panelGradient;
        ctx.fillRect(x, y, w, h);

        // Edge highlights (6 layers)
        for (let i = 0; i < 6; i++) {
            const alpha = 0.5 - i * 0.08;
            ctx.strokeStyle = `rgba(100, 100, 100, ${alpha})`;
            ctx.lineWidth = 4 - Math.floor(i / 2);
            ctx.beginPath();
            ctx.moveTo(back.tl.x, back.tl.y);
            ctx.lineTo(back.tr.x, back.tr.y);
            ctx.stroke();
        }

        // Inner shadows (deep recess)
        ctx.fillStyle = this.colors.shadowDeep;
        ctx.fillRect(x, y, w, 3);
        ctx.fillRect(x, y, 3, h);

        ctx.fillStyle = this.colors.shadowMid;
        ctx.fillRect(x + 3, y + 3, w - 6, 2);
        ctx.fillRect(x + 3, y + 3, 2, h - 6);
    }

    /**
     * Draw button grid
     */
    drawButtonGrid(x, y, rows, cols, buttonSize, spacing) {
        for (let row = 0; row < rows; row++) {
            for (let col = 0; col < cols; col++) {
                const bx = x + col * (buttonSize + spacing);
                const by = y + row * (buttonSize + spacing);
                this.drawing.draw3DButton(bx, by, buttonSize, buttonSize, false);
            }
        }
    }

    /**
     * Draw rotary wheel/dial with notches
     */
    drawRotaryWheel(x, y, radius, time) {
        const ctx = this.ctx;
        
        // Wheel shadow (deep)
        ctx.fillStyle = this.colors.shadowDeep;
        ctx.beginPath();
        ctx.arc(x + 3, y + 3, radius, 0, Math.PI * 2);
        ctx.fill();
        
        // Wheel body with radial gradient
        const gradient = ctx.createRadialGradient(x - radius/3, y - radius/3, 0, x, y, radius);
        gradient.addColorStop(0, this.colors.metalBright);
        gradient.addColorStop(0.4, this.colors.metalLight);
        gradient.addColorStop(0.7, this.colors.metalMid);
        gradient.addColorStop(1, this.colors.metalDark);
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.fill();
        
        // Outer rim (raised edge)
        ctx.strokeStyle = this.colors.highlightBright;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(x, y, radius - 1, 0, Math.PI * 2);
        ctx.stroke();
        
        // Notches around edge (12 positions)
        for (let i = 0; i < 12; i++) {
            const angle = (i / 12) * Math.PI * 2;
            const notchX = x + Math.cos(angle) * (radius - 4);
            const notchY = y + Math.sin(angle) * (radius - 4);
            
            // Notch recess
            ctx.fillStyle = this.colors.shadowDeep;
            ctx.fillRect(notchX - 2, notchY - 2, 4, 4);
            
            // Notch highlight
            ctx.fillStyle = this.colors.highlightDim;
            ctx.fillRect(notchX - 1, notchY - 1, 2, 2);
        }
        
        // Center hub (recessed)
        ctx.fillStyle = this.colors.shadowMid;
        ctx.beginPath();
        ctx.arc(x, y, radius / 2.5, 0, Math.PI * 2);
        ctx.fill();
        
        const hubGradient = ctx.createRadialGradient(x, y, 0, x, y, radius / 2.5);
        hubGradient.addColorStop(0, this.colors.metalDark);
        hubGradient.addColorStop(1, this.colors.metalDarkest);
        ctx.fillStyle = hubGradient;
        ctx.beginPath();
        ctx.arc(x, y, radius / 2.5, 0, Math.PI * 2);
        ctx.fill();
        
        // Pointer (animated rotation)
        const pointerAngle = time * 0.5;
        ctx.strokeStyle = this.colors.indicatorAmber;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + Math.cos(pointerAngle) * (radius - 6), y + Math.sin(pointerAngle) * (radius - 6));
        ctx.stroke();
        
        // Pointer tip
        ctx.fillStyle = this.colors.indicatorAmber;
        ctx.beginPath();
        ctx.arc(x + Math.cos(pointerAngle) * (radius - 6), y + Math.sin(pointerAngle) * (radius - 6), 3, 0, Math.PI * 2);
        ctx.fill();
    }

    /**
     * Draw lever control (vertical slider)
     */
    drawLever(x, y, position, label) {
        const ctx = this.ctx;
        const slotHeight = 50;
        
        // Lever slot (deep groove)
        ctx.fillStyle = this.colors.shadowDeepest;
        ctx.fillRect(x - 5, y - slotHeight/2, 10, slotHeight);
        
        ctx.fillStyle = this.colors.shadowDeeper;
        ctx.fillRect(x - 4, y - slotHeight/2 + 1, 8, slotHeight - 2);
        
        ctx.fillStyle = this.colors.shadowDeep;
        ctx.fillRect(x - 3, y - slotHeight/2 + 2, 6, slotHeight - 4);
        
        // Slot highlights (sides)
        ctx.fillStyle = this.colors.highlightDimmer;
        ctx.fillRect(x - 5, y - slotHeight/2, 1, slotHeight);
        ctx.fillRect(x + 4, y - slotHeight/2, 1, slotHeight);
        
        // Lever handle position (0-100)
        const leverY = y - slotHeight/2 + (slotHeight * (position / 100));
        
        // Lever handle shadow
        ctx.fillStyle = this.colors.shadowDeep;
        ctx.fillRect(x - 8, leverY - 8 + 3, 16, 16);
        
        // Lever handle with gradient
        const gradient = ctx.createLinearGradient(x - 8, leverY - 8, x + 8, leverY + 8);
        gradient.addColorStop(0, this.colors.metalLight);
        gradient.addColorStop(0.5, this.colors.metalMid);
        gradient.addColorStop(1, this.colors.metalDark);
        ctx.fillStyle = gradient;
        ctx.fillRect(x - 8, leverY - 8, 16, 16);
        
        // Handle highlights (top-left)
        ctx.fillStyle = this.colors.highlightBright;
        ctx.fillRect(x - 8, leverY - 8, 16, 2);
        ctx.fillRect(x - 8, leverY - 8, 2, 16);
        
        // Handle shadows (bottom-right)
        ctx.fillStyle = this.colors.shadowMid;
        ctx.fillRect(x - 8, leverY + 6, 16, 2);
        ctx.fillRect(x + 6, leverY - 8, 2, 16);
        
        // Grip lines on handle
        for (let i = 0; i < 3; i++) {
            const lineY = leverY - 4 + i * 4;
            ctx.strokeStyle = this.colors.shadowMid;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(x - 6, lineY);
            ctx.lineTo(x + 6, lineY);
            ctx.stroke();
        }
        
        // Label below
        ctx.font = 'bold 8px "Courier New", monospace';
        ctx.fillStyle = this.colors.textDim;
        ctx.fillText(label, x - 15, y + slotHeight/2 + 12);
    }

    /**
     * Draw toggle switch
     */
    drawToggleSwitch(x, y, on) {
        const ctx = this.ctx;
        
        // Switch base (recessed housing)
        ctx.fillStyle = this.colors.shadowDeep;
        ctx.fillRect(x - 8, y - 12, 16, 24);
        
        ctx.fillStyle = this.colors.panelDeeper;
        ctx.fillRect(x - 7, y - 11, 14, 22);
        
        // Switch lever position
        const leverY = on ? y - 6 : y + 6;
        const leverColor = on ? this.colors.indicatorAmber : this.colors.metalMid;
        
        // Lever shadow
        ctx.fillStyle = this.colors.shadowMid;
        ctx.fillRect(x - 6, leverY - 4 + 2, 12, 8);
        
        // Lever body with gradient
        const gradient = ctx.createLinearGradient(x - 6, leverY - 4, x + 6, leverY + 4);
        gradient.addColorStop(0, on ? leverColor : this.colors.metalLight);
        gradient.addColorStop(1, on ? leverColor : this.colors.metalDark);
        ctx.fillStyle = gradient;
        ctx.fillRect(x - 6, leverY - 4, 12, 8);
        
        // Lever highlight
        if (on) {
            ctx.fillStyle = this.colors.highlightBrightest;
            ctx.fillRect(x - 6, leverY - 4, 12, 2);
        } else {
            ctx.fillStyle = this.colors.highlightMid;
            ctx.fillRect(x - 6, leverY - 4, 12, 1);
        }
    }

    /**
     * Draw indicator light strip (vertical)
     */
    drawLightStrip(x, y, count, time) {
        for (let i = 0; i < count; i++) {
            const ly = y + i * 10;
            const on = Math.sin(time * 2 + i * 0.7) > 0;
            this.drawing.drawLight(x, ly, this.colors.indicatorAmber, on, 4);
        }
    }

    /**
     * Draw control panel 1 (between monitors 1-2)
     */
    drawControlPanel1(x, y, w, h, time) {
        this.drawControlPanelBackground(x, y, w, h);
        
        // Button grid (3x3)
        const buttonSize = 14;
        const spacing = 6;
        const gridX = x + (w - 3 * buttonSize - 2 * spacing) / 2;
        const gridY = y + 12;
        this.drawButtonGrid(gridX, gridY, 3, 3, buttonSize, spacing);
        
        // Indicator lights below
        const lightX = x + w / 2;
        const lightY = y + h - 35;
        this.drawLightStrip(lightX, lightY, 3, time);
    }

    /**
     * Draw control panel 2 (between monitors 2-3)
     */
    drawControlPanel2(x, y, w, h, time) {
        this.drawControlPanelBackground(x, y, w, h);
        
        // Rotary wheel at top
        const wheelX = x + w / 2;
        const wheelY = y + 28;
        this.drawRotaryWheel(wheelX, wheelY, 20, time);
        
        // Lever below
        const leverX = x + w / 2;
        const leverY = y + 75;
        this.drawLever(leverX, leverY, 65, 'THRTL');
        
        // Small buttons at bottom
        this.drawing.draw3DButton(x + 12, y + h - 18, 12, 12, false);
        this.drawing.draw3DButton(x + w - 24, y + h - 18, 12, 12, false);
    }

    /**
     * Draw control panel 3 (between monitors 3-4)
     */
    drawControlPanel3(x, y, w, h, time) {
        this.drawControlPanelBackground(x, y, w, h);
        
        // Toggle switches (vertical column)
        const switchX = x + w / 2;
        for (let i = 0; i < 4; i++) {
            const sy = y + 20 + i * 24;
            const on = i < 3; // First 3 on, last off
            this.drawToggleSwitch(switchX, sy, on);
        }
    }
}

