/**
 * PixelVerse - Menu System
 * Retro sci-fi menus with thick frames and mechanical buttons
 * Industrial, functional design
 */

class MenuSystem {
    constructor(renderer) {
        this.renderer = renderer;
        this.currentMenu = null;
        this.selectedIndex = 0;
        this.visible = false;

        // Menu colors
        this.frameColor = RETRO_PALETTE.hullPrimary;
        this.bgColor = RETRO_PALETTE.voidDeep;
        this.textColor = RETRO_PALETTE.vintageAmber;
        this.selectedColor = RETRO_PALETTE.warningYellow;
        this.disabledColor = RETRO_PALETTE.darkGray;

        // Define menus
        this.menus = {
            main: {
                title: 'MAIN MENU',
                items: [
                    { text: 'CONTINUE', action: 'continue' },
                    { text: 'NEW GAME', action: 'newGame' },
                    { text: 'LOAD GAME', action: 'loadGame' },
                    { text: 'SETTINGS', action: 'settings' },
                    { text: 'CREDITS', action: 'credits' },
                    { text: 'EXIT', action: 'exit' }
                ]
            },
            pause: {
                title: 'PAUSED',
                items: [
                    { text: 'RESUME', action: 'resume' },
                    { text: 'SETTINGS', action: 'settings' },
                    { text: 'SAVE GAME', action: 'saveGame' },
                    { text: 'MAIN MENU', action: 'mainMenu' }
                ]
            },
            settings: {
                title: 'SETTINGS',
                items: [
                    { text: 'AUDIO', action: 'audioSettings' },
                    { text: 'VIDEO', action: 'videoSettings' },
                    { text: 'CONTROLS', action: 'controlSettings' },
                    { text: 'BACK', action: 'back' }
                ]
            }
        };
    }

    /**
     * Show menu
     */
    show(menuName = 'main') {
        this.currentMenu = menuName;
        this.selectedIndex = 0;
        this.visible = true;
    }

    /**
     * Hide menu
     */
    hide() {
        this.visible = false;
        this.currentMenu = null;
    }

    /**
     * Navigate menu
     */
    navigate(direction) {
        if (!this.visible || !this.currentMenu) return;

        const menu = this.menus[this.currentMenu];
        if (!menu) return;

        if (direction === 'up') {
            this.selectedIndex--;
            if (this.selectedIndex < 0) {
                this.selectedIndex = menu.items.length - 1;
            }
        } else if (direction === 'down') {
            this.selectedIndex++;
            if (this.selectedIndex >= menu.items.length) {
                this.selectedIndex = 0;
            }
        }
    }

    /**
     * Select current menu item
     */
    select() {
        if (!this.visible || !this.currentMenu) return null;

        const menu = this.menus[this.currentMenu];
        if (!menu) return null;

        const item = menu.items[this.selectedIndex];
        return item ? item.action : null;
    }

    /**
     * Render menu
     */
    render() {
        if (!this.visible || !this.currentMenu) return;

        const menu = this.menus[this.currentMenu];
        if (!menu) return;

        const ctx = this.renderer.context;

        // Menu dimensions
        const width = 400;
        const height = 60 + (menu.items.length * 50);
        const x = (this.renderer.baseWidth - width) / 2;
        const y = (this.renderer.baseHeight - height) / 2;

        // Draw menu background with thick frame
        this.drawMenuFrame(ctx, x, y, width, height);

        // Draw title
        this.drawTitle(ctx, menu.title, x, y, width);

        // Draw menu items
        this.drawMenuItems(ctx, menu.items, x, y + 60, width);
    }

    /**
     * Draw thick menu frame
     */
    drawMenuFrame(ctx, x, y, width, height) {
        // Outer thick frame
        ctx.fillStyle = this.frameColor;
        ctx.fillRect(x - 6, y - 6, width + 12, height + 12);

        // Shadow for depth
        ctx.fillStyle = RETRO_PALETTE.hullShadow;
        ctx.fillRect(x - 4, y - 4, width + 12, height + 12);

        // Inner frame
        ctx.strokeStyle = RETRO_PALETTE.darkGray;
        ctx.lineWidth = 2;
        ctx.strokeRect(x - 2, y - 2, width + 4, height + 4);

        // Background
        ctx.fillStyle = this.bgColor;
        ctx.fillRect(x, y, width, height);

        // Panel lines
        ctx.strokeStyle = RETRO_PALETTE.hullShadow;
        ctx.lineWidth = 1;
        for (let i = 1; i < 4; i++) {
            const lineY = y + (i * height / 4);
            ctx.beginPath();
            ctx.moveTo(x + 10, lineY);
            ctx.lineTo(x + width - 10, lineY);
            ctx.stroke();
        }

        // Corner screws
        const screwSize = 4;
        const screwPositions = [
            [x + 10, y + 10],
            [x + width - 10, y + 10],
            [x + 10, y + height - 10],
            [x + width - 10, y + height - 10]
        ];

        for (const [sx, sy] of screwPositions) {
            ctx.fillStyle = RETRO_PALETTE.darkGray;
            ctx.fillRect(sx - screwSize / 2, sy - screwSize / 2, screwSize, screwSize);
            ctx.fillStyle = RETRO_PALETTE.voidBlack;
            ctx.fillRect(sx - 1, sy - 1, 2, 2);
        }

        // Highlight edge
        ctx.strokeStyle = RETRO_PALETTE.hullHighlight;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(x, y + height);
        ctx.lineTo(x, y);
        ctx.lineTo(x + width, y);
        ctx.stroke();
    }

    /**
     * Draw menu title
     */
    drawTitle(ctx, title, x, y, width) {
        ctx.font = 'bold 16px "DigitalDisco", "Courier New", monospace';
        ctx.fillStyle = this.selectedColor;
        ctx.textAlign = 'center';
        ctx.fillText(title, x + width / 2, y + 30);

        // Underline
        ctx.strokeStyle = this.selectedColor;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(x + 40, y + 40);
        ctx.lineTo(x + width - 40, y + 40);
        ctx.stroke();

        ctx.textAlign = 'left';
    }

    /**
     * Draw menu items
     */
    drawMenuItems(ctx, items, x, y, width) {
        const itemHeight = 40;
        const itemSpacing = 10;

        for (let i = 0; i < items.length; i++) {
            const item = items[i];
            const itemY = y + (i * (itemHeight + itemSpacing));
            const isSelected = (i === this.selectedIndex);

            this.drawMenuItem(ctx, item, x + 20, itemY, width - 40, itemHeight, isSelected);
        }
    }

    /**
     * Draw single menu item (button)
     */
    drawMenuItem(ctx, item, x, y, width, height, isSelected) {
        // Button frame
        if (isSelected) {
            // Selected - bright frame
            ctx.fillStyle = this.selectedColor;
            ctx.fillRect(x - 2, y - 2, width + 4, height + 4);

            ctx.fillStyle = RETRO_PALETTE.hullSecondary;
            ctx.fillRect(x, y, width, height);
        } else {
            // Normal - dark frame
            ctx.strokeStyle = RETRO_PALETTE.darkGray;
            ctx.lineWidth = 2;
            ctx.strokeRect(x, y, width, height);

            ctx.fillStyle = RETRO_PALETTE.voidMid;
            ctx.fillRect(x + 2, y + 2, width - 4, height - 4);
        }

        // Button text
        ctx.font = '14px "DigitalDisco", "Courier New", monospace';
        ctx.fillStyle = isSelected ? RETRO_PALETTE.voidBlack : this.textColor;
        ctx.textAlign = 'center';
        ctx.fillText(item.text, x + width / 2, y + height / 2 + 5);
        ctx.textAlign = 'left';

        // Selection indicator (arrow)
        if (isSelected) {
            ctx.fillStyle = this.selectedColor;
            ctx.beginPath();
            ctx.moveTo(x - 12, y + height / 2 - 4);
            ctx.lineTo(x - 12, y + height / 2 + 4);
            ctx.lineTo(x - 6, y + height / 2);
            ctx.closePath();
            ctx.fill();
        }
    }

    /**
     * Toggle menu visibility
     */
    toggle(menuName = 'pause') {
        if (this.visible) {
            this.hide();
        } else {
            this.show(menuName);
        }
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = MenuSystem;
}

