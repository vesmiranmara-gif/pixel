/**
 * PixelVerse - Cockpit Drawing Utilities
 * Basic drawing functions with proper depth, shadows, and gradients
 */

class CockpitDrawing {
    constructor(ctx, colors) {
        this.ctx = ctx;
        this.colors = colors;
    }

    /**
     * Draw text with vintage style
     */
    drawText(x, y, text, color, size = 10, bold = false) {
        const ctx = this.ctx;
        ctx.font = `${bold ? 'bold ' : ''}${size}px "Courier New", monospace`;
        ctx.fillStyle = color;
        ctx.fillText(text, Math.floor(x), Math.floor(y));
    }

    /**
     * Draw large text (for monitors)
     */
    drawLargeText(x, y, text, color, size = 12) {
        this.drawText(x, y, text, color, size, true);
    }

    /**
     * Draw status bar with gradient
     */
    drawBar(x, y, w, h, percent) {
        const ctx = this.ctx;
        
        // Background (deep shadow)
        ctx.fillStyle = this.colors.shadowDeepest;
        ctx.fillRect(x, y, w, h);
        
        // Inner background
        ctx.fillStyle = this.colors.panelDeepest;
        ctx.fillRect(x + 1, y + 1, w - 2, h - 2);
        
        // Fill with gradient
        const fillW = Math.floor((w - 2) * (percent / 100));
        if (fillW > 0) {
            let color1, color2;
            if (percent < 30) {
                color1 = this.colors.indicatorRed;
                color2 = '#aa0000';
            } else if (percent < 60) {
                color1 = this.colors.indicatorOrange;
                color2 = '#cc6600';
            } else {
                color1 = this.colors.indicatorAmber;
                color2 = '#cc8822';
            }
            
            const gradient = ctx.createLinearGradient(x + 1, y + 1, x + 1, y + h - 1);
            gradient.addColorStop(0, color1);
            gradient.addColorStop(1, color2);
            ctx.fillStyle = gradient;
            ctx.fillRect(x + 1, y + 1, fillW, h - 2);
        }
        
        // Top highlight
        ctx.fillStyle = this.colors.highlightDim;
        ctx.fillRect(x + 1, y + 1, fillW, 1);
    }

    /**
     * Draw 3D button with deep shadows
     */
    draw3DButton(x, y, w, h, pressed = false) {
        const ctx = this.ctx;
        const offset = pressed ? 2 : 0;
        const depth = 3;
        
        // Multiple shadow layers for depth
        ctx.fillStyle = this.colors.shadowDeepest;
        ctx.fillRect(x + depth, y + depth, w, h);
        
        ctx.fillStyle = this.colors.shadowDeep;
        ctx.fillRect(x + depth - 1, y + depth - 1, w, h);
        
        ctx.fillStyle = this.colors.shadowMid;
        ctx.fillRect(x + depth - 2, y + depth - 2, w, h);
        
        // Button body with gradient
        const gradient = ctx.createLinearGradient(x, y, x, y + h);
        if (pressed) {
            gradient.addColorStop(0, this.colors.buttonPressed);
            gradient.addColorStop(0.5, this.colors.buttonOn);
            gradient.addColorStop(1, this.colors.buttonPressed);
        } else {
            gradient.addColorStop(0, this.colors.metalLight);
            gradient.addColorStop(0.5, this.colors.metalMid);
            gradient.addColorStop(1, this.colors.metalDark);
        }
        ctx.fillStyle = gradient;
        ctx.fillRect(x + offset, y + offset, w, h);
        
        // Highlights (top-left) - multiple layers
        if (!pressed) {
            ctx.fillStyle = this.colors.highlightBrightest;
            ctx.fillRect(x, y, w, 1);
            ctx.fillRect(x, y, 1, h);
            
            ctx.fillStyle = this.colors.highlightBright;
            ctx.fillRect(x + 1, y + 1, w - 2, 1);
            ctx.fillRect(x + 1, y + 1, 1, h - 2);
        }
        
        // Shadows (bottom-right)
        ctx.fillStyle = this.colors.shadowMid;
        ctx.fillRect(x + offset, y + h + offset - 1, w, 1);
        ctx.fillRect(x + w + offset - 1, y + offset, 1, h);
    }

    /**
     * Draw indicator light with glow
     */
    drawLight(x, y, color, on, size = 6) {
        const ctx = this.ctx;
        
        // Housing (deep recess)
        ctx.fillStyle = this.colors.shadowDeepest;
        ctx.beginPath();
        ctx.arc(x, y, size + 3, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.fillStyle = this.colors.shadowDeep;
        ctx.beginPath();
        ctx.arc(x, y, size + 2, 0, Math.PI * 2);
        ctx.fill();
        
        if (on) {
            // Outer glow
            ctx.save();
            ctx.globalAlpha = 0.5;
            ctx.fillStyle = color;
            ctx.beginPath();
            ctx.arc(x, y, size + 5, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
            
            // Mid glow
            ctx.save();
            ctx.globalAlpha = 0.7;
            ctx.fillStyle = color;
            ctx.beginPath();
            ctx.arc(x, y, size + 3, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
            
            // Light body
            ctx.fillStyle = color;
            ctx.beginPath();
            ctx.arc(x, y, size, 0, Math.PI * 2);
            ctx.fill();
            
            // Bright highlight
            ctx.fillStyle = this.colors.highlightBrightest;
            ctx.beginPath();
            ctx.arc(x - size/3, y - size/3, size/3, 0, Math.PI * 2);
            ctx.fill();
        } else {
            // Off state
            ctx.fillStyle = this.colors.panelDeepest;
            ctx.beginPath();
            ctx.arc(x, y, size, 0, Math.PI * 2);
            ctx.fill();
            
            // Dim reflection
            ctx.fillStyle = this.colors.highlightDimmer;
            ctx.beginPath();
            ctx.arc(x - size/4, y - size/4, size/4, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    /**
     * Draw rivet/bolt with REAL 3D depth
     */
    drawRivet(x, y, size = 4) {
        const ctx = this.ctx;
        const depth = size * 0.4;

        // Multiple shadow layers for depth
        for (let i = 3; i >= 0; i--) {
            const offset = i * 0.8;
            const alpha = 0.3 + i * 0.15;
            ctx.save();
            ctx.globalAlpha = alpha;
            ctx.fillStyle = '#000000';
            ctx.beginPath();
            ctx.arc(x + offset, y + offset, size + offset * 0.5, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
        }

        // Rivet housing (raised)
        const housingGradient = ctx.createRadialGradient(x - size/2, y - size/2, 0, x, y, size * 1.2);
        housingGradient.addColorStop(0, this.colors.metalBright);
        housingGradient.addColorStop(0.3, this.colors.metalLight);
        housingGradient.addColorStop(0.6, this.colors.metalMid);
        housingGradient.addColorStop(1, this.colors.metalDark);
        ctx.fillStyle = housingGradient;
        ctx.beginPath();
        ctx.arc(x, y, size * 1.1, 0, Math.PI * 2);
        ctx.fill();

        // Rivet body
        const bodyGradient = ctx.createRadialGradient(x - size/3, y - size/3, 0, x, y, size);
        bodyGradient.addColorStop(0, this.colors.metalLighter);
        bodyGradient.addColorStop(0.4, this.colors.metalLight);
        bodyGradient.addColorStop(0.7, this.colors.metalMid);
        bodyGradient.addColorStop(1, this.colors.metalDark);
        ctx.fillStyle = bodyGradient;
        ctx.beginPath();
        ctx.arc(x, y, size, 0, Math.PI * 2);
        ctx.fill();

        // Multiple highlights for 3D effect
        ctx.fillStyle = this.colors.highlightBrightest;
        ctx.beginPath();
        ctx.arc(x - size/2, y - size/2, size/2.5, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = 'rgba(120, 120, 120, 0.6)';
        ctx.beginPath();
        ctx.arc(x - size/3, y - size/3, size/4, 0, Math.PI * 2);
        ctx.fill();

        // Cross indent (screw slot) - deeper
        ctx.strokeStyle = this.colors.shadowDeepest;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(x - size/1.5, y);
        ctx.lineTo(x + size/1.5, y);
        ctx.moveTo(x, y - size/1.5);
        ctx.lineTo(x, y + size/1.5);
        ctx.stroke();

        ctx.strokeStyle = this.colors.shadowDeep;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(x - size/1.5, y);
        ctx.lineTo(x + size/1.5, y);
        ctx.moveTo(x, y - size/1.5);
        ctx.lineTo(x, y + size/1.5);
        ctx.stroke();
    }

    /**
     * Draw corner bracket (decorative)
     */
    drawCornerBracket(x, y, size) {
        const ctx = this.ctx;
        
        // Shadow
        ctx.strokeStyle = this.colors.shadowMid;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(x + 1, y + size + 1);
        ctx.lineTo(x + 1, y + 1);
        ctx.lineTo(x + size + 1, y + 1);
        ctx.stroke();
        
        // Bracket body
        ctx.strokeStyle = this.colors.metalMid;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(x, y + size);
        ctx.lineTo(x, y);
        ctx.lineTo(x + size, y);
        ctx.stroke();
        
        // Highlight
        ctx.strokeStyle = this.colors.highlightBright;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(x, y + size);
        ctx.lineTo(x, y);
        ctx.lineTo(x + size, y);
        ctx.stroke();
        
        // Rivets at corners
        this.drawRivet(x + 2, y + 2, 2);
        this.drawRivet(x + size - 2, y + 2, 2);
    }

    /**
     * Draw vent grille
     */
    drawVentGrille(x, y, w, h) {
        const ctx = this.ctx;
        
        // Grille recess
        ctx.fillStyle = this.colors.shadowDeeper;
        ctx.fillRect(x, y, w, h);
        
        ctx.fillStyle = this.colors.shadowDeep;
        ctx.fillRect(x + 1, y + 1, w - 2, h - 2);
        
        // Horizontal slats
        ctx.strokeStyle = this.colors.metalDark;
        ctx.lineWidth = 2;
        for (let i = 0; i < h; i += 4) {
            ctx.beginPath();
            ctx.moveTo(x + 2, y + i);
            ctx.lineTo(x + w - 2, y + i);
            ctx.stroke();
        }
        
        // Slat highlights
        ctx.strokeStyle = this.colors.highlightDimmer;
        ctx.lineWidth = 1;
        for (let i = 1; i < h; i += 4) {
            ctx.beginPath();
            ctx.moveTo(x + 2, y + i);
            ctx.lineTo(x + w - 2, y + i);
            ctx.stroke();
        }
    }

    /**
     * Draw warning stripes
     */
    drawWarningStripes(x, y, w) {
        const ctx = this.ctx;
        const stripeWidth = 6;
        const stripeCount = Math.floor(w / stripeWidth);
        
        for (let i = 0; i < stripeCount; i++) {
            const sx = x + i * stripeWidth;
            ctx.fillStyle = i % 2 === 0 ? this.colors.indicatorYellow : this.colors.panelDark;
            ctx.fillRect(sx, y, stripeWidth, 8);
        }
        
        // Border
        ctx.strokeStyle = this.colors.shadowMid;
        ctx.lineWidth = 1;
        ctx.strokeRect(x, y, w, 8);
    }

    /**
     * Draw hex bolt (decorative)
     */
    drawHexBolt(x, y, size) {
        const ctx = this.ctx;
        
        // Shadow
        ctx.fillStyle = this.colors.shadowDeep;
        ctx.beginPath();
        for (let i = 0; i < 6; i++) {
            const angle = (i / 6) * Math.PI * 2;
            const px = x + 1 + Math.cos(angle) * size;
            const py = y + 1 + Math.sin(angle) * size;
            if (i === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.fill();
        
        // Bolt body
        const gradient = ctx.createRadialGradient(x - size/2, y - size/2, 0, x, y, size);
        gradient.addColorStop(0, this.colors.metalLight);
        gradient.addColorStop(1, this.colors.metalDark);
        ctx.fillStyle = gradient;
        ctx.beginPath();
        for (let i = 0; i < 6; i++) {
            const angle = (i / 6) * Math.PI * 2;
            const px = x + Math.cos(angle) * size;
            const py = y + Math.sin(angle) * size;
            if (i === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.fill();
        
        // Highlight
        ctx.strokeStyle = this.colors.highlightBright;
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (let i = 0; i < 3; i++) {
            const angle = (i / 6) * Math.PI * 2;
            const px = x + Math.cos(angle) * size;
            const py = y + Math.sin(angle) * size;
            if (i === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
        }
        ctx.stroke();
    }
}

