/**
 * PixelVerse - TRUE 3D Angled Cockpit Panel
 * Real 3D geometry with physical depth and proper angles
 */

class CockpitUI {
    constructor(renderer) {
        this.renderer = renderer;
        this.canvas = renderer.canvas;
        this.ctx = renderer.context;
        
        this.visible = true;
        this.alpha = 1.0;
        this.time = 0;
        
        // Dark vintage colors
        this.colors = {
            // Many shades for depth
            black: '#000000',
            veryDark: '#0a0a0a',
            darker: '#141414',
            dark: '#1e1e1e',
            midDark: '#282828',
            mid: '#323232',
            midLight: '#3c3c3c',
            light: '#464646',
            lighter: '#505050',
            lightest: '#5a5a5a',

            // Metal colors for monitor housing (from COCKPIT_ENHANCED_COMPLETE.md)
            metalBright: '#454545',
            metalLighter: '#3a3a3a',
            metalLight: '#303030',
            metalMid: '#252525',
            metalDark: '#1a1a1a',
            metalDarker: '#121212',
            metalDarkest: '#0a0a0a',

            // Highlights
            highlight1: 'rgba(100, 100, 100, 0.8)',
            highlight2: 'rgba(90, 90, 90, 0.6)',
            highlight3: 'rgba(80, 80, 80, 0.4)',
            highlight4: 'rgba(70, 70, 70, 0.2)',
            highlightBrightest: '#787878',
            highlightBright: '#6e6e6e',
            highlightMid: '#646464',
            highlightDim: '#5a5a5a',
            highlightDimmer: '#505050',

            // Shadows
            shadow1: 'rgba(0, 0, 0, 0.9)',
            shadow2: 'rgba(0, 0, 0, 0.7)',
            shadow3: 'rgba(0, 0, 0, 0.5)',
            shadow4: 'rgba(0, 0, 0, 0.3)',
            shadowDeepest: '#000000',
            shadowDeeper: '#050505',
            shadowDeep: '#0a0a0a',
            shadowMid: '#0f0f0f',
            shadowLight: '#141414',

            // Screen colors
            screenBg: '#1a1410',
            screenGlow: '#4a4428',
            screenLight: '#2a2418',
            screenMid: '#1f1c12',
            screenDark: '#14120c',
            screenOff: '#0a0906',

            // Panel colors (from COCKPIT_ENHANCED_COMPLETE.md)
            panelDark: '#141414',
            panelDeeper: '#0a0a0a',
            panelDeepest: '#050505',

            // Indicators
            amber: '#ffb03b',
            orange: '#ff8800',
            red: '#ff4400',
            yellow: '#ffcc00',
            blue: '#6688aa',
            indicatorAmber: '#ffb03b',

            // Text
            textBright: '#ffb03b',
            textMid: '#cc8822',
            textDim: '#886633'
        };
        
        // Initialize sub-systems
        this.drawing = new CockpitDrawing(this.ctx, this.colors);
        this.monitors = new CockpitMonitors(this.ctx, this.colors, this.drawing);
        this.controls = new CockpitControls(this.ctx, this.colors, this.drawing);
        this.decorations = new CockpitDecorations(this.ctx, this.colors, this.drawing);
        
        this.updateDimensions();
    }

    updateDimensions() {
        this.width = this.canvas.width;
        this.height = this.canvas.height;

        // Panel takes only 18% of screen height (much thinner, more realistic)
        this.panelHeight = Math.floor(this.height * 0.18);
        this.panelY = this.height - this.panelHeight;

        // Realistic 3D parameters for a thin, detailed panel
        this.depth3D = 25;           // Moderate depth (realistic)
        this.angleX = 15;            // Subtle tilt toward viewer
        this.angleY = 5;             // Very slight side angle
        this.perspectiveScale = 0.85; // Subtle perspective (more realistic)
    }

    update(deltaTime) {
        this.time += deltaTime;
    }

    render(playerShip, shipSystems, inventory, weaponSystem) {
        if (!this.visible) return;
        
        const ctx = this.ctx;
        ctx.save();
        ctx.globalAlpha = this.alpha;
        
        // Draw TRUE 3D angled panel
        this.draw3DAngledPanel();
        
        // Draw monitors and controls on the angled surface
        this.drawPanelElements(playerShip, shipSystems, weaponSystem);
        
        // Draw decorations
        this.decorations.drawAll(this.panelY, this.panelHeight, this.width, this.time);
        
        ctx.restore();
    }

    /**
     * Draw realistic thin cockpit panel with detailed surface
     */
    draw3DAngledPanel() {
        const ctx = this.ctx;
        const w = this.width;
        const h = this.panelHeight;
        const y = this.panelY;
        const d = this.depth3D;

        // Calculate 3D points with subtle perspective
        const topScale = this.perspectiveScale;
        const topInset = (w - w * topScale) / 2;

        const topLeft = { x: topInset, y: y };
        const topRight = { x: w - topInset, y: y };
        const bottomLeft = { x: 0, y: y + h };
        const bottomRight = { x: w, y: y + h };

        // Back points for 3D depth (subtle)
        const backTopLeft = { x: topLeft.x + d * 0.2, y: topLeft.y - d * 0.3 };
        const backTopRight = { x: topRight.x - d * 0.2, y: topRight.y - d * 0.3 };
        const backBottomLeft = { x: bottomLeft.x + d * 0.1, y: bottomLeft.y - d * 0.2 };
        const backBottomRight = { x: bottomRight.x - d * 0.1, y: bottomRight.y - d * 0.2 };

        // Draw subtle depth shadows (6 layers for realism)
        for (let i = 6; i >= 0; i--) {
            const ratio = i / 6;
            const alpha = 0.02 + ratio * 0.08;
            const shadowDepth = ratio * d * 0.6;

            ctx.save();
            ctx.globalAlpha = alpha;
            ctx.fillStyle = '#000000';

            ctx.beginPath();
            ctx.moveTo(bottomLeft.x - shadowDepth, bottomLeft.y + shadowDepth);
            ctx.lineTo(bottomRight.x + shadowDepth, bottomRight.y + shadowDepth);
            ctx.lineTo(topRight.x + shadowDepth - topInset * 0.3, topRight.y + shadowDepth);
            ctx.lineTo(topLeft.x - shadowDepth + topInset * 0.3, topLeft.y + shadowDepth);
            ctx.closePath();
            ctx.fill();
            ctx.restore();
        }

        // Main panel surface with realistic metal gradient
        const mainGradient = ctx.createLinearGradient(topLeft.x, topLeft.y, bottomLeft.x, bottomLeft.y);
        mainGradient.addColorStop(0, this.colors.metalLight);
        mainGradient.addColorStop(0.2, this.colors.metalMid);
        mainGradient.addColorStop(0.5, this.colors.metalDark);
        mainGradient.addColorStop(0.8, this.colors.metalDarker);
        mainGradient.addColorStop(1, this.colors.metalDarkest);

        ctx.fillStyle = mainGradient;
        ctx.beginPath();
        ctx.moveTo(topLeft.x, topLeft.y);
        ctx.lineTo(topRight.x, topRight.y);
        ctx.lineTo(bottomRight.x, bottomRight.y);
        ctx.lineTo(bottomLeft.x, bottomLeft.y);
        ctx.closePath();
        ctx.fill();

        // Top angled face (subtle)
        const topGradient = ctx.createLinearGradient(topLeft.x, topLeft.y, backTopLeft.x, backTopLeft.y);
        topGradient.addColorStop(0, this.colors.metalBright);
        topGradient.addColorStop(0.5, this.colors.metalLight);
        topGradient.addColorStop(1, this.colors.metalMid);

        ctx.fillStyle = topGradient;
        ctx.beginPath();
        ctx.moveTo(topLeft.x, topLeft.y);
        ctx.lineTo(topRight.x, topRight.y);
        ctx.lineTo(backTopRight.x, backTopRight.y);
        ctx.lineTo(backTopLeft.x, backTopLeft.y);
        ctx.closePath();
        ctx.fill();

        // Add detailed panel segments and surface details
        this.drawPanelDetails(y, h, w);

        // Subtle edge highlights
        ctx.save();
        ctx.globalAlpha = 0.4;
        ctx.strokeStyle = this.colors.highlightBright;
        ctx.lineWidth = 1;

        // Top edge
        ctx.beginPath();
        ctx.moveTo(topLeft.x, topLeft.y);
        ctx.lineTo(topRight.x, topRight.y);
        ctx.stroke();

        // Left edge
        ctx.beginPath();
        ctx.moveTo(topLeft.x, topLeft.y);
        ctx.lineTo(bottomLeft.x, bottomLeft.y);
        ctx.stroke();

        ctx.restore();
    }

    /**
     * Draw detailed panel surface with segments, rivets, and technical details
     */
    drawPanelDetails(y, h, w) {
        const ctx = this.ctx;

        // Panel segments (divide into sections)
        const segmentWidth = w / 7;
        for (let i = 1; i < 7; i++) {
            const x = i * segmentWidth;

            // Vertical divider lines
            ctx.save();
            ctx.globalAlpha = 0.3;
            ctx.strokeStyle = this.colors.metalDarker;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(x, y + 5);
            ctx.lineTo(x, y + h - 5);
            ctx.stroke();

            // Highlight on dividers
            ctx.globalAlpha = 0.2;
            ctx.strokeStyle = this.colors.highlightMid;
            ctx.beginPath();
            ctx.moveTo(x + 1, y + 5);
            ctx.lineTo(x + 1, y + h - 5);
            ctx.stroke();
            ctx.restore();
        }

        // Horizontal detail lines
        const lineY1 = y + h * 0.3;
        const lineY2 = y + h * 0.7;

        ctx.save();
        ctx.globalAlpha = 0.2;
        ctx.strokeStyle = this.colors.metalDarker;
        ctx.lineWidth = 1;

        ctx.beginPath();
        ctx.moveTo(20, lineY1);
        ctx.lineTo(w - 20, lineY1);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(20, lineY2);
        ctx.lineTo(w - 20, lineY2);
        ctx.stroke();
        ctx.restore();

        // Corner rivets
        this.drawing.drawRivet(15, y + 8, 3);
        this.drawing.drawRivet(w - 15, y + 8, 3);
        this.drawing.drawRivet(15, y + h - 8, 3);
        this.drawing.drawRivet(w - 15, y + h - 8, 3);

        // Technical labels
        ctx.save();
        ctx.font = '8px "Courier New", monospace';
        ctx.fillStyle = this.colors.textDim;
        ctx.fillText('CONTROL INTERFACE MK-VII', 25, y + 12);
        ctx.fillText('AUTHORIZED PERSONNEL ONLY', w - 180, y + 12);
        ctx.fillText('MAX POWER: 2.5KW', 25, y + h - 5);
        ctx.fillText('TEMP RANGE: -40°C TO +85°C', w - 200, y + h - 5);
        ctx.restore();

        // Status indicators (small)
        this.drawing.drawLight(w - 40, y + h * 0.3, this.colors.amber, true, 2);
        this.drawing.drawLight(w - 30, y + h * 0.3, this.colors.blue, true, 2);
        this.drawing.drawLight(w - 20, y + h * 0.3, this.colors.amber, false, 2);
    }

    /**
     * Draw edge highlights
     */
    drawEdgeHighlights(backTopLeft, backTopRight, topLeft, topRight, bottomLeft, bottomRight) {
        const ctx = this.ctx;
        
        // Top back edge (brightest - 8 layers!)
        const highlights = [
            { color: this.colors.highlight1, width: 6 },
            { color: this.colors.highlight2, width: 5 },
            { color: this.colors.highlight3, width: 4 },
            { color: this.colors.highlight4, width: 3 },
            { color: 'rgba(70, 70, 70, 0.15)', width: 2 },
            { color: 'rgba(60, 60, 60, 0.1)', width: 2 },
            { color: 'rgba(50, 50, 50, 0.05)', width: 1 },
            { color: 'rgba(40, 40, 40, 0.03)', width: 1 }
        ];
        
        highlights.forEach(hl => {
            ctx.strokeStyle = hl.color;
            ctx.lineWidth = hl.width;
            ctx.beginPath();
            ctx.moveTo(backTopLeft.x, backTopLeft.y);
            ctx.lineTo(backTopRight.x, backTopRight.y);
            ctx.stroke();
        });
        
        // Left edge highlights (5 layers)
        for (let i = 0; i < 5; i++) {
            ctx.strokeStyle = i === 0 ? this.colors.highlight2 :
                             i === 1 ? this.colors.highlight3 :
                             i === 2 ? this.colors.highlight4 :
                             i === 3 ? 'rgba(60, 60, 60, 0.15)' : 'rgba(50, 50, 50, 0.1)';
            ctx.lineWidth = 5 - i;
            ctx.beginPath();
            ctx.moveTo(backTopLeft.x, backTopLeft.y);
            ctx.lineTo(topLeft.x, topLeft.y);
            ctx.stroke();
        }
        
        // Front top edge (4 layers)
        for (let i = 0; i < 4; i++) {
            ctx.strokeStyle = i === 0 ? this.colors.highlight3 :
                             i === 1 ? this.colors.highlight4 :
                             i === 2 ? 'rgba(60, 60, 60, 0.2)' : 'rgba(50, 50, 50, 0.1)';
            ctx.lineWidth = 4 - i;
            ctx.beginPath();
            ctx.moveTo(topLeft.x, topLeft.y);
            ctx.lineTo(topRight.x, topRight.y);
            ctx.stroke();
        }
    }

    /**
     * Draw panel elements (monitors and controls) on the angled surface
     */
    drawPanelElements(playerShip, shipSystems, weaponSystem) {
        const y = this.panelY;
        const h = this.panelHeight;
        const topScale = this.perspectiveScale;
        const topInset = (this.width - this.width * topScale) / 2;

        // Calculate positions with properly sized elements to prevent overlap
        const monitorSize = 50;      // Base monitor size
        const controlWidth = 25;     // Base control panel width
        const spacing = 25;          // More generous spacing between elements

        // Account for 3D depth extensions:
        // Monitors extend 25px in each direction (total +50px width)
        // Control panels extend 10px in each direction (total +20px width)
        const monitorDepth = 25;
        const controlDepth = 10;

        const monitorActualWidth = monitorSize + (monitorDepth * 2);
        const controlActualWidth = controlWidth + (controlDepth * 2);

        // Layout: Monitor1 - Control1 - Monitor2 - Control2 - Monitor3 - Control3 - Monitor4
        // Calculate total width including 3D extensions and spacing
        const totalActualWidth = (4 * monitorActualWidth) + (3 * controlActualWidth) + (6 * spacing);

        // Make sure we don't exceed canvas width, add large margin
        const availableWidth = this.width - 200; // 100px margin on each side for safety
        let actualMonitorSize = monitorSize;
        let actualControlWidth = controlWidth;
        let actualSpacing = spacing;

        if (totalActualWidth > availableWidth) {
            // Scale everything down proportionally
            const scale = availableWidth / totalActualWidth;
            actualMonitorSize = Math.floor(monitorSize * scale);
            actualControlWidth = Math.floor(controlWidth * scale);
            actualSpacing = Math.floor(spacing * scale);
        }

        // Recalculate with scaled values
        const scaledMonitorActualWidth = actualMonitorSize + (monitorDepth * 2);
        const scaledControlActualWidth = actualControlWidth + (controlDepth * 2);
        const finalTotalWidth = (4 * scaledMonitorActualWidth) + (3 * scaledControlActualWidth) + (6 * actualSpacing);

        // Start position - center the entire layout
        const startX = (this.width - finalTotalWidth) / 2;

        // Adjust Y position for angle (monitors sit on angled surface)
        const monitorY = y + h * 0.2; // Position monitors in upper portion of thinner panel

        // Draw monitors and controls with proper spacing
        // Each element's x position is where its CENTER should be, accounting for depth extensions
        let currentX = startX;

        // Monitor 1 - renders from (x - depth) to (x + size + depth)
        this.monitors.drawMonitor1(currentX + monitorDepth, monitorY, actualMonitorSize, playerShip, shipSystems);
        currentX += scaledMonitorActualWidth + actualSpacing;

        // Control 1 - renders from (x - depth) to (x + width + depth)
        this.controls.drawControlPanel1(currentX + controlDepth, monitorY, actualControlWidth, actualMonitorSize, this.time);
        currentX += scaledControlActualWidth + actualSpacing;

        // Monitor 2
        this.monitors.drawMonitor2(currentX + monitorDepth, monitorY, actualMonitorSize, playerShip, this.time);
        currentX += scaledMonitorActualWidth + actualSpacing;

        // Control 2
        this.controls.drawControlPanel2(currentX + controlDepth, monitorY, actualControlWidth, actualMonitorSize, this.time);
        currentX += scaledControlActualWidth + actualSpacing;

        // Monitor 3
        this.monitors.drawMonitor3(currentX + monitorDepth, monitorY, actualMonitorSize, playerShip);
        currentX += scaledMonitorActualWidth + actualSpacing;

        // Control 3
        this.controls.drawControlPanel3(currentX + controlDepth, monitorY, actualControlWidth, actualMonitorSize, this.time);
        currentX += scaledControlActualWidth + actualSpacing;

        // Monitor 4
        this.monitors.drawMonitor4(currentX + monitorDepth, monitorY, actualMonitorSize, shipSystems, this.time);
    }

    toggle() {
        this.visible = !this.visible;
    }

    setAlpha(alpha) {
        this.alpha = Math.max(0, Math.min(1, alpha));
    }
}

