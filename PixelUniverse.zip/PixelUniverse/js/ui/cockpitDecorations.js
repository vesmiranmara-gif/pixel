/**
 * PixelVerse - Cockpit Decorative Elements
 * Sci-fi retro decorative elements: pipes, conduits, panels, labels, etc.
 */

class CockpitDecorations {
    constructor(ctx, colors, drawing) {
        this.ctx = ctx;
        this.colors = colors;
        this.drawing = drawing;
    }

    /**
     * Draw conduit/pipe (decorative)
     */
    drawConduit(x1, y1, x2, y2) {
        const ctx = this.ctx;
        const thickness = 6;
        
        // Pipe shadow
        ctx.strokeStyle = this.colors.shadowDeep;
        ctx.lineWidth = thickness + 2;
        ctx.beginPath();
        ctx.moveTo(x1 + 1, y1 + 1);
        ctx.lineTo(x2 + 1, y2 + 1);
        ctx.stroke();
        
        // Pipe body with gradient
        const gradient = ctx.createLinearGradient(x1, y1 - thickness/2, x1, y1 + thickness/2);
        gradient.addColorStop(0, this.colors.metalDark);
        gradient.addColorStop(0.5, this.colors.metalMid);
        gradient.addColorStop(1, this.colors.metalDarkest);
        ctx.strokeStyle = gradient;
        ctx.lineWidth = thickness;
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
        
        // Pipe highlight (top edge)
        ctx.strokeStyle = this.colors.highlightMid;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(x1, y1 - thickness/2);
        ctx.lineTo(x2, y2 - thickness/2);
        ctx.stroke();
        
        // Pipe segments (rivets along pipe)
        const segments = 5;
        for (let i = 0; i <= segments; i++) {
            const t = i / segments;
            const px = x1 + (x2 - x1) * t;
            const py = y1 + (y2 - y1) * t;
            this.drawing.drawRivet(px, py, 3);
        }
    }

    /**
     * Draw status plate (decorative label)
     */
    drawStatusPlate(x, y, w, h, text) {
        const ctx = this.ctx;
        
        // Plate shadow
        ctx.fillStyle = this.colors.shadowMid;
        ctx.fillRect(x + 2, y + 2, w, h);
        
        // Plate body with gradient
        const gradient = ctx.createLinearGradient(x, y, x, y + h);
        gradient.addColorStop(0, this.colors.metalMid);
        gradient.addColorStop(0.5, this.colors.metalDark);
        gradient.addColorStop(1, this.colors.metalMid);
        ctx.fillStyle = gradient;
        ctx.fillRect(x, y, w, h);
        
        // Plate border
        ctx.strokeStyle = this.colors.highlightMid;
        ctx.lineWidth = 1;
        ctx.strokeRect(x, y, w, h);
        
        // Rivets at corners
        this.drawing.drawRivet(x + 3, y + h/2, 2);
        this.drawing.drawRivet(x + w - 3, y + h/2, 2);
        
        // Text
        ctx.font = 'bold 7px "Courier New", monospace';
        ctx.fillStyle = this.colors.textBright;
        const textWidth = ctx.measureText(text).width;
        ctx.fillText(text, x + (w - textWidth) / 2, y + h/2 + 3);
    }

    /**
     * Draw panel label
     */
    drawPanelLabel(x, y, text) {
        const ctx = this.ctx;
        ctx.font = 'bold 7px "Courier New", monospace';
        ctx.fillStyle = this.colors.textDim;
        ctx.fillText(text, x, y);
    }

    /**
     * Draw all decorative elements (MUCH MORE DETAIL!)
     */
    drawAll(panelY, panelHeight, width, time) {
        const ctx = this.ctx;

        // Corner brackets (4 corners)
        this.drawing.drawCornerBracket(18, panelY + 18, 14);
        this.drawing.drawCornerBracket(width - 32, panelY + 18, 14);
        this.drawing.drawCornerBracket(18, panelY + panelHeight - 32, 14);
        this.drawing.drawCornerBracket(width - 32, panelY + panelHeight - 32, 14);

        // MANY MORE rivets along edges
        const rivetSpacing = 25;
        for (let x = 20; x < width - 20; x += rivetSpacing) {
            this.drawing.drawRivet(x, panelY + 8, 4);
            this.drawing.drawRivet(x, panelY + panelHeight - 12, 4);
        }

        // Rivets along sides
        for (let y = panelY + 30; y < panelY + panelHeight - 30; y += 30) {
            this.drawing.drawRivet(15, y, 3);
            this.drawing.drawRivet(width - 15, y, 3);
        }

        // Vent grilles (more of them)
        this.drawing.drawVentGrille(width * 0.05, panelY + panelHeight - 48, 50, 25);
        this.drawing.drawVentGrille(width * 0.95 - 50, panelY + panelHeight - 48, 50, 25);
        this.drawing.drawVentGrille(width * 0.15, panelY + 10, 40, 15);
        this.drawing.drawVentGrille(width * 0.85 - 40, panelY + 10, 40, 15);

        // Warning stripes (more locations)
        this.drawing.drawWarningStripes(width * 0.03, panelY + panelHeight - 16, 45);
        this.drawing.drawWarningStripes(width * 0.97 - 45, panelY + panelHeight - 16, 45);

        // Warning labels
        this.drawPanelLabel(width * 0.03 + 8, panelY + panelHeight - 6, 'CAUTION');
        this.drawPanelLabel(width * 0.97 - 70, panelY + panelHeight - 6, 'HIGH VOLTAGE');

        // Conduits/pipes (MORE of them)
        this.drawConduit(width * 0.10, panelY + panelHeight - 55, width * 0.20, panelY + panelHeight - 55);
        this.drawConduit(width * 0.80, panelY + panelHeight - 55, width * 0.90, panelY + panelHeight - 55);
        this.drawConduit(width * 0.25, panelY + 15, width * 0.30, panelY + 15);
        this.drawConduit(width * 0.70, panelY + 15, width * 0.75, panelY + 15);

        // Hex bolts (MORE decorative bolts)
        this.drawing.drawHexBolt(width * 0.08, panelY + panelHeight / 2, 7);
        this.drawing.drawHexBolt(width * 0.92, panelY + panelHeight / 2, 7);
        this.drawing.drawHexBolt(width * 0.20, panelY + 25, 6);
        this.drawing.drawHexBolt(width * 0.80, panelY + 25, 6);

        // Status plates (MORE information plates)
        this.drawStatusPlate(width * 0.05, panelY + 5, 80, 14, 'OPERATIONAL');
        this.drawStatusPlate(width * 0.95 - 80, panelY + 5, 80, 14, 'SYSTEMS OK');

        // Serial numbers and notes
        this.drawSerialNumber(width * 0.12, panelY + panelHeight - 25, 'SN: MK7-2847-A');
        this.drawSerialNumber(width * 0.88 - 80, panelY + panelHeight - 25, 'REV: 3.14.2');

        // Technical notes
        this.drawTechnicalNote(width * 0.25, panelY + panelHeight - 10, 'MAX LOAD: 500A');
        this.drawTechnicalNote(width * 0.75 - 100, panelY + panelHeight - 10, 'TEMP: -40/+85C');

        // Wires and cables
        this.drawWires(panelY, panelHeight, width, time);

        // Panel dividers
        this.drawPanelDividers(panelY, panelHeight, width);

        // Vent slots
        this.drawVentSlots(panelY, panelHeight, width);

        // Additional small details
        this.drawSmallDetails(panelY, panelHeight, width);
    }

    /**
     * Draw panel dividers (vertical grooves)
     */
    drawPanelDividers(panelY, panelHeight, width) {
        const ctx = this.ctx;
        const grooveDepth = 5;
        
        // Vertical grooves at monitor boundaries
        const groovePositions = [
            width * 0.24,
            width * 0.48,
            width * 0.72
        ];
        
        for (const x of groovePositions) {
            // Deep shadow (left side)
            ctx.fillStyle = this.colors.shadowDeeper;
            ctx.fillRect(x - grooveDepth, panelY + 15, grooveDepth, panelHeight - 30);
            
            // Mid shadow
            ctx.fillStyle = this.colors.shadowDeep;
            ctx.fillRect(x - grooveDepth + 1, panelY + 15, grooveDepth - 2, panelHeight - 30);
            
            // Light shadow
            ctx.fillStyle = this.colors.shadowMid;
            ctx.fillRect(x - grooveDepth + 2, panelY + 15, grooveDepth - 4, panelHeight - 30);
            
            // Highlight (right side)
            ctx.fillStyle = this.colors.highlightDim;
            ctx.fillRect(x, panelY + 15, 2, panelHeight - 30);
            
            ctx.fillStyle = this.colors.highlightDimmer;
            ctx.fillRect(x + 2, panelY + 15, 1, panelHeight - 30);
        }
    }

    /**
     * Draw vent slots (decorative cooling vents)
     */
    drawVentSlots(panelY, panelHeight, width) {
        const ctx = this.ctx;

        // Small vent slots near top
        const slotPositions = [
            width * 0.30,
            width * 0.40,
            width * 0.60,
            width * 0.70
        ];

        for (const x of slotPositions) {
            // Vent slot (small horizontal grille)
            ctx.fillStyle = this.colors.shadowDeep;
            ctx.fillRect(x, panelY + 8, 20, 8);

            // Grille lines
            ctx.strokeStyle = this.colors.metalDark;
            ctx.lineWidth = 1;
            for (let i = 0; i < 8; i += 2) {
                ctx.beginPath();
                ctx.moveTo(x + 1, panelY + 8 + i);
                ctx.lineTo(x + 19, panelY + 8 + i);
                ctx.stroke();
            }
        }
    }

    /**
     * Draw serial number label
     */
    drawSerialNumber(x, y, text) {
        const ctx = this.ctx;

        // Label background (small plate)
        ctx.fillStyle = this.colors.shadowMid;
        ctx.fillRect(x + 1, y + 1, 90, 12);

        const gradient = ctx.createLinearGradient(x, y, x, y + 12);
        gradient.addColorStop(0, this.colors.metalDark);
        gradient.addColorStop(1, this.colors.metalDarker);
        ctx.fillStyle = gradient;
        ctx.fillRect(x, y, 90, 12);

        // Border
        ctx.strokeStyle = this.colors.highlightDimmer;
        ctx.lineWidth = 1;
        ctx.strokeRect(x, y, 90, 12);

        // Text
        ctx.font = '7px "Courier New", monospace';
        ctx.fillStyle = this.colors.textDim;
        ctx.fillText(text, x + 4, y + 9);
    }

    /**
     * Draw technical note
     */
    drawTechnicalNote(x, y, text) {
        const ctx = this.ctx;
        ctx.font = '6px "Courier New", monospace';
        ctx.fillStyle = this.colors.textDarkGray;
        ctx.fillText(text, x, y);
    }

    /**
     * Draw wires and cables (decorative)
     */
    drawWires(panelY, panelHeight, width, time) {
        const ctx = this.ctx;

        // Wire bundles (left side)
        this.drawWireBundle(width * 0.08, panelY + 40, width * 0.12, panelY + 80, 3, this.colors.indicatorRed);
        this.drawWireBundle(width * 0.09, panelY + 45, width * 0.13, panelY + 85, 3, this.colors.indicatorBlue);
        this.drawWireBundle(width * 0.10, panelY + 50, width * 0.14, panelY + 90, 3, this.colors.indicatorYellow);

        // Wire bundles (right side)
        this.drawWireBundle(width * 0.92, panelY + 40, width * 0.88, panelY + 80, 3, this.colors.indicatorRed);
        this.drawWireBundle(width * 0.91, panelY + 45, width * 0.87, panelY + 85, 3, this.colors.indicatorBlue);
        this.drawWireBundle(width * 0.90, panelY + 50, width * 0.86, panelY + 90, 3, this.colors.indicatorYellow);

        // Cable ties
        this.drawCableTie(width * 0.10, panelY + 60);
        this.drawCableTie(width * 0.90, panelY + 60);
    }

    /**
     * Draw single wire
     */
    drawWireBundle(x1, y1, x2, y2, thickness, color) {
        const ctx = this.ctx;

        // Wire shadow
        ctx.strokeStyle = this.colors.shadowMid;
        ctx.lineWidth = thickness + 1;
        ctx.beginPath();
        ctx.moveTo(x1 + 1, y1 + 1);
        ctx.lineTo(x2 + 1, y2 + 1);
        ctx.stroke();

        // Wire body
        ctx.strokeStyle = color;
        ctx.lineWidth = thickness;
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();

        // Wire highlight
        ctx.strokeStyle = this.colors.highlightDimmer;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
    }

    /**
     * Draw cable tie
     */
    drawCableTie(x, y) {
        const ctx = this.ctx;

        // Tie body
        ctx.fillStyle = this.colors.panelDeepest;
        ctx.fillRect(x - 4, y - 2, 8, 4);

        // Tie highlight
        ctx.fillStyle = this.colors.highlightDimmer;
        ctx.fillRect(x - 4, y - 2, 8, 1);
    }

    /**
     * Draw small decorative details
     */
    drawSmallDetails(panelY, panelHeight, width) {
        const ctx = this.ctx;

        // Small indicator dots (decorative LEDs)
        const dotPositions = [
            [width * 0.18, panelY + 12],
            [width * 0.22, panelY + 12],
            [width * 0.78, panelY + 12],
            [width * 0.82, panelY + 12]
        ];

        dotPositions.forEach(([x, y], i) => {
            // LED housing
            ctx.fillStyle = this.colors.shadowDeep;
            ctx.beginPath();
            ctx.arc(x, y, 3, 0, Math.PI * 2);
            ctx.fill();

            // LED light (some on, some off)
            if (i % 2 === 0) {
                ctx.fillStyle = this.colors.indicatorAmber;
                ctx.beginPath();
                ctx.arc(x, y, 2, 0, Math.PI * 2);
                ctx.fill();
            }
        });

        // Small screws (decorative)
        const screwPositions = [
            [width * 0.16, panelY + 20],
            [width * 0.24, panelY + 20],
            [width * 0.76, panelY + 20],
            [width * 0.84, panelY + 20]
        ];

        screwPositions.forEach(([x, y]) => {
            this.drawing.drawRivet(x, y, 2);
        });

        // Panel seams (decorative lines)
        ctx.strokeStyle = this.colors.shadowLight;
        ctx.lineWidth = 1;
        ctx.setLineDash([3, 3]);

        ctx.beginPath();
        ctx.moveTo(width * 0.20, panelY + panelHeight - 35);
        ctx.lineTo(width * 0.35, panelY + panelHeight - 35);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(width * 0.65, panelY + panelHeight - 35);
        ctx.lineTo(width * 0.80, panelY + panelHeight - 35);
        ctx.stroke();

        ctx.setLineDash([]);
    }
}

