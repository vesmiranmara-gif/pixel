/**
 * PixelVerse - Entity Component System (ECS) Architecture
 * Provides scalable and performant game object management
 */

class Entity {
    constructor(id) {
        this.id = id;
        this.components = new Map();
        this.active = true;
    }

    addComponent(name, component) {
        this.components.set(name, component);
        return this;
    }

    getComponent(name) {
        return this.components.get(name);
    }

    hasComponent(name) {
        return this.components.has(name);
    }

    removeComponent(name) {
        this.components.delete(name);
        return this;
    }

    destroy() {
        this.active = false;
        this.components.clear();
    }
}

class EntityManager {
    constructor() {
        this.entities = new Map();
        this.nextEntityId = 1;
        this.systems = [];
    }

    createEntity() {
        const id = this.nextEntityId++;
        const entity = new Entity(id);
        this.entities.set(id, entity);
        return entity;
    }

    getEntity(id) {
        return this.entities.get(id);
    }

    removeEntity(id) {
        const entity = this.entities.get(id);
        if (entity) {
            entity.destroy();
            this.entities.delete(id);
        }
    }

    getEntitiesWithComponents(...componentNames) {
        const result = [];
        for (const entity of this.entities.values()) {
            if (!entity.active) continue;
            
            let hasAll = true;
            for (const name of componentNames) {
                if (!entity.hasComponent(name)) {
                    hasAll = false;
                    break;
                }
            }
            
            if (hasAll) {
                result.push(entity);
            }
        }
        return result;
    }

    addSystem(system) {
        this.systems.push(system);
        system.entityManager = this;
    }

    update(deltaTime) {
        // Clean up inactive entities
        for (const [id, entity] of this.entities.entries()) {
            if (!entity.active) {
                this.entities.delete(id);
            }
        }

        // Update all systems
        for (const system of this.systems) {
            if (system.update) {
                system.update(deltaTime);
            }
        }
    }

    clear() {
        for (const entity of this.entities.values()) {
            entity.destroy();
        }
        this.entities.clear();
    }
}

/**
 * Common Components
 */

class TransformComponent {
    constructor(x = 0, y = 0, rotation = 0, scale = 1) {
        this.x = x;
        this.y = y;
        this.rotation = rotation;
        this.scale = scale;
    }
}

class VelocityComponent {
    constructor(vx = 0, vy = 0, angularVelocity = 0) {
        this.vx = vx;
        this.vy = vy;
        this.angularVelocity = angularVelocity;
    }
}

class SpriteComponent {
    constructor(sprite, width, height) {
        this.sprite = sprite;
        this.width = width;
        this.height = height;
        this.visible = true;
        this.alpha = 1.0;
    }
}

class PhysicsComponent {
    constructor(mass = 1, drag = 0.01) {
        this.mass = mass;
        this.drag = drag;
        this.forces = [];
    }

    addForce(fx, fy) {
        this.forces.push({ fx, fy });
    }

    clearForces() {
        this.forces = [];
    }
}

class CollisionComponent {
    constructor(radius, type = 'circle') {
        this.radius = radius;
        this.type = type;
        this.collisionMask = 0xFFFFFFFF;
        this.onCollision = null;
    }
}

class HealthComponent {
    constructor(maxHealth, maxShield = 0) {
        this.maxHealth = maxHealth;
        this.health = maxHealth;
        this.maxShield = maxShield;
        this.shield = maxShield;
        this.shieldRegenRate = 1.0;
        this.shieldRegenDelay = 3.0;
        this.timeSinceLastHit = 0;
    }

    takeDamage(amount) {
        if (this.shield > 0) {
            const shieldDamage = Math.min(this.shield, amount);
            this.shield -= shieldDamage;
            amount -= shieldDamage;
        }
        
        if (amount > 0) {
            this.health -= amount;
        }
        
        this.timeSinceLastHit = 0;
        return this.health <= 0;
    }

    heal(amount) {
        this.health = Math.min(this.maxHealth, this.health + amount);
    }

    rechargeShield(amount) {
        this.shield = Math.min(this.maxShield, this.shield + amount);
    }
}

class AIComponent {
    constructor(type = 'passive') {
        this.type = type; // passive, aggressive, defensive, patrol
        this.target = null;
        this.state = 'idle';
        this.stateTimer = 0;
        this.waypoints = [];
        this.currentWaypoint = 0;
    }
}

class WeaponComponent {
    constructor(weaponType, damage, fireRate, range) {
        this.weaponType = weaponType;
        this.damage = damage;
        this.fireRate = fireRate;
        this.range = range;
        this.cooldown = 0;
        this.ammo = -1; // -1 = infinite
        this.maxAmmo = -1;
    }

    canFire() {
        return this.cooldown <= 0 && (this.ammo === -1 || this.ammo > 0);
    }

    fire() {
        if (this.canFire()) {
            this.cooldown = 1.0 / this.fireRate;
            if (this.ammo > 0) {
                this.ammo--;
            }
            return true;
        }
        return false;
    }

    update(deltaTime) {
        if (this.cooldown > 0) {
            this.cooldown -= deltaTime;
        }
    }
}

class ParticleComponent {
    constructor(lifetime, color, size) {
        this.lifetime = lifetime;
        this.maxLifetime = lifetime;
        this.color = color;
        this.size = size;
        this.startSize = size;
        this.endSize = size * 0.5;
    }

    update(deltaTime) {
        this.lifetime -= deltaTime;
        
        // Interpolate size
        const t = 1 - (this.lifetime / this.maxLifetime);
        this.size = this.startSize + (this.endSize - this.startSize) * t;
        
        return this.lifetime > 0;
    }
}

/**
 * Base System Class
 */
class System {
    constructor() {
        this.entityManager = null;
        this.enabled = true;
    }

    update(deltaTime) {
        // Override in subclasses
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        Entity,
        EntityManager,
        TransformComponent,
        VelocityComponent,
        SpriteComponent,
        PhysicsComponent,
        CollisionComponent,
        HealthComponent,
        AIComponent,
        WeaponComponent,
        ParticleComponent,
        System
    };
}

