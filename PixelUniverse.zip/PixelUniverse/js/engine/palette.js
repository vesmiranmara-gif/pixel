/**
 * PixelVerse - Color Palette System
 * Defines the exact RETRO_PALETTE for authentic 16-bit aesthetics
 * All visual elements must use only these colors
 */

const RETRO_PALETTE = {
    // Core grayscale spectrum (primary colors) - Emphasize darker tones
    deepBlack: '#000000',
    voidBlack: '#0a0a0a',
    shadowGray: '#1a1a1a',
    darkGray: '#2a2a2a',
    mediumGray: '#4a4a4a',
    lightGray: '#6a6a6a',
    silverGray: '#8a8a8a',
    brightGray: '#aaaaaa',
    paleGray: '#cccccc',
    offWhite: '#eeeeee',
    pureWhite: '#ffffff',

    // Vintage accent colors (limited use) - Muted, industrial tones
    vintageAmber: '#cc9933',
    vintageCream: '#ddcc99',
    vintageCopper: '#aa6644',
    vintageBrass: '#b8860b',

    // Space environment colors - Deep, foreboding void
    voidDeep: '#000511',
    voidMid: '#001122',
    voidLight: '#002244',
    starfieldDim: '#333366',

    // Ship hull materials - Worn, industrial metal
    hullPrimary: '#666666',
    hullSecondary: '#555555',
    hullShadow: '#333333',
    hullHighlight: '#888888',
    hullAccent: '#999999',

    // Warning/status colors (minimal use) - Harsh, functional indicators
    alertRed: '#cc3333',
    cautionOrange: '#cc6633',
    statusBlue: '#336699',

    // Alien Thematic Colors (Dark, Biological, Warning)
    alienGreen: '#336633',
    warningYellow: '#ffff00',
    bloodRed: '#990000'
};

/**
 * Palette Utility Functions
 */
const PaletteUtils = {
    /**
     * Validate if a color is in the palette
     */
    isValidColor(color) {
        return Object.values(RETRO_PALETTE).includes(color.toLowerCase());
    },

    /**
     * Get a darker version of a color (50% darker)
     */
    darken(color) {
        const hex = color.replace('#', '');
        const r = Math.floor(parseInt(hex.substr(0, 2), 16) * 0.5);
        const g = Math.floor(parseInt(hex.substr(2, 2), 16) * 0.5);
        const b = Math.floor(parseInt(hex.substr(4, 2), 16) * 0.5);
        return '#' + [r, g, b].map(x => x.toString(16).padStart(2, '0')).join('');
    },

    /**
     * Get a lighter version of a color (50% lighter)
     */
    lighten(color) {
        const hex = color.replace('#', '');
        const r = Math.min(255, Math.floor(parseInt(hex.substr(0, 2), 16) * 1.5));
        const g = Math.min(255, Math.floor(parseInt(hex.substr(2, 2), 16) * 1.5));
        const b = Math.min(255, Math.floor(parseInt(hex.substr(4, 2), 16) * 1.5));
        return '#' + [r, g, b].map(x => x.toString(16).padStart(2, '0')).join('');
    },

    /**
     * Convert hex to RGB
     */
    hexToRgb(hex) {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? {
            r: parseInt(result[1], 16),
            g: parseInt(result[2], 16),
            b: parseInt(result[3], 16)
        } : null;
    },

    /**
     * Convert RGB to hex
     */
    rgbToHex(r, g, b) {
        return '#' + [r, g, b].map(x => {
            const hex = Math.floor(x).toString(16);
            return hex.length === 1 ? '0' + hex : hex;
        }).join('');
    },

    /**
     * Get color with alpha
     */
    withAlpha(color, alpha) {
        const rgb = this.hexToRgb(color);
        if (!rgb) return color;
        return `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${alpha})`;
    },

    /**
     * Get nearest palette color (for validation/correction)
     */
    getNearestPaletteColor(color) {
        const rgb = this.hexToRgb(color);
        if (!rgb) return RETRO_PALETTE.deepBlack;

        let minDistance = Infinity;
        let nearestColor = RETRO_PALETTE.deepBlack;

        for (const [name, paletteColor] of Object.entries(RETRO_PALETTE)) {
            const paletteRgb = this.hexToRgb(paletteColor);
            const distance = Math.sqrt(
                Math.pow(rgb.r - paletteRgb.r, 2) +
                Math.pow(rgb.g - paletteRgb.g, 2) +
                Math.pow(rgb.b - paletteRgb.b, 2)
            );

            if (distance < minDistance) {
                minDistance = distance;
                nearestColor = paletteColor;
            }
        }

        return nearestColor;
    }
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { RETRO_PALETTE, PaletteUtils };
}

