/**
 * PixelVerse - Core Game Engine
 * Fixed timestep game loop running at 60 FPS
 */

class GameEngine {
    constructor() {
        this.canvas = null;
        this.renderer = null;
        this.entityManager = null;
        
        // Game loop timing
        this.targetFPS = 60;
        this.targetFrameTime = 1000 / this.targetFPS;
        this.lastFrameTime = 0;
        this.accumulator = 0;
        this.deltaTime = 1 / this.targetFPS;
        
        // Game state
        this.running = false;
        this.paused = false;
        this.timeScale = 1.0;
        
        // Camera
        this.camera = {
            x: 0,
            y: 0,
            targetX: 0,
            targetY: 0,
            smoothing: 0.1
        };
        
        // Performance tracking
        this.frameCount = 0;
        this.fps = 60;
        this.fpsUpdateTime = 0;
        
        // Input state
        this.input = {
            keys: new Set(),
            mouse: { x: 0, y: 0, buttons: new Set() },
            touches: new Map()
        };
        
        // Game systems
        this.systems = [];
    }

    /**
     * Initialize the game engine
     */
    async initialize() {
        console.log('Initializing PixelVerse Engine...');
        
        // Get canvas
        this.canvas = document.getElementById('game-canvas');
        if (!this.canvas) {
            throw new Error('Canvas element not found');
        }
        
        // Create renderer
        this.renderer = new PixelRenderer(this.canvas);
        console.log('Renderer initialized');
        
        // Create entity manager
        this.entityManager = new EntityManager();
        console.log('Entity Manager initialized');
        
        // Setup input handlers
        this.setupInputHandlers();
        console.log('Input handlers initialized');
        
        // Initialize game systems
        await this.initializeSystems();
        console.log('Game systems initialized');
        
        console.log('PixelVerse Engine ready!');
    }

    /**
     * Initialize game systems
     */
    async initializeSystems() {
        // Systems will be added here as they are created
        // Example: this.entityManager.addSystem(new PhysicsSystem());
    }

    /**
     * Setup input event handlers
     */
    setupInputHandlers() {
        // Keyboard input
        window.addEventListener('keydown', (e) => {
            this.input.keys.add(e.code);
            this.onKeyDown(e);
        });
        
        window.addEventListener('keyup', (e) => {
            this.input.keys.delete(e.code);
            this.onKeyUp(e);
        });
        
        // Mouse input
        this.canvas.addEventListener('mousemove', (e) => {
            const rect = this.canvas.getBoundingClientRect();
            this.input.mouse.x = (e.clientX - rect.left) * (this.renderer.baseWidth / rect.width);
            this.input.mouse.y = (e.clientY - rect.top) * (this.renderer.baseHeight / rect.height);
            this.onMouseMove(e);
        });
        
        this.canvas.addEventListener('mousedown', (e) => {
            this.input.mouse.buttons.add(e.button);
            this.onMouseDown(e);
        });
        
        this.canvas.addEventListener('mouseup', (e) => {
            this.input.mouse.buttons.delete(e.button);
            this.onMouseUp(e);
        });
        
        // Touch input
        this.canvas.addEventListener('touchstart', (e) => {
            e.preventDefault();
            for (const touch of e.changedTouches) {
                const rect = this.canvas.getBoundingClientRect();
                this.input.touches.set(touch.identifier, {
                    x: (touch.clientX - rect.left) * (this.renderer.baseWidth / rect.width),
                    y: (touch.clientY - rect.top) * (this.renderer.baseHeight / rect.height)
                });
            }
            this.onTouchStart(e);
        });
        
        this.canvas.addEventListener('touchmove', (e) => {
            e.preventDefault();
            for (const touch of e.changedTouches) {
                const rect = this.canvas.getBoundingClientRect();
                this.input.touches.set(touch.identifier, {
                    x: (touch.clientX - rect.left) * (this.renderer.baseWidth / rect.width),
                    y: (touch.clientY - rect.top) * (this.renderer.baseHeight / rect.height)
                });
            }
            this.onTouchMove(e);
        });
        
        this.canvas.addEventListener('touchend', (e) => {
            e.preventDefault();
            for (const touch of e.changedTouches) {
                this.input.touches.delete(touch.identifier);
            }
            this.onTouchEnd(e);
        });
    }

    /**
     * Input event handlers (to be overridden)
     */
    onKeyDown(e) {}
    onKeyUp(e) {}
    onMouseMove(e) {}
    onMouseDown(e) {}
    onMouseUp(e) {}
    onTouchStart(e) {}
    onTouchMove(e) {}
    onTouchEnd(e) {}

    /**
     * Check if a key is pressed
     */
    isKeyPressed(keyCode) {
        return this.input.keys.has(keyCode);
    }

    /**
     * Check if mouse button is pressed
     */
    isMouseButtonPressed(button) {
        return this.input.mouse.buttons.has(button);
    }

    /**
     * Start the game loop
     */
    start() {
        if (this.running) return;
        
        this.running = true;
        this.lastFrameTime = performance.now();
        this.gameLoop(this.lastFrameTime);
        
        console.log('Game loop started');
    }

    /**
     * Stop the game loop
     */
    stop() {
        this.running = false;
        console.log('Game loop stopped');
    }

    /**
     * Pause/unpause the game
     */
    togglePause() {
        this.paused = !this.paused;
    }

    /**
     * Main game loop with fixed timestep
     */
    gameLoop(currentTime) {
        if (!this.running) return;
        
        // Request next frame
        requestAnimationFrame((time) => this.gameLoop(time));
        
        // Calculate delta time
        const frameTime = currentTime - this.lastFrameTime;
        this.lastFrameTime = currentTime;
        
        // Update FPS counter
        this.updateFPS(currentTime);
        
        // Accumulate time
        this.accumulator += frameTime;
        
        // Fixed timestep updates
        while (this.accumulator >= this.targetFrameTime) {
            if (!this.paused) {
                this.update(this.deltaTime * this.timeScale);
            }
            this.accumulator -= this.targetFrameTime;
        }
        
        // Render
        this.render();
    }

    /**
     * Update FPS counter
     */
    updateFPS(currentTime) {
        this.frameCount++;
        
        if (currentTime - this.fpsUpdateTime >= 1000) {
            this.fps = this.frameCount;
            this.frameCount = 0;
            this.fpsUpdateTime = currentTime;
        }
    }

    /**
     * Update game state
     */
    update(deltaTime) {
        // Update camera
        this.updateCamera(deltaTime);
        
        // Update entity manager and all systems
        this.entityManager.update(deltaTime);
        
        // Call custom update
        this.onUpdate(deltaTime);
    }

    /**
     * Update camera position with smoothing
     */
    updateCamera(deltaTime) {
        const dx = this.camera.targetX - this.camera.x;
        const dy = this.camera.targetY - this.camera.y;
        
        this.camera.x += dx * this.camera.smoothing;
        this.camera.y += dy * this.camera.smoothing;
    }

    /**
     * Set camera target
     */
    setCameraTarget(x, y) {
        this.camera.targetX = x;
        this.camera.targetY = y;
    }

    /**
     * Render game state
     */
    render() {
        // Begin frame
        this.renderer.beginFrame();
        
        // Call custom render
        this.onRender();
        
        // Draw FPS counter (debug)
        if (this.showDebug) {
            this.renderer.drawText(`FPS: ${this.fps}`, 10, 10, RETRO_PALETTE.statusBlue, 12);
        }
        
        // End frame
        this.renderer.endFrame();
    }

    /**
     * Custom update (to be overridden)
     */
    onUpdate(deltaTime) {}

    /**
     * Custom render (to be overridden)
     */
    onRender() {}

    /**
     * Set time scale (for slow motion, fast forward, etc.)
     */
    setTimeScale(scale) {
        this.timeScale = Math.max(0, scale);
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = GameEngine;
}

