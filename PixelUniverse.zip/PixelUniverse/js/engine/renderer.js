/**
 * PixelVerse - Pixel-Perfect Rendering Engine
 * Maintains authentic 16-bit aesthetics with strict pixel-perfect rendering
 */

class PixelRenderer {
    constructor(canvas) {
        this.canvas = canvas;
        this.context = canvas.getContext('2d');
        
        // Critical for pixel art - disable image smoothing
        this.context.imageSmoothingEnabled = false;
        this.context.mozImageSmoothingEnabled = false;
        this.context.webkitImageSmoothingEnabled = false;
        this.context.msImageSmoothingEnabled = false;
        
        // Base resolution (16:9 aspect ratio)
        this.baseWidth = 1920;
        this.baseHeight = 1080;
        
        // Current scale factor
        this.scale = 1;
        
        // Viewport configuration
        this.viewport = {
            x: 160,
            y: 0,
            width: 1600,
            height: 900
        };
        
        // Cockpit UI configuration
        this.cockpit = {
            bottomBar: {
                x: 0,
                y: 900,
                width: 1920,
                height: 180
            }
        };
        
        // Depth buffer for layered rendering
        this.depthBuffer = new Float32Array(this.baseWidth * this.baseHeight);
        
        // Sprite cache
        this.spriteCache = new Map();
        
        // Initialize canvas
        this.initializeCanvas();
    }

    /**
     * Initialize canvas with proper dimensions and scaling
     */
    initializeCanvas() {
        // Set canvas internal resolution
        this.canvas.width = this.baseWidth;
        this.canvas.height = this.baseHeight;
        
        // Calculate scale based on window size
        this.updateScale();
        
        // Apply CSS for pixel-perfect rendering
        this.canvas.style.imageRendering = 'pixelated';
        this.canvas.style.imageRendering = '-moz-crisp-edges';
        this.canvas.style.imageRendering = '-webkit-crisp-edges';
        
        // Handle window resize
        window.addEventListener('resize', () => this.updateScale());
    }

    /**
     * Update scale factor based on window size
     */
    updateScale() {
        const windowWidth = window.innerWidth;
        const windowHeight = window.innerHeight;
        
        // Calculate scale to fit window while maintaining aspect ratio
        const scaleX = windowWidth / this.baseWidth;
        const scaleY = windowHeight / this.baseHeight;
        this.scale = Math.floor(Math.min(scaleX, scaleY) * 100) / 100; // Round to 2 decimals
        
        // Apply integer scaling for pixel-perfect display
        const integerScale = Math.max(1, Math.floor(this.scale));
        
        // Set canvas display size
        this.canvas.style.width = (this.baseWidth * integerScale) + 'px';
        this.canvas.style.height = (this.baseHeight * integerScale) + 'px';
    }

    /**
     * Clear the entire canvas
     */
    clear(color = RETRO_PALETTE.deepBlack) {
        this.context.fillStyle = color;
        this.context.fillRect(0, 0, this.baseWidth, this.baseHeight);
    }

    /**
     * Clear a specific region
     */
    clearRegion(x, y, width, height, color = RETRO_PALETTE.deepBlack) {
        this.context.fillStyle = color;
        this.context.fillRect(Math.floor(x), Math.floor(y), Math.floor(width), Math.floor(height));
    }

    /**
     * Render a sprite with pixel-perfect positioning
     */
    renderSprite(sprite, x, y, scale = 1, alpha = 1) {
        if (!sprite || !sprite.image) return;
        
        // Ensure pixel-perfect positioning (integer coordinates only)
        const renderX = Math.floor(x);
        const renderY = Math.floor(y);
        const scaledWidth = Math.floor(sprite.width * scale);
        const scaledHeight = Math.floor(sprite.height * scale);
        
        // Apply alpha if needed
        const previousAlpha = this.context.globalAlpha;
        if (alpha < 1) {
            this.context.globalAlpha = alpha;
        }
        
        // Render using nearest-neighbor interpolation
        this.context.drawImage(
            sprite.image,
            renderX,
            renderY,
            scaledWidth,
            scaledHeight
        );
        
        // Restore alpha
        this.context.globalAlpha = previousAlpha;
    }

    /**
     * Draw a pixel-perfect rectangle
     */
    drawRect(x, y, width, height, color, filled = true) {
        this.context.fillStyle = color;
        this.context.strokeStyle = color;
        
        const renderX = Math.floor(x);
        const renderY = Math.floor(y);
        const renderWidth = Math.floor(width);
        const renderHeight = Math.floor(height);
        
        if (filled) {
            this.context.fillRect(renderX, renderY, renderWidth, renderHeight);
        } else {
            this.context.strokeRect(renderX, renderY, renderWidth, renderHeight);
        }
    }

    /**
     * Draw a pixel-perfect line
     */
    drawLine(x1, y1, x2, y2, color, width = 1) {
        this.context.strokeStyle = color;
        this.context.lineWidth = Math.floor(width);
        
        this.context.beginPath();
        this.context.moveTo(Math.floor(x1), Math.floor(y1));
        this.context.lineTo(Math.floor(x2), Math.floor(y2));
        this.context.stroke();
    }

    /**
     * Draw a single pixel
     */
    drawPixel(x, y, color) {
        this.context.fillStyle = color;
        this.context.fillRect(Math.floor(x), Math.floor(y), 1, 1);
    }

    /**
     * Draw text with custom DigitalDisco font
     */
    drawText(text, x, y, color = RETRO_PALETTE.brightGray, size = 8) {
        this.context.fillStyle = color;
        this.context.font = `${size}px "DigitalDisco", "Courier New", monospace`;
        this.context.textBaseline = 'top';
        this.context.fillText(text, Math.floor(x), Math.floor(y));
    }

    /**
     * Draw the cockpit frame
     */
    drawCockpitFrame() {
        // Left panel
        this.drawRect(0, 0, this.viewport.x, this.baseHeight, RETRO_PALETTE.hullPrimary);
        
        // Right panel
        const rightPanelX = this.viewport.x + this.viewport.width;
        this.drawRect(rightPanelX, 0, this.baseWidth - rightPanelX, this.baseHeight, RETRO_PALETTE.hullPrimary);
        
        // Bottom control bar
        this.drawRect(
            this.cockpit.bottomBar.x,
            this.cockpit.bottomBar.y,
            this.cockpit.bottomBar.width,
            this.cockpit.bottomBar.height,
            RETRO_PALETTE.darkGray
        );
        
        // Add panel details
        this.addCockpitDetails();
    }

    /**
     * Add decorative details to cockpit
     */
    addCockpitDetails() {
        // Panel lines on left side
        for (let i = 0; i < 10; i++) {
            const y = i * 100;
            this.drawLine(0, y, this.viewport.x, y, RETRO_PALETTE.hullShadow, 1);
        }
        
        // Panel lines on bottom bar
        for (let i = 0; i < 5; i++) {
            const x = i * 384;
            this.drawLine(x, this.cockpit.bottomBar.y, x, this.baseHeight, RETRO_PALETTE.shadowGray, 2);
        }
        
        // Viewport frame
        this.drawRect(
            this.viewport.x - 2,
            this.viewport.y - 2,
            this.viewport.width + 4,
            this.viewport.height + 4,
            RETRO_PALETTE.brightGray,
            false
        );
    }

    /**
     * Begin a new frame
     */
    beginFrame() {
        // Clear the entire canvas first
        this.context.fillStyle = RETRO_PALETTE.voidBlack;
        this.context.fillRect(0, 0, this.baseWidth, this.baseHeight);

        // Draw cockpit frame (will be drawn over by background in viewport area)
        this.drawCockpitFrame();
    }

    /**
     * End the current frame
     */
    endFrame() {
        // Apply scanline effect (optional)
        // this.applyScanlines();
    }

    /**
     * Apply CRT scanline effect
     */
    applyScanlines() {
        this.context.globalAlpha = 0.1;
        for (let y = 0; y < this.baseHeight; y += 2) {
            this.drawLine(0, y, this.baseWidth, y, RETRO_PALETTE.deepBlack, 1);
        }
        this.context.globalAlpha = 1.0;
    }

    /**
     * Get viewport coordinates (for rendering game objects)
     * Camera position should be at the CENTER of the viewport
     */
    getViewportCoords(worldX, worldY, cameraX, cameraY) {
        // Calculate viewport center
        const viewportCenterX = this.viewport.x + this.viewport.width / 2;
        const viewportCenterY = this.viewport.y + this.viewport.height / 2;

        // Calculate position relative to camera, then offset to viewport center
        return {
            x: viewportCenterX + (worldX - cameraX),
            y: viewportCenterY + (worldY - cameraY)
        };
    }

    /**
     * Check if coordinates are within viewport
     */
    isInViewport(x, y) {
        return x >= this.viewport.x && 
               x < this.viewport.x + this.viewport.width &&
               y >= this.viewport.y && 
               y < this.viewport.y + this.viewport.height;
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = PixelRenderer;
}

