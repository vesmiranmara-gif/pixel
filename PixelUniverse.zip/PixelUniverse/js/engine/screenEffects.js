/**
 * PixelVerse - Screen Effects System
 * Retro CRT effects, damage overlays, and visual polish
 * Inspired by 1970s-80s sci-fi aesthetic
 */

class ScreenEffects {
    constructor(renderer) {
        this.renderer = renderer;
        
        // Effect toggles
        this.effects = {
            scanlines: true,
            phosphorGlow: false,
            screenCurvature: false,
            vignette: true,
            damageStatic: false,
            chromatic: false
        };
        
        // Damage state
        this.damageLevel = 0; // 0-1
        this.staticIntensity = 0;
        this.flickerTimer = 0;
        
        // Animation
        this.scanlineOffset = 0;
        this.glitchTimer = 0;
    }

    /**
     * Update effects (called each frame)
     */
    update(deltaTime) {
        this.scanlineOffset += deltaTime * 60;
        if (this.scanlineOffset > 2) this.scanlineOffset = 0;
        
        this.glitchTimer += deltaTime;
        this.flickerTimer += deltaTime;
        
        // Update damage effects
        if (this.damageLevel > 0) {
            this.staticIntensity = this.damageLevel * 0.3;
        }
    }

    /**
     * Set damage level (0-1)
     */
    setDamageLevel(level) {
        this.damageLevel = Math.max(0, Math.min(1, level));
        this.effects.damageStatic = this.damageLevel > 0.3;
    }

    /**
     * Apply all enabled screen effects
     */
    applyEffects() {
        const ctx = this.renderer.context;
        
        if (this.effects.scanlines) {
            this.applyScanlines();
        }
        
        if (this.effects.phosphorGlow) {
            this.applyPhosphorGlow();
        }
        
        if (this.effects.vignette) {
            this.applyVignette();
        }
        
        if (this.effects.damageStatic && this.damageLevel > 0) {
            this.applyDamageStatic();
        }
        
        if (this.damageLevel > 0.5) {
            this.applyDamageFlicker();
        }
    }

    /**
     * CRT Scanlines - subtle horizontal lines
     */
    applyScanlines() {
        const ctx = this.renderer.context;
        const width = this.renderer.baseWidth;
        const height = this.renderer.baseHeight;
        
        ctx.globalAlpha = 0.08;
        ctx.fillStyle = RETRO_PALETTE.voidBlack;
        
        for (let y = Math.floor(this.scanlineOffset); y < height; y += 2) {
            ctx.fillRect(0, y, width, 1);
        }
        
        ctx.globalAlpha = 1.0;
    }

    /**
     * Phosphor glow - warm CRT glow effect
     */
    applyPhosphorGlow() {
        const ctx = this.renderer.context;
        const width = this.renderer.baseWidth;
        const height = this.renderer.baseHeight;
        
        // Create subtle warm glow
        ctx.globalCompositeOperation = 'screen';
        ctx.globalAlpha = 0.03;
        ctx.fillStyle = RETRO_PALETTE.vintageAmber;
        ctx.fillRect(0, 0, width, height);
        
        ctx.globalCompositeOperation = 'source-over';
        ctx.globalAlpha = 1.0;
    }

    /**
     * Vignette - darker edges
     */
    applyVignette() {
        const ctx = this.renderer.context;
        const width = this.renderer.baseWidth;
        const height = this.renderer.baseHeight;
        const cx = width / 2;
        const cy = height / 2;
        
        // Create radial gradient
        const gradient = ctx.createRadialGradient(cx, cy, height * 0.3, cx, cy, height * 0.7);
        gradient.addColorStop(0, 'rgba(0, 0, 0, 0)');
        gradient.addColorStop(1, 'rgba(0, 0, 0, 0.4)');
        
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, width, height);
    }

    /**
     * Damage static - TV interference when damaged
     */
    applyDamageStatic() {
        const ctx = this.renderer.context;
        const width = this.renderer.baseWidth;
        const height = this.renderer.baseHeight;
        
        // Random static pixels
        const pixelCount = Math.floor(width * height * this.staticIntensity * 0.01);
        
        for (let i = 0; i < pixelCount; i++) {
            const x = Math.floor(Math.random() * width);
            const y = Math.floor(Math.random() * height);
            const brightness = Math.random();
            
            if (brightness > 0.5) {
                ctx.fillStyle = RETRO_PALETTE.paleGray;
            } else {
                ctx.fillStyle = RETRO_PALETTE.darkGray;
            }
            
            ctx.fillRect(x, y, 1, 1);
        }
        
        // Horizontal glitch lines
        if (Math.random() < this.damageLevel * 0.3) {
            const glitchY = Math.floor(Math.random() * height);
            const glitchHeight = 2 + Math.floor(Math.random() * 4);
            
            ctx.globalAlpha = 0.5;
            ctx.fillStyle = RETRO_PALETTE.alertRed;
            ctx.fillRect(0, glitchY, width, glitchHeight);
            ctx.globalAlpha = 1.0;
        }
    }

    /**
     * Damage flicker - screen flickers when heavily damaged
     */
    applyDamageFlicker() {
        if (Math.sin(this.flickerTimer * 20) > 0.7) {
            const ctx = this.renderer.context;
            const width = this.renderer.baseWidth;
            const height = this.renderer.baseHeight;
            
            ctx.globalAlpha = 0.1;
            ctx.fillStyle = RETRO_PALETTE.alertRed;
            ctx.fillRect(0, 0, width, height);
            ctx.globalAlpha = 1.0;
        }
    }

    /**
     * Flash effect - bright flash (for explosions, impacts)
     */
    flash(color = RETRO_PALETTE.pureWhite, intensity = 0.5, duration = 0.1) {
        const ctx = this.renderer.context;
        const width = this.renderer.baseWidth;
        const height = this.renderer.baseHeight;
        
        ctx.globalAlpha = intensity;
        ctx.fillStyle = color;
        ctx.fillRect(0, 0, width, height);
        ctx.globalAlpha = 1.0;
    }

    /**
     * Warp effect - screen distortion during warp
     */
    applyWarpEffect(intensity = 1.0) {
        const ctx = this.renderer.context;
        const width = this.renderer.baseWidth;
        const height = this.renderer.baseHeight;
        
        // Motion blur lines
        ctx.globalAlpha = 0.3 * intensity;
        ctx.strokeStyle = RETRO_PALETTE.statusBlue;
        ctx.lineWidth = 2;
        
        for (let i = 0; i < 20; i++) {
            const y = Math.random() * height;
            const length = 100 + Math.random() * 200;
            
            ctx.beginPath();
            ctx.moveTo(width / 2 - length / 2, y);
            ctx.lineTo(width / 2 + length / 2, y);
            ctx.stroke();
        }
        
        ctx.globalAlpha = 1.0;
    }

    /**
     * Shield hit effect - blue flash
     */
    shieldHit(x, y) {
        const ctx = this.renderer.context;
        
        // Convert world to screen coordinates
        const screenX = x;
        const screenY = y;
        
        // Radial flash
        ctx.globalAlpha = 0.5;
        const gradient = ctx.createRadialGradient(screenX, screenY, 0, screenX, screenY, 50);
        gradient.addColorStop(0, RETRO_PALETTE.pureWhite);
        gradient.addColorStop(0.5, RETRO_PALETTE.statusBlue);
        gradient.addColorStop(1, 'rgba(51, 102, 153, 0)');
        
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(screenX, screenY, 50, 0, Math.PI * 2);
        ctx.fill();
        
        ctx.globalAlpha = 1.0;
    }

    /**
     * Toggle effect on/off
     */
    toggleEffect(effectName) {
        if (this.effects.hasOwnProperty(effectName)) {
            this.effects[effectName] = !this.effects[effectName];
        }
    }

    /**
     * Enable effect
     */
    enableEffect(effectName) {
        if (this.effects.hasOwnProperty(effectName)) {
            this.effects[effectName] = true;
        }
    }

    /**
     * Disable effect
     */
    disableEffect(effectName) {
        if (this.effects.hasOwnProperty(effectName)) {
            this.effects[effectName] = false;
        }
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ScreenEffects;
}

