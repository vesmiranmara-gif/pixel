/**
 * PixelVerse - Physics Engine
 * Newtonian physics with orbital mechanics and realistic space flight
 */

class PhysicsSystem extends System {
    constructor() {
        super();
        this.gravity = 0; // No global gravity in space
        this.gravityWells = []; // Celestial bodies with gravity
    }

    update(deltaTime) {
        if (!this.entityManager) return;
        
        // Get all entities with physics
        const entities = this.entityManager.getEntitiesWithComponents('transform', 'velocity', 'physics');
        
        for (const entity of entities) {
            const transform = entity.getComponent('transform');
            const velocity = entity.getComponent('velocity');
            const physics = entity.getComponent('physics');
            
            // Apply forces
            this.applyForces(transform, velocity, physics, deltaTime);
            
            // Apply gravity wells
            this.applyGravityWells(transform, velocity, physics, deltaTime);
            
            // Apply drag
            this.applyDrag(velocity, physics, deltaTime);
            
            // Update position based on velocity
            transform.x += velocity.vx * deltaTime;
            transform.y += velocity.vy * deltaTime;
            transform.rotation += velocity.angularVelocity * deltaTime;
            
            // Clear forces for next frame
            physics.clearForces();
        }
    }

    /**
     * Apply accumulated forces to velocity
     */
    applyForces(transform, velocity, physics, deltaTime) {
        for (const force of physics.forces) {
            const ax = force.fx / physics.mass;
            const ay = force.fy / physics.mass;
            
            velocity.vx += ax * deltaTime;
            velocity.vy += ay * deltaTime;
        }
    }

    /**
     * Apply gravity from celestial bodies
     */
    applyGravityWells(transform, velocity, physics, deltaTime) {
        for (const well of this.gravityWells) {
            const dx = well.x - transform.x;
            const dy = well.y - transform.y;
            const distanceSquared = dx * dx + dy * dy;
            const distance = Math.sqrt(distanceSquared);
            
            if (distance < well.radius) {
                // Calculate gravitational force
                // F = G * m1 * m2 / r^2
                const forceMagnitude = well.mass / distanceSquared;
                
                // Normalize direction
                const forceX = (dx / distance) * forceMagnitude;
                const forceY = (dy / distance) * forceMagnitude;
                
                // Apply to velocity
                velocity.vx += forceX * deltaTime;
                velocity.vy += forceY * deltaTime;
            }
        }
    }

    /**
     * Apply drag (space friction)
     */
    applyDrag(velocity, physics, deltaTime) {
        const dragFactor = 1 - (physics.drag * deltaTime);
        velocity.vx *= dragFactor;
        velocity.vy *= dragFactor;
        velocity.angularVelocity *= dragFactor;
    }

    /**
     * Add a gravity well (planet, star, etc.)
     */
    addGravityWell(x, y, mass, radius) {
        this.gravityWells.push({ x, y, mass, radius });
    }

    /**
     * Remove all gravity wells
     */
    clearGravityWells() {
        this.gravityWells = [];
    }
}

/**
 * Collision Detection System
 */
class CollisionSystem extends System {
    constructor() {
        super();
        this.collisions = [];
    }

    update(deltaTime) {
        if (!this.entityManager) return;
        
        this.collisions = [];
        
        // Get all entities with collision
        const entities = this.entityManager.getEntitiesWithComponents('transform', 'collision');
        
        // Broad phase - check all pairs
        for (let i = 0; i < entities.length; i++) {
            for (let j = i + 1; j < entities.length; j++) {
                const entityA = entities[i];
                const entityB = entities[j];
                
                if (this.checkCollision(entityA, entityB)) {
                    this.collisions.push({ entityA, entityB });
                    this.resolveCollision(entityA, entityB);
                }
            }
        }
    }

    /**
     * Check if two entities are colliding
     */
    checkCollision(entityA, entityB) {
        const transformA = entityA.getComponent('transform');
        const transformB = entityB.getComponent('transform');
        const collisionA = entityA.getComponent('collision');
        const collisionB = entityB.getComponent('collision');
        
        // Circle-circle collision
        if (collisionA.type === 'circle' && collisionB.type === 'circle') {
            const dx = transformB.x - transformA.x;
            const dy = transformB.y - transformA.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            const minDistance = collisionA.radius + collisionB.radius;
            
            return distance < minDistance;
        }
        
        return false;
    }

    /**
     * Resolve collision between two entities
     */
    resolveCollision(entityA, entityB) {
        const collisionA = entityA.getComponent('collision');
        const collisionB = entityB.getComponent('collision');
        
        // Call collision callbacks
        if (collisionA.onCollision) {
            collisionA.onCollision(entityB);
        }
        
        if (collisionB.onCollision) {
            collisionB.onCollision(entityA);
        }
        
        // Apply physics response if both have velocity
        if (entityA.hasComponent('velocity') && entityB.hasComponent('velocity')) {
            this.applyPhysicsResponse(entityA, entityB);
        }
    }

    /**
     * Apply physics response to collision
     */
    applyPhysicsResponse(entityA, entityB) {
        const transformA = entityA.getComponent('transform');
        const transformB = entityB.getComponent('transform');
        const velocityA = entityA.getComponent('velocity');
        const velocityB = entityB.getComponent('velocity');
        const physicsA = entityA.getComponent('physics');
        const physicsB = entityB.getComponent('physics');
        
        if (!physicsA || !physicsB) return;
        
        // Calculate collision normal
        const dx = transformB.x - transformA.x;
        const dy = transformB.y - transformA.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance === 0) return;
        
        const nx = dx / distance;
        const ny = dy / distance;
        
        // Relative velocity
        const dvx = velocityB.vx - velocityA.vx;
        const dvy = velocityB.vy - velocityA.vy;
        
        // Relative velocity in collision normal direction
        const velocityAlongNormal = dvx * nx + dvy * ny;
        
        // Don't resolve if velocities are separating
        if (velocityAlongNormal > 0) return;
        
        // Calculate restitution (bounciness)
        const restitution = 0.5;
        
        // Calculate impulse scalar
        const impulse = -(1 + restitution) * velocityAlongNormal;
        const impulseMagnitude = impulse / (1 / physicsA.mass + 1 / physicsB.mass);
        
        // Apply impulse
        const impulseX = impulseMagnitude * nx;
        const impulseY = impulseMagnitude * ny;
        
        velocityA.vx -= impulseX / physicsA.mass;
        velocityA.vy -= impulseY / physicsA.mass;
        velocityB.vx += impulseX / physicsB.mass;
        velocityB.vy += impulseY / physicsB.mass;
    }
}

/**
 * Orbital Mechanics Helper
 */
class OrbitalMechanics {
    /**
     * Calculate orbital velocity for circular orbit
     */
    static getOrbitalVelocity(centralMass, radius) {
        return Math.sqrt(centralMass / radius);
    }

    /**
     * Calculate escape velocity
     */
    static getEscapeVelocity(centralMass, radius) {
        return Math.sqrt(2 * centralMass / radius);
    }

    /**
     * Calculate orbital period
     */
    static getOrbitalPeriod(centralMass, radius) {
        return 2 * Math.PI * Math.sqrt(Math.pow(radius, 3) / centralMass);
    }

    /**
     * Predict orbital path
     */
    static predictOrbit(x, y, vx, vy, centralX, centralY, centralMass, steps = 100, timeStep = 0.1) {
        const path = [];
        let px = x;
        let py = y;
        let pvx = vx;
        let pvy = vy;
        
        for (let i = 0; i < steps; i++) {
            path.push({ x: px, y: py });
            
            // Calculate gravity
            const dx = centralX - px;
            const dy = centralY - py;
            const distanceSquared = dx * dx + dy * dy;
            const distance = Math.sqrt(distanceSquared);
            
            const forceMagnitude = centralMass / distanceSquared;
            const forceX = (dx / distance) * forceMagnitude;
            const forceY = (dy / distance) * forceMagnitude;
            
            // Update velocity
            pvx += forceX * timeStep;
            pvy += forceY * timeStep;
            
            // Update position
            px += pvx * timeStep;
            py += pvy * timeStep;
        }
        
        return path;
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        PhysicsSystem,
        CollisionSystem,
        OrbitalMechanics
    };
}

