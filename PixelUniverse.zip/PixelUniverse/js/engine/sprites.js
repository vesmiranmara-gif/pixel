/**
 * PixelVerse - Sprite Management System
 * Handles sprite loading, caching, and rendering with pixel-perfect precision
 */

class Sprite {
    constructor(name, width, height) {
        this.name = name;
        this.width = width;
        this.height = height;
        this.image = null;
        this.canvas = null;
        this.context = null;
        this.loaded = false;
        this.frames = [];
        this.currentFrame = 0;
    }

    /**
     * Create sprite from canvas
     */
    createFromCanvas(width, height) {
        this.canvas = document.createElement('canvas');
        this.canvas.width = width;
        this.canvas.height = height;
        this.context = this.canvas.getContext('2d');
        this.context.imageSmoothingEnabled = false;
        this.image = this.canvas;
        this.loaded = true;
        return this.context;
    }

    /**
     * Load sprite from image file
     */
    async loadFromFile(url) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            img.onload = () => {
                this.image = img;
                this.width = img.width;
                this.height = img.height;
                this.loaded = true;
                resolve(this);
            };
            img.onerror = reject;
            img.src = url;
        });
    }

    /**
     * Add animation frame
     */
    addFrame(frameData) {
        this.frames.push(frameData);
    }

    /**
     * Get current frame
     */
    getFrame() {
        if (this.frames.length === 0) return this;
        return this.frames[this.currentFrame];
    }

    /**
     * Advance to next frame
     */
    nextFrame() {
        if (this.frames.length === 0) return;
        this.currentFrame = (this.currentFrame + 1) % this.frames.length;
    }

    /**
     * Set specific frame
     */
    setFrame(index) {
        if (index >= 0 && index < this.frames.length) {
            this.currentFrame = index;
        }
    }
}

class SpriteManager {
    constructor() {
        this.sprites = new Map();
        this.loading = new Set();
    }

    /**
     * Create a new sprite
     */
    createSprite(name, width, height) {
        const sprite = new Sprite(name, width, height);
        this.sprites.set(name, sprite);
        return sprite;
    }

    /**
     * Load sprite from file
     */
    async loadSprite(name, url) {
        if (this.sprites.has(name)) {
            return this.sprites.get(name);
        }

        if (this.loading.has(name)) {
            // Wait for existing load
            while (this.loading.has(name)) {
                await new Promise(resolve => setTimeout(resolve, 10));
            }
            return this.sprites.get(name);
        }

        this.loading.add(name);
        
        try {
            const sprite = new Sprite(name, 0, 0);
            await sprite.loadFromFile(url);
            this.sprites.set(name, sprite);
            return sprite;
        } finally {
            this.loading.delete(name);
        }
    }

    /**
     * Get sprite by name
     */
    getSprite(name) {
        return this.sprites.get(name);
    }

    /**
     * Check if sprite exists
     */
    hasSprite(name) {
        return this.sprites.has(name);
    }

    /**
     * Remove sprite
     */
    removeSprite(name) {
        this.sprites.delete(name);
    }

    /**
     * Clear all sprites
     */
    clear() {
        this.sprites.clear();
    }
}

/**
 * Procedural Sprite Generator
 * Creates pixel-perfect sprites programmatically
 */
class SpriteGenerator {
    /**
     * Draw a pixel
     */
    static drawPixel(ctx, x, y, color) {
        ctx.fillStyle = color;
        ctx.fillRect(Math.floor(x), Math.floor(y), 1, 1);
    }

    /**
     * Draw a line
     */
    static drawLine(ctx, x1, y1, x2, y2, color) {
        ctx.strokeStyle = color;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(Math.floor(x1), Math.floor(y1));
        ctx.lineTo(Math.floor(x2), Math.floor(y2));
        ctx.stroke();
    }

    /**
     * Draw a rectangle
     */
    static drawRect(ctx, x, y, width, height, color, filled = true) {
        ctx.fillStyle = color;
        ctx.strokeStyle = color;
        
        const rx = Math.floor(x);
        const ry = Math.floor(y);
        const rw = Math.floor(width);
        const rh = Math.floor(height);
        
        if (filled) {
            ctx.fillRect(rx, ry, rw, rh);
        } else {
            ctx.strokeRect(rx, ry, rw, rh);
        }
    }

    /**
     * Apply hard shadow (1px down-right)
     */
    static applyHardShadow(ctx, x, y, width, height, baseColor, shadowColor) {
        // Draw shadow offset
        this.drawRect(ctx, x + 1, y + 1, width, height, shadowColor);
        // Draw main shape
        this.drawRect(ctx, x, y, width, height, baseColor);
    }

    /**
     * Create dithering pattern
     */
    static drawDither(ctx, x, y, width, height, color1, color2) {
        for (let dy = 0; dy < height; dy++) {
            for (let dx = 0; dx < width; dx++) {
                const color = ((dx + dy) % 2 === 0) ? color1 : color2;
                this.drawPixel(ctx, x + dx, y + dy, color);
            }
        }
    }

    /**
     * Draw isometric block (8x8 base)
     */
    static drawIsometricBlock(ctx, x, y, size, topColor, leftColor, rightColor) {
        const halfSize = size / 2;
        
        // Top face (diamond)
        ctx.fillStyle = topColor;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + halfSize, y + halfSize / 2);
        ctx.lineTo(x, y + halfSize);
        ctx.lineTo(x - halfSize, y + halfSize / 2);
        ctx.closePath();
        ctx.fill();
        
        // Left face
        ctx.fillStyle = leftColor;
        ctx.beginPath();
        ctx.moveTo(x - halfSize, y + halfSize / 2);
        ctx.lineTo(x, y + halfSize);
        ctx.lineTo(x, y + size);
        ctx.lineTo(x - halfSize, y + size - halfSize / 2);
        ctx.closePath();
        ctx.fill();
        
        // Right face
        ctx.fillStyle = rightColor;
        ctx.beginPath();
        ctx.moveTo(x + halfSize, y + halfSize / 2);
        ctx.lineTo(x, y + halfSize);
        ctx.lineTo(x, y + size);
        ctx.lineTo(x + halfSize, y + size - halfSize / 2);
        ctx.closePath();
        ctx.fill();
    }

    /**
     * Add panel lines (seams)
     */
    static addPanelLines(ctx, x, y, width, height, spacing, color) {
        // Vertical lines
        for (let dx = spacing; dx < width; dx += spacing) {
            this.drawLine(ctx, x + dx, y, x + dx, y + height, color);
        }
        
        // Horizontal lines
        for (let dy = spacing; dy < height; dy += spacing) {
            this.drawLine(ctx, x, y + dy, x + width, y + dy, color);
        }
    }

    /**
     * Add greeble details (small functional elements)
     */
    static addGreeble(ctx, x, y, type, size = 2) {
        switch (type) {
            case 'sensor':
                // Small rectangular cluster with center dot
                this.drawRect(ctx, x, y, size, size, RETRO_PALETTE.hullAccent);
                this.drawPixel(ctx, x + Math.floor(size / 2), y + Math.floor(size / 2), RETRO_PALETTE.brightGray);
                break;
                
            case 'hatch':
                // Square panel with cross-hatch
                this.drawRect(ctx, x, y, size, size, RETRO_PALETTE.hullSecondary);
                this.drawLine(ctx, x, y, x + size, y + size, RETRO_PALETTE.darkGray);
                this.drawLine(ctx, x + size, y, x, y + size, RETRO_PALETTE.darkGray);
                break;
                
            case 'vent':
                // Rectangular opening with bars
                this.drawRect(ctx, x, y, size, size, RETRO_PALETTE.voidBlack);
                for (let i = 1; i < size; i += 2) {
                    this.drawLine(ctx, x, y + i, x + size, y + i, RETRO_PALETTE.darkGray);
                }
                break;
                
            case 'light':
                // Single pixel indicator
                const colors = [RETRO_PALETTE.alertRed, RETRO_PALETTE.statusBlue, RETRO_PALETTE.cautionOrange];
                this.drawPixel(ctx, x, y, colors[Math.floor(Math.random() * colors.length)]);
                break;
        }
    }

    /**
     * Add wear and tear
     */
    static addWear(ctx, x, y, width, height, intensity = 0.1) {
        const pixels = Math.floor(width * height * intensity);
        
        for (let i = 0; i < pixels; i++) {
            const px = x + Math.floor(Math.random() * width);
            const py = y + Math.floor(Math.random() * height);
            
            const wearType = Math.random();
            if (wearType < 0.6) {
                // Scratch
                this.drawPixel(ctx, px, py, RETRO_PALETTE.shadowGray);
            } else if (wearType < 0.9) {
                // Scuff mark
                this.drawRect(ctx, px, py, 2, 2, RETRO_PALETTE.darkGray);
            } else {
                // Oil smear
                this.drawPixel(ctx, px, py, RETRO_PALETTE.vintageAmber);
            }
        }
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { Sprite, SpriteManager, SpriteGenerator };
}

