/**
 * PixelVerse - Performance Optimization System
 * Object pooling, culling, LOD, and performance monitoring
 */

class PerformanceOptimizer {
    constructor() {
        // Performance monitoring
        this.fps = 60;
        this.frameTime = 0;
        this.lastFrameTime = performance.now();
        this.frameCount = 0;
        this.fpsUpdateInterval = 1000; // Update FPS every second
        this.lastFpsUpdate = performance.now();
        
        // Object pooling
        this.pools = {
            particles: [],
            projectiles: [],
            effects: []
        };
        
        this.poolSizes = {
            particles: 1000,
            projectiles: 100,
            effects: 50
        };
        
        // Culling
        this.cullingEnabled = true;
        this.cullingMargin = 200; // Extra margin around viewport
        
        // LOD (Level of Detail)
        this.lodEnabled = true;
        this.lodDistances = {
            high: 500,
            medium: 1000,
            low: 2000
        };
        
        // Performance settings
        this.settings = {
            maxParticles: 500,
            maxProjectiles: 50,
            maxEntities: 100,
            particleLifetime: 2.0,
            enableShadows: false,
            enableGlow: true,
            enableScanlines: true,
            starDensity: 1.0 // Multiplier for star count
        };
        
        // Initialize pools
        this.initializePools();
    }

    /**
     * Initialize object pools
     */
    initializePools() {
        // Pre-allocate objects for pooling
        for (const poolName in this.poolSizes) {
            this.pools[poolName] = [];
        }
    }

    /**
     * Update performance monitoring
     */
    update(deltaTime) {
        const now = performance.now();
        
        // Calculate frame time
        this.frameTime = now - this.lastFrameTime;
        this.lastFrameTime = now;
        
        // Update FPS
        this.frameCount++;
        if (now - this.lastFpsUpdate >= this.fpsUpdateInterval) {
            this.fps = Math.round(this.frameCount * 1000 / (now - this.lastFpsUpdate));
            this.frameCount = 0;
            this.lastFpsUpdate = now;
            
            // Auto-adjust quality based on FPS
            this.autoAdjustQuality();
        }
    }

    /**
     * Auto-adjust quality settings based on FPS
     */
    autoAdjustQuality() {
        if (this.fps < 30) {
            // Low FPS - reduce quality
            this.settings.maxParticles = Math.max(100, this.settings.maxParticles - 50);
            this.settings.enableGlow = false;
            this.settings.starDensity = Math.max(0.5, this.settings.starDensity - 0.1);
            console.log('Performance: Reducing quality (FPS:', this.fps, ')');
        } else if (this.fps > 55 && this.settings.maxParticles < 500) {
            // Good FPS - can increase quality
            this.settings.maxParticles = Math.min(500, this.settings.maxParticles + 25);
            this.settings.enableGlow = true;
            this.settings.starDensity = Math.min(1.0, this.settings.starDensity + 0.05);
        }
    }

    /**
     * Check if object should be culled (not rendered)
     */
    shouldCull(x, y, viewport) {
        if (!this.cullingEnabled) return false;
        
        const margin = this.cullingMargin;
        return (
            x < viewport.x - margin ||
            x > viewport.x + viewport.width + margin ||
            y < viewport.y - margin ||
            y > viewport.y + viewport.height + margin
        );
    }

    /**
     * Get LOD level based on distance
     */
    getLODLevel(distance) {
        if (!this.lodEnabled) return 'high';
        
        if (distance < this.lodDistances.high) return 'high';
        if (distance < this.lodDistances.medium) return 'medium';
        if (distance < this.lodDistances.low) return 'low';
        return 'none'; // Don't render
    }

    /**
     * Get object from pool
     */
    getFromPool(poolName) {
        if (!this.pools[poolName]) return null;
        return this.pools[poolName].pop() || null;
    }

    /**
     * Return object to pool
     */
    returnToPool(poolName, object) {
        if (!this.pools[poolName]) return;
        if (this.pools[poolName].length < this.poolSizes[poolName]) {
            this.pools[poolName].push(object);
        }
    }

    /**
     * Get performance stats
     */
    getStats() {
        return {
            fps: this.fps,
            frameTime: this.frameTime.toFixed(2),
            maxParticles: this.settings.maxParticles,
            starDensity: this.settings.starDensity.toFixed(2),
            cullingEnabled: this.cullingEnabled,
            lodEnabled: this.lodEnabled
        };
    }

    /**
     * Set performance preset
     */
    setPreset(preset) {
        switch (preset) {
            case 'low':
                this.settings.maxParticles = 100;
                this.settings.maxProjectiles = 25;
                this.settings.enableGlow = false;
                this.settings.enableScanlines = false;
                this.settings.starDensity = 0.5;
                this.cullingEnabled = true;
                this.lodEnabled = true;
                break;
                
            case 'medium':
                this.settings.maxParticles = 300;
                this.settings.maxProjectiles = 40;
                this.settings.enableGlow = true;
                this.settings.enableScanlines = true;
                this.settings.starDensity = 0.75;
                this.cullingEnabled = true;
                this.lodEnabled = true;
                break;
                
            case 'high':
                this.settings.maxParticles = 500;
                this.settings.maxProjectiles = 50;
                this.settings.enableGlow = true;
                this.settings.enableScanlines = true;
                this.settings.starDensity = 1.0;
                this.cullingEnabled = true;
                this.lodEnabled = false;
                break;
                
            case 'ultra':
                this.settings.maxParticles = 1000;
                this.settings.maxProjectiles = 100;
                this.settings.enableGlow = true;
                this.settings.enableScanlines = true;
                this.settings.starDensity = 1.0;
                this.cullingEnabled = false;
                this.lodEnabled = false;
                break;
        }
        
        console.log('Performance preset set to:', preset);
    }
}

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = PerformanceOptimizer;
}

