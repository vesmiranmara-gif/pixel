/**
 * PixelVerse - Audio System
 * Comprehensive audio architecture for immersive retro-futuristic soundscape
 */

class AudioManager {
    constructor() {
        this.context = null;
        this.masterGain = null;
        this.musicGain = null;
        this.sfxGain = null;
        this.ambientGain = null;
        
        // Audio caches
        this.sounds = new Map();
        this.music = new Map();
        
        // Currently playing
        this.currentMusic = null;
        this.activeSounds = new Set();
        
        // Volume settings
        this.volumes = {
            master: 1.0,
            music: 0.7,
            sfx: 0.8,
            ambient: 0.5
        };
        
        // Spatial audio settings
        this.listenerPosition = { x: 0, y: 0 };
        
        this.initialized = false;
    }

    /**
     * Initialize audio context (deferred until user interaction)
     */
    async initialize() {
        // Don't create AudioContext yet - wait for user interaction
        // Just mark as ready to initialize
        console.log('Audio system ready (will initialize on first user interaction)');
    }

    /**
     * Actually create the AudioContext (called on first user interaction)
     */
    createContext() {
        if (this.initialized) return;

        try {
            // Create audio context
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            this.context = new AudioContext();

            // Create gain nodes
            this.masterGain = this.context.createGain();
            this.musicGain = this.context.createGain();
            this.sfxGain = this.context.createGain();
            this.ambientGain = this.context.createGain();

            // Connect gain nodes
            this.musicGain.connect(this.masterGain);
            this.sfxGain.connect(this.masterGain);
            this.ambientGain.connect(this.masterGain);
            this.masterGain.connect(this.context.destination);

            // Set initial volumes
            this.updateVolumes();

            this.initialized = true;
            console.log('Audio context created');
        } catch (error) {
            console.error('Failed to create audio context:', error);
        }
    }

    /**
     * Update volume levels
     */
    updateVolumes() {
        if (!this.initialized) return;
        
        this.masterGain.gain.value = this.volumes.master;
        this.musicGain.gain.value = this.volumes.music;
        this.sfxGain.gain.value = this.volumes.sfx;
        this.ambientGain.gain.value = this.volumes.ambient;
    }

    /**
     * Set volume for a specific channel
     */
    setVolume(channel, value) {
        this.volumes[channel] = Math.max(0, Math.min(1, value));
        this.updateVolumes();
    }

    /**
     * Load a sound file
     */
    async loadSound(name, url) {
        if (this.sounds.has(name)) return;
        
        try {
            const response = await fetch(url);
            const arrayBuffer = await response.arrayBuffer();
            const audioBuffer = await this.context.decodeAudioData(arrayBuffer);
            
            this.sounds.set(name, audioBuffer);
            console.log(`Loaded sound: ${name}`);
        } catch (error) {
            console.error(`Failed to load sound ${name}:`, error);
        }
    }

    /**
     * Play a sound effect
     */
    playSound(name, options = {}) {
        if (!this.initialized || !this.sounds.has(name)) return null;
        
        const buffer = this.sounds.get(name);
        const source = this.context.createBufferSource();
        source.buffer = buffer;
        
        // Create gain node for this sound
        const gainNode = this.context.createGain();
        gainNode.gain.value = options.volume || 1.0;
        
        // Spatial audio
        if (options.position) {
            const panner = this.context.createPanner();
            panner.panningModel = 'HRTF';
            panner.distanceModel = 'inverse';
            panner.refDistance = 100;
            panner.maxDistance = 10000;
            panner.rolloffFactor = 1;
            
            panner.setPosition(options.position.x, options.position.y, 0);
            
            source.connect(panner);
            panner.connect(gainNode);
        } else {
            source.connect(gainNode);
        }
        
        gainNode.connect(this.sfxGain);
        
        // Loop if specified
        source.loop = options.loop || false;
        
        // Play
        source.start(0);
        
        // Track active sound
        const soundInstance = {
            source,
            gainNode,
            name,
            startTime: this.context.currentTime
        };
        
        this.activeSounds.add(soundInstance);
        
        // Remove when finished
        source.onended = () => {
            this.activeSounds.delete(soundInstance);
        };
        
        return soundInstance;
    }

    /**
     * Stop a sound
     */
    stopSound(soundInstance) {
        if (soundInstance && soundInstance.source) {
            soundInstance.source.stop();
            this.activeSounds.delete(soundInstance);
        }
    }

    /**
     * Play music
     */
    async playMusic(name, fadeInTime = 1.0) {
        if (!this.initialized) return;
        
        // Stop current music
        if (this.currentMusic) {
            await this.stopMusic(1.0);
        }
        
        if (!this.music.has(name)) {
            console.warn(`Music ${name} not loaded`);
            return;
        }
        
        const buffer = this.music.get(name);
        const source = this.context.createBufferSource();
        source.buffer = buffer;
        source.loop = true;
        
        const gainNode = this.context.createGain();
        gainNode.gain.value = 0;
        
        source.connect(gainNode);
        gainNode.connect(this.musicGain);
        
        source.start(0);
        
        // Fade in
        gainNode.gain.linearRampToValueAtTime(1.0, this.context.currentTime + fadeInTime);
        
        this.currentMusic = {
            source,
            gainNode,
            name
        };
    }

    /**
     * Stop music
     */
    async stopMusic(fadeOutTime = 1.0) {
        if (!this.currentMusic) return;
        
        const music = this.currentMusic;
        this.currentMusic = null;
        
        // Fade out
        music.gainNode.gain.linearRampToValueAtTime(0, this.context.currentTime + fadeOutTime);
        
        // Stop after fade
        setTimeout(() => {
            music.source.stop();
        }, fadeOutTime * 1000);
    }

    /**
     * Create procedural sound (for retro effects)
     */
    createTone(frequency, duration, type = 'sine', volume = 0.3) {
        if (!this.initialized) return null;
        
        const oscillator = this.context.createOscillator();
        const gainNode = this.context.createGain();
        
        oscillator.type = type;
        oscillator.frequency.value = frequency;
        
        gainNode.gain.value = volume;
        gainNode.gain.exponentialRampToValueAtTime(0.01, this.context.currentTime + duration);
        
        oscillator.connect(gainNode);
        gainNode.connect(this.sfxGain);
        
        oscillator.start();
        oscillator.stop(this.context.currentTime + duration);
        
        return { oscillator, gainNode };
    }

    /**
     * Create engine sound (continuous)
     */
    createEngineSound(baseFrequency = 100, volume = 0.3) {
        if (!this.initialized) return null;
        
        const oscillator = this.context.createOscillator();
        const gainNode = this.context.createGain();
        const filter = this.context.createBiquadFilter();
        
        oscillator.type = 'sawtooth';
        oscillator.frequency.value = baseFrequency;
        
        filter.type = 'lowpass';
        filter.frequency.value = 500;
        
        gainNode.gain.value = volume;
        
        oscillator.connect(filter);
        filter.connect(gainNode);
        gainNode.connect(this.ambientGain);
        
        oscillator.start();
        
        return {
            oscillator,
            gainNode,
            filter,
            setThrottle: (throttle) => {
                const freq = baseFrequency + (throttle * 200);
                oscillator.frequency.linearRampToValueAtTime(freq, this.context.currentTime + 0.1);
            },
            stop: () => {
                oscillator.stop();
            }
        };
    }

    /**
     * Update listener position for spatial audio
     */
    updateListenerPosition(x, y) {
        if (!this.initialized) return;
        
        this.listenerPosition.x = x;
        this.listenerPosition.y = y;
        
        if (this.context.listener.positionX) {
            this.context.listener.positionX.value = x;
            this.context.listener.positionY.value = y;
            this.context.listener.positionZ.value = 0;
        }
    }

    /**
     * Resume audio context (needed for user interaction)
     */
    resume() {
        // Create context if it doesn't exist yet
        if (!this.initialized) {
            this.createContext();
        }

        // Resume if suspended
        if (this.context && this.context.state === 'suspended') {
            this.context.resume();
        }
    }

    /**
     * Clean up
     */
    dispose() {
        this.stopMusic(0);

        for (const sound of this.activeSounds) {
            this.stopSound(sound);
        }

        if (this.context) {
            this.context.close();
        }
    }

    // ===== PROCEDURAL SOUND GENERATION =====

    /**
     * Play laser sound (procedural)
     */
    playLaser() {
        if (!this.initialized) return;
        this.resume();

        const now = this.context.currentTime;
        const osc = this.context.createOscillator();
        const gain = this.context.createGain();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(800, now);
        osc.frequency.exponentialRampToValueAtTime(200, now + 0.1);

        gain.gain.setValueAtTime(0.3, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.1);

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(now);
        osc.stop(now + 0.1);
    }

    /**
     * Play plasma sound (procedural)
     */
    playPlasma() {
        if (!this.initialized) return;
        this.resume();

        const now = this.context.currentTime;
        const osc = this.context.createOscillator();
        const gain = this.context.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(400, now);
        osc.frequency.exponentialRampToValueAtTime(100, now + 0.2);

        gain.gain.setValueAtTime(0.4, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(now);
        osc.stop(now + 0.2);
    }

    /**
     * Play railgun sound (procedural)
     */
    playRailgun() {
        if (!this.initialized) return;
        this.resume();

        const now = this.context.currentTime;
        const bufferSize = this.context.sampleRate * 0.3;
        const buffer = this.context.createBuffer(1, bufferSize, this.context.sampleRate);
        const data = buffer.getChannelData(0);

        for (let i = 0; i < bufferSize; i++) {
            data[i] = Math.random() * 2 - 1;
        }

        const noise = this.context.createBufferSource();
        noise.buffer = buffer;

        const filter = this.context.createBiquadFilter();
        filter.type = 'highpass';
        filter.frequency.value = 2000;

        const gain = this.context.createGain();
        gain.gain.setValueAtTime(0.5, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);

        noise.connect(filter);
        filter.connect(gain);
        gain.connect(this.sfxGain);

        noise.start(now);
        noise.stop(now + 0.3);
    }

    /**
     * Play missile launch sound (procedural)
     */
    playMissile() {
        if (!this.initialized) return;
        this.resume();

        const now = this.context.currentTime;
        const osc = this.context.createOscillator();
        const gain = this.context.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(80, now);
        osc.frequency.linearRampToValueAtTime(120, now + 0.5);

        gain.gain.setValueAtTime(0.3, now);
        gain.gain.linearRampToValueAtTime(0.01, now + 0.5);

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(now);
        osc.stop(now + 0.5);
    }

    /**
     * Play explosion sound (procedural)
     */
    playExplosion() {
        if (!this.initialized) return;
        this.resume();

        const now = this.context.currentTime;
        const bufferSize = this.context.sampleRate * 0.5;
        const buffer = this.context.createBuffer(1, bufferSize, this.context.sampleRate);
        const data = buffer.getChannelData(0);

        for (let i = 0; i < bufferSize; i++) {
            data[i] = (Math.random() * 2 - 1) * Math.exp(-i / bufferSize * 5);
        }

        const noise = this.context.createBufferSource();
        noise.buffer = buffer;

        const filter = this.context.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(2000, now);
        filter.frequency.exponentialRampToValueAtTime(100, now + 0.5);

        const gain = this.context.createGain();
        gain.gain.setValueAtTime(0.6, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.5);

        noise.connect(filter);
        filter.connect(gain);
        gain.connect(this.sfxGain);

        noise.start(now);
        noise.stop(now + 0.5);
    }

    /**
     * Play UI beep (procedural)
     */
    playUIBeep() {
        if (!this.initialized) return;
        this.resume();

        const now = this.context.currentTime;
        const osc = this.context.createOscillator();
        const gain = this.context.createGain();

        osc.type = 'square';
        osc.frequency.value = 800;

        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.05);

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(now);
        osc.stop(now + 0.05);
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AudioManager;
}

