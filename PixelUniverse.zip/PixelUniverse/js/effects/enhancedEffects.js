/**
 * PixelVerse - Enhanced Visual Effects
 * Directional thrusters, shield bubbles, enhanced warp/hit/explosion effects
 */

class EnhancedEffects {
    constructor(ctx, particleSystem) {
        this.ctx = ctx;
        this.particleSystem = particleSystem;

        // Active effects
        this.shieldBubbles = [];
        this.warpTunnels = [];
        this.explosions = [];
        this.hitEffects = [];

        // Thruster positions relative to ship center
        this.thrusterPositions = {
            main: { x: -20, y: 0 },      // Rear thruster
            left: { x: 8, y: -10 },      // Left side thruster
            right: { x: 8, y: 10 },      // Right side thruster
            front: { x: 15, y: 0 }       // Front thruster (braking)
        };
    }

    /**
     * Helper: Create a single particle directly
     */
    createParticle(x, y, vx, vy, color, lifetime, size) {
        const particle = this.particleSystem.particlePool.find(p => !p.active);
        if (!particle) return;

        particle.active = true;
        particle.x = x;
        particle.y = y;
        particle.vx = vx;
        particle.vy = vy;
        particle.lifetime = lifetime;
        particle.maxLifetime = lifetime;
        particle.color = color;
        particle.size = size;
        particle.startSize = size;
        particle.endSize = 0;
        particle.alpha = 1.0;
    }

    /**
     * Create directional engine thrust effect
     */
    createEngineThrust(x, y, angle, thrustLevel, shipVelocity) {
        if (thrustLevel <= 0) return;

        // Calculate thruster position (rear of ship)
        const thrusterX = x + Math.cos(angle + Math.PI) * 20;
        const thrusterY = y + Math.sin(angle + Math.PI) * 20;

        // Particle count based on thrust level
        const particleCount = Math.floor(thrustLevel * 3) + 1;

        for (let i = 0; i < particleCount; i++) {
            // Thrust direction (opposite of ship facing)
            const thrustAngle = angle + Math.PI + (Math.random() - 0.5) * 0.3;

            // Particle velocity (relative to ship, not absolute)
            const speed = 200 + Math.random() * 100;
            const vx = Math.cos(thrustAngle) * speed;
            const vy = Math.sin(thrustAngle) * speed;

            // Color based on thrust intensity (blue to white)
            const intensity = 0.5 + thrustLevel * 0.5;
            const color = this.getThrustColor(intensity);

            this.createParticle(
                thrusterX + (Math.random() - 0.5) * 4,
                thrusterY + (Math.random() - 0.5) * 4,
                vx,
                vy,
                color,
                0.3 + Math.random() * 0.2,
                2 + Math.random() * 2
            );
        }
    }

    /**
     * Create maneuvering thruster effects
     */
    createManeuveringThrusters(x, y, angle, turning, braking) {
        // Left thruster fires when turning right
        if (turning > 0) {
            this.createSideThruster(x, y, angle, 'left', turning);
        }

        // Right thruster fires when turning left
        if (turning < 0) {
            this.createSideThruster(x, y, angle, 'right', Math.abs(turning));
        }

        // Front thrusters fire when braking
        if (braking) {
            this.createBrakingThrusters(x, y, angle);
        }
    }

    /**
     * Create side thruster burst
     */
    createSideThruster(x, y, angle, side, intensity) {
        const pos = this.thrusterPositions[side];

        // Rotate position based on ship angle
        const rotatedX = pos.x * Math.cos(angle) - pos.y * Math.sin(angle);
        const rotatedY = pos.x * Math.sin(angle) + pos.y * Math.cos(angle);

        const thrusterX = x + rotatedX;
        const thrusterY = y + rotatedY;

        // Thrust direction (perpendicular to ship)
        const thrustAngle = side === 'left' ? angle - Math.PI / 2 : angle + Math.PI / 2;

        // Small burst of particles
        const particleCount = Math.floor(intensity * 2) + 1;

        for (let i = 0; i < particleCount; i++) {
            const speed = 100 + Math.random() * 50;
            const vx = Math.cos(thrustAngle + (Math.random() - 0.5) * 0.5) * speed;
            const vy = Math.sin(thrustAngle + (Math.random() - 0.5) * 0.5) * speed;

            this.createParticle(
                thrusterX,
                thrusterY,
                vx,
                vy,
                '#4A90E2',
                0.2 + Math.random() * 0.1,
                1 + Math.random()
            );
        }
    }

    /**
     * Create braking thruster effects
     */
    createBrakingThrusters(x, y, angle) {
        const pos = this.thrusterPositions.front;

        // Rotate position based on ship angle
        const rotatedX = pos.x * Math.cos(angle) - pos.y * Math.sin(angle);
        const rotatedY = pos.x * Math.sin(angle) + pos.y * Math.cos(angle);

        const thrusterX = x + rotatedX;
        const thrusterY = y + rotatedY;

        // Thrust direction (forward from ship)
        const thrustAngle = angle;

        // Small burst of particles
        for (let i = 0; i < 2; i++) {
            const speed = 80 + Math.random() * 40;
            const vx = Math.cos(thrustAngle + (Math.random() - 0.5) * 0.4) * speed;
            const vy = Math.sin(thrustAngle + (Math.random() - 0.5) * 0.4) * speed;

            this.createParticle(
                thrusterX,
                thrusterY,
                vx,
                vy,
                '#E67E22',
                0.2 + Math.random() * 0.1,
                1 + Math.random()
            );
        }
    }

    /**
     * Get thrust color based on intensity
     */
    getThrustColor(intensity) {
        if (intensity > 0.8) return '#FFFFFF';
        if (intensity > 0.6) return '#E8F4F8';
        if (intensity > 0.4) return '#87CEEB';
        return '#4A90E2';
    }

    /**
     * Create shield bubble effect
     */
    createShieldBubble(entity, active = true) {
        const transform = entity.getComponent('transform');
        if (!transform) return;

        // Check if shield already exists for this entity
        const existing = this.shieldBubbles.find(s => s.entity === entity);
        if (existing) {
            existing.active = active;
            existing.opacity = active ? 0.6 : existing.opacity;
            return existing;
        }

        // Create new shield bubble
        const shield = {
            entity: entity,
            active: active,
            radius: 35,
            opacity: active ? 0.6 : 0,
            hexagons: this.generateHexagonGrid(35),
            impactRipples: [],
            shimmerPhase: Math.random() * Math.PI * 2
        };

        this.shieldBubbles.push(shield);
        return shield;
    }

    /**
     * Generate hexagon grid for shield
     */
    generateHexagonGrid(radius) {
        const hexagons = [];
        const hexSize = 8;
        const rows = Math.ceil(radius * 2 / (hexSize * 1.5));
        const cols = Math.ceil(radius * 2 / (hexSize * Math.sqrt(3)));

        for (let row = 0; row < rows; row++) {
            for (let col = 0; col < cols; col++) {
                const x = col * hexSize * Math.sqrt(3) + (row % 2) * hexSize * Math.sqrt(3) / 2 - radius;
                const y = row * hexSize * 1.5 - radius;

                // Only include hexagons within shield radius
                if (Math.sqrt(x * x + y * y) < radius) {
                    hexagons.push({ x, y, brightness: 0.5 + Math.random() * 0.5 });
                }
            }
        }

        return hexagons;
    }

    /**
     * Add impact ripple to shield
     */
    addShieldImpact(entity, impactX, impactY) {
        const shield = this.shieldBubbles.find(s => s.entity === entity);
        if (!shield) return;

        const transform = entity.getComponent('transform');
        if (!transform) return;

        // Calculate impact position relative to shield center
        const dx = impactX - transform.x;
        const dy = impactY - transform.y;

        shield.impactRipples.push({
            x: dx,
            y: dy,
            radius: 0,
            maxRadius: shield.radius,
            opacity: 1.0,
            lifetime: 0.5,
            age: 0
        });
    }

    /**
     * Create enhanced warp tunnel effect
     */
    createWarpTunnel(entity) {
        const transform = entity.getComponent('transform');
        if (!transform) return;

        const tunnel = {
            entity: entity,
            x: transform.x,
            y: transform.y,
            angle: transform.rotation,
            radius: 10,
            maxRadius: 150,
            particles: [],
            accretionDisk: [],
            lifetime: 2.0,
            age: 0
        };

        // Create accretion disk particles
        for (let i = 0; i < 50; i++) {
            const angle = Math.random() * Math.PI * 2;
            const distance = 30 + Math.random() * 80;
            tunnel.accretionDisk.push({
                angle: angle,
                distance: distance,
                speed: 0.5 + Math.random() * 1.0,
                size: 1 + Math.random() * 2,
                color: Math.random() > 0.5 ? '#4A90E2' : '#FFFFFF'
            });
        }

        this.warpTunnels.push(tunnel);
    }

    /**
     * Create enhanced explosion effect
     */
    createEnhancedExplosion(x, y, size = 1.0) {
        const explosion = {
            x: x,
            y: y,
            size: size,
            stage: 0, // 0: fireball, 1: expansion, 2: smoke
            radius: 0,
            maxRadius: 50 * size,
            opacity: 1.0,
            lifetime: 1.5,
            age: 0,
            debris: [],
            shockwave: { radius: 0, opacity: 1.0 }
        };

        // Create debris particles
        const debrisCount = Math.floor(20 * size);
        for (let i = 0; i < debrisCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = 50 + Math.random() * 150;
            explosion.debris.push({
                x: 0,
                y: 0,
                vx: Math.cos(angle) * speed,
                vy: Math.sin(angle) * speed,
                size: 1 + Math.random() * 3,
                rotation: Math.random() * Math.PI * 2,
                rotationSpeed: (Math.random() - 0.5) * 5
            });
        }

        this.explosions.push(explosion);

        // Also create particle explosion
        this.particleSystem.createEffect('explosion', x, y, { count: Math.floor(30 * size) });
    }

    /**
     * Create enhanced hit effect
     */
    createEnhancedHit(x, y, angle, intensity = 1.0) {
        const hit = {
            x: x,
            y: y,
            angle: angle,
            intensity: intensity,
            sparks: [],
            lifetime: 0.3,
            age: 0
        };

        // Create directional sparks
        const sparkCount = Math.floor(10 * intensity);
        for (let i = 0; i < sparkCount; i++) {
            const spreadAngle = angle + (Math.random() - 0.5) * Math.PI / 2;
            const speed = 100 + Math.random() * 200;
            hit.sparks.push({
                x: 0,
                y: 0,
                vx: Math.cos(spreadAngle) * speed,
                vy: Math.sin(spreadAngle) * speed,
                size: 1 + Math.random() * 2,
                color: Math.random() > 0.5 ? '#FDB813' : '#FFFFFF',
                life: 1.0
            });
        }

        this.hitEffects.push(hit);
    }

    /**
     * Update all enhanced effects
     */
    update(deltaTime) {
        // Update shield bubbles
        for (let i = this.shieldBubbles.length - 1; i >= 0; i--) {
            const shield = this.shieldBubbles[i];

            // Fade in/out based on active state
            if (shield.active) {
                shield.opacity = Math.min(0.6, shield.opacity + deltaTime * 2);
            } else {
                shield.opacity = Math.max(0, shield.opacity - deltaTime * 2);
                if (shield.opacity <= 0) {
                    this.shieldBubbles.splice(i, 1);
                    continue;
                }
            }

            // Update shimmer animation
            shield.shimmerPhase += deltaTime * 3;

            // Update impact ripples
            for (let j = shield.impactRipples.length - 1; j >= 0; j--) {
                const ripple = shield.impactRipples[j];
                ripple.age += deltaTime;
                ripple.radius = (ripple.age / ripple.lifetime) * ripple.maxRadius;
                ripple.opacity = 1.0 - (ripple.age / ripple.lifetime);

                if (ripple.age >= ripple.lifetime) {
                    shield.impactRipples.splice(j, 1);
                }
            }
        }

        // Update warp tunnels
        for (let i = this.warpTunnels.length - 1; i >= 0; i--) {
            const tunnel = this.warpTunnels[i];
            tunnel.age += deltaTime;

            // Expand tunnel
            tunnel.radius = Math.min(tunnel.maxRadius, tunnel.radius + deltaTime * 100);

            // Rotate accretion disk
            for (const particle of tunnel.accretionDisk) {
                particle.angle += particle.speed * deltaTime;
                particle.distance -= deltaTime * 50;
            }

            if (tunnel.age >= tunnel.lifetime) {
                this.warpTunnels.splice(i, 1);
            }
        }

        // Update explosions
        for (let i = this.explosions.length - 1; i >= 0; i--) {
            const explosion = this.explosions[i];
            explosion.age += deltaTime;

            const progress = explosion.age / explosion.lifetime;

            // Stage transitions
            if (progress < 0.3) {
                explosion.stage = 0; // Fireball
                explosion.radius = progress * 3.33 * explosion.maxRadius;
            } else if (progress < 0.7) {
                explosion.stage = 1; // Expansion
                explosion.radius = explosion.maxRadius;
            } else {
                explosion.stage = 2; // Smoke
                explosion.radius = explosion.maxRadius * (1 + (progress - 0.7) * 0.5);
            }

            explosion.opacity = 1.0 - progress;

            // Update shockwave
            explosion.shockwave.radius = progress * explosion.maxRadius * 2;
            explosion.shockwave.opacity = Math.max(0, 1.0 - progress * 2);

            // Update debris
            for (const debris of explosion.debris) {
                debris.x += debris.vx * deltaTime;
                debris.y += debris.vy * deltaTime;
                debris.rotation += debris.rotationSpeed * deltaTime;
                debris.vx *= 0.98; // Drag
                debris.vy *= 0.98;
            }

            if (explosion.age >= explosion.lifetime) {
                this.explosions.splice(i, 1);
            }
        }

        // Update hit effects
        for (let i = this.hitEffects.length - 1; i >= 0; i--) {
            const hit = this.hitEffects[i];
            hit.age += deltaTime;

            // Update sparks
            for (const spark of hit.sparks) {
                spark.x += spark.vx * deltaTime;
                spark.y += spark.vy * deltaTime;
                spark.life = 1.0 - (hit.age / hit.lifetime);
            }

            if (hit.age >= hit.lifetime) {
                this.hitEffects.splice(i, 1);
            }
        }
    }

    /**
     * Render all enhanced effects
     */
    render(cameraX, cameraY, width, height) {
        const ctx = this.ctx;

        // Render warp tunnels
        for (const tunnel of this.warpTunnels) {
            this.renderWarpTunnel(ctx, tunnel, cameraX, cameraY, width, height);
        }

        // Render explosions
        for (const explosion of this.explosions) {
            this.renderExplosion(ctx, explosion, cameraX, cameraY, width, height);
        }

        // Render hit effects
        for (const hit of this.hitEffects) {
            this.renderHitEffect(ctx, hit, cameraX, cameraY, width, height);
        }

        // Render shield bubbles
        for (const shield of this.shieldBubbles) {
            this.renderShieldBubble(ctx, shield, cameraX, cameraY, width, height);
        }
    }


    /**
     * Render shield bubble
     */
    renderShieldBubble(ctx, shield, cameraX, cameraY, width, height) {
        const transform = shield.entity.getComponent('transform');
        if (!transform) return;

        const screenX = transform.x - cameraX + width / 2;
        const screenY = transform.y - cameraY + height / 2;

        ctx.save();
        ctx.translate(screenX, screenY);
        ctx.globalAlpha = shield.opacity;

        // Draw hexagon grid
        ctx.strokeStyle = '#4A90E2';
        ctx.lineWidth = 1;

        for (const hex of shield.hexagons) {
            const shimmer = Math.sin(shield.shimmerPhase + hex.x * 0.1 + hex.y * 0.1) * 0.3 + 0.7;
            ctx.globalAlpha = shield.opacity * hex.brightness * shimmer;
            this.drawHexagon(ctx, hex.x, hex.y, 4);
        }

        // Draw impact ripples
        ctx.globalAlpha = shield.opacity;
        for (const ripple of shield.impactRipples) {
            ctx.strokeStyle = '#FFFFFF';
            ctx.lineWidth = 2;
            ctx.globalAlpha = ripple.opacity * shield.opacity;
            ctx.beginPath();
            ctx.arc(ripple.x, ripple.y, ripple.radius, 0, Math.PI * 2);
            ctx.stroke();
        }

        ctx.restore();
    }

    /**
     * Draw hexagon
     */
    drawHexagon(ctx, x, y, size) {
        ctx.beginPath();
        for (let i = 0; i < 6; i++) {
            const angle = (Math.PI / 3) * i;
            const hx = x + Math.cos(angle) * size;
            const hy = y + Math.sin(angle) * size;
            if (i === 0) ctx.moveTo(hx, hy);
            else ctx.lineTo(hx, hy);
        }
        ctx.closePath();
        ctx.stroke();
    }

    /**
     * Render warp tunnel
     */
    renderWarpTunnel(ctx, tunnel, cameraX, cameraY, width, height) {
        const screenX = tunnel.x - cameraX + width / 2;
        const screenY = tunnel.y - cameraY + height / 2;

        ctx.save();
        ctx.translate(screenX, screenY);

        // Black hole center
        const gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, tunnel.radius);
        gradient.addColorStop(0, '#000000');
        gradient.addColorStop(0.7, '#1a1a1a');
        gradient.addColorStop(1, 'rgba(26, 26, 26, 0)');
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(0, 0, tunnel.radius, 0, Math.PI * 2);
        ctx.fill();

        // Accretion disk particles
        for (const particle of tunnel.accretionDisk) {
            if (particle.distance > 0) {
                const px = Math.cos(particle.angle) * particle.distance;
                const py = Math.sin(particle.angle) * particle.distance;

                ctx.fillStyle = particle.color;
                ctx.globalAlpha = Math.min(1, particle.distance / 30);
                ctx.beginPath();
                ctx.arc(px, py, particle.size, 0, Math.PI * 2);
                ctx.fill();
            }
        }

        // Spacetime distortion lines
        ctx.strokeStyle = '#4A90E2';
        ctx.lineWidth = 1;
        ctx.globalAlpha = 0.3;
        for (let i = 0; i < 8; i++) {
            const angle = (i / 8) * Math.PI * 2;
            const startDist = tunnel.radius;
            const endDist = tunnel.maxRadius;

            ctx.beginPath();
            ctx.moveTo(Math.cos(angle) * startDist, Math.sin(angle) * startDist);

            // Curved line
            for (let t = 0; t <= 1; t += 0.1) {
                const dist = startDist + (endDist - startDist) * t;
                const curve = Math.sin(t * Math.PI) * 20;
                const perpAngle = angle + Math.PI / 2;
                const px = Math.cos(angle) * dist + Math.cos(perpAngle) * curve;
                const py = Math.sin(angle) * dist + Math.sin(perpAngle) * curve;
                ctx.lineTo(px, py);
            }
            ctx.stroke();
        }

        ctx.restore();
    }

    /**
     * Render explosion
     */
    renderExplosion(ctx, explosion, cameraX, cameraY, width, height) {
        const screenX = explosion.x - cameraX + width / 2;
        const screenY = explosion.y - cameraY + height / 2;

        ctx.save();
        ctx.translate(screenX, screenY);
        ctx.globalAlpha = explosion.opacity;

        // Shockwave ring
        if (explosion.shockwave.opacity > 0) {
            ctx.strokeStyle = '#FFFFFF';
            ctx.lineWidth = 3;
            ctx.globalAlpha = explosion.shockwave.opacity;
            ctx.beginPath();
            ctx.arc(0, 0, explosion.shockwave.radius, 0, Math.PI * 2);
            ctx.stroke();
        }

        // Fireball
        ctx.globalAlpha = explosion.opacity;
        if (explosion.stage === 0) {
            // Bright fireball
            const gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, explosion.radius);
            gradient.addColorStop(0, '#FFFFFF');
            gradient.addColorStop(0.3, '#FDB813');
            gradient.addColorStop(0.6, '#E74C3C');
            gradient.addColorStop(1, 'rgba(231, 76, 60, 0)');
            ctx.fillStyle = gradient;
            ctx.beginPath();
            ctx.arc(0, 0, explosion.radius, 0, Math.PI * 2);
            ctx.fill();
        } else if (explosion.stage === 1) {
            // Expanding fire
            const gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, explosion.radius);
            gradient.addColorStop(0, '#FDB813');
            gradient.addColorStop(0.5, '#E74C3C');
            gradient.addColorStop(1, 'rgba(231, 76, 60, 0)');
            ctx.fillStyle = gradient;
            ctx.beginPath();
            ctx.arc(0, 0, explosion.radius, 0, Math.PI * 2);
            ctx.fill();
        } else {
            // Smoke
            const gradient = ctx.createRadialGradient(0, 0, 0, 0, 0, explosion.radius);
            gradient.addColorStop(0, 'rgba(100, 100, 100, 0.5)');
            gradient.addColorStop(0.5, 'rgba(80, 80, 80, 0.3)');
            gradient.addColorStop(1, 'rgba(60, 60, 60, 0)');
            ctx.fillStyle = gradient;
            ctx.beginPath();
            ctx.arc(0, 0, explosion.radius, 0, Math.PI * 2);
            ctx.fill();
        }

        // Debris
        ctx.fillStyle = '#8B7355';
        for (const debris of explosion.debris) {
            ctx.save();
            ctx.translate(debris.x, debris.y);
            ctx.rotate(debris.rotation);
            ctx.fillRect(-debris.size / 2, -debris.size / 2, debris.size, debris.size);
            ctx.restore();
        }

        ctx.restore();
    }

    /**
     * Render hit effect
     */
    renderHitEffect(ctx, hit, cameraX, cameraY, width, height) {
        const screenX = hit.x - cameraX + width / 2;
        const screenY = hit.y - cameraY + height / 2;

        ctx.save();
        ctx.translate(screenX, screenY);

        // Draw sparks
        for (const spark of hit.sparks) {
            ctx.fillStyle = spark.color;
            ctx.globalAlpha = spark.life;
            ctx.beginPath();
            ctx.arc(spark.x, spark.y, spark.size, 0, Math.PI * 2);
            ctx.fill();
        }

        ctx.restore();
    }

    /**
     * Clear all effects
     */
    clear() {
        this.shieldBubbles = [];
        this.warpTunnels = [];
        this.explosions = [];
        this.hitEffects = [];
    }
}
