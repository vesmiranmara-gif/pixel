/**
 * PixelVerse - Main Entry Point
 * Initializes and starts the game
 */

class PixelVerse extends GameEngine {
    constructor() {
        super();

        this.audioManager = null;
        this.physicsSystem = null;
        this.collisionSystem = null;
        this.spriteManager = null;
        this.particleSystem = null;
        this.screenEffects = null;
        this.visualEffects = null;
        this.hud = null;
        this.terminal = null;
        this.menuSystem = null;
        this.cockpit = null;
        this.backgroundSystem = null;
        this.asteroidFieldSystem = null;
        this.weaponSystem = null;
        this.warpDriveSystem = null;
        this.enemyAISystem = null;
        this.shipSystemsManager = null;
        this.inventorySystem = null;
        this.tradingSystem = null;
        this.missionSystem = null;
        this.factionSystem = null;
        this.performanceOptimizer = null;
        this.qualityOfLife = null;
        this.visualPolish = null;
        this.enhancedThrusterSystem = null;

        // Enemy ships
        this.enemyShips = [];

        // Game state
        this.gameState = 'loading'; // loading, menu, playing, paused
        this.loadingProgress = 0;

        // Player ship
        this.playerShip = null;

        // Test objects
        this.testAsteroids = [];
        this.testPlanet = null;
        this.testAsteroidField = null;

        // Debug mode
        this.showDebug = true;
    }

    /**
     * Initialize the game
     */
    async initialize() {
        console.log('=== PixelVerse Initialization ===');
        
        // Initialize base engine
        await super.initialize();
        
        // Initialize sprite manager
        this.spriteManager = new SpriteManager();
        this.updateLoadingProgress(10);

        // Initialize audio
        this.audioManager = new AudioManager();
        await this.audioManager.initialize();
        this.updateLoadingProgress(20);

        // Initialize physics system
        this.physicsSystem = new PhysicsSystem();
        this.entityManager.addSystem(this.physicsSystem);
        this.updateLoadingProgress(30);

        // Initialize collision system
        this.collisionSystem = new CollisionSystem();
        this.entityManager.addSystem(this.collisionSystem);
        this.updateLoadingProgress(40);

        // Initialize particle system
        this.particleSystem = new ParticleSystem();
        this.entityManager.addSystem(this.particleSystem);
        this.updateLoadingProgress(50);

        // Initialize screen effects
        this.screenEffects = new ScreenEffects(this.renderer);
        this.updateLoadingProgress(60);

        // Initialize visual effects
        this.visualEffects = new VisualEffectsSystem(this.renderer);
        this.updateLoadingProgress(68);

        // Initialize enhanced effects
        this.enhancedEffects = new EnhancedEffects(this.renderer.context, this.particleSystem);
        this.updateLoadingProgress(70);

        // Initialize UI systems
        this.hud = new HUD(this.renderer);
        this.terminal = new TerminalInterface(this.renderer);
        this.menuSystem = new MenuSystem(this.renderer);
        this.cockpit = new CockpitUI(this.renderer);
        this.updateLoadingProgress(75);

        // Initialize background system
        this.backgroundSystem = new BackgroundSystem(this.renderer);
        this.updateLoadingProgress(74);

        // Initialize enhanced rendering systems
        this.celestialRenderer = new CelestialRenderer();
        this.starSystemGenerator = new StarSystemGenerator();
        this.shipRenderer = new ShipRenderer();
        this.stationRenderer = new StationRenderer();
        console.log('✅ Enhanced renderers initialized');
        this.updateLoadingProgress(76);

        // Initialize celestial body system with enhanced renderers
        this.celestialBodies = new CelestialBodySystem(
            this.renderer.context,
            this.renderer.baseWidth,
            this.renderer.baseHeight,
            this.celestialRenderer,
            this.starSystemGenerator
        );
        this.celestialBodies.initialize();
        this.updateLoadingProgress(78);

        // Initialize weapon system
        this.weaponSystem = new WeaponSystem(this.entityManager, this.particleSystem, this.visualEffects, this.audioManager);

        // Set up weapon system callback for enemy kills
        this.weaponSystem.onEnemyKilled = (target, killer) => {
            // Award XP if killer is player
            if (killer === this.playerShip && this.progressionSystem) {
                this.awardKillXP(target);
            }

            // Award reputation if killer is player
            if (killer === this.playerShip && this.reputationSystem) {
                this.awardKillReputation(target);
            }
        };

        this.updateLoadingProgress(79);

        // Initialize warp drive system
        this.warpDriveSystem = new WarpDriveSystem(this.visualEffects, this.audioManager);
        this.updateLoadingProgress(80);

        // Initialize enemy AI system
        this.enemyAISystem = new EnemyAISystem(this.entityManager, this.weaponSystem);
        this.updateLoadingProgress(82);

        // Initialize ship systems manager
        this.shipSystemsManager = new ShipSystemsManager(this.entityManager);
        this.updateLoadingProgress(85);

        // Connect ship systems to weapon system
        this.weaponSystem.shipSystemsManager = this.shipSystemsManager;

        // Initialize inventory system
        this.inventorySystem = new InventorySystem();
        this.updateLoadingProgress(87);

        // Initialize trading system
        this.tradingSystem = new TradingSystem(this.inventorySystem);
        this.updateLoadingProgress(89);

        // Initialize mission system
        this.missionSystem = new MissionSystem(this.inventorySystem);

        // Set up mission completion callback for XP
        this.missionSystem.onMissionComplete = (mission, entity) => {
            if (entity === this.playerShip && this.progressionSystem) {
                this.progressionSystem.awardMissionXP(mission.difficulty || 'normal', true);
            }
        };

        this.updateLoadingProgress(91);

        // Initialize faction system
        this.factionSystem = new FactionSystem();
        this.updateLoadingProgress(91);

        // Initialize progression system
        this.progressionSystem = new ProgressionSystem();
        this.setupProgressionCallbacks();
        this.updateLoadingProgress(91);

        // Initialize skill tree system
        this.skillTreeSystem = new SkillTreeSystem();
        this.setupSkillTreeCallbacks();
        this.updateLoadingProgress(91);

        // Initialize ship upgrade system
        this.shipUpgradeSystem = new ShipUpgradeSystem(this.inventorySystem);
        this.setupShipUpgradeCallbacks();
        this.updateLoadingProgress(91);

        // Initialize reputation system
        this.reputationSystem = new ReputationSystem();
        this.setupReputationCallbacks();
        this.updateLoadingProgress(91);

        // Initialize achievement system
        this.achievementSystem = new AchievementSystem();
        this.setupAchievementCallbacks();
        this.updateLoadingProgress(93);

        // Initialize performance optimizer
        this.performanceOptimizer = new PerformanceOptimizer();
        this.performanceOptimizer.setPreset('high'); // Default to high quality
        this.updateLoadingProgress(95);

        // Initialize quality of life systems
        this.qualityOfLife = new QualityOfLife();
        this.updateLoadingProgress(97);

        // Initialize visual polish
        this.visualPolish = new VisualPolish(this.renderer);
        this.updateLoadingProgress(99);

        // Initialize enhanced thruster system
        this.enhancedThrusterSystem = new EnhancedThrusterSystem(this.particleSystem);
        this.updateLoadingProgress(99.5);

        // Load initial assets
        await this.loadAssets();
        this.updateLoadingProgress(85);

        // Create test scene
        this.createTestScene();
        this.updateLoadingProgress(95);

        // Final initialization
        await new Promise(resolve => setTimeout(resolve, 100));
        this.updateLoadingProgress(100);
        
        // Hide loading screen
        setTimeout(() => {
            this.hideLoadingScreen();
            this.gameState = 'playing';
        }, 500);
        
        console.log('=== PixelVerse Ready ===');
    }

    /**
     * Update loading progress
     */
    updateLoadingProgress(percent) {
        this.loadingProgress = percent;
        const progressBar = document.getElementById('loading-progress');
        if (progressBar) {
            progressBar.style.width = percent + '%';
        }
    }

    /**
     * Hide loading screen
     */
    hideLoadingScreen() {
        const loadingScreen = document.getElementById('loading-screen');
        if (loadingScreen) {
            loadingScreen.classList.add('hidden');
            setTimeout(() => {
                loadingScreen.style.display = 'none';
            }, 500);
        }
    }

    /**
     * Load game assets
     */
    async loadAssets() {
        console.log('Loading assets...');

        // Generate spacecraft sprites
        SpacecraftSpriteGenerator.generateAll(this.spriteManager);
        await new Promise(resolve => setTimeout(resolve, 100));

        // Generate environmental sprites
        EnvironmentSpriteGenerator.generateAll(this.spriteManager);
        await new Promise(resolve => setTimeout(resolve, 100));

        // Generate enhanced celestial bodies (DISABLED - causing lag, needs optimization)
        // EnhancedCelestialGenerator.generateAll(this.spriteManager);
        // await new Promise(resolve => setTimeout(resolve, 200));

        console.log('Assets loaded:', this.spriteManager.sprites.size, 'sprites');
    }

    /**
     * Create a test scene
     */
    createTestScene() {
        console.log('Creating test scene...');

        // Create player ship (using enhanced renderer)
        this.playerShip = this.entityManager.createEntity();

        // Use enhanced ship renderer if available
        let playerSprite;
        const shipSize = 48; // New detailed ship size
        if (this.shipRenderer) {
            const shipCanvas = this.shipRenderer.getShip('playerFighter', shipSize);
            playerSprite = this.spriteManager.createSprite('playerFighter', shipSize, shipSize);
            playerSprite.image = shipCanvas;
            console.log('✅ Using enhanced player ship sprite (48x48, highly pixelated, points UP)');
        } else {
            playerSprite = this.spriteManager.getSprite('frigate');
            console.log('⚠️ Using fallback player ship sprite');
        }

        this.playerShip
            .addComponent('transform', new TransformComponent(960, 450, 0, 1))
            .addComponent('velocity', new VelocityComponent(0, 0, 0))
            .addComponent('physics', new PhysicsComponent(100, 0.02))
            .addComponent('health', new HealthComponent(100, 50))
            .addComponent('sprite', new SpriteComponent(playerSprite, shipSize, shipSize))
            .addComponent('weapon', new WeaponComponent('laser', 0));

        // Initialize warp drive for player
        this.warpDriveSystem.initializeWarpDrive(this.playerShip, 2.0, 5.0, 2000);

        // Initialize ship systems for player
        this.shipSystemsManager.initializeSystems(this.playerShip, {
            totalPower: 100,
            powerRegen: 5.0
        });

        // Initialize inventory for player
        this.inventorySystem.initializeInventory(this.playerShip, {
            maxWeight: 100,
            credits: 1000
        });

        // Add some starting items
        this.inventorySystem.addItem(this.playerShip, 'fuel_cell', 50);
        this.inventorySystem.addItem(this.playerShip, 'iron_ore', 10);

        // Initialize faction reputation for player
        this.factionSystem.initializeReputation(this.playerShip);

        // Set player reference for AI
        this.enemyAISystem.setPlayerShip(this.playerShip);

        // Load saved progression data
        this.loadProgression();

        // Initialize asteroid field system
        const envFactory = new EnvironmentFactory(this.entityManager, this.spriteManager);
        this.asteroidFieldSystem = new AsteroidFieldSystem(this.entityManager, this.spriteManager, envFactory);

        // Create asteroid field around player
        this.testAsteroidField = this.asteroidFieldSystem.createField(960, 450, 400, 'medium', 'mixed');

        // Add some other ship types
        const shipFactory = new ShipFactory(this.entityManager, this.spriteManager);

        // Interceptor flying by
        const interceptor = shipFactory.createInterceptor(1200, 300);
        const interceptorTransform = interceptor.getComponent('transform');
        const interceptorVelocity = interceptor.getComponent('velocity');
        interceptorTransform.rotation = Math.PI;
        interceptorVelocity.vx = -50;

        // Mining ship near asteroids
        const miner = shipFactory.createMiningShip(800, 600);
        const minerTransform = miner.getComponent('transform');
        minerTransform.rotation = Math.PI / 4;

        // Transport in distance
        const transport = shipFactory.createTransport(1500, 700);
        const transportTransform = transport.getComponent('transform');
        transportTransform.rotation = -Math.PI / 2;

        // Create a test planet (old small one for comparison)
        this.testPlanet = this.entityManager.createEntity();
        const planetSprite = this.spriteManager.getSprite('planet_terran_64');

        this.testPlanet
            .addComponent('transform', new TransformComponent(1400, 300, 0, 1))
            .addComponent('sprite', new SpriteComponent(planetSprite, 64, 64));

        // Add a gravity well for the planet
        this.physicsSystem.addGravityWell(1400, 300, 30000, 400);

        // Add a mining station
        const station = envFactory.createStation(600, 200, 'mining');

        // Add a derelict
        const derelict = envFactory.createDerelict(1100, 550, 32);

        // Add a distant star (old small one)
        const star = envFactory.createStar(200, 150, 16, 'G');

        // Create enemy ships
        this.spawnEnemyShips();

        // Set camera to follow player
        this.setCameraTarget(960, 450);

        console.log('Test scene created with', this.entityManager.entities.size, 'entities');
    }

    /**
     * Spawn enemy ships
     */
    spawnEnemyShips() {
        // Create 3 enemy ships at different positions
        const enemyPositions = [
            { x: 1400, y: 300, behavior: 'aggressive' },
            { x: 1200, y: 600, behavior: 'defensive' },
            { x: 500, y: 300, behavior: 'patrol' }
        ];

        for (const pos of enemyPositions) {
            const enemy = this.entityManager.createEntity();
            const enemySprite = this.spriteManager.getSprite('fighter_enemy');

            enemy
                .addComponent('transform', new TransformComponent(pos.x, pos.y, Math.PI, 1))
                .addComponent('velocity', new VelocityComponent(0, 0, 0))
                .addComponent('physics', new PhysicsComponent(80, 0.02))
                .addComponent('health', new HealthComponent(50, 0))
                .addComponent('sprite', new SpriteComponent(enemySprite, 32, 32))
                .addComponent('weapon', new WeaponComponent('laser', 0));

            // Initialize AI
            this.enemyAISystem.initializeAI(enemy, pos.behavior, 800);

            this.enemyShips.push(enemy);
        }

        console.log('Spawned', this.enemyShips.length, 'enemy ships');
    }

    /**
     * Handle keyboard input
     */
    onKeyDown(e) {
        // Terminal toggle
        if (e.code === 'Backquote') { // ` key
            this.terminal.toggle();
            return;
        }

        // Menu toggle
        if (e.code === 'Escape') {
            if (this.terminal.visible) {
                this.terminal.hide();
            } else {
                this.menuSystem.toggle('pause');
                if (this.menuSystem.visible) {
                    this.togglePause();
                }
            }
            return;
        }

        // Pause/unpause
        if (e.code === 'KeyP') {
            this.togglePause();
            return;
        }

        // Debug toggle
        if (e.code === 'F3') {
            this.showDebug = !this.showDebug;
            return;
        }

        // HUD toggle
        if (e.code === 'F1') {
            this.hud.toggle();
            return;
        }

        // Menu navigation
        if (this.menuSystem.visible) {
            if (e.code === 'ArrowUp' || e.code === 'KeyW') {
                this.menuSystem.navigate('up');
                return;
            }
            if (e.code === 'ArrowDown' || e.code === 'KeyS') {
                this.menuSystem.navigate('down');
                return;
            }
            if (e.code === 'Enter' || e.code === 'Space') {
                const action = this.menuSystem.select();
                this.handleMenuAction(action);
                return;
            }
        }

        // Terminal input
        if (this.terminal.visible) {
            if (e.code === 'Enter') {
                this.terminal.handleInput('Enter');
            } else if (e.code === 'Backspace') {
                this.terminal.handleInput('Backspace');
            } else if (e.key.length === 1) {
                this.terminal.handleInput(e.key);
            }
            return;
        }
        
        // Time controls
        if (e.code === 'Equal' || e.code === 'Period') {
            this.setTimeScale(Math.min(4, this.timeScale * 2));
            return;
        }

        if (e.code === 'Minus' || e.code === 'Comma') {
            this.setTimeScale(Math.max(0.25, this.timeScale * 0.5));
            return;
        }

        // Visual effect tests
        if (e.code === 'Digit1') {
            // Test shield effect
            if (this.playerShip) {
                const transform = this.playerShip.getComponent('transform');
                if (transform) {
                    this.visualEffects.createShieldBarrier(transform.x, transform.y, 40, 0.5);
                }
            }
            return;
        }

        if (e.code === 'Digit2') {
            // Test warp charge
            if (this.playerShip) {
                const transform = this.playerShip.getComponent('transform');
                if (transform) {
                    this.visualEffects.createWarpCharge(transform.x, transform.y, 2.0);
                }
            }
            return;
        }

        if (e.code === 'Digit3') {
            // Test explosion
            if (this.playerShip) {
                const transform = this.playerShip.getComponent('transform');
                if (transform) {
                    this.particleSystem.createEffect('explosion', transform.x + 100, transform.y, { count: 30 });
                }
            }
            return;
        }

        if (e.code === 'Digit4') {
            // Toggle scanlines
            this.screenEffects.toggleEffect('scanlines');
            return;
        }

        if (e.code === 'Digit5') {
            // Test damage
            if (this.playerShip) {
                const health = this.playerShip.getComponent('health');
                if (health) {
                    health.takeDamage(20);
                }
            }
            return;
        }

        if (e.code === 'Digit6') {
            // Regenerate background
            this.backgroundSystem.regenerate();
            console.log('Background regenerated');
            return;
        }

        if (e.code === 'Digit7') {
            // Test warp drive
            if (this.playerShip) {
                const transform = this.playerShip.getComponent('transform');
                if (transform) {
                    // Warp forward 1000 units
                    const targetX = transform.x + Math.cos(transform.rotation) * 1000;
                    const targetY = transform.y + Math.sin(transform.rotation) * 1000;
                    this.warpDriveSystem.startWarpCharge(this.playerShip, targetX, targetY);
                }
            }
            return;
        }
    }

    /**
     * Handle menu actions
     */
    handleMenuAction(action) {
        if (!action) return;

        switch (action) {
            case 'resume':
                this.menuSystem.hide();
                this.togglePause();
                break;

            case 'settings':
                this.menuSystem.show('settings');
                break;

            case 'back':
                this.menuSystem.show('pause');
                break;

            case 'mainMenu':
                this.menuSystem.hide();
                this.menuSystem.show('main');
                break;

            case 'exit':
                console.log('Exit game');
                break;

            default:
                console.log('Menu action:', action);
        }
    }

    /**
     * Update game logic
     */
    onUpdate(deltaTime) {
        if (this.gameState !== 'playing' || this.paused) return;

        // Update player ship controls
        this.updatePlayerControls(deltaTime);

        // Update particle system
        this.particleSystem.update(deltaTime);

        // Update screen effects
        this.screenEffects.update(deltaTime);

        // Update visual effects
        this.visualEffects.update(deltaTime);

        // Update enhanced effects
        this.enhancedEffects.update(deltaTime);

        // Update background
        this.backgroundSystem.update(deltaTime);

        // Update celestial bodies
        this.celestialBodies.update(deltaTime);

        // Update weapon system
        this.weaponSystem.update(deltaTime);

        // Update warp drive system
        this.warpDriveSystem.update(deltaTime);

        // Update enemy AI
        this.enemyAISystem.update(deltaTime);

        // Update ship systems
        this.shipSystemsManager.update(deltaTime);

        // Update performance optimizer
        this.performanceOptimizer.update(deltaTime);

        // Update quality of life systems
        this.qualityOfLife.update(deltaTime);

        // Update visual polish
        this.visualPolish.update(deltaTime);

        // Update UI systems
        this.hud.update(deltaTime);
        this.terminal.update(deltaTime);
        this.cockpit.update(deltaTime);

        // Update damage level based on player health
        if (this.playerShip) {
            const health = this.playerShip.getComponent('health');
            if (health) {
                const damageLevel = 1 - (health.health / health.maxHealth);
                this.screenEffects.setDamageLevel(damageLevel);

                // Create/update shield bubble if shields are active
                if (health.shield > 0) {
                    this.enhancedEffects.createShieldBubble(this.playerShip, true);
                }
            }
        }

        // Auto-save progression every 30 seconds
        if (!this.lastProgressionSave) this.lastProgressionSave = 0;
        this.lastProgressionSave += deltaTime;
        if (this.lastProgressionSave >= 30) {
            this.saveProgression();
            this.lastProgressionSave = 0;
        }

        // Update achievement progress every 5 seconds
        if (!this.lastAchievementUpdate) this.lastAchievementUpdate = 0;
        this.lastAchievementUpdate += deltaTime;
        if (this.lastAchievementUpdate >= 5) {
            this.updateAchievementProgress();
            this.lastAchievementUpdate = 0;
        }

        // Emit enhanced thruster particles from player ship
        if (this.playerShip && this.enhancedThrusterSystem) {
            // Determine control inputs and intensities
            const controls = {
                thrust: 0,
                turnLeft: 0,
                turnRight: 0,
                brake: 0
            };

            // Forward thrust
            if (this.isKeyPressed('KeyW') || this.isKeyPressed('ArrowUp')) {
                controls.thrust = 1.0;
            }

            // Reverse thrust / brake
            if (this.isKeyPressed('KeyS') || this.isKeyPressed('ArrowDown')) {
                controls.brake = 0.8;
            }

            // Turn left (right thruster fires)
            if (this.isKeyPressed('KeyA') || this.isKeyPressed('ArrowLeft')) {
                controls.turnLeft = 1.0;
            }

            // Turn right (left thruster fires)
            if (this.isKeyPressed('KeyD') || this.isKeyPressed('ArrowRight')) {
                controls.turnRight = 1.0;
            }

            // Update thrusters with controls
            this.enhancedThrusterSystem.updateShipThrusters(
                this.playerShip,
                controls,
                'medium',  // Ship size
                'chemical' // Engine type
            );
        }

        // Update camera to follow player
        if (this.playerShip) {
            const transform = this.playerShip.getComponent('transform');
            if (transform) {
                this.setCameraTarget(transform.x, transform.y);
            }
        }
    }

    /**
     * Update player ship controls
     */
    updatePlayerControls(deltaTime) {
        if (!this.playerShip) return;
        
        const transform = this.playerShip.getComponent('transform');
        const velocity = this.playerShip.getComponent('velocity');
        const physics = this.playerShip.getComponent('physics');
        
        if (!transform || !velocity || !physics) return;
        
        const thrustPower = 5000;
        const rotationSpeed = 3;

        // Track turning for maneuvering thrusters
        let turning = 0;

        // Rotation
        if (this.isKeyPressed('KeyA') || this.isKeyPressed('ArrowLeft')) {
            velocity.angularVelocity = -rotationSpeed;
            turning = -1;
        } else if (this.isKeyPressed('KeyD') || this.isKeyPressed('ArrowRight')) {
            velocity.angularVelocity = rotationSpeed;
            turning = 1;
        } else {
            velocity.angularVelocity *= 0.9; // Damping
        }

        // Thrust
        let thrusting = false;
        let braking = false;

        if (this.isKeyPressed('KeyW') || this.isKeyPressed('ArrowUp')) {
            const thrustX = Math.cos(transform.rotation) * thrustPower;
            const thrustY = Math.sin(transform.rotation) * thrustPower;
            physics.addForce(thrustX, thrustY);
            thrusting = true;

            // Enhanced directional engine thrust
            this.enhancedEffects.createEngineThrust(
                transform.x,
                transform.y,
                transform.rotation,
                1.0,
                { vx: velocity.vx, vy: velocity.vy }
            );
        }

        // Reverse thrust
        if (this.isKeyPressed('KeyS') || this.isKeyPressed('ArrowDown')) {
            const thrustX = -Math.cos(transform.rotation) * thrustPower * 0.5;
            const thrustY = -Math.sin(transform.rotation) * thrustPower * 0.5;
            physics.addForce(thrustX, thrustY);
            braking = true;
        }

        // Maneuvering thrusters
        if (turning !== 0 || braking) {
            this.enhancedEffects.createManeuveringThrusters(
                transform.x,
                transform.y,
                transform.rotation,
                turning,
                braking
            );
        }

        // Weapon firing
        if (this.isKeyPressed('Space')) {
            const projectile = this.weaponSystem.fireWeapon(this.playerShip, 'laser');
            if (projectile) {
                // Small screen shake on weapon fire
                this.visualPolish.shake(2, 0.1);
            }
        }
    }

    /**
     * Render game
     */
    onRender() {
        if (this.gameState === 'loading') return;

        // Render background (starfield, nebulae, dust)
        if (this.backgroundSystem) {
            this.backgroundSystem.render(this.camera.x, this.camera.y);
        }

        // Render celestial bodies (planets, moons, stars)
        if (this.celestialBodies) {
            this.celestialBodies.render(this.camera);
        }

        // Render all entities with sprites
        this.renderEntities();

        // Render visual effects (shields, beams, etc.)
        this.visualEffects.render(this.camera.x, this.camera.y);

        // Render enhanced effects (shield bubbles, warp tunnels, explosions, hits)
        this.enhancedEffects.render(this.camera.x, this.camera.y, this.renderer.width, this.renderer.height);

        // Render particles
        this.particleSystem.render(this.renderer, this.camera.x, this.camera.y);

        // Render projectiles
        this.weaponSystem.render(this.renderer, this.camera.x, this.camera.y);

        // Apply screen effects (scanlines, damage, etc.)
        this.screenEffects.applyEffects();

        // Apply visual polish post-processing
        this.visualPolish.renderPostProcessing(this.renderer.context);

        // Render cockpit UI (redesigned - modular system)
        this.cockpit.render(this.playerShip, this.shipSystemsManager, this.inventorySystem, this.weaponSystem);

        // Render HUD (disabled - using cockpit instead)
        // this.hud.render(this.playerShip);

        // Render terminal
        this.terminal.render();

        // Render menu
        this.menuSystem.render();

        // Render debug info
        if (this.showDebug) {
            this.renderDebugInfo();
        }
    }



    /**
     * Render all entities with sprites
     */
    renderEntities() {
        const entities = this.entityManager.getEntitiesWithComponents('transform', 'sprite');

        for (const entity of entities) {
            const transform = entity.getComponent('transform');
            const spriteComp = entity.getComponent('sprite');

            if (!spriteComp.visible) continue;

            const coords = this.renderer.getViewportCoords(
                transform.x,
                transform.y,
                this.camera.x,
                this.camera.y
            );

            // Check if in viewport
            if (!this.renderer.isInViewport(coords.x, coords.y)) continue;

            // Save context state
            const ctx = this.renderer.context;
            ctx.save();

            // Translate to sprite position
            ctx.translate(coords.x, coords.y);

            // Rotate if needed
            if (transform.rotation !== 0) {
                ctx.rotate(transform.rotation);
            }

            // Scale if needed
            if (transform.scale !== 1) {
                ctx.scale(transform.scale, transform.scale);
            }

            // Draw sprite centered
            if (spriteComp.sprite && spriteComp.sprite.image) {
                ctx.globalAlpha = spriteComp.alpha;
                ctx.drawImage(
                    spriteComp.sprite.image,
                    -spriteComp.width / 2,
                    -spriteComp.height / 2,
                    spriteComp.width,
                    spriteComp.height
                );
            }

            // Restore context state
            ctx.restore();
        }
    }



    /**
     * Render debug information
     */
    renderDebugInfo() {
        const x = this.renderer.baseWidth - 300;
        let y = 20;
        const lineHeight = 15;
        
        this.renderer.drawText(`FPS: ${this.fps}`, x, y, RETRO_PALETTE.statusBlue, 10);
        y += lineHeight;
        
        this.renderer.drawText(`Time Scale: ${this.timeScale.toFixed(2)}x`, x, y, RETRO_PALETTE.statusBlue, 10);
        y += lineHeight;
        
        this.renderer.drawText(`Entities: ${this.entityManager.entities.size}`, x, y, RETRO_PALETTE.statusBlue, 10);
        y += lineHeight;
        
        if (this.playerShip) {
            const transform = this.playerShip.getComponent('transform');
            const velocity = this.playerShip.getComponent('velocity');
            
            if (transform) {
                this.renderer.drawText(`Pos: ${Math.floor(transform.x)}, ${Math.floor(transform.y)}`, x, y, RETRO_PALETTE.statusBlue, 10);
                y += lineHeight;
            }
            
            if (velocity) {
                const speed = Math.sqrt(velocity.vx * velocity.vx + velocity.vy * velocity.vy);
                this.renderer.drawText(`Speed: ${speed.toFixed(1)}`, x, y, RETRO_PALETTE.statusBlue, 10);
                y += lineHeight;
            }
        }
    }

    /**
     * Setup progression system callbacks
     */
    setupProgressionCallbacks() {
        // Level-up callback
        this.progressionSystem.onLevelUp = (level, rewards) => {
            console.log(`🎉 LEVEL UP! Now level ${level}`);

            // Award credits to player
            if (this.playerShip && this.inventorySystem) {
                this.inventorySystem.addCredits(this.playerShip, rewards.credits);
            }

            // Show notification
            if (this.notificationSystem) {
                this.notificationSystem.show(
                    `LEVEL UP! Level ${level}`,
                    `+${rewards.skillPoints} Skill Points | +${rewards.credits} Credits`,
                    'success',
                    5000
                );
            }

            // Play level-up sound
            if (this.audioManager) {
                this.audioManager.playUIBeep();
            }
        };

        // XP gain callback
        this.progressionSystem.onXPGain = (amount, source) => {
            // Optional: Show small XP notification
            // For now, just log it
            // console.log(`+${amount} XP from ${source}`);
        };
    }

    /**
     * Setup skill tree system callbacks
     */
    setupSkillTreeCallbacks() {
        // Skill learned callback
        this.skillTreeSystem.onSkillLearned = (category, skillId, level) => {
            console.log(`📚 Learned skill: ${skillId} level ${level}`);

            // Show notification
            if (this.notificationSystem) {
                const skill = this.skillTreeSystem.skills[category][skillId];
                this.notificationSystem.show(
                    `Skill Learned!`,
                    `${skill.name} Level ${level}`,
                    'success',
                    3000
                );
            }

            // Play sound
            if (this.audioManager) {
                this.audioManager.playUIBeep();
            }

            // Apply skill effects to player
            this.applySkillEffects();
        };

        // Skill maxed callback
        this.skillTreeSystem.onSkillMaxed = (category, skillId) => {
            console.log(`⭐ Maxed skill: ${skillId}`);

            // Show notification
            if (this.notificationSystem) {
                const skill = this.skillTreeSystem.skills[category][skillId];
                this.notificationSystem.show(
                    `Skill Maxed!`,
                    `${skill.name} - Maximum Level`,
                    'success',
                    4000
                );
            }
        };
    }

    /**
     * Apply skill effects to player ship
     */
    applySkillEffects() {
        if (!this.playerShip) return;

        const effects = this.skillTreeSystem.activeEffects;

        // Apply weapon damage bonus
        if (effects.weaponDamage) {
            // Will be applied in weapon system
        }

        // Apply shield capacity bonus
        if (effects.shieldCapacity) {
            const health = this.playerShip.getComponent('health');
            if (health) {
                const baseShield = 100; // Base shield value
                health.maxShield = baseShield * (1 + effects.shieldCapacity);
            }
        }

        // Apply speed bonus
        if (effects.speed) {
            const physics = this.playerShip.getComponent('physics');
            if (physics) {
                const baseMaxSpeed = 300; // Base max speed
                physics.maxSpeed = baseMaxSpeed * (1 + effects.speed);
            }
        }

        // More effects will be applied as needed
    }

    /**
     * Setup ship upgrade system callbacks
     */
    setupShipUpgradeCallbacks() {
        // Upgrade callback
        this.shipUpgradeSystem.onUpgrade = (component, tier, upgrade) => {
            console.log(`🔧 Upgraded ${component} to tier ${tier}`);

            // Show notification
            if (this.notificationSystem) {
                this.notificationSystem.show(
                    `Upgrade Complete!`,
                    `${upgrade.name} - Tier ${tier}`,
                    'success',
                    4000
                );
            }

            // Play sound
            if (this.audioManager) {
                this.audioManager.playUIBeep();
            }

            // Apply upgrade effects to player
            this.applyUpgradeEffects();
        };

        // Max tier callback
        this.shipUpgradeSystem.onMaxTier = (component) => {
            console.log(`⭐ Maxed ${component} upgrades!`);

            // Show notification
            if (this.notificationSystem) {
                this.notificationSystem.show(
                    `Component Maxed!`,
                    `${component.toUpperCase()} - Maximum Tier`,
                    'success',
                    5000
                );
            }
        };
    }

    /**
     * Apply upgrade effects to player ship
     */
    applyUpgradeEffects() {
        if (!this.playerShip) return;

        const stats = this.shipUpgradeSystem.getAllStats();

        // Apply weapon upgrades
        if (stats.weapons) {
            // Weapon damage and fire rate will be applied in weapon system
        }

        // Apply shield upgrades
        if (stats.shields) {
            const health = this.playerShip.getComponent('health');
            if (health) {
                const baseShield = 100;
                health.maxShield = baseShield * stats.shields.capacity;
                health.shieldRegenRate = 1.0 * stats.shields.regenRate;
            }
        }

        // Apply engine upgrades
        if (stats.engines) {
            const physics = this.playerShip.getComponent('physics');
            if (physics) {
                const baseMaxSpeed = 300;
                physics.maxSpeed = baseMaxSpeed * stats.engines.speed;
            }
        }

        // Apply hull upgrades
        if (stats.hull) {
            const health = this.playerShip.getComponent('health');
            if (health) {
                const baseHealth = 100;
                health.maxHealth = baseHealth * stats.hull.health;
            }
        }

        // Apply sensor upgrades
        if (stats.sensors) {
            // Sensor range will be applied in sensor/radar system
        }
    }

    /**
     * Setup reputation system callbacks
     */
    setupReputationCallbacks() {
        // Reputation change callback
        this.reputationSystem.onReputationChange = (faction, oldRep, newRep) => {
            const change = newRep - oldRep;
            const sign = change > 0 ? '+' : '';
            console.log(`📊 ${faction} reputation: ${sign}${change.toFixed(1)} (${newRep.toFixed(1)})`);
        };

        // Status change callback
        this.reputationSystem.onStatusChange = (faction, oldStatus, newStatus) => {
            console.log(`⭐ ${faction} status changed: ${oldStatus} → ${newStatus}`);

            // Show notification
            if (this.notificationSystem) {
                const info = this.reputationSystem.factionInfo[faction];
                const statusName = this.reputationSystem.getStatusName(newStatus);
                const color = this.reputationSystem.getStatusColor(newStatus);

                this.notificationSystem.show(
                    `${info.icon} ${info.name}`,
                    `Status: ${statusName}`,
                    'info',
                    4000
                );
            }

            // Play sound
            if (this.audioManager) {
                this.audioManager.playUIBeep();
            }
        };
    }

    /**
     * Setup achievement system callbacks
     */
    setupAchievementCallbacks() {
        // Achievement unlocked callback
        this.achievementSystem.onAchievementUnlocked = (achievement) => {
            console.log(`🏆 Achievement Unlocked: ${achievement.name}`);

            // Show notification
            if (this.notificationSystem) {
                this.notificationSystem.show(
                    `${achievement.icon} Achievement Unlocked!`,
                    `${achievement.name} - ${achievement.description}`,
                    'success',
                    6000
                );
            }

            // Play sound
            if (this.audioManager) {
                this.audioManager.playUIBeep();
            }

            // Award rewards
            if (achievement.reward) {
                if (achievement.reward.credits && this.playerShip && this.inventorySystem) {
                    this.inventorySystem.addCredits(this.playerShip, achievement.reward.credits);
                }
                if (achievement.reward.xp && this.progressionSystem) {
                    this.progressionSystem.awardXP(achievement.reward.xp, 'achievement');
                }
            }
        };

        // Category complete callback
        this.achievementSystem.onCategoryComplete = (category) => {
            console.log(`⭐ Category Complete: ${category}`);

            // Show notification
            if (this.notificationSystem) {
                this.notificationSystem.show(
                    `🎉 Category Complete!`,
                    `${category.toUpperCase()} - All achievements unlocked`,
                    'success',
                    7000
                );
            }
        };
    }

    /**
     * Update achievement progress
     */
    updateAchievementProgress() {
        if (!this.achievementSystem || !this.progressionSystem) return;

        const stats = this.progressionSystem.stats;

        // Update all progress types
        this.achievementSystem.updateProgress('kills', stats.enemiesKilled || 0);
        this.achievementSystem.updateProgress('damageDealt', stats.damageDealt || 0);
        this.achievementSystem.updateProgress('planetsDiscovered', stats.planetsDiscovered || 0);
        this.achievementSystem.updateProgress('distanceTraveled', stats.distanceTraveled || 0);
        this.achievementSystem.updateProgress('creditsEarned', stats.creditsEarned || 0);
        this.achievementSystem.updateProgress('timePlayed', stats.timePlayed || 0);
        this.achievementSystem.updateProgress('level', this.progressionSystem.level || 1);

        // Update skill-based achievements
        if (this.skillTreeSystem) {
            const skillsSummary = this.skillTreeSystem.getSummary();
            this.achievementSystem.updateProgress('skillsLearned', skillsSummary.totalSkillsLearned || 0);
        }

        // Update upgrade-based achievements
        if (this.shipUpgradeSystem) {
            const upgrades = this.shipUpgradeSystem.currentUpgrades;
            const minTier = Math.min(...Object.values(upgrades));
            this.achievementSystem.updateProgress('allUpgradesTier', minTier);
        }

        // Update reputation-based achievements
        if (this.reputationSystem) {
            const repSummary = this.reputationSystem.getSummary();
            this.achievementSystem.updateProgress('factionAllied', repSummary.allied.length);
            this.achievementSystem.updateProgress('allFactionsAllied',
                repSummary.allied.length === 5 ? 1 : 0);
        }
    }

    /**
     * Award XP for enemy kill
     */
    awardKillXP(enemy) {
        if (!this.progressionSystem) return;

        // Determine enemy type and level
        const enemyType = enemy.enemyType || 'basic';
        const enemyLevel = enemy.level || 1;

        this.progressionSystem.awardKillXP(enemyType, enemyLevel);
    }

    /**
     * Award reputation for enemy kill
     */
    awardKillReputation(enemy) {
        if (!this.reputationSystem) return;

        // Determine enemy faction
        const enemyFaction = enemy.faction || 'pirates';

        // Lose reputation with enemy faction
        this.reputationSystem.loseReputation(enemyFaction, 2);

        // Gain reputation with opposing factions based on relationships
        for (const faction of this.reputationSystem.factions) {
            if (faction === enemyFaction) continue;

            const relationship = this.reputationSystem.getRelationship(faction, enemyFaction);
            if (relationship < 0) {
                // This faction dislikes the enemy, so they like us more
                const gain = Math.abs(relationship) * 3; // Up to 3 points
                this.reputationSystem.gainReputation(faction, gain);
            }
        }
    }

    /**
     * Load progression data
     */
    loadProgression() {
        if (!this.progressionSystem) return;

        const savedData = localStorage.getItem('pixelverse_progression');
        if (savedData) {
            try {
                const data = JSON.parse(savedData);
                this.progressionSystem.load(data);
                console.log(`Loaded progression: Level ${this.progressionSystem.level}`);
            } catch (error) {
                console.error('Failed to load progression:', error);
            }
        }

        // Load skill tree
        if (!this.skillTreeSystem) return;

        const savedSkills = localStorage.getItem('pixelverse_skills');
        if (savedSkills) {
            try {
                const data = JSON.parse(savedSkills);
                this.skillTreeSystem.load(data);
                console.log(`Loaded skills: ${this.skillTreeSystem.getTotalSkillPointsSpent()} points spent`);

                // Apply skill effects
                this.applySkillEffects();
            } catch (error) {
                console.error('Failed to load skills:', error);
            }
        }

        // Load ship upgrades
        if (!this.shipUpgradeSystem) return;

        const savedUpgrades = localStorage.getItem('pixelverse_upgrades');
        if (savedUpgrades) {
            try {
                const data = JSON.parse(savedUpgrades);
                this.shipUpgradeSystem.load(data);
                console.log(`Loaded upgrades: ${this.shipUpgradeSystem.getTotalUpgradeCost()} credits spent`);

                // Apply upgrade effects
                this.applyUpgradeEffects();
            } catch (error) {
                console.error('Failed to load upgrades:', error);
            }
        }

        // Load reputation
        if (!this.reputationSystem) return;

        const savedReputation = localStorage.getItem('pixelverse_reputation');
        if (savedReputation) {
            try {
                const data = JSON.parse(savedReputation);
                this.reputationSystem.load(data);
                console.log(`Loaded reputation data`);
            } catch (error) {
                console.error('Failed to load reputation:', error);
            }
        }

        // Load achievements
        if (!this.achievementSystem) return;

        const savedAchievements = localStorage.getItem('pixelverse_achievements');
        if (savedAchievements) {
            try {
                const data = JSON.parse(savedAchievements);
                this.achievementSystem.load(data);
                const summary = this.achievementSystem.getOverallProgress();
                console.log(`Loaded achievements: ${summary.unlocked}/${summary.total} (${summary.percentage.toFixed(1)}%)`);
            } catch (error) {
                console.error('Failed to load achievements:', error);
            }
        }
    }

    /**
     * Save progression data
     */
    saveProgression() {
        if (!this.progressionSystem) return;

        const data = this.progressionSystem.save();
        localStorage.setItem('pixelverse_progression', JSON.stringify(data));

        // Save skill tree
        if (!this.skillTreeSystem) return;

        const skillData = this.skillTreeSystem.save();
        localStorage.setItem('pixelverse_skills', JSON.stringify(skillData));

        // Save ship upgrades
        if (!this.shipUpgradeSystem) return;

        const upgradeData = this.shipUpgradeSystem.save();
        localStorage.setItem('pixelverse_upgrades', JSON.stringify(upgradeData));

        // Save reputation
        if (!this.reputationSystem) return;

        const reputationData = this.reputationSystem.save();
        localStorage.setItem('pixelverse_reputation', JSON.stringify(reputationData));

        // Save achievements
        if (!this.achievementSystem) return;

        const achievementData = this.achievementSystem.save();
        localStorage.setItem('pixelverse_achievements', JSON.stringify(achievementData));
    }
}

// Start the game when page loads
window.addEventListener('DOMContentLoaded', async () => {
    try {
        const game = new PixelVerse();
        await game.initialize();
        game.start();

        // Resume audio on first user interaction
        document.addEventListener('click', () => {
            if (game.audioManager) {
                game.audioManager.resume();
            }
        }, { once: true });

        console.log('🚀 PixelVerse launched successfully!');
    } catch (error) {
        console.error('❌ Failed to initialize PixelVerse:', error);

        // Show error message to user
        const loadingScreen = document.getElementById('loading-screen');
        if (loadingScreen) {
            loadingScreen.innerHTML = `
                <div style="color: #ff4444; text-align: center; padding: 50px;">
                    <h2>⚠️ Game Failed to Load</h2>
                    <p>Error: ${error.message}</p>
                    <p>Please refresh the page to try again.</p>
                    <button onclick="location.reload()" style="padding: 10px 20px; margin-top: 20px; background: #444; color: white; border: 1px solid #666; cursor: pointer;">Refresh Page</button>
                </div>
            `;
        }
    }
});

