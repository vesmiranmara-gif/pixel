/**
 * PixelVerse - Enhanced Celestial Body Sprite Generator
 * Creates detailed large-scale planets, moons, and stars with surface features
 * Task 3.1: Enhanced Celestial Bodies
 */

class EnhancedCelestialGenerator {
    /**
     * Generate detailed planet with surface features
     * @param {SpriteManager} spriteManager - Sprite manager instance
     * @param {string} name - Sprite name
     * @param {number} size - Planet size (500-2000px)
     * @param {string} type - Planet type (terran, desert, ice, gas, toxic, volcanic, ocean)
     */
    static generateDetailedPlanet(spriteManager, name, size, type = 'terran') {
        const sprite = spriteManager.createSprite(name, size, size);
        const ctx = sprite.createFromCanvas(size, size);

        ctx.clearRect(0, 0, size, size);

        const cx = size / 2;
        const cy = size / 2;
        const radius = size / 2 - 4;

        // Planet type configurations
        const planetConfigs = {
            terran: {
                base: '#2B5F8F',      // Ocean blue
                land: '#4A7C4E',      // Green land
                mountain: '#6B6B6B',  // Gray mountains
                ice: '#E8F4F8',       // Ice caps
                atmosphere: 'rgba(100, 150, 200, 0.3)'
            },
            desert: {
                base: '#C4A572',      // Sand
                land: '#8B6F47',      // Dark sand
                mountain: '#5C4A3A',  // Rock
                ice: '#D4C4B4',       // Light sand
                atmosphere: 'rgba(200, 180, 140, 0.2)'
            },
            ice: {
                base: '#D0E8F0',      // Ice
                land: '#A8C8D8',      // Darker ice
                mountain: '#E8F4F8',  // Snow
                ice: '#FFFFFF',       // Pure white
                atmosphere: 'rgba(200, 220, 240, 0.3)'
            },
            gas: {
                base: '#D4A574',      // Orange
                land: '#B48860',      // Brown bands
                mountain: '#E8C090',  // Light bands
                ice: '#F0D8B0',       // Cream
                atmosphere: 'rgba(220, 180, 120, 0.4)'
            },
            toxic: {
                base: '#6B8B3D',      // Toxic green
                land: '#4A6B2D',      // Dark green
                mountain: '#8BAB5D',  // Light green
                ice: '#3D4A2D',       // Dark patches
                atmosphere: 'rgba(100, 140, 60, 0.4)'
            },
            volcanic: {
                base: '#4A3A3A',      // Dark rock
                land: '#6B4A4A',      // Lighter rock
                mountain: '#8B5A5A',  // Reddish rock
                ice: '#FF4500',       // Lava
                atmosphere: 'rgba(100, 50, 30, 0.3)'
            },
            ocean: {
                base: '#1A4A7A',      // Deep ocean
                land: '#2B5F8F',      // Shallow water
                mountain: '#3A7FAF',  // Light water
                ice: '#E8F4F8',       // Ice
                atmosphere: 'rgba(50, 100, 150, 0.4)'
            }
        };

        const config = planetConfigs[type] || planetConfigs.terran;

        // Draw base sphere
        ctx.fillStyle = config.base;
        ctx.beginPath();
        ctx.arc(cx, cy, radius, 0, Math.PI * 2);
        ctx.fill();

        // Add surface features based on type
        if (type === 'terran' || type === 'ocean') {
            this.addTerranFeatures(ctx, cx, cy, radius, config);
        } else if (type === 'desert') {
            this.addDesertFeatures(ctx, cx, cy, radius, config);
        } else if (type === 'ice') {
            this.addIceFeatures(ctx, cx, cy, radius, config);
        } else if (type === 'gas') {
            this.addGasGiantFeatures(ctx, cx, cy, radius, config);
        } else if (type === 'toxic') {
            this.addToxicFeatures(ctx, cx, cy, radius, config);
        } else if (type === 'volcanic') {
            this.addVolcanicFeatures(ctx, cx, cy, radius, config);
        }

        // Add terminator (day/night line)
        this.addTerminator(ctx, cx, cy, radius);

        // Add atmosphere glow
        this.addAtmosphere(ctx, cx, cy, radius, config.atmosphere);

        return sprite;
    }

    /**
     * Add terran planet features (continents, oceans, mountains, rivers)
     */
    static addTerranFeatures(ctx, cx, cy, radius, config) {
        // Generate continents (5-8 large land masses)
        const continentCount = 5 + Math.floor(Math.random() * 4);
        for (let i = 0; i < continentCount; i++) {
            const angle = (i / continentCount) * Math.PI * 2 + Math.random() * 0.5;
            const dist = Math.random() * radius * 0.6;
            const contX = cx + Math.cos(angle) * dist;
            const contY = cy + Math.sin(angle) * dist;
            const contSize = radius * (0.15 + Math.random() * 0.25);

            // Draw irregular continent shape
            ctx.fillStyle = config.land;
            ctx.beginPath();
            const points = 12 + Math.floor(Math.random() * 8);
            for (let j = 0; j < points; j++) {
                const a = (j / points) * Math.PI * 2;
                const r = contSize * (0.6 + Math.random() * 0.4);
                const x = contX + Math.cos(a) * r;
                const y = contY + Math.sin(a) * r;

                // Check if within planet bounds
                const distFromCenter = Math.sqrt(Math.pow(x - cx, 2) + Math.pow(y - cy, 2));
                if (distFromCenter < radius) {
                    if (j === 0) ctx.moveTo(x, y);
                    else ctx.lineTo(x, y);
                }
            }
            ctx.closePath();
            ctx.fill();

            // Add mountains on continents (small peaks)
            const mountainCount = 3 + Math.floor(Math.random() * 5);
            for (let m = 0; m < mountainCount; m++) {
                const mx = contX + (Math.random() - 0.5) * contSize * 0.8;
                const my = contY + (Math.random() - 0.5) * contSize * 0.8;
                const mSize = 2 + Math.floor(Math.random() * 6);

                const distFromCenter = Math.sqrt(Math.pow(mx - cx, 2) + Math.pow(my - cy, 2));
                if (distFromCenter < radius - 5) {
                    // Draw small mountain peak
                    ctx.fillStyle = config.mountain;
                    ctx.beginPath();
                    ctx.moveTo(mx, my - mSize);
                    ctx.lineTo(mx - mSize, my + mSize);
                    ctx.lineTo(mx + mSize, my + mSize);
                    ctx.closePath();
                    ctx.fill();
                }
            }

            // Add rivers (winding blue lines)
            const riverCount = 1 + Math.floor(Math.random() * 3);
            for (let r = 0; r < riverCount; r++) {
                const startX = contX + (Math.random() - 0.5) * contSize * 0.5;
                const startY = contY + (Math.random() - 0.5) * contSize * 0.5;

                ctx.strokeStyle = config.base;
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.moveTo(startX, startY);

                let rx = startX;
                let ry = startY;
                const segments = 5 + Math.floor(Math.random() * 10);

                for (let s = 0; s < segments; s++) {
                    rx += (Math.random() - 0.5) * 8;
                    ry += (Math.random() - 0.5) * 8;

                    const distFromCenter = Math.sqrt(Math.pow(rx - cx, 2) + Math.pow(ry - cy, 2));
                    if (distFromCenter < radius - 5) {
                        ctx.lineTo(rx, ry);
                    }
                }
                ctx.stroke();
            }
        }

        // Add ice caps at poles
        ctx.fillStyle = config.ice;
        ctx.beginPath();
        ctx.arc(cx, cy - radius + 5, radius * 0.15, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(cx, cy + radius - 5, radius * 0.15, 0, Math.PI * 2);
        ctx.fill();

        // Add craters (impact sites)
        const craterCount = 5 + Math.floor(Math.random() * 10);
        for (let i = 0; i < craterCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * radius * 0.9;
            const crX = cx + Math.cos(angle) * dist;
            const crY = cy + Math.sin(angle) * dist;
            const crSize = 2 + Math.floor(Math.random() * 5);

            // Crater depression
            ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
            ctx.beginPath();
            ctx.arc(crX, crY, crSize, 0, Math.PI * 2);
            ctx.fill();

            // Crater rim
            ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.arc(crX, crY, crSize + 1, 0, Math.PI * 2);
            ctx.stroke();
        }
    }

    /**
     * Add desert planet features (dunes, plains, craters)
     */
    static addDesertFeatures(ctx, cx, cy, radius, config) {
        // Add dune patterns (curved lines)
        const duneCount = 20 + Math.floor(Math.random() * 30);
        for (let i = 0; i < duneCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * radius * 0.9;
            const dx = cx + Math.cos(angle) * dist;
            const dy = cy + Math.sin(angle) * dist;

            ctx.strokeStyle = config.land;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(dx, dy);

            const length = 10 + Math.random() * 30;
            const duneAngle = Math.random() * Math.PI * 2;
            const endX = dx + Math.cos(duneAngle) * length;
            const endY = dy + Math.sin(duneAngle) * length;

            // Curved line for dune
            const cpX = (dx + endX) / 2 + (Math.random() - 0.5) * 10;
            const cpY = (dy + endY) / 2 + (Math.random() - 0.5) * 10;
            ctx.quadraticCurveTo(cpX, cpY, endX, endY);
            ctx.stroke();
        }

        // Add large craters
        const craterCount = 10 + Math.floor(Math.random() * 15);
        for (let i = 0; i < craterCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * radius * 0.9;
            const crX = cx + Math.cos(angle) * dist;
            const crY = cy + Math.sin(angle) * dist;
            const crSize = 3 + Math.floor(Math.random() * 8);

            // Crater
            ctx.fillStyle = config.mountain;
            ctx.beginPath();
            ctx.arc(crX, crY, crSize, 0, Math.PI * 2);
            ctx.fill();

            // Rim highlight
            ctx.strokeStyle = config.ice;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.arc(crX, crY, crSize + 1, Math.PI, Math.PI * 1.5);
            ctx.stroke();
        }

        // Add plains (flat colored areas)
        const plainCount = 5 + Math.floor(Math.random() * 8);
        for (let i = 0; i < plainCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * radius * 0.7;
            const px = cx + Math.cos(angle) * dist;
            const py = cy + Math.sin(angle) * dist;
            const pSize = radius * (0.1 + Math.random() * 0.2);

            ctx.fillStyle = config.ice;
            ctx.beginPath();
            ctx.arc(px, py, pSize, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    /**
     * Add ice planet features (glaciers, crevasses, ice sheets)
     */
    static addIceFeatures(ctx, cx, cy, radius, config) {
        // Add ice sheets (large white areas)
        const sheetCount = 8 + Math.floor(Math.random() * 12);
        for (let i = 0; i < sheetCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * radius * 0.8;
            const sx = cx + Math.cos(angle) * dist;
            const sy = cy + Math.sin(angle) * dist;
            const sSize = radius * (0.08 + Math.random() * 0.15);

            ctx.fillStyle = config.ice;
            ctx.beginPath();
            ctx.arc(sx, sy, sSize, 0, Math.PI * 2);
            ctx.fill();
        }

        // Add crevasses (dark cracks)
        const crevCount = 15 + Math.floor(Math.random() * 20);
        for (let i = 0; i < crevCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * radius * 0.9;
            const cx1 = cx + Math.cos(angle) * dist;
            const cy1 = cy + Math.sin(angle) * dist;

            ctx.strokeStyle = config.land;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(cx1, cy1);

            const segments = 3 + Math.floor(Math.random() * 5);
            let x = cx1;
            let y = cy1;

            for (let s = 0; s < segments; s++) {
                x += (Math.random() - 0.5) * 10;
                y += (Math.random() - 0.5) * 10;
                ctx.lineTo(x, y);
            }
            ctx.stroke();
        }

        // Add polar ice caps (very large)
        ctx.fillStyle = config.ice;
        ctx.beginPath();
        ctx.arc(cx, cy - radius + 10, radius * 0.25, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(cx, cy + radius - 10, radius * 0.25, 0, Math.PI * 2);
        ctx.fill();
    }

    /**
     * Add gas giant features (bands, storms, swirls)
     */
    static addGasGiantFeatures(ctx, cx, cy, radius, config) {
        // Add horizontal cloud bands
        const bandCount = 8 + Math.floor(Math.random() * 12);
        for (let i = 0; i < bandCount; i++) {
            const y = cy - radius + (i / bandCount) * (radius * 2);
            const bandHeight = (radius * 2) / bandCount;

            // Alternate band colors
            const bandColor = i % 2 === 0 ? config.land : config.mountain;

            ctx.fillStyle = bandColor;
            ctx.fillRect(cx - radius, y, radius * 2, bandHeight);
        }

        // Add storm systems (large swirls)
        const stormCount = 3 + Math.floor(Math.random() * 5);
        for (let i = 0; i < stormCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * radius * 0.7;
            const stormX = cx + Math.cos(angle) * dist;
            const stormY = cy + Math.sin(angle) * dist;
            const stormSize = radius * (0.1 + Math.random() * 0.15);

            // Draw swirl pattern
            ctx.strokeStyle = config.ice;
            ctx.lineWidth = 2;

            for (let r = 0; r < 3; r++) {
                ctx.beginPath();
                const spiralRadius = stormSize * (0.3 + r * 0.3);
                const turns = 1.5;
                const steps = 20;

                for (let s = 0; s <= steps; s++) {
                    const t = s / steps;
                    const a = t * Math.PI * 2 * turns;
                    const r = spiralRadius * t;
                    const x = stormX + Math.cos(a) * r;
                    const y = stormY + Math.sin(a) * r;

                    if (s === 0) ctx.moveTo(x, y);
                    else ctx.lineTo(x, y);
                }
                ctx.stroke();
            }
        }
    }

    /**
     * Add toxic planet features (pollution, toxic seas, dead zones)
     */
    static addToxicFeatures(ctx, cx, cy, radius, config) {
        // Add toxic seas (irregular dark patches)
        const seaCount = 5 + Math.floor(Math.random() * 8);
        for (let i = 0; i < seaCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * radius * 0.7;
            const seaX = cx + Math.cos(angle) * dist;
            const seaY = cy + Math.sin(angle) * dist;
            const seaSize = radius * (0.12 + Math.random() * 0.2);

            ctx.fillStyle = config.ice;
            ctx.beginPath();

            const points = 8 + Math.floor(Math.random() * 6);
            for (let j = 0; j < points; j++) {
                const a = (j / points) * Math.PI * 2;
                const r = seaSize * (0.7 + Math.random() * 0.3);
                const x = seaX + Math.cos(a) * r;
                const y = seaY + Math.sin(a) * r;

                if (j === 0) ctx.moveTo(x, y);
                else ctx.lineTo(x, y);
            }
            ctx.closePath();
            ctx.fill();
        }

        // Add pollution clouds (lighter patches)
        const cloudCount = 10 + Math.floor(Math.random() * 15);
        for (let i = 0; i < cloudCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * radius * 0.9;
            const cloudX = cx + Math.cos(angle) * dist;
            const cloudY = cy + Math.sin(angle) * dist;
            const cloudSize = 5 + Math.random() * 15;

            ctx.fillStyle = config.mountain;
            ctx.beginPath();
            ctx.arc(cloudX, cloudY, cloudSize, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    /**
     * Add volcanic planet features (volcanoes, lava flows, ash)
     */
    static addVolcanicFeatures(ctx, cx, cy, radius, config) {
        // Add volcanoes (small cones with lava)
        const volcanoCount = 8 + Math.floor(Math.random() * 12);
        for (let i = 0; i < volcanoCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * radius * 0.85;
            const vx = cx + Math.cos(angle) * dist;
            const vy = cy + Math.sin(angle) * dist;
            const vSize = 3 + Math.floor(Math.random() * 7);

            // Volcano cone
            ctx.fillStyle = config.mountain;
            ctx.beginPath();
            ctx.moveTo(vx, vy - vSize);
            ctx.lineTo(vx - vSize, vy + vSize);
            ctx.lineTo(vx + vSize, vy + vSize);
            ctx.closePath();
            ctx.fill();

            // Lava at peak
            ctx.fillStyle = config.ice; // Using 'ice' as lava color (red/orange)
            ctx.fillRect(vx - 1, vy - vSize, 2, 2);

            // Lava flow
            ctx.strokeStyle = config.ice;
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(vx, vy);

            const flowLength = 5 + Math.floor(Math.random() * 15);
            const flowAngle = angle + (Math.random() - 0.5) * 0.5;
            const flowEndX = vx + Math.cos(flowAngle) * flowLength;
            const flowEndY = vy + Math.sin(flowAngle) * flowLength;

            ctx.lineTo(flowEndX, flowEndY);
            ctx.stroke();
        }

        // Add lava seas (bright orange/red areas)
        const lavaSeaCount = 3 + Math.floor(Math.random() * 5);
        for (let i = 0; i < lavaSeaCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * radius * 0.7;
            const lx = cx + Math.cos(angle) * dist;
            const ly = cy + Math.sin(angle) * dist;
            const lSize = radius * (0.08 + Math.random() * 0.12);

            ctx.fillStyle = config.ice;
            ctx.beginPath();
            ctx.arc(lx, ly, lSize, 0, Math.PI * 2);
            ctx.fill();
        }

        // Add ash clouds (dark patches)
        const ashCount = 15 + Math.floor(Math.random() * 20);
        for (let i = 0; i < ashCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * radius * 0.9;
            const ax = cx + Math.cos(angle) * dist;
            const ay = cy + Math.sin(angle) * dist;
            const aSize = 3 + Math.random() * 8;

            ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
            ctx.beginPath();
            ctx.arc(ax, ay, aSize, 0, Math.PI * 2);
            ctx.fill();
        }
    }


    /**
     * Add terminator line (day/night boundary)
     */
    static addTerminator(ctx, cx, cy, radius) {
        // Dark side
        ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
        ctx.beginPath();
        ctx.arc(cx, cy, radius, Math.PI * 0.4, Math.PI * 1.6);
        ctx.lineTo(cx, cy);
        ctx.closePath();
        ctx.fill();

        // Terminator line
        ctx.strokeStyle = 'rgba(0, 0, 0, 0.3)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(cx, cy, radius, Math.PI * 0.4, Math.PI * 1.6);
        ctx.stroke();
    }

    /**
     * Add atmosphere glow
     */
    static addAtmosphere(ctx, cx, cy, radius, atmosphereColor) {
        // Outer glow
        ctx.strokeStyle = atmosphereColor;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(cx, cy, radius + 2, 0, Math.PI * 2);
        ctx.stroke();

        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(cx, cy, radius + 4, 0, Math.PI * 2);
        ctx.stroke();

        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(cx, cy, radius + 6, 0, Math.PI * 2);
        ctx.stroke();
    }

    /**
     * Generate detailed star with plasma texture and corona
     * @param {SpriteManager} spriteManager - Sprite manager instance
     * @param {string} name - Sprite name
     * @param {number} size - Star size (1000-5000px)
     * @param {string} type - Star type (G, M, K, F, O, Giant, Supergiant)
     */
    static generateDetailedStar(spriteManager, name, size, type = 'G') {
        const sprite = spriteManager.createSprite(name, size, size);
        const ctx = sprite.createFromCanvas(size, size);

        ctx.clearRect(0, 0, size, size);

        const cx = size / 2;
        const cy = size / 2;
        const radius = size / 2 - 50; // Leave room for corona

        // Star type configurations
        const starConfigs = {
            'G': { core: '#FFFFFF', mid: '#FFF8DC', outer: '#FFD700', corona: '#FFE4B5' }, // Yellow
            'M': { core: '#FF6347', mid: '#FF4500', outer: '#DC143C', corona: '#FF8C00' }, // Red
            'K': { core: '#FFD700', mid: '#FFA500', outer: '#FF8C00', corona: '#FFE4B5' }, // Orange
            'F': { core: '#FFFFFF', mid: '#F0F8FF', outer: '#E0FFFF', corona: '#F0FFFF' }, // White-blue
            'O': { core: '#E0FFFF', mid: '#B0E0E6', outer: '#87CEEB', corona: '#ADD8E6' }, // Blue
            'Giant': { core: '#FF4500', mid: '#FF6347', outer: '#FF7F50', corona: '#FFA07A' }, // Red giant
            'Supergiant': { core: '#FF0000', mid: '#FF4500', outer: '#FF6347', corona: '#FF8C00' } // Red supergiant
        };

        const config = starConfigs[type] || starConfigs['G'];

        // Draw base star with gradient
        const gradient = ctx.createRadialGradient(cx, cy, 0, cx, cy, radius);
        gradient.addColorStop(0, config.core);
        gradient.addColorStop(0.5, config.mid);
        gradient.addColorStop(1, config.outer);

        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(cx, cy, radius, 0, Math.PI * 2);
        ctx.fill();

        // Add chaotic plasma texture
        this.addPlasmaTexture(ctx, cx, cy, radius, config);

        // Add sunspots (dark spots)
        this.addSunspots(ctx, cx, cy, radius);

        // Add solar flares (extending arcs)
        this.addSolarFlares(ctx, cx, cy, radius, config);

        // Add corona (outer glow)
        this.addCorona(ctx, cx, cy, radius, config.corona);

        // Make large stars asymmetrical (bubbles)
        if (size >= 2000) {
            this.addAsymmetricalBubbles(ctx, cx, cy, radius, config);
        }

        return sprite;
    }

    /**
     * Add chaotic plasma texture to star surface
     */
    static addPlasmaTexture(ctx, cx, cy, radius, config) {
        // Create turbulent plasma patterns
        const cellCount = Math.floor(radius / 10);

        for (let i = 0; i < cellCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * radius * 0.9;
            const px = cx + Math.cos(angle) * dist;
            const py = cy + Math.sin(angle) * dist;
            const pSize = 5 + Math.random() * 20;

            // Plasma cell
            const cellGradient = ctx.createRadialGradient(px, py, 0, px, py, pSize);
            cellGradient.addColorStop(0, config.core);
            cellGradient.addColorStop(1, 'transparent');

            ctx.fillStyle = cellGradient;
            ctx.beginPath();
            ctx.arc(px, py, pSize, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    /**
     * Add sunspots (dark spots on star surface)
     */
    static addSunspots(ctx, cx, cy, radius) {
        const spotCount = 5 + Math.floor(Math.random() * 10);

        for (let i = 0; i < spotCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * radius * 0.8;
            const sx = cx + Math.cos(angle) * dist;
            const sy = cy + Math.sin(angle) * dist;
            const sSize = 5 + Math.random() * 15;

            // Dark spot
            ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
            ctx.beginPath();
            ctx.arc(sx, sy, sSize, 0, Math.PI * 2);
            ctx.fill();

            // Darker center
            ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
            ctx.beginPath();
            ctx.arc(sx, sy, sSize * 0.5, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    /**
     * Add solar flares (extending arcs from star surface)
     */
    static addSolarFlares(ctx, cx, cy, radius, config) {
        const flareCount = 8 + Math.floor(Math.random() * 12);

        for (let i = 0; i < flareCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const startDist = radius;
            const flareLength = 20 + Math.random() * 80;

            const startX = cx + Math.cos(angle) * startDist;
            const startY = cy + Math.sin(angle) * startDist;
            const endX = cx + Math.cos(angle) * (startDist + flareLength);
            const endY = cy + Math.sin(angle) * (startDist + flareLength);

            // Flare gradient
            const flareGradient = ctx.createLinearGradient(startX, startY, endX, endY);
            flareGradient.addColorStop(0, config.outer);
            flareGradient.addColorStop(1, 'transparent');

            ctx.strokeStyle = flareGradient;
            ctx.lineWidth = 3 + Math.random() * 5;
            ctx.beginPath();
            ctx.moveTo(startX, startY);

            // Curved flare
            const cpX = (startX + endX) / 2 + (Math.random() - 0.5) * 30;
            const cpY = (startY + endY) / 2 + (Math.random() - 0.5) * 30;
            ctx.quadraticCurveTo(cpX, cpY, endX, endY);
            ctx.stroke();
        }
    }

    /**
     * Add corona (outer glow around star)
     */
    static addCorona(ctx, cx, cy, radius, coronaColor) {
        // Multiple layers of corona
        for (let i = 0; i < 5; i++) {
            const coronaRadius = radius + 10 + i * 8;
            const alpha = 0.3 - i * 0.05;

            ctx.strokeStyle = coronaColor.replace(')', `, ${alpha})`).replace('rgb', 'rgba');
            ctx.lineWidth = 4;
            ctx.beginPath();
            ctx.arc(cx, cy, coronaRadius, 0, Math.PI * 2);
            ctx.stroke();
        }
    }

    /**
     * Add asymmetrical bubbles for large stars
     */
    static addAsymmetricalBubbles(ctx, cx, cy, radius, config) {
        const bubbleCount = 5 + Math.floor(Math.random() * 8);

        for (let i = 0; i < bubbleCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = radius * (0.7 + Math.random() * 0.3);
            const bx = cx + Math.cos(angle) * dist;
            const by = cy + Math.sin(angle) * dist;
            const bSize = radius * (0.1 + Math.random() * 0.2);

            // Bubble
            const bubbleGradient = ctx.createRadialGradient(bx, by, 0, bx, by, bSize);
            bubbleGradient.addColorStop(0, config.mid);
            bubbleGradient.addColorStop(1, config.outer);

            ctx.fillStyle = bubbleGradient;
            ctx.beginPath();
            ctx.arc(bx, by, bSize, 0, Math.PI * 2);
            ctx.fill();
        }
    }

    /**
     * Generate detailed moon
     * @param {SpriteManager} spriteManager - Sprite manager instance
     * @param {string} name - Sprite name
     * @param {number} size - Moon size (200-800px)
     * @param {string} type - Moon type (rocky, ice, volcanic, dead)
     */
    static generateDetailedMoon(spriteManager, name, size, type = 'rocky') {
        const sprite = spriteManager.createSprite(name, size, size);
        const ctx = sprite.createFromCanvas(size, size);

        ctx.clearRect(0, 0, size, size);

        const cx = size / 2;
        const cy = size / 2;
        const radius = size / 2 - 2;

        // Moon type configurations
        const moonConfigs = {
            rocky: { base: '#8B8B8B', dark: '#5A5A5A', light: '#A8A8A8' },
            ice: { base: '#D0E8F0', dark: '#A8C8D8', light: '#FFFFFF' },
            volcanic: { base: '#4A3A3A', dark: '#2A1A1A', light: '#FF4500' },
            dead: { base: '#6B6B6B', dark: '#3A3A3A', light: '#8B8B8B' }
        };

        const config = moonConfigs[type] || moonConfigs.rocky;

        // Draw base sphere
        ctx.fillStyle = config.base;
        ctx.beginPath();
        ctx.arc(cx, cy, radius, 0, Math.PI * 2);
        ctx.fill();

        // Add many craters (moons are heavily cratered)
        const craterCount = 20 + Math.floor(Math.random() * 40);
        for (let i = 0; i < craterCount; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * radius * 0.9;
            const crX = cx + Math.cos(angle) * dist;
            const crY = cy + Math.sin(angle) * dist;
            const crSize = 2 + Math.floor(Math.random() * (size / 20));

            // Crater depression
            ctx.fillStyle = config.dark;
            ctx.beginPath();
            ctx.arc(crX, crY, crSize, 0, Math.PI * 2);
            ctx.fill();

            // Crater rim
            ctx.strokeStyle = config.light;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.arc(crX, crY, crSize + 1, Math.PI * 1.2, Math.PI * 1.8);
            ctx.stroke();
        }

        // Add volcanic features if volcanic type
        if (type === 'volcanic') {
            const volcanoCount = 5 + Math.floor(Math.random() * 10);
            for (let i = 0; i < volcanoCount; i++) {
                const angle = Math.random() * Math.PI * 2;
                const dist = Math.random() * radius * 0.8;
                const vx = cx + Math.cos(angle) * dist;
                const vy = cy + Math.sin(angle) * dist;

                ctx.fillStyle = config.light;
                ctx.fillRect(vx - 1, vy - 1, 2, 2);
            }
        }

        // Add terminator
        ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
        ctx.beginPath();
        ctx.arc(cx, cy, radius, Math.PI * 0.4, Math.PI * 1.6);
        ctx.lineTo(cx, cy);
        ctx.closePath();
        ctx.fill();

        return sprite;
    }

    /**
     * Generate all enhanced celestial bodies
     */
    static generateAll(spriteManager) {
        console.log('Generating enhanced celestial bodies...');

        // Generate detailed planets (various sizes)
        this.generateDetailedPlanet(spriteManager, 'enhanced_planet_terran_500', 500, 'terran');
        this.generateDetailedPlanet(spriteManager, 'enhanced_planet_terran_1000', 1000, 'terran');
        this.generateDetailedPlanet(spriteManager, 'enhanced_planet_desert_800', 800, 'desert');
        this.generateDetailedPlanet(spriteManager, 'enhanced_planet_ice_600', 600, 'ice');
        this.generateDetailedPlanet(spriteManager, 'enhanced_planet_gas_1500', 1500, 'gas');
        this.generateDetailedPlanet(spriteManager, 'enhanced_planet_toxic_700', 700, 'toxic');
        this.generateDetailedPlanet(spriteManager, 'enhanced_planet_volcanic_900', 900, 'volcanic');
        this.generateDetailedPlanet(spriteManager, 'enhanced_planet_ocean_1200', 1200, 'ocean');

        // Generate detailed stars (various sizes and types)
        this.generateDetailedStar(spriteManager, 'enhanced_star_g_1000', 1000, 'G');
        this.generateDetailedStar(spriteManager, 'enhanced_star_m_1500', 1500, 'M');
        this.generateDetailedStar(spriteManager, 'enhanced_star_k_1200', 1200, 'K');
        this.generateDetailedStar(spriteManager, 'enhanced_star_f_1800', 1800, 'F');
        this.generateDetailedStar(spriteManager, 'enhanced_star_giant_3000', 3000, 'Giant');
        this.generateDetailedStar(spriteManager, 'enhanced_star_supergiant_5000', 5000, 'Supergiant');

        // Generate detailed moons (various sizes)
        this.generateDetailedMoon(spriteManager, 'enhanced_moon_rocky_200', 200, 'rocky');
        this.generateDetailedMoon(spriteManager, 'enhanced_moon_rocky_400', 400, 'rocky');
        this.generateDetailedMoon(spriteManager, 'enhanced_moon_ice_300', 300, 'ice');
        this.generateDetailedMoon(spriteManager, 'enhanced_moon_volcanic_500', 500, 'volcanic');
        this.generateDetailedMoon(spriteManager, 'enhanced_moon_dead_350', 350, 'dead');

        console.log('Enhanced celestial bodies generated!');
    }
}

