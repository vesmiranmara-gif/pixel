/**
 * PixelVerse - Spacecraft Sprite Generator
 * Creates detailed, pixel-perfect spacecraft sprites with isometric projection
 * Based on Prompts 9 & 13 specifications
 */

class SpacecraftSpriteGenerator {
    /**
     * Generate Frigate Class spaceship (64x64, pointed design)
     */
    static generateFrigate(spriteManager) {
        const sprite = spriteManager.createSprite('frigate', 64, 64);
        const ctx = sprite.createFromCanvas(64, 64);
        
        // Clear background
        ctx.clearRect(0, 0, 64, 64);
        
        // Center position
        const cx = 32;
        const cy = 32;
        
        // Main hull (triangular wedge)
        ctx.fillStyle = RETRO_PALETTE.hullPrimary;
        ctx.beginPath();
        ctx.moveTo(cx + 20, cy); // Nose (pointed)
        ctx.lineTo(cx - 10, cy - 12); // Top left
        ctx.lineTo(cx - 15, cy); // Mid left
        ctx.lineTo(cx - 10, cy + 12); // Bottom left
        ctx.closePath();
        ctx.fill();
        
        // Hull shadow (bottom-right)
        ctx.fillStyle = RETRO_PALETTE.hullShadow;
        ctx.beginPath();
        ctx.moveTo(cx + 20, cy + 1);
        ctx.lineTo(cx - 10, cy + 13);
        ctx.lineTo(cx - 15, cy + 1);
        ctx.lineTo(cx - 10, cy + 12);
        ctx.closePath();
        ctx.fill();
        
        // Secondary hull section
        ctx.fillStyle = RETRO_PALETTE.hullSecondary;
        SpriteGenerator.drawRect(ctx, cx - 12, cy - 8, 10, 16, RETRO_PALETTE.hullSecondary);
        
        // Side fins
        ctx.fillStyle = RETRO_PALETTE.hullPrimary;
        // Top fin
        ctx.beginPath();
        ctx.moveTo(cx, cy - 12);
        ctx.lineTo(cx + 5, cy - 15);
        ctx.lineTo(cx + 8, cy - 12);
        ctx.closePath();
        ctx.fill();
        
        // Bottom fin
        ctx.beginPath();
        ctx.moveTo(cx, cy + 12);
        ctx.lineTo(cx + 5, cy + 15);
        ctx.lineTo(cx + 8, cy + 12);
        ctx.closePath();
        ctx.fill();
        
        // Twin engines at rear
        SpriteGenerator.drawRect(ctx, cx - 14, cy - 6, 4, 4, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawRect(ctx, cx - 14, cy + 2, 4, 4, RETRO_PALETTE.hullSecondary);
        
        // Engine nozzles
        SpriteGenerator.drawRect(ctx, cx - 16, cy - 5, 2, 2, RETRO_PALETTE.darkGray);
        SpriteGenerator.drawRect(ctx, cx - 16, cy + 3, 2, 2, RETRO_PALETTE.darkGray);
        
        // Weapon turrets (dorsal and ventral)
        SpriteGenerator.drawRect(ctx, cx + 8, cy - 2, 3, 4, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawPixel(ctx, cx + 9, cy, RETRO_PALETTE.darkGray);
        
        // Sensor dome on top
        SpriteGenerator.drawRect(ctx, cx + 2, cy - 2, 3, 3, RETRO_PALETTE.hullAccent);
        SpriteGenerator.drawPixel(ctx, cx + 3, cy - 1, RETRO_PALETTE.brightGray);
        
        // Panel lines (every 8-16 pixels)
        SpriteGenerator.addPanelLines(ctx, cx - 15, cy - 12, 35, 24, 8, RETRO_PALETTE.hullShadow);
        
        // Greebles
        SpriteGenerator.addGreeble(ctx, cx + 5, cy - 4, 'sensor', 3);
        SpriteGenerator.addGreeble(ctx, cx - 8, cy - 6, 'hatch', 2);
        SpriteGenerator.addGreeble(ctx, cx - 8, cy + 4, 'hatch', 2);
        SpriteGenerator.addGreeble(ctx, cx - 4, cy - 8, 'vent', 2);
        
        // Navigation lights
        SpriteGenerator.drawPixel(ctx, cx + 20, cy, RETRO_PALETTE.alertRed); // Nose
        SpriteGenerator.drawPixel(ctx, cx - 13, cy - 5, RETRO_PALETTE.statusBlue); // Engine
        SpriteGenerator.drawPixel(ctx, cx - 13, cy + 5, RETRO_PALETTE.statusBlue); // Engine
        
        // Wear and tear
        SpriteGenerator.addWear(ctx, cx - 15, cy - 12, 35, 24, 0.05);
        
        return sprite;
    }

    /**
     * Generate Transport Class spaceship (96x48, flat design)
     */
    static generateTransport(spriteManager) {
        const sprite = spriteManager.createSprite('transport', 96, 48);
        const ctx = sprite.createFromCanvas(96, 48);
        
        ctx.clearRect(0, 0, 96, 48);
        
        const cx = 48;
        const cy = 24;
        
        // Main fuselage (elongated rectangle)
        SpriteGenerator.drawRect(ctx, cx - 30, cy - 8, 60, 16, RETRO_PALETTE.hullPrimary);
        
        // Shadow
        SpriteGenerator.drawRect(ctx, cx - 29, cy - 7, 60, 16, RETRO_PALETTE.hullShadow);
        
        // Central cargo section
        SpriteGenerator.drawRect(ctx, cx - 15, cy - 6, 30, 12, RETRO_PALETTE.hullSecondary);
        
        // Cargo bay doors (grid pattern)
        for (let i = 0; i < 5; i++) {
            const x = cx - 12 + (i * 6);
            SpriteGenerator.drawLine(ctx, x, cy - 6, x, cy + 6, RETRO_PALETTE.darkGray);
        }
        for (let j = 0; j < 3; j++) {
            const y = cy - 6 + (j * 6);
            SpriteGenerator.drawLine(ctx, cx - 15, y, cx + 15, y, RETRO_PALETTE.darkGray);
        }
        
        // Wing-like extensions at rear
        ctx.fillStyle = RETRO_PALETTE.hullPrimary;
        ctx.beginPath();
        ctx.moveTo(cx - 28, cy - 8);
        ctx.lineTo(cx - 35, cy - 12);
        ctx.lineTo(cx - 30, cy - 8);
        ctx.closePath();
        ctx.fill();
        
        ctx.beginPath();
        ctx.moveTo(cx - 28, cy + 8);
        ctx.lineTo(cx - 35, cy + 12);
        ctx.lineTo(cx - 30, cy + 8);
        ctx.closePath();
        ctx.fill();
        
        // Four engines (2x2 cluster)
        SpriteGenerator.drawRect(ctx, cx - 32, cy - 4, 4, 3, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawRect(ctx, cx - 32, cy + 1, 4, 3, RETRO_PALETTE.hullSecondary);
        
        // Engine nozzles
        SpriteGenerator.drawRect(ctx, cx - 34, cy - 3, 2, 2, RETRO_PALETTE.darkGray);
        SpriteGenerator.drawRect(ctx, cx - 34, cy + 2, 2, 2, RETRO_PALETTE.darkGray);
        
        // Docking clamps (articulated arms)
        ctx.strokeStyle = RETRO_PALETTE.hullSecondary;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(cx + 20, cy - 8);
        ctx.lineTo(cx + 25, cy - 10);
        ctx.lineTo(cx + 28, cy - 8);
        ctx.stroke();
        
        ctx.beginPath();
        ctx.moveTo(cx + 20, cy + 8);
        ctx.lineTo(cx + 25, cy + 10);
        ctx.lineTo(cx + 28, cy + 8);
        ctx.stroke();
        
        // Weapon emplacements
        SpriteGenerator.drawRect(ctx, cx + 10, cy - 10, 3, 3, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawRect(ctx, cx, cy - 10, 3, 3, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawRect(ctx, cx - 10, cy - 10, 3, 3, RETRO_PALETTE.hullSecondary);
        
        // Panel lines
        SpriteGenerator.addPanelLines(ctx, cx - 30, cy - 8, 60, 16, 12, RETRO_PALETTE.hullShadow);
        
        // Greebles
        SpriteGenerator.addGreeble(ctx, cx + 15, cy - 2, 'sensor', 2);
        SpriteGenerator.addGreeble(ctx, cx - 5, cy + 2, 'hatch', 3);
        SpriteGenerator.addGreeble(ctx, cx + 5, cy - 4, 'vent', 2);
        
        // Navigation lights
        SpriteGenerator.drawPixel(ctx, cx + 30, cy, RETRO_PALETTE.alertRed);
        SpriteGenerator.drawPixel(ctx, cx - 30, cy, RETRO_PALETTE.alertRed);
        SpriteGenerator.drawPixel(ctx, cx - 35, cy - 12, RETRO_PALETTE.statusBlue);
        SpriteGenerator.drawPixel(ctx, cx - 35, cy + 12, RETRO_PALETTE.statusBlue);
        
        // Wear (more extensive for cargo ship)
        SpriteGenerator.addWear(ctx, cx - 30, cy - 8, 60, 16, 0.08);
        
        // Damaged cargo bay door
        SpriteGenerator.drawRect(ctx, cx - 3, cy - 2, 2, 2, RETRO_PALETTE.voidBlack);
        
        return sprite;
    }

    /**
     * Generate Huge Spaceship (128x96, bulky design)
     */
    static generateHugeShip(spriteManager) {
        const sprite = spriteManager.createSprite('huge_ship', 128, 96);
        const ctx = sprite.createFromCanvas(128, 96);
        
        ctx.clearRect(0, 0, 128, 96);
        
        const cx = 64;
        const cy = 48;
        
        // Main superstructure (multiple blocky sections)
        SpriteGenerator.drawRect(ctx, cx - 40, cy - 24, 80, 48, RETRO_PALETTE.hullPrimary);
        
        // Shadow
        SpriteGenerator.drawRect(ctx, cx - 39, cy - 23, 80, 48, RETRO_PALETTE.hullShadow);
        
        // Upper deck
        SpriteGenerator.drawRect(ctx, cx - 30, cy - 32, 60, 16, RETRO_PALETTE.hullSecondary);
        
        // Lower deck
        SpriteGenerator.drawRect(ctx, cx - 35, cy + 16, 70, 12, RETRO_PALETTE.hullSecondary);
        
        // Command tower
        SpriteGenerator.drawRect(ctx, cx - 10, cy - 40, 20, 16, RETRO_PALETTE.hullPrimary);
        
        // Main engines (two large rectangular nozzles)
        SpriteGenerator.drawRect(ctx, cx - 45, cy - 16, 8, 12, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawRect(ctx, cx - 45, cy + 4, 8, 12, RETRO_PALETTE.hullSecondary);
        
        // Engine nozzles (detailed)
        SpriteGenerator.drawRect(ctx, cx - 48, cy - 14, 3, 8, RETRO_PALETTE.darkGray);
        SpriteGenerator.drawRect(ctx, cx - 48, cy + 6, 3, 8, RETRO_PALETTE.darkGray);
        SpriteGenerator.drawRect(ctx, cx - 50, cy - 12, 2, 4, RETRO_PALETTE.voidDeep);
        SpriteGenerator.drawRect(ctx, cx - 50, cy + 8, 2, 4, RETRO_PALETTE.voidDeep);
        
        // Large weapon arrays
        SpriteGenerator.drawRect(ctx, cx + 20, cy - 28, 8, 8, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawRect(ctx, cx + 20, cy + 20, 8, 8, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawPixel(ctx, cx + 24, cy - 24, RETRO_PALETTE.darkGray);
        SpriteGenerator.drawPixel(ctx, cx + 24, cy + 24, RETRO_PALETTE.darkGray);
        
        // Viewports/windows (rows of small squares)
        for (let i = 0; i < 10; i++) {
            const x = cx - 25 + (i * 5);
            SpriteGenerator.drawPixel(ctx, x, cy - 20, RETRO_PALETTE.paleGray);
            SpriteGenerator.drawPixel(ctx, x, cy - 10, RETRO_PALETTE.paleGray);
            SpriteGenerator.drawPixel(ctx, x, cy, RETRO_PALETTE.paleGray);
            SpriteGenerator.drawPixel(ctx, x, cy + 10, RETRO_PALETTE.paleGray);
        }
        
        // Landing bay (large opening on bottom)
        SpriteGenerator.drawRect(ctx, cx - 15, cy + 20, 30, 8, RETRO_PALETTE.voidBlack);
        SpriteGenerator.drawRect(ctx, cx - 16, cy + 19, 32, 1, RETRO_PALETTE.hullHighlight);
        
        // Extensive panel lines
        SpriteGenerator.addPanelLines(ctx, cx - 40, cy - 32, 80, 64, 16, RETRO_PALETTE.hullShadow);
        
        // Communication dishes
        ctx.fillStyle = RETRO_PALETTE.hullAccent;
        ctx.beginPath();
        ctx.arc(cx + 10, cy - 35, 3, 0, Math.PI * 2);
        ctx.fill();
        
        // Sensor clusters
        SpriteGenerator.addGreeble(ctx, cx - 5, cy - 36, 'sensor', 4);
        SpriteGenerator.addGreeble(ctx, cx + 15, cy - 15, 'sensor', 3);
        
        // Maintenance hatches
        for (let i = 0; i < 5; i++) {
            SpriteGenerator.addGreeble(ctx, cx - 30 + (i * 15), cy - 5, 'hatch', 3);
        }
        
        // Ventilation
        SpriteGenerator.addGreeble(ctx, cx - 20, cy + 5, 'vent', 4);
        SpriteGenerator.addGreeble(ctx, cx + 10, cy + 5, 'vent', 4);
        
        // Caution stripe down center
        ctx.strokeStyle = RETRO_PALETTE.cautionOrange;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(cx, cy - 32);
        ctx.lineTo(cx, cy + 24);
        ctx.stroke();
        
        // Multiple navigation lights
        SpriteGenerator.drawPixel(ctx, cx + 40, cy, RETRO_PALETTE.alertRed);
        SpriteGenerator.drawPixel(ctx, cx - 40, cy - 24, RETRO_PALETTE.statusBlue);
        SpriteGenerator.drawPixel(ctx, cx - 40, cy + 24, RETRO_PALETTE.statusBlue);
        SpriteGenerator.drawPixel(ctx, cx, cy - 40, RETRO_PALETTE.statusBlue);
        
        // Extensive wear
        SpriteGenerator.addWear(ctx, cx - 40, cy - 32, 80, 64, 0.12);
        
        // Hull breaches/damage
        SpriteGenerator.drawRect(ctx, cx + 15, cy + 8, 3, 3, RETRO_PALETTE.voidBlack);
        SpriteGenerator.drawRect(ctx, cx - 25, cy - 18, 2, 2, RETRO_PALETTE.voidBlack);
        
        return sprite;
    }

    /**
     * Generate Interceptor Class (48x48, fast fighter)
     */
    static generateInterceptor(spriteManager) {
        const sprite = spriteManager.createSprite('interceptor', 48, 48);
        const ctx = sprite.createFromCanvas(48, 48);

        ctx.clearRect(0, 0, 48, 48);

        const cx = 24;
        const cy = 24;

        // Sleek, narrow fuselage
        ctx.fillStyle = RETRO_PALETTE.hullPrimary;
        ctx.beginPath();
        ctx.moveTo(cx + 15, cy); // Nose
        ctx.lineTo(cx - 8, cy - 4);
        ctx.lineTo(cx - 12, cy);
        ctx.lineTo(cx - 8, cy + 4);
        ctx.closePath();
        ctx.fill();

        // Shadow
        ctx.fillStyle = RETRO_PALETTE.hullShadow;
        ctx.beginPath();
        ctx.moveTo(cx + 15, cy + 1);
        ctx.lineTo(cx - 8, cy + 5);
        ctx.lineTo(cx - 12, cy + 1);
        ctx.lineTo(cx - 8, cy + 4);
        ctx.closePath();
        ctx.fill();

        // Swept-back wings
        ctx.fillStyle = RETRO_PALETTE.hullSecondary;
        // Top wing
        ctx.beginPath();
        ctx.moveTo(cx, cy - 4);
        ctx.lineTo(cx + 8, cy - 10);
        ctx.lineTo(cx + 10, cy - 8);
        ctx.lineTo(cx + 2, cy - 4);
        ctx.closePath();
        ctx.fill();

        // Bottom wing
        ctx.beginPath();
        ctx.moveTo(cx, cy + 4);
        ctx.lineTo(cx + 8, cy + 10);
        ctx.lineTo(cx + 10, cy + 8);
        ctx.lineTo(cx + 2, cy + 4);
        ctx.closePath();
        ctx.fill();

        // Single powerful engine
        SpriteGenerator.drawRect(ctx, cx - 13, cy - 2, 3, 4, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawRect(ctx, cx - 15, cy - 1, 2, 2, RETRO_PALETTE.darkGray);

        // Cockpit canopy
        SpriteGenerator.drawRect(ctx, cx + 8, cy - 1, 3, 2, RETRO_PALETTE.paleGray);

        // Weapon pods on wings
        SpriteGenerator.drawRect(ctx, cx + 6, cy - 8, 2, 2, RETRO_PALETTE.darkGray);
        SpriteGenerator.drawRect(ctx, cx + 6, cy + 6, 2, 2, RETRO_PALETTE.darkGray);

        // Panel lines
        SpriteGenerator.addPanelLines(ctx, cx - 12, cy - 4, 27, 8, 6, RETRO_PALETTE.hullShadow);

        // Minimal greebles (fast and light)
        SpriteGenerator.addGreeble(ctx, cx + 2, cy - 2, 'sensor', 2);
        SpriteGenerator.addGreeble(ctx, cx - 6, cy - 1, 'vent', 2);

        // Navigation lights
        SpriteGenerator.drawPixel(ctx, cx + 15, cy, RETRO_PALETTE.alertRed);
        SpriteGenerator.drawPixel(ctx, cx - 13, cy, RETRO_PALETTE.statusBlue);

        // Light wear (new ship)
        SpriteGenerator.addWear(ctx, cx - 12, cy - 4, 27, 8, 0.03);

        return sprite;
    }

    /**
     * Generate Bomber Class (80x64, heavy weapons platform)
     */
    static generateBomber(spriteManager) {
        const sprite = spriteManager.createSprite('bomber', 80, 64);
        const ctx = sprite.createFromCanvas(80, 64);

        ctx.clearRect(0, 0, 80, 64);

        const cx = 40;
        const cy = 32;

        // Bulky main hull
        SpriteGenerator.drawRect(ctx, cx - 25, cy - 12, 50, 24, RETRO_PALETTE.hullPrimary);

        // Shadow
        SpriteGenerator.drawRect(ctx, cx - 24, cy - 11, 50, 24, RETRO_PALETTE.hullShadow);

        // Reinforced nose section
        ctx.fillStyle = RETRO_PALETTE.hullSecondary;
        ctx.beginPath();
        ctx.moveTo(cx + 25, cy);
        ctx.lineTo(cx + 20, cy - 8);
        ctx.lineTo(cx + 20, cy + 8);
        ctx.closePath();
        ctx.fill();

        // Heavy armor plating
        SpriteGenerator.drawRect(ctx, cx - 20, cy - 10, 40, 20, RETRO_PALETTE.hullSecondary);

        // Weapon bays (large rectangular pods)
        SpriteGenerator.drawRect(ctx, cx + 5, cy - 16, 12, 6, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawRect(ctx, cx + 5, cy + 10, 12, 6, RETRO_PALETTE.hullSecondary);

        // Bomb bay doors
        for (let i = 0; i < 6; i++) {
            const x = cx - 15 + (i * 5);
            SpriteGenerator.drawLine(ctx, x, cy - 10, x, cy + 10, RETRO_PALETTE.darkGray);
        }

        // Four engines (2x2 cluster)
        SpriteGenerator.drawRect(ctx, cx - 27, cy - 8, 4, 5, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawRect(ctx, cx - 27, cy + 3, 4, 5, RETRO_PALETTE.hullSecondary);

        // Engine nozzles
        SpriteGenerator.drawRect(ctx, cx - 29, cy - 7, 2, 3, RETRO_PALETTE.darkGray);
        SpriteGenerator.drawRect(ctx, cx - 29, cy + 4, 2, 3, RETRO_PALETTE.darkGray);

        // Turret mounts
        SpriteGenerator.drawRect(ctx, cx - 5, cy - 14, 4, 4, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawRect(ctx, cx + 10, cy - 14, 4, 4, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawPixel(ctx, cx - 3, cy - 12, RETRO_PALETTE.darkGray);
        SpriteGenerator.drawPixel(ctx, cx + 12, cy - 12, RETRO_PALETTE.darkGray);

        // Heavy panel lines
        SpriteGenerator.addPanelLines(ctx, cx - 25, cy - 12, 50, 24, 10, RETRO_PALETTE.hullShadow);

        // Greebles
        SpriteGenerator.addGreeble(ctx, cx, cy - 6, 'sensor', 3);
        SpriteGenerator.addGreeble(ctx, cx - 10, cy + 4, 'hatch', 3);
        SpriteGenerator.addGreeble(ctx, cx + 8, cy, 'vent', 3);

        // Caution stripes on weapon bays
        ctx.strokeStyle = RETRO_PALETTE.cautionOrange;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(cx + 6, cy - 15);
        ctx.lineTo(cx + 16, cy - 15);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(cx + 6, cy + 11);
        ctx.lineTo(cx + 16, cy + 11);
        ctx.stroke();

        // Navigation lights
        SpriteGenerator.drawPixel(ctx, cx + 25, cy, RETRO_PALETTE.alertRed);
        SpriteGenerator.drawPixel(ctx, cx - 25, cy - 8, RETRO_PALETTE.statusBlue);
        SpriteGenerator.drawPixel(ctx, cx - 25, cy + 8, RETRO_PALETTE.statusBlue);

        // Heavy wear (combat veteran)
        SpriteGenerator.addWear(ctx, cx - 25, cy - 12, 50, 24, 0.1);

        return sprite;
    }

    /**
     * Generate Mining Ship (72x56, industrial)
     */
    static generateMiningShip(spriteManager) {
        const sprite = spriteManager.createSprite('mining_ship', 72, 56);
        const ctx = sprite.createFromCanvas(72, 56);

        ctx.clearRect(0, 0, 72, 56);

        const cx = 36;
        const cy = 28;

        // Boxy industrial hull
        SpriteGenerator.drawRect(ctx, cx - 20, cy - 10, 40, 20, RETRO_PALETTE.hullPrimary);
        SpriteGenerator.drawRect(ctx, cx - 19, cy - 9, 40, 20, RETRO_PALETTE.hullShadow);

        // Large mining laser array (front)
        SpriteGenerator.drawRect(ctx, cx + 15, cy - 6, 8, 12, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawRect(ctx, cx + 18, cy - 4, 2, 8, RETRO_PALETTE.darkGray);
        SpriteGenerator.drawPixel(ctx, cx + 19, cy, RETRO_PALETTE.cautionOrange);

        // Ore storage containers
        SpriteGenerator.drawRect(ctx, cx - 10, cy - 8, 15, 16, RETRO_PALETTE.hullSecondary);
        for (let i = 0; i < 3; i++) {
            SpriteGenerator.drawLine(ctx, cx - 10 + (i * 5), cy - 8, cx - 10 + (i * 5), cy + 8, RETRO_PALETTE.darkGray);
        }

        // Articulated mining arms
        ctx.strokeStyle = RETRO_PALETTE.hullSecondary;
        ctx.lineWidth = 2;
        // Top arm
        ctx.beginPath();
        ctx.moveTo(cx + 10, cy - 10);
        ctx.lineTo(cx + 15, cy - 14);
        ctx.lineTo(cx + 18, cy - 12);
        ctx.stroke();
        // Bottom arm
        ctx.beginPath();
        ctx.moveTo(cx + 10, cy + 10);
        ctx.lineTo(cx + 15, cy + 14);
        ctx.lineTo(cx + 18, cy + 12);
        ctx.stroke();

        // Claw details
        SpriteGenerator.drawRect(ctx, cx + 17, cy - 13, 2, 2, RETRO_PALETTE.darkGray);
        SpriteGenerator.drawRect(ctx, cx + 17, cy + 11, 2, 2, RETRO_PALETTE.darkGray);

        // Engines
        SpriteGenerator.drawRect(ctx, cx - 22, cy - 6, 4, 4, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawRect(ctx, cx - 22, cy + 2, 4, 4, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawRect(ctx, cx - 24, cy - 5, 2, 2, RETRO_PALETTE.darkGray);
        SpriteGenerator.drawRect(ctx, cx - 24, cy + 3, 2, 2, RETRO_PALETTE.darkGray);

        // Heavy industrial panel lines
        SpriteGenerator.addPanelLines(ctx, cx - 20, cy - 10, 40, 20, 8, RETRO_PALETTE.hullShadow);

        // Industrial greebles
        SpriteGenerator.addGreeble(ctx, cx - 5, cy - 4, 'hatch', 4);
        SpriteGenerator.addGreeble(ctx, cx + 5, cy + 2, 'vent', 3);
        SpriteGenerator.addGreeble(ctx, cx - 15, cy, 'sensor', 2);

        // Warning lights
        SpriteGenerator.drawPixel(ctx, cx + 20, cy - 6, RETRO_PALETTE.cautionOrange);
        SpriteGenerator.drawPixel(ctx, cx + 20, cy + 6, RETRO_PALETTE.cautionOrange);

        // Heavy wear (hard work)
        SpriteGenerator.addWear(ctx, cx - 20, cy - 10, 40, 20, 0.15);

        // Scorch marks from mining laser
        SpriteGenerator.drawRect(ctx, cx + 14, cy - 2, 2, 4, RETRO_PALETTE.voidBlack);

        return sprite;
    }

    /**
     * Generate Scout Ship (40x40, small and agile)
     */
    static generateScout(spriteManager) {
        const sprite = spriteManager.createSprite('scout', 40, 40);
        const ctx = sprite.createFromCanvas(40, 40);

        ctx.clearRect(0, 0, 40, 40);

        const cx = 20;
        const cy = 20;

        // Compact triangular hull
        ctx.fillStyle = RETRO_PALETTE.hullPrimary;
        ctx.beginPath();
        ctx.moveTo(cx + 12, cy);
        ctx.lineTo(cx - 6, cy - 6);
        ctx.lineTo(cx - 8, cy);
        ctx.lineTo(cx - 6, cy + 6);
        ctx.closePath();
        ctx.fill();

        // Shadow
        ctx.fillStyle = RETRO_PALETTE.hullShadow;
        ctx.beginPath();
        ctx.moveTo(cx + 12, cy + 1);
        ctx.lineTo(cx - 6, cy + 7);
        ctx.lineTo(cx - 8, cy + 1);
        ctx.closePath();
        ctx.fill();

        // Large sensor array (distinctive feature)
        SpriteGenerator.drawRect(ctx, cx + 4, cy - 3, 6, 6, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawRect(ctx, cx + 5, cy - 2, 4, 4, RETRO_PALETTE.paleGray);
        SpriteGenerator.drawPixel(ctx, cx + 7, cy, RETRO_PALETTE.statusBlue);

        // Small stabilizer fins
        SpriteGenerator.drawRect(ctx, cx - 2, cy - 8, 4, 2, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawRect(ctx, cx - 2, cy + 6, 4, 2, RETRO_PALETTE.hullSecondary);

        // Single efficient engine
        SpriteGenerator.drawRect(ctx, cx - 9, cy - 1, 2, 2, RETRO_PALETTE.darkGray);

        // Minimal panel lines
        SpriteGenerator.addPanelLines(ctx, cx - 8, cy - 6, 20, 12, 6, RETRO_PALETTE.hullShadow);

        // Sensor greebles
        SpriteGenerator.addGreeble(ctx, cx, cy - 2, 'sensor', 2);
        SpriteGenerator.addGreeble(ctx, cx - 4, cy + 2, 'sensor', 2);

        // Navigation lights
        SpriteGenerator.drawPixel(ctx, cx + 12, cy, RETRO_PALETTE.alertRed);
        SpriteGenerator.drawPixel(ctx, cx - 8, cy, RETRO_PALETTE.statusBlue);

        // Minimal wear (well-maintained)
        SpriteGenerator.addWear(ctx, cx - 8, cy - 6, 20, 12, 0.02);

        return sprite;
    }

    /**
     * Generate Corvette (56x48, patrol ship)
     */
    static generateCorvette(spriteManager) {
        const sprite = spriteManager.createSprite('corvette', 56, 48);
        const ctx = sprite.createFromCanvas(56, 48);

        ctx.clearRect(0, 0, 56, 48);

        const cx = 28;
        const cy = 24;

        // Sleek hull
        ctx.fillStyle = RETRO_PALETTE.hullPrimary;
        ctx.beginPath();
        ctx.moveTo(cx + 18, cy);
        ctx.lineTo(cx - 8, cy - 8);
        ctx.lineTo(cx - 12, cy);
        ctx.lineTo(cx - 8, cy + 8);
        ctx.closePath();
        ctx.fill();

        // Shadow
        ctx.fillStyle = RETRO_PALETTE.hullShadow;
        ctx.beginPath();
        ctx.moveTo(cx + 18, cy + 1);
        ctx.lineTo(cx - 8, cy + 9);
        ctx.lineTo(cx - 12, cy + 1);
        ctx.closePath();
        ctx.fill();

        // Command section
        SpriteGenerator.drawRect(ctx, cx - 4, cy - 6, 12, 12, RETRO_PALETTE.hullSecondary);

        // Bridge windows
        for (let i = 0; i < 3; i++) {
            SpriteGenerator.drawPixel(ctx, cx + 2 + (i * 2), cy - 2, RETRO_PALETTE.paleGray);
        }

        // Weapon hardpoints
        SpriteGenerator.drawRect(ctx, cx + 8, cy - 10, 3, 3, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawRect(ctx, cx + 8, cy + 7, 3, 3, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawPixel(ctx, cx + 9, cy - 9, RETRO_PALETTE.darkGray);
        SpriteGenerator.drawPixel(ctx, cx + 9, cy + 8, RETRO_PALETTE.darkGray);

        // Twin engines
        SpriteGenerator.drawRect(ctx, cx - 13, cy - 4, 3, 3, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawRect(ctx, cx - 13, cy + 1, 3, 3, RETRO_PALETTE.hullSecondary);
        SpriteGenerator.drawRect(ctx, cx - 15, cy - 3, 2, 2, RETRO_PALETTE.darkGray);
        SpriteGenerator.drawRect(ctx, cx - 15, cy + 2, 2, 2, RETRO_PALETTE.darkGray);

        // Panel lines
        SpriteGenerator.addPanelLines(ctx, cx - 12, cy - 8, 30, 16, 8, RETRO_PALETTE.hullShadow);

        // Greebles
        SpriteGenerator.addGreeble(ctx, cx + 4, cy, 'sensor', 2);
        SpriteGenerator.addGreeble(ctx, cx - 6, cy - 3, 'hatch', 2);
        SpriteGenerator.addGreeble(ctx, cx, cy + 4, 'vent', 2);

        // Navigation lights
        SpriteGenerator.drawPixel(ctx, cx + 18, cy, RETRO_PALETTE.alertRed);
        SpriteGenerator.drawPixel(ctx, cx - 12, cy - 4, RETRO_PALETTE.statusBlue);
        SpriteGenerator.drawPixel(ctx, cx - 12, cy + 4, RETRO_PALETTE.statusBlue);

        // Moderate wear
        SpriteGenerator.addWear(ctx, cx - 12, cy - 8, 30, 16, 0.06);

        return sprite;
    }

    /**
     * Generate all spacecraft sprites
     */
    static generateAll(spriteManager) {
        console.log('Generating spacecraft sprites...');

        this.generateFrigate(spriteManager);
        this.generateTransport(spriteManager);
        this.generateHugeShip(spriteManager);
        this.generateInterceptor(spriteManager);
        this.generateBomber(spriteManager);
        this.generateMiningShip(spriteManager);
        this.generateScout(spriteManager);
        this.generateCorvette(spriteManager);

        console.log('Spacecraft sprites generated: 8 types');
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SpacecraftSpriteGenerator;
}

