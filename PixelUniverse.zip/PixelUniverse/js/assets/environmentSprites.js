/**
 * PixelVerse - Environmental Sprite Generator
 * Creates asteroids, planets, stars, and other space objects
 * Based on Prompts 10 & 13 specifications
 */

class EnvironmentSpriteGenerator {
    /**
     * Generate asteroid sprite (32x32, iron composition)
     */
    static generateAsteroid(spriteManager, name = 'asteroid_iron', size = 32, composition = 'iron') {
        const sprite = spriteManager.createSprite(name, size, size);
        const ctx = sprite.createFromCanvas(size, size);
        
        ctx.clearRect(0, 0, size, size);
        
        const cx = size / 2;
        const cy = size / 2;
        const radius = size / 2 - 2;
        
        // Base color based on composition
        const baseColors = {
            iron: RETRO_PALETTE.hullPrimary,
            ice: RETRO_PALETTE.offWhite,
            mineral: RETRO_PALETTE.vintageAmber,
            organic: RETRO_PALETTE.alienGreen
        };
        
        const baseColor = baseColors[composition] || RETRO_PALETTE.hullPrimary;
        
        // Create irregular rocky silhouette
        const points = 12;
        const angleStep = (Math.PI * 2) / points;
        
        ctx.fillStyle = baseColor;
        ctx.beginPath();
        
        for (let i = 0; i < points; i++) {
            const angle = i * angleStep;
            const variance = 0.7 + Math.random() * 0.6; // Random radius variation
            const r = radius * variance;
            const x = cx + Math.cos(angle) * r;
            const y = cy + Math.sin(angle) * r;
            
            if (i === 0) {
                ctx.moveTo(x, y);
            } else {
                ctx.lineTo(x, y);
            }
        }
        
        ctx.closePath();
        ctx.fill();
        
        // Add 2-3 impact craters
        const craterCount = 2 + Math.floor(Math.random() * 2);
        for (let i = 0; i < craterCount; i++) {
            const craterX = cx + (Math.random() - 0.5) * radius;
            const craterY = cy + (Math.random() - 0.5) * radius;
            const craterSize = 3 + Math.floor(Math.random() * 4);
            
            // Crater depression
            ctx.fillStyle = RETRO_PALETTE.shadowGray;
            ctx.beginPath();
            ctx.arc(craterX, craterY, craterSize, 0, Math.PI * 2);
            ctx.fill();
            
            // Raised rim
            ctx.strokeStyle = RETRO_PALETTE.mediumGray;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.arc(craterX, craterY, craterSize + 1, 0, Math.PI * 2);
            ctx.stroke();
        }
        
        // Scattered surface debris (1-pixel rocks)
        const debrisCount = Math.floor(size * size * 0.05);
        for (let i = 0; i < debrisCount; i++) {
            const dx = Math.floor(Math.random() * size);
            const dy = Math.floor(Math.random() * size);
            
            // Check if within asteroid bounds (rough check)
            const dist = Math.sqrt(Math.pow(dx - cx, 2) + Math.pow(dy - cy, 2));
            if (dist < radius) {
                const color = Math.random() > 0.5 ? RETRO_PALETTE.darkGray : RETRO_PALETTE.shadowGray;
                SpriteGenerator.drawPixel(ctx, dx, dy, color);
            }
        }
        
        // Add some 2x2 boulder patches
        const boulderCount = 2 + Math.floor(Math.random() * 2);
        for (let i = 0; i < boulderCount; i++) {
            const bx = cx + (Math.random() - 0.5) * radius * 0.8;
            const by = cy + (Math.random() - 0.5) * radius * 0.8;
            SpriteGenerator.drawRect(ctx, bx, by, 2, 2, RETRO_PALETTE.shadowGray);
        }
        
        // Fissures (tiny cracks)
        const fissureCount = 1 + Math.floor(Math.random() * 2);
        for (let i = 0; i < fissureCount; i++) {
            const fx = cx + (Math.random() - 0.5) * radius;
            const fy = cy + (Math.random() - 0.5) * radius;
            SpriteGenerator.drawLine(ctx, fx, fy, fx + 2, fy + 2, RETRO_PALETTE.voidBlack);
        }
        
        // Hard shadow (bottom-right)
        ctx.globalCompositeOperation = 'multiply';
        ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
        ctx.beginPath();
        ctx.arc(cx + 1, cy + 1, radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalCompositeOperation = 'source-over';
        
        return sprite;
    }

    /**
     * Generate multiple asteroid variants
     */
    static generateAsteroidVariants(spriteManager) {
        this.generateAsteroid(spriteManager, 'asteroid_iron_32', 32, 'iron');
        this.generateAsteroid(spriteManager, 'asteroid_ice_32', 32, 'ice');
        this.generateAsteroid(spriteManager, 'asteroid_mineral_32', 32, 'mineral');
        this.generateAsteroid(spriteManager, 'asteroid_organic_32', 32, 'organic');
        
        // Different sizes
        this.generateAsteroid(spriteManager, 'asteroid_iron_16', 16, 'iron');
        this.generateAsteroid(spriteManager, 'asteroid_iron_64', 64, 'iron');
    }

    /**
     * Generate star sprite (Type G - yellow/white)
     */
    static generateStar(spriteManager, name = 'star_g', size = 16, type = 'G') {
        const sprite = spriteManager.createSprite(name, size, size);
        const ctx = sprite.createFromCanvas(size, size);
        
        ctx.clearRect(0, 0, size, size);
        
        const cx = size / 2;
        const cy = size / 2;
        const radius = size / 2 - 1;
        
        // Star colors by type
        const starColors = {
            'G': { core: RETRO_PALETTE.pureWhite, body: RETRO_PALETTE.vintageAmber, outer: RETRO_PALETTE.vintageCream },
            'M': { core: RETRO_PALETTE.alertRed, body: RETRO_PALETTE.bloodRed, outer: RETRO_PALETTE.vintageCopper },
            'K': { core: RETRO_PALETTE.vintageAmber, body: RETRO_PALETTE.cautionOrange, outer: RETRO_PALETTE.vintageCream },
            'F': { core: RETRO_PALETTE.pureWhite, body: RETRO_PALETTE.paleGray, outer: RETRO_PALETTE.offWhite },
            'Giant': { core: RETRO_PALETTE.bloodRed, body: RETRO_PALETTE.alertRed, outer: RETRO_PALETTE.cautionOrange }
        };
        
        const colors = starColors[type] || starColors['G'];
        
        // Draw star body with radial gradient simulation using dithering
        for (let r = radius; r > 0; r--) {
            let color;
            if (r < radius * 0.3) {
                color = colors.core;
            } else if (r < radius * 0.7) {
                color = colors.body;
            } else {
                color = colors.outer;
            }
            
            ctx.fillStyle = color;
            ctx.beginPath();
            ctx.arc(cx, cy, r, 0, Math.PI * 2);
            ctx.fill();
        }
        
        // Bright center pixel
        SpriteGenerator.drawPixel(ctx, cx, cy, colors.core);
        
        // Hard terminator line (dividing light and shadow)
        ctx.strokeStyle = RETRO_PALETTE.voidDeep;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(cx, cy, radius, Math.PI * 0.3, Math.PI * 1.3);
        ctx.stroke();
        
        // Dark side
        ctx.fillStyle = RETRO_PALETTE.voidDeep;
        ctx.beginPath();
        ctx.arc(cx, cy, radius, Math.PI * 0.3, Math.PI * 1.3);
        ctx.lineTo(cx, cy);
        ctx.closePath();
        ctx.fill();
        
        // Atmospheric glow for larger stars
        if (size >= 16 && type === 'Giant') {
            ctx.strokeStyle = PaletteUtils.withAlpha(colors.outer, 0.5);
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.arc(cx, cy, radius + 1, 0, Math.PI * 2);
            ctx.stroke();
        }
        
        return sprite;
    }

    /**
     * Generate multiple star types
     */
    static generateStarVariants(spriteManager) {
        this.generateStar(spriteManager, 'star_g_16', 16, 'G');
        this.generateStar(spriteManager, 'star_m_16', 16, 'M');
        this.generateStar(spriteManager, 'star_k_16', 16, 'K');
        this.generateStar(spriteManager, 'star_f_16', 16, 'F');
        this.generateStar(spriteManager, 'star_giant_32', 32, 'Giant');
    }

    /**
     * Generate planet sprite
     */
    static generatePlanet(spriteManager, name = 'planet_terran', size = 64, type = 'terran') {
        const sprite = spriteManager.createSprite(name, size, size);
        const ctx = sprite.createFromCanvas(size, size);
        
        ctx.clearRect(0, 0, size, size);
        
        const cx = size / 2;
        const cy = size / 2;
        const radius = size / 2 - 2;
        
        // Planet types
        const planetTypes = {
            terran: { base: RETRO_PALETTE.statusBlue, land: RETRO_PALETTE.hullSecondary, ice: RETRO_PALETTE.offWhite },
            desert: { base: RETRO_PALETTE.vintageAmber, land: RETRO_PALETTE.vintageCream, ice: RETRO_PALETTE.paleGray },
            ice: { base: RETRO_PALETTE.paleGray, land: RETRO_PALETTE.offWhite, ice: RETRO_PALETTE.pureWhite },
            gas: { base: RETRO_PALETTE.cautionOrange, land: RETRO_PALETTE.vintageAmber, ice: RETRO_PALETTE.vintageCream },
            toxic: { base: RETRO_PALETTE.alienGreen, land: RETRO_PALETTE.darkGray, ice: RETRO_PALETTE.voidMid }
        };
        
        const colors = planetTypes[type] || planetTypes.terran;
        
        // Base sphere
        ctx.fillStyle = colors.base;
        ctx.beginPath();
        ctx.arc(cx, cy, radius, 0, Math.PI * 2);
        ctx.fill();
        
        // Surface features (continents/clouds)
        ctx.fillStyle = colors.land;
        for (let i = 0; i < 5; i++) {
            const fx = cx + (Math.random() - 0.5) * radius * 1.5;
            const fy = cy + (Math.random() - 0.5) * radius * 1.5;
            const fsize = 5 + Math.random() * 10;
            
            ctx.beginPath();
            ctx.arc(fx, fy, fsize, 0, Math.PI * 2);
            ctx.fill();
        }
        
        // Ice caps (if applicable)
        if (type === 'terran' || type === 'ice') {
            ctx.fillStyle = colors.ice;
            ctx.beginPath();
            ctx.arc(cx, cy - radius + 3, 5, 0, Math.PI * 2);
            ctx.fill();
            ctx.beginPath();
            ctx.arc(cx, cy + radius - 3, 5, 0, Math.PI * 2);
            ctx.fill();
        }
        
        // Storm systems (darker patches)
        if (type === 'gas') {
            ctx.fillStyle = RETRO_PALETTE.voidDeep;
            for (let i = 0; i < 3; i++) {
                const sx = cx + (Math.random() - 0.5) * radius;
                const sy = cy + (Math.random() - 0.5) * radius;
                SpriteGenerator.drawRect(ctx, sx, sy, 4, 4, RETRO_PALETTE.voidDeep);
            }
        }
        
        // Hard-edge terminator line
        ctx.strokeStyle = RETRO_PALETTE.voidDeep;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(cx, cy - radius);
        ctx.lineTo(cx, cy + radius);
        ctx.stroke();
        
        // Dark side
        ctx.fillStyle = PaletteUtils.withAlpha(RETRO_PALETTE.voidDeep, 0.6);
        ctx.beginPath();
        ctx.arc(cx, cy, radius, Math.PI * 0.5, Math.PI * 1.5);
        ctx.lineTo(cx, cy);
        ctx.closePath();
        ctx.fill();
        
        // Atmospheric glow for gas giants
        if (type === 'gas') {
            ctx.strokeStyle = PaletteUtils.withAlpha(colors.base, 0.5);
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.arc(cx, cy, radius + 1, 0, Math.PI * 2);
            ctx.stroke();
        }
        
        return sprite;
    }

    /**
     * Generate multiple planet types
     */
    static generatePlanetVariants(spriteManager) {
        this.generatePlanet(spriteManager, 'planet_terran_64', 64, 'terran');
        this.generatePlanet(spriteManager, 'planet_desert_64', 64, 'desert');
        this.generatePlanet(spriteManager, 'planet_ice_64', 64, 'ice');
        this.generatePlanet(spriteManager, 'planet_gas_128', 128, 'gas');
        this.generatePlanet(spriteManager, 'planet_toxic_64', 64, 'toxic');
    }

    /**
     * Generate derelict ship fragment
     */
    static generateDerelict(spriteManager, name = 'derelict_fragment', size = 32) {
        const sprite = spriteManager.createSprite(name, size, size);
        const ctx = sprite.createFromCanvas(size, size);
        
        ctx.clearRect(0, 0, size, size);
        
        // Angular piece of hull
        ctx.fillStyle = RETRO_PALETTE.hullPrimary;
        ctx.beginPath();
        ctx.moveTo(5, 10);
        ctx.lineTo(size - 5, 8);
        ctx.lineTo(size - 8, size - 10);
        ctx.lineTo(8, size - 8);
        ctx.closePath();
        ctx.fill();
        
        // Damage (voidBlack holes)
        SpriteGenerator.drawRect(ctx, 10, 12, 4, 4, RETRO_PALETTE.voidBlack);
        SpriteGenerator.drawRect(ctx, size - 15, size - 15, 3, 3, RETRO_PALETTE.voidBlack);
        
        // Shadow
        SpriteGenerator.drawRect(ctx, 6, 11, size - 14, size - 19, RETRO_PALETTE.hullShadow);
        
        // Panel lines
        SpriteGenerator.addPanelLines(ctx, 5, 10, size - 13, size - 18, 8, RETRO_PALETTE.hullShadow);
        
        // Flickering red spark (single pixel)
        SpriteGenerator.drawPixel(ctx, 12, 14, RETRO_PALETTE.alertRed);
        
        // Extensive wear
        SpriteGenerator.addWear(ctx, 5, 10, size - 10, size - 18, 0.15);
        
        return sprite;
    }

    /**
     * Generate Mining Station (96x96)
     */
    static generateMiningStation(spriteManager) {
        const sprite = spriteManager.createSprite('station_mining_96', 96, 96);
        const ctx = sprite.createFromCanvas(96, 96);

        ctx.clearRect(0, 0, 96, 96);

        const cx = 48;
        const cy = 48;

        // Central hub (octagonal)
        ctx.fillStyle = RETRO_PALETTE.hullPrimary;
        ctx.beginPath();
        const sides = 8;
        const radius = 20;
        for (let i = 0; i < sides; i++) {
            const angle = (i / sides) * Math.PI * 2;
            const x = cx + Math.cos(angle) * radius;
            const y = cy + Math.sin(angle) * radius;
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
        }
        ctx.closePath();
        ctx.fill();

        // Four extending arms (cross pattern)
        const armLength = 25;
        const armWidth = 8;

        // Top arm
        SpriteGenerator.drawRect(ctx, cx - armWidth/2, cy - radius - armLength, armWidth, armLength, RETRO_PALETTE.hullSecondary);
        // Bottom arm
        SpriteGenerator.drawRect(ctx, cx - armWidth/2, cy + radius, armWidth, armLength, RETRO_PALETTE.hullSecondary);
        // Left arm
        SpriteGenerator.drawRect(ctx, cx - radius - armLength, cy - armWidth/2, armLength, armWidth, RETRO_PALETTE.hullSecondary);
        // Right arm
        SpriteGenerator.drawRect(ctx, cx + radius, cy - armWidth/2, armLength, armWidth, RETRO_PALETTE.hullSecondary);

        // Docking ports at arm ends
        SpriteGenerator.drawRect(ctx, cx - 3, cy - radius - armLength - 2, 6, 4, RETRO_PALETTE.darkGray);
        SpriteGenerator.drawRect(ctx, cx - 3, cy + radius + armLength - 2, 6, 4, RETRO_PALETTE.darkGray);
        SpriteGenerator.drawRect(ctx, cx - radius - armLength - 2, cy - 3, 4, 6, RETRO_PALETTE.darkGray);
        SpriteGenerator.drawRect(ctx, cx + radius + armLength - 2, cy - 3, 4, 6, RETRO_PALETTE.darkGray);

        // Ore processing modules (bulky sections on arms)
        SpriteGenerator.drawRect(ctx, cx - 8, cy - radius - 15, 16, 10, RETRO_PALETTE.hullPrimary);
        SpriteGenerator.drawRect(ctx, cx - 8, cy + radius + 5, 16, 10, RETRO_PALETTE.hullPrimary);

        // Storage tanks
        ctx.fillStyle = RETRO_PALETTE.hullSecondary;
        ctx.beginPath();
        ctx.arc(cx - radius - 15, cy, 6, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(cx + radius + 15, cy, 6, 0, Math.PI * 2);
        ctx.fill();

        // Central command dome
        SpriteGenerator.drawRect(ctx, cx - 8, cy - 8, 16, 16, RETRO_PALETTE.hullSecondary);

        // Windows on command dome
        for (let i = 0; i < 4; i++) {
            for (let j = 0; j < 4; j++) {
                SpriteGenerator.drawPixel(ctx, cx - 6 + (i * 4), cy - 6 + (j * 4), RETRO_PALETTE.paleGray);
            }
        }

        // Communication dishes
        ctx.fillStyle = RETRO_PALETTE.hullAccent;
        ctx.beginPath();
        ctx.arc(cx - 12, cy - 12, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(cx + 12, cy + 12, 4, 0, Math.PI * 2);
        ctx.fill();

        // Panel lines on all structures
        SpriteGenerator.addPanelLines(ctx, cx - radius, cy - radius, radius * 2, radius * 2, 8, RETRO_PALETTE.hullShadow);

        // Greebles everywhere
        SpriteGenerator.addGreeble(ctx, cx - 4, cy - radius - 12, 'vent', 3);
        SpriteGenerator.addGreeble(ctx, cx + 2, cy + radius + 8, 'vent', 3);
        SpriteGenerator.addGreeble(ctx, cx - radius - 10, cy - 2, 'sensor', 2);
        SpriteGenerator.addGreeble(ctx, cx + radius + 10, cy + 2, 'sensor', 2);

        // Navigation lights
        SpriteGenerator.drawPixel(ctx, cx, cy - radius - armLength - 3, RETRO_PALETTE.statusBlue);
        SpriteGenerator.drawPixel(ctx, cx, cy + radius + armLength + 2, RETRO_PALETTE.statusBlue);
        SpriteGenerator.drawPixel(ctx, cx - radius - armLength - 3, cy, RETRO_PALETTE.statusBlue);
        SpriteGenerator.drawPixel(ctx, cx + radius + armLength + 2, cy, RETRO_PALETTE.statusBlue);

        // Heavy industrial wear
        SpriteGenerator.addWear(ctx, cx - radius - armLength, cy - radius - armLength, radius * 2 + armLength * 2, radius * 2 + armLength * 2, 0.12);

        return sprite;
    }

    /**
     * Generate Research Station (80x80)
     */
    static generateResearchStation(spriteManager) {
        const sprite = spriteManager.createSprite('station_research_80', 80, 80);
        const ctx = sprite.createFromCanvas(80, 80);

        ctx.clearRect(0, 0, 80, 80);

        const cx = 40;
        const cy = 40;

        // Rotating ring structure
        ctx.strokeStyle = RETRO_PALETTE.hullPrimary;
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.arc(cx, cy, 25, 0, Math.PI * 2);
        ctx.stroke();

        // Inner ring detail
        ctx.strokeStyle = RETRO_PALETTE.hullShadow;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(cx, cy, 23, 0, Math.PI * 2);
        ctx.stroke();

        // Central research module (sphere)
        ctx.fillStyle = RETRO_PALETTE.hullSecondary;
        ctx.beginPath();
        ctx.arc(cx, cy, 12, 0, Math.PI * 2);
        ctx.fill();

        // Observation windows
        for (let i = 0; i < 8; i++) {
            const angle = (i / 8) * Math.PI * 2;
            const x = cx + Math.cos(angle) * 10;
            const y = cy + Math.sin(angle) * 10;
            SpriteGenerator.drawPixel(ctx, x, y, RETRO_PALETTE.paleGray);
        }

        // Laboratory modules on ring (4 positions)
        for (let i = 0; i < 4; i++) {
            const angle = (i / 4) * Math.PI * 2;
            const x = cx + Math.cos(angle) * 25;
            const y = cy + Math.sin(angle) * 25;
            SpriteGenerator.drawRect(ctx, x - 4, y - 4, 8, 8, RETRO_PALETTE.hullSecondary);
            SpriteGenerator.drawPixel(ctx, x, y, RETRO_PALETTE.statusBlue);
        }

        // Solar panels (extending outward)
        ctx.fillStyle = RETRO_PALETTE.darkGray;
        // Top panel
        SpriteGenerator.drawRect(ctx, cx - 15, cy - 38, 30, 6, RETRO_PALETTE.darkGray);
        // Bottom panel
        SpriteGenerator.drawRect(ctx, cx - 15, cy + 32, 30, 6, RETRO_PALETTE.darkGray);

        // Panel grid lines
        for (let i = 0; i < 6; i++) {
            SpriteGenerator.drawLine(ctx, cx - 15 + (i * 5), cy - 38, cx - 15 + (i * 5), cy - 32, RETRO_PALETTE.voidBlack);
            SpriteGenerator.drawLine(ctx, cx - 15 + (i * 5), cy + 32, cx - 15 + (i * 5), cy + 38, RETRO_PALETTE.voidBlack);
        }

        // Antenna array
        ctx.strokeStyle = RETRO_PALETTE.hullAccent;
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(cx - 20, cy - 20);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(cx + 20, cy - 20);
        ctx.stroke();

        // Sensor dishes at antenna ends
        ctx.fillStyle = RETRO_PALETTE.hullAccent;
        ctx.beginPath();
        ctx.arc(cx - 20, cy - 20, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(cx + 20, cy - 20, 3, 0, Math.PI * 2);
        ctx.fill();

        // Navigation lights
        SpriteGenerator.drawPixel(ctx, cx, cy - 38, RETRO_PALETTE.statusBlue);
        SpriteGenerator.drawPixel(ctx, cx, cy + 38, RETRO_PALETTE.statusBlue);

        // Clean (well-maintained research facility)
        SpriteGenerator.addWear(ctx, cx - 30, cy - 30, 60, 60, 0.03);

        return sprite;
    }

    /**
     * Generate Trade Hub Station (112x96)
     */
    static generateTradeHub(spriteManager) {
        const sprite = spriteManager.createSprite('station_trade_112', 112, 96);
        const ctx = sprite.createFromCanvas(112, 96);

        ctx.clearRect(0, 0, 112, 96);

        const cx = 56;
        const cy = 48;

        // Large central marketplace structure
        SpriteGenerator.drawRect(ctx, cx - 30, cy - 20, 60, 40, RETRO_PALETTE.hullPrimary);
        SpriteGenerator.drawRect(ctx, cx - 29, cy - 19, 60, 40, RETRO_PALETTE.hullShadow);

        // Multiple docking bays (6 total)
        for (let i = 0; i < 3; i++) {
            const y = cy - 15 + (i * 15);
            // Left side
            SpriteGenerator.drawRect(ctx, cx - 40, y, 10, 8, RETRO_PALETTE.hullSecondary);
            SpriteGenerator.drawRect(ctx, cx - 42, y + 2, 2, 4, RETRO_PALETTE.darkGray);
            // Right side
            SpriteGenerator.drawRect(ctx, cx + 30, y, 10, 8, RETRO_PALETTE.hullSecondary);
            SpriteGenerator.drawRect(ctx, cx + 40, y + 2, 2, 4, RETRO_PALETTE.darkGray);
        }

        // Market signage (bright sections)
        SpriteGenerator.drawRect(ctx, cx - 25, cy - 15, 50, 8, RETRO_PALETTE.vintageAmber);
        SpriteGenerator.drawRect(ctx, cx - 25, cy + 7, 50, 8, RETRO_PALETTE.vintageCream);

        // Cargo loading arms
        ctx.strokeStyle = RETRO_PALETTE.hullSecondary;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(cx - 30, cy - 25);
        ctx.lineTo(cx - 35, cy - 30);
        ctx.lineTo(cx - 38, cy - 28);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(cx + 30, cy + 25);
        ctx.lineTo(cx + 35, cy + 30);
        ctx.lineTo(cx + 38, cy + 28);
        ctx.stroke();

        // Communication tower
        SpriteGenerator.drawRect(ctx, cx - 3, cy - 30, 6, 10, RETRO_PALETTE.hullSecondary);
        ctx.fillStyle = RETRO_PALETTE.hullAccent;
        ctx.beginPath();
        ctx.arc(cx, cy - 32, 4, 0, Math.PI * 2);
        ctx.fill();

        // Extensive windows (busy marketplace)
        for (let i = 0; i < 10; i++) {
            for (let j = 0; j < 4; j++) {
                SpriteGenerator.drawPixel(ctx, cx - 24 + (i * 5), cy - 12 + (j * 6), RETRO_PALETTE.paleGray);
            }
        }

        // Panel lines
        SpriteGenerator.addPanelLines(ctx, cx - 30, cy - 20, 60, 40, 10, RETRO_PALETTE.hullShadow);

        // Greebles
        SpriteGenerator.addGreeble(ctx, cx - 20, cy - 8, 'hatch', 3);
        SpriteGenerator.addGreeble(ctx, cx + 15, cy + 5, 'vent', 4);
        SpriteGenerator.addGreeble(ctx, cx, cy + 15, 'sensor', 3);

        // Bright navigation lights (busy hub)
        SpriteGenerator.drawPixel(ctx, cx - 40, cy - 20, RETRO_PALETTE.statusBlue);
        SpriteGenerator.drawPixel(ctx, cx + 40, cy - 20, RETRO_PALETTE.statusBlue);
        SpriteGenerator.drawPixel(ctx, cx - 40, cy + 20, RETRO_PALETTE.alertRed);
        SpriteGenerator.drawPixel(ctx, cx + 40, cy + 20, RETRO_PALETTE.alertRed);

        // Moderate wear (high traffic)
        SpriteGenerator.addWear(ctx, cx - 40, cy - 30, 80, 60, 0.08);

        return sprite;
    }

    /**
     * Generate all environmental sprites
     */
    static generateAll(spriteManager) {
        console.log('Generating environmental sprites...');

        this.generateAsteroidVariants(spriteManager);
        this.generateStarVariants(spriteManager);
        this.generatePlanetVariants(spriteManager);
        this.generateDerelict(spriteManager, 'derelict_fragment_32', 32);
        this.generateMiningStation(spriteManager);
        this.generateResearchStation(spriteManager);
        this.generateTradeHub(spriteManager);

        console.log('Environmental sprites generated: 20+ types');
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = EnvironmentSpriteGenerator;
}

