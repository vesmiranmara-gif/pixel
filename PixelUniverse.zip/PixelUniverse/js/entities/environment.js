/**
 * PixelVerse - Environmental Entities
 * Handles asteroids, planets, stations, and other space objects
 */

class EnvironmentFactory {
    constructor(entityManager, spriteManager) {
        this.entityManager = entityManager;
        this.spriteManager = spriteManager;
    }

    /**
     * Create an asteroid
     */
    createAsteroid(x, y, size = 32, composition = 'iron') {
        const asteroid = this.entityManager.createEntity();
        const spriteName = `asteroid_${composition}_${size}`;
        const sprite = this.spriteManager.getSprite(spriteName);

        if (!sprite) {
            console.warn(`Asteroid sprite not found: ${spriteName}`);
            return null;
        }

        asteroid
            .addComponent('transform', new TransformComponent(x, y, Math.random() * Math.PI * 2, 1))
            .addComponent('velocity', new VelocityComponent(
                (Math.random() - 0.5) * 20,
                (Math.random() - 0.5) * 20,
                (Math.random() - 0.5) * 0.5
            ))
            .addComponent('sprite', new SpriteComponent(sprite, size, size))
            .addComponent('collision', new CollisionComponent(size / 2, 'circle'));

        return asteroid;
    }

    /**
     * Create a planet
     */
    createPlanet(x, y, size = 64, type = 'terran') {
        const planet = this.entityManager.createEntity();
        const spriteName = `planet_${type}_${size}`;
        const sprite = this.spriteManager.getSprite(spriteName);

        if (!sprite) {
            console.warn(`Planet sprite not found: ${spriteName}`);
            return null;
        }

        planet
            .addComponent('transform', new TransformComponent(x, y, 0, 1))
            .addComponent('sprite', new SpriteComponent(sprite, size, size))
            .addComponent('collision', new CollisionComponent(size / 2, 'circle'));

        return planet;
    }

    /**
     * Create a star
     */
    createStar(x, y, size = 16, type = 'G') {
        const star = this.entityManager.createEntity();
        const spriteName = `star_${type.toLowerCase()}_${size}`;
        const sprite = this.spriteManager.getSprite(spriteName);

        if (!sprite) {
            console.warn(`Star sprite not found: ${spriteName}`);
            return null;
        }

        star
            .addComponent('transform', new TransformComponent(x, y, 0, 1))
            .addComponent('sprite', new SpriteComponent(sprite, size, size));

        return star;
    }

    /**
     * Create an enhanced detailed planet
     */
    createEnhancedPlanet(x, y, size = 1000, type = 'terran') {
        const planet = this.entityManager.createEntity();
        const spriteName = `enhanced_planet_${type}_${size}`;
        const sprite = this.spriteManager.getSprite(spriteName);

        if (!sprite) {
            console.warn(`Enhanced planet sprite not found: ${spriteName}`);
            return null;
        }

        planet
            .addComponent('transform', new TransformComponent(x, y, 0, 1))
            .addComponent('sprite', new SpriteComponent(sprite, size, size))
            .addComponent('collision', new CollisionComponent(size / 2, 'circle'));

        return planet;
    }

    /**
     * Create an enhanced detailed star
     */
    createEnhancedStar(x, y, size = 1000, type = 'G') {
        const star = this.entityManager.createEntity();
        const spriteName = `enhanced_star_${type.toLowerCase()}_${size}`;
        const sprite = this.spriteManager.getSprite(spriteName);

        if (!sprite) {
            console.warn(`Enhanced star sprite not found: ${spriteName}`);
            return null;
        }

        star
            .addComponent('transform', new TransformComponent(x, y, 0, 1))
            .addComponent('sprite', new SpriteComponent(sprite, size, size));

        return star;
    }

    /**
     * Create an enhanced detailed moon
     */
    createEnhancedMoon(x, y, size = 400, type = 'rocky') {
        const moon = this.entityManager.createEntity();
        const spriteName = `enhanced_moon_${type}_${size}`;
        const sprite = this.spriteManager.getSprite(spriteName);

        if (!sprite) {
            console.warn(`Enhanced moon sprite not found: ${spriteName}`);
            return null;
        }

        moon
            .addComponent('transform', new TransformComponent(x, y, 0, 1))
            .addComponent('sprite', new SpriteComponent(sprite, size, size))
            .addComponent('collision', new CollisionComponent(size / 2, 'circle'));

        return moon;
    }

    /**
     * Create a derelict ship fragment
     */
    createDerelict(x, y, size = 32) {
        const derelict = this.entityManager.createEntity();
        const spriteName = `derelict_fragment_${size}`;
        const sprite = this.spriteManager.getSprite(spriteName);

        if (!sprite) {
            console.warn(`Derelict sprite not found: ${spriteName}`);
            return null;
        }

        derelict
            .addComponent('transform', new TransformComponent(x, y, Math.random() * Math.PI * 2, 1))
            .addComponent('velocity', new VelocityComponent(
                (Math.random() - 0.5) * 10,
                (Math.random() - 0.5) * 10,
                (Math.random() - 0.5) * 0.3
            ))
            .addComponent('sprite', new SpriteComponent(sprite, size, size))
            .addComponent('collision', new CollisionComponent(size / 2, 'circle'));

        return derelict;
    }

    /**
     * Create a station
     */
    createStation(x, y, type = 'mining') {
        const station = this.entityManager.createEntity();

        let spriteName, size;
        switch (type.toLowerCase()) {
            case 'mining':
                spriteName = 'station_mining_96';
                size = 96;
                break;
            case 'research':
                spriteName = 'station_research_80';
                size = 80;
                break;
            case 'trade':
                spriteName = 'station_trade_112';
                size = 112;
                break;
            default:
                spriteName = 'station_mining_96';
                size = 96;
        }

        const sprite = this.spriteManager.getSprite(spriteName);

        if (!sprite) {
            console.warn(`Station sprite not found: ${spriteName}`);
            return null;
        }

        station
            .addComponent('transform', new TransformComponent(x, y, 0, 1))
            .addComponent('sprite', new SpriteComponent(sprite, size, size))
            .addComponent('collision', new CollisionComponent(size / 2, 'circle'));

        return station;
    }

    /**
     * Create an asteroid field
     */
    createAsteroidField(centerX, centerY, radius, count = 20) {
        const asteroids = [];

        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const distance = Math.random() * radius;
            const x = centerX + Math.cos(angle) * distance;
            const y = centerY + Math.sin(angle) * distance;

            const compositions = ['iron', 'ice', 'mineral', 'organic'];
            const composition = compositions[Math.floor(Math.random() * compositions.length)];

            const asteroid = this.createAsteroid(x, y, 32, composition);
            if (asteroid) {
                asteroids.push(asteroid);
            }
        }

        return asteroids;
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = EnvironmentFactory;
}

