/**
 * PixelVerse - Ship Entities
 * Handles ship creation and management
 */

class ShipFactory {
    constructor(entityManager, spriteManager) {
        this.entityManager = entityManager;
        this.spriteManager = spriteManager;
    }

    /**
     * Create a Frigate class ship
     */
    createFrigate(x, y, faction = 'player') {
        const ship = this.entityManager.createEntity();
        const sprite = this.spriteManager.getSprite('frigate');

        ship
            .addComponent('transform', new TransformComponent(x, y, 0, 1))
            .addComponent('velocity', new VelocityComponent(0, 0, 0))
            .addComponent('physics', new PhysicsComponent(100, 0.02))
            .addComponent('health', new HealthComponent(100, 50))
            .addComponent('sprite', new SpriteComponent(sprite, 64, 64))
            .addComponent('collision', new CollisionComponent(20, 'circle'));

        return ship;
    }

    /**
     * Create a Transport class ship
     */
    createTransport(x, y, faction = 'neutral') {
        const ship = this.entityManager.createEntity();
        const sprite = this.spriteManager.getSprite('transport');

        ship
            .addComponent('transform', new TransformComponent(x, y, 0, 1))
            .addComponent('velocity', new VelocityComponent(0, 0, 0))
            .addComponent('physics', new PhysicsComponent(500, 0.03))
            .addComponent('health', new HealthComponent(200, 0))
            .addComponent('sprite', new SpriteComponent(sprite, 96, 48))
            .addComponent('collision', new CollisionComponent(30, 'circle'));

        return ship;
    }

    /**
     * Create a Huge Ship
     */
    createHugeShip(x, y, faction = 'enemy') {
        const ship = this.entityManager.createEntity();
        const sprite = this.spriteManager.getSprite('huge_ship');

        ship
            .addComponent('transform', new TransformComponent(x, y, 0, 1))
            .addComponent('velocity', new VelocityComponent(0, 0, 0))
            .addComponent('physics', new PhysicsComponent(2000, 0.05))
            .addComponent('health', new HealthComponent(1000, 500))
            .addComponent('sprite', new SpriteComponent(sprite, 128, 96))
            .addComponent('collision', new CollisionComponent(50, 'circle'));

        return ship;
    }

    /**
     * Create an Interceptor
     */
    createInterceptor(x, y, faction = 'player') {
        const ship = this.entityManager.createEntity();
        const sprite = this.spriteManager.getSprite('interceptor');

        ship
            .addComponent('transform', new TransformComponent(x, y, 0, 1))
            .addComponent('velocity', new VelocityComponent(0, 0, 0))
            .addComponent('physics', new PhysicsComponent(50, 0.01))
            .addComponent('health', new HealthComponent(60, 30))
            .addComponent('sprite', new SpriteComponent(sprite, 48, 48))
            .addComponent('collision', new CollisionComponent(15, 'circle'));

        return ship;
    }

    /**
     * Create a Bomber
     */
    createBomber(x, y, faction = 'player') {
        const ship = this.entityManager.createEntity();
        const sprite = this.spriteManager.getSprite('bomber');

        ship
            .addComponent('transform', new TransformComponent(x, y, 0, 1))
            .addComponent('velocity', new VelocityComponent(0, 0, 0))
            .addComponent('physics', new PhysicsComponent(300, 0.04))
            .addComponent('health', new HealthComponent(250, 100))
            .addComponent('sprite', new SpriteComponent(sprite, 80, 64))
            .addComponent('collision', new CollisionComponent(25, 'circle'));

        return ship;
    }

    /**
     * Create a Mining Ship
     */
    createMiningShip(x, y, faction = 'neutral') {
        const ship = this.entityManager.createEntity();
        const sprite = this.spriteManager.getSprite('mining_ship');

        ship
            .addComponent('transform', new TransformComponent(x, y, 0, 1))
            .addComponent('velocity', new VelocityComponent(0, 0, 0))
            .addComponent('physics', new PhysicsComponent(400, 0.05))
            .addComponent('health', new HealthComponent(150, 0))
            .addComponent('sprite', new SpriteComponent(sprite, 72, 56))
            .addComponent('collision', new CollisionComponent(22, 'circle'));

        return ship;
    }

    /**
     * Create a Scout
     */
    createScout(x, y, faction = 'player') {
        const ship = this.entityManager.createEntity();
        const sprite = this.spriteManager.getSprite('scout');

        ship
            .addComponent('transform', new TransformComponent(x, y, 0, 1))
            .addComponent('velocity', new VelocityComponent(0, 0, 0))
            .addComponent('physics', new PhysicsComponent(40, 0.01))
            .addComponent('health', new HealthComponent(40, 20))
            .addComponent('sprite', new SpriteComponent(sprite, 40, 40))
            .addComponent('collision', new CollisionComponent(12, 'circle'));

        return ship;
    }

    /**
     * Create a Corvette
     */
    createCorvette(x, y, faction = 'neutral') {
        const ship = this.entityManager.createEntity();
        const sprite = this.spriteManager.getSprite('corvette');

        ship
            .addComponent('transform', new TransformComponent(x, y, 0, 1))
            .addComponent('velocity', new VelocityComponent(0, 0, 0))
            .addComponent('physics', new PhysicsComponent(120, 0.02))
            .addComponent('health', new HealthComponent(120, 60))
            .addComponent('sprite', new SpriteComponent(sprite, 56, 48))
            .addComponent('collision', new CollisionComponent(18, 'circle'));

        return ship;
    }

    /**
     * Create a ship by type
     */
    createShip(type, x, y, faction = 'neutral') {
        switch (type.toLowerCase()) {
            case 'frigate':
                return this.createFrigate(x, y, faction);
            case 'transport':
                return this.createTransport(x, y, faction);
            case 'huge':
            case 'huge_ship':
                return this.createHugeShip(x, y, faction);
            case 'interceptor':
                return this.createInterceptor(x, y, faction);
            case 'bomber':
                return this.createBomber(x, y, faction);
            case 'mining':
            case 'mining_ship':
                return this.createMiningShip(x, y, faction);
            case 'scout':
                return this.createScout(x, y, faction);
            case 'corvette':
                return this.createCorvette(x, y, faction);
            default:
                console.warn(`Unknown ship type: ${type}`);
                return this.createFrigate(x, y, faction);
        }
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ShipFactory;
}

