/**
 * PixelVerse - Game Balance Configuration
 * Centralized balance values for easy tuning
 */

const GameBalance = {
    // Player ship
    player: {
        maxHealth: 100,
        maxShield: 100,
        shieldRegen: 1.0,
        mass: 100,
        drag: 0.02,
        thrustPower: 300,
        turnSpeed: 2.0,
        startingCredits: 1000
    },
    
    // Enemy ships
    enemy: {
        maxHealth: 50,
        maxShield: 0,
        mass: 80,
        drag: 0.02,
        thrustPower: 200,
        turnSpeed: 3.0,
        detectionRange: 800,
        attackRange: 400,
        fleeThreshold: 0.3
    },
    
    // Weapons
    weapons: {
        laser: {
            damage: 10,
            speed: 800,
            lifetime: 2.0,
            fireRate: 0.3,
            heat: 8,
            energyCost: 5
        },
        plasma: {
            damage: 25,
            speed: 600,
            lifetime: 2.5,
            fireRate: 0.8,
            heat: 15,
            energyCost: 10
        },
        railgun: {
            damage: 50,
            speed: 1200,
            lifetime: 1.5,
            fireRate: 1.5,
            heat: 25,
            energyCost: 20
        },
        missile: {
            damage: 75,
            speed: 400,
            lifetime: 5.0,
            fireRate: 2.0,
            heat: 20,
            energyCost: 30,
            homingStrength: 0.5
        }
    },
    
    // Ship systems
    systems: {
        power: {
            total: 100,
            regenRate: 5.0,
            shieldDraw: 2.0
        },
        shields: {
            regenRate: 1.0,
            efficiency: 1.0
        },
        weapons: {
            coolingRate: 10.0,
            overheatThreshold: 100,
            overheatRecovery: 50
        },
        engines: {
            efficiency: 1.0,
            damagedEfficiency: 0.5
        },
        repair: {
            autoRepair: true,
            repairRate: 5.0
        },
        hull: {
            criticalThreshold: 25
        }
    },
    
    // Economy
    economy: {
        startingCredits: 1000,
        startingCargo: {
            fuel_cell: 50,
            iron_ore: 10
        },
        cargoCapacity: 100,
        tradingMargin: 0.2 // 20% price variation
    },
    
    // Missions
    missions: {
        availableCount: 5,
        rewardMultiplier: 1.0,
        difficultyScaling: 1.0
    },
    
    // Factions
    factions: {
        reputationMin: -100,
        reputationMax: 100,
        hostileThreshold: -40,
        friendlyThreshold: 40,
        reputationDecay: 0.1 // Per day
    },
    
    // Difficulty presets
    difficulty: {
        easy: {
            playerHealthMultiplier: 1.5,
            enemyHealthMultiplier: 0.75,
            enemyDamageMultiplier: 0.75,
            rewardMultiplier: 1.0
        },
        normal: {
            playerHealthMultiplier: 1.0,
            enemyHealthMultiplier: 1.0,
            enemyDamageMultiplier: 1.0,
            rewardMultiplier: 1.0
        },
        hard: {
            playerHealthMultiplier: 0.75,
            enemyHealthMultiplier: 1.25,
            enemyDamageMultiplier: 1.25,
            rewardMultiplier: 1.5
        },
        extreme: {
            playerHealthMultiplier: 0.5,
            enemyHealthMultiplier: 1.5,
            enemyDamageMultiplier: 1.5,
            rewardMultiplier: 2.0
        }
    },
    
    // Current difficulty
    currentDifficulty: 'normal',
    
    /**
     * Get value with difficulty modifier
     */
    getValue(category, key, applyDifficulty = true) {
        if (!this[category] || !this[category][key]) {
            return null;
        }
        
        let value = this[category][key];
        
        if (applyDifficulty && this.difficulty[this.currentDifficulty]) {
            const diff = this.difficulty[this.currentDifficulty];
            
            // Apply difficulty modifiers
            if (category === 'player' && key === 'maxHealth' && diff.playerHealthMultiplier) {
                value *= diff.playerHealthMultiplier;
            } else if (category === 'enemy' && key === 'maxHealth' && diff.enemyHealthMultiplier) {
                value *= diff.enemyHealthMultiplier;
            }
        }
        
        return value;
    },
    
    /**
     * Set difficulty
     */
    setDifficulty(difficulty) {
        if (this.difficulty[difficulty]) {
            this.currentDifficulty = difficulty;
            console.log('Difficulty set to:', difficulty);
            return true;
        }
        return false;
    },
    
    /**
     * Get weapon stats
     */
    getWeaponStats(weaponType) {
        return this.weapons[weaponType] || null;
    },
    
    /**
     * Adjust balance value
     */
    adjustValue(category, key, value) {
        if (this[category] && this[category][key] !== undefined) {
            this[category][key] = value;
            console.log(`Balance adjusted: ${category}.${key} = ${value}`);
            return true;
        }
        return false;
    }
};

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = GameBalance;
}

